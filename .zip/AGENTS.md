# MoonBit 教学工程 — 开发约定

本文件为 workspace 级开发约定，适用于 `moonbit_learning` 下所有成员模块。

## 工程性质

本工程是 **MoonBit 快速入门教学示例**，面向零基础学习者。所有代码与文档
均以"可读、可教、可复现"为第一目标，而非生产级性能或完整性。

## Workspace 结构

- 根目录 `moon.work` 列出全部成员模块，由 `moon work init` / `moon work use` 维护
- 每个成员模块是独立的 MoonBit module（含 `moon.mod`），可独立 `moon -C <模块> ...` 操作
- 在根目录直接 `moon check` / `moon test` / `moon fmt` 会作用于全部成员

## 包组织约定

- 每个教学模块含一个根包（库包，占位或放公共教学类型）与 `cmd/main`（可执行包）
- `cmd/main` 负责演示，按主题拆分多个 `.mbt` 文件（同包内顶层定义互相可见）
- 库包（如 `examine`）演示"库 + 可执行包"协作模式

## 三级文档注释体系

| 级别 | 语法 | 要求 |
|------|------|------|
| 包级 | 每个包目录的 `README.md` | 模块概览、文件清单、运行方式 |
| 模块级 | 每个模块根的 `README.mbt.md` | 模块介绍、项目结构、常用命令、文档约定 |
| API 级 | 源码中 `///` + `///|` | 每个 `pub fn` / `pub struct` / `pub enum` / `pub trait` 必须有文档注释 |
| 行内级 | `//` | 解释"为什么"，不解释"是什么" |

公开 API 文档注释须内嵌文档测试：

```moonbit
///|
/// 功能描述。
///
/// # 参数
///
/// - `x` : 说明
///
/// # 返回值
///
/// 说明
///
/// # 示例
///
/// ```mbt check
/// test "xxx" {
///   assert_eq(@main.foo(1), 2)
/// }
/// ```
pub fn foo(x : Int) -> Int { x + 1 }
```

## 命令

```bash
moon check           # 类型检查（必须 0 errors）
moon test            # 测试（必须全部通过）
moon fmt             # 格式化
moon info            # 生成 .mbti（提交前执行）
```

## Warning 治理原则

教学工程中，warning 分两类：

1. **应修**：真正的代码问题（unused 变量但无教学意义、todo 未完成）
2. **可豁免**：演示语法而故意保留的未使用项（须用行内注释说明"演示用，故意未使用"）

目标：`moon check` 0 errors；warning 须逐一审视并记录处理结论。

## 提交规范

```
vX.Y.Z: <一句话亮点> - <关键变更摘要>
```

## 工具链版本

```
moon 0.1.20260819
moonc v0.10.9
```
