# walkzzz/mcp_server

MCP（Model Context Protocol）费用追踪服务器教学示例。

本模块演示如何用 MoonBit 实现一个符合 JSON-RPC 2.0 / MCP 协议的
命令行服务器，通过 stdin/stdout 与 MCP 客户端通信，提供费用记录的
增删改查统功能，并支持 JSON 文件持久化存储。

## 核心类型

| 类型 | 说明 |
|------|------|
| `Expense` | 费用记录（ID、金额、分类、备注、创建时间） |
| `Category` | 五种支出分类枚举 |
| `ExpenseError` | 费用相关错误（未知分类、无效金额、未找到） |

## 公开 API

| 函数 | 签名 | 说明 |
|------|------|------|
| `Category::from_string` | `(String) -> Category raise ExpenseError` | 字符串解析为分类 |
| `Category::to_string` | `(Category) -> String` | 分类转小写字符串 |
| `all_categories` | `() -> Array[Category]` | 返回全部五种分类 |
| `Expense::to_json` | `(Expense) -> Json` | 序列化为 JSON 对象 |
| `Expense::from_json` | `(Json) -> Expense? raise ExpenseError` | 从 JSON 反序列化 |
| `add` | `(Double, Category, String, created_at~:Int) -> Expense raise ExpenseError` | 添加一笔费用 |
| `delete` | `(Int) -> Bool` | 按 ID 删除 |
| `update` | `(Int, amount?:Double, category?:Category, note?:String) -> Expense? raise ExpenseError` | 按 ID 更新 |
| `get` | `(Int) -> Expense?` | 按 ID 获取 |
| `list` | `(category? : Category) -> Array[Expense]` | 查询费用（可按分类过滤） |
| `search` | `(String) -> Array[Expense]` | 按备注关键词搜索 |
| `stats` | `() -> (Double, Map[Category, Double])` | 统计总额和分类明细 |
| `count` | `() -> Int` | 返回记录总数 |
| `clear` | `() -> Unit` | 清空全部记录 |
| `load` | `(Array[Expense]) -> Unit` | 从数组加载（持久化恢复） |
| `to_json_array` | `() -> Json` | 序列化全部记录为 JSON 数组 |

## MCP 工具

服务器暴露 10 个 MCP 工具供客户端调用：

| 工具 | 参数 | 说明 |
|------|------|------|
| `add_expense` | `amount`, `category`, `note?` | 记一笔账 |
| `list_expenses` | `category?` | 列出账目（可过滤） |
| `stats` | 无 | 展示总支出和分类小计 |
| `delete_expense` | `id` | 按 ID 删除 |
| `update_expense` | `id`, `amount?`, `category?`, `note?` | 按 ID 更新 |
| `get_expense` | `id` | 按 ID 获取详情 |
| `clear_expenses` | 无 | 清空全部记录 |
| `count_expenses` | 无 | 返回记录总数 |
| `search_expenses` | `keyword` | 按备注搜索 |
| `summary_by_category` | 无 | 分类汇总（带百分比） |

## 持久化

费用记录自动保存到当前目录下的 `expenses.json` 文件。
服务器启动时自动加载，每次修改操作（add/delete/update/clear）后自动保存。

## 运行

```bash
moon -C mcp_server run cmd/main   # 启动服务器（从 stdin 读取请求）
moon -C mcp_server test           # 运行测试
moon -C mcp_server check          # 类型检查
moon -C mcp_server fmt            # 格式化
```
