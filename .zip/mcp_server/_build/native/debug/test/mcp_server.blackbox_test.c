#ifdef __cplusplus
extern "C" {
#endif

#include "moonbit.h"
#include "moonbit_runtime.h"
#include "moonbit_simd.h"

#ifdef _MSC_VER
#define _Noreturn __declspec(noreturn)
#endif

#if defined(__clang__)
#pragma clang diagnostic ignored "-Wshift-op-parentheses"
#pragma clang diagnostic ignored "-Wtautological-compare"
#endif

// TinyCC's in-memory run mode has no executable of its own; an OS lookup would
// report the host process instead.
#if defined(__TCC_RUN__)
#define moonbit_rt_get_current_exe moonbit_rt_get_current_exe_tcc
#endif

MOONBIT_EXPORT _Noreturn void moonbit_panic(void);
MOONBIT_EXPORT void *moonbit_malloc_array(enum moonbit_block_kind kind,
                                          int elem_size_shift, int32_t len);
int memcmp(const void *s1, const void *s2, size_t n);
MOONBIT_EXPORT int moonbit_val_array_equal_sized(const void *lhs,
                                                 const void *rhs,
                                                 int32_t elem_size);
MOONBIT_EXPORT moonbit_string_t moonbit_add_string(moonbit_string_t s1,
                                                   moonbit_string_t s2);
MOONBIT_EXPORT void moonbit_unsafe_bytes_blit(moonbit_bytes_t dst,
                                              int32_t dst_start,
                                              moonbit_bytes_t src,
                                              int32_t src_offset, int32_t len);
MOONBIT_EXPORT moonbit_string_t moonbit_unsafe_bytes_sub_string(
    moonbit_bytes_t bytes, int32_t start, int32_t len);
MOONBIT_EXPORT int32_t moonbit_unsafe_val_array_blit(void *dst,
                                                     int32_t dst_offset,
                                                     void *src,
                                                     int32_t src_offset,
                                                     int32_t len,
                                                     int32_t elem_size);
MOONBIT_EXPORT int32_t moonbit_unsafe_ref_array_blit(void *dst,
                                                     int32_t dst_offset,
                                                     void *src,
                                                     int32_t src_offset,
                                                     int32_t len);
MOONBIT_EXPORT void moonbit_println(moonbit_string_t str);
MOONBIT_EXPORT moonbit_bytes_t *moonbit_get_cli_args(void);
MOONBIT_EXPORT void moonbit_runtime_init(int argc, char **argv);
MOONBIT_EXPORT void moonbit_drop_object(void *);
// Slow paths of the inlined value-enum retain/release below (defined in
// runtime.c). Internal helpers, so declared here rather than in the public
// moonbit.h; reached only when a value's current variant carries references.
MOONBIT_EXPORT void moonbit_incref_value_enum_loop(void *p);
MOONBIT_EXPORT void moonbit_decref_value_enum_loop(void *p);
MOONBIT_EXPORT int32_t moonbit_utf16_len_from_utf8(moonbit_bytes_t src,
                                                   int32_t src_offset,
                                                   int32_t src_length);
MOONBIT_EXPORT int32_t moonbit_utf8_decode_into_utf16(
    moonbit_bytes_t src, int32_t src_offset, int32_t src_length,
    moonbit_string_t dst, int32_t dst_offset);
MOONBIT_EXPORT int32_t moonbit_utf8_decode_lossy_into_utf16(
    moonbit_bytes_t src, int32_t src_offset, int32_t src_length,
    moonbit_string_t dst, int32_t dst_offset);
MOONBIT_EXPORT int32_t moonbit_utf8_len_from_utf16(moonbit_string_t src,
                                                   int32_t src_offset,
                                                   int32_t src_length);
MOONBIT_EXPORT int32_t moonbit_utf8_encode_from_utf16(
    moonbit_string_t src, int32_t src_offset, int32_t src_length,
    moonbit_bytes_t dst, int32_t dst_offset);

#if !defined(_WIN64) && !defined(_WIN32)
void *malloc(size_t size);
void free(void *ptr);
#define libc_malloc malloc
#define libc_free free
#endif

// several important runtime functions are inlined
static void *moonbit_malloc_inlined(size_t size) {
  struct moonbit_object *ptr = (struct moonbit_object *)libc_malloc(
      sizeof(struct moonbit_object) + size);
  Moonbit_init_dynamic_rc(ptr, moonbit_BLOCK_KIND_REGULAR);
  return ptr + 1;
}

#define moonbit_malloc(obj) moonbit_malloc_inlined(obj)
#define moonbit_free(obj) libc_free(Moonbit_object_header(obj))

#define MOONBIT_RC_COUNT_UNIT ((int32_t)(1u << MOONBIT_RC_COUNT_SHIFT))
#define raw_rc_is_dynamic(rc) ((int32_t)(rc) >= MOONBIT_RC_COUNT_UNIT)
#define raw_rc_is_shared(rc) ((int32_t)(rc) >= (MOONBIT_RC_COUNT_UNIT * 2))

static inline int32_t moonbit_unsafe_obj_cycle_capable(void *ptr) {
  return MOONBIT_IN_ROOT(ptr) ||
         !MOONBIT_CHECK_CYCLE_STATUS(
             ptr, moonbit_CYCLE_STATUS_ACYCLIC_OR_CANDIDATE);
}

extern const uint32_t *moonbit_layout_table;

static void moonbit_incref_inlined(void *ptr) {
  struct moonbit_object *header = Moonbit_object_header(ptr);
  int32_t const rc = header->rc;
  if (raw_rc_is_dynamic(rc)) {
    Moonbit_increase_rc_count(header);
  }
}

#define moonbit_incref moonbit_incref_inlined

static void moonbit_decref_inlined(void *ptr) {
  struct moonbit_object *header = Moonbit_object_header(ptr);
  int32_t const rc = header->rc;
  if (raw_rc_is_shared(rc)) {
    header->rc = rc - MOONBIT_RC_COUNT_UNIT;
  } else if (raw_rc_is_dynamic(rc)) {
    moonbit_drop_object(ptr);
  }
}

#define moonbit_decref moonbit_decref_inlined

// Value-enum retain/release: inline the cheap "does the current variant carry
// references?" test (a header read + class compare) so scalar-tag moves pay no
// call, and delegate the reference-walking loop to the out-of-line slow path in
// runtime.c. Mirrors the moonbit_incref/decref fast/slow split above.
static inline void moonbit_incref_value_enum_inlined(void *p) {
  if (Moonbit_header_layout_class(*(uint32_t *)p) ==
      MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED)
    moonbit_incref_value_enum_loop(p);
}

#define moonbit_incref_value_enum moonbit_incref_value_enum_inlined

static inline void moonbit_decref_value_enum_inlined(void *p) {
  if (Moonbit_header_layout_class(*(uint32_t *)p) ==
      MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED)
    moonbit_decref_value_enum_loop(p);
}

#define moonbit_decref_value_enum moonbit_decref_value_enum_inlined

#define moonbit_unsafe_make_string moonbit_make_string

#if defined(MOONBIT_V128_NEON)
#define Moonbit_v128_make(lo, hi)                                             \
  vreinterpretq_u8_u64(                                                       \
      vcombine_u64(vcreate_u64((uint64_t)(lo)), vcreate_u64((uint64_t)(hi))))
#define Moonbit_v128_lo(v) vgetq_lane_u64(vreinterpretq_u64_u8(v), 0)
#define Moonbit_v128_hi(v) vgetq_lane_u64(vreinterpretq_u64_u8(v), 1)
#define Moonbit_v128_load_storage(p) vld1q_u8((const uint8_t *)(p))
#define Moonbit_v128_store_storage(p, v) vst1q_u8((uint8_t *)(p), (v))
#elif defined(MOONBIT_V128_SSE2)
#define Moonbit_v128_make(lo, hi) _mm_set_epi64x((int64_t)(hi), (int64_t)(lo))
#define Moonbit_v128_lo(v) ((uint64_t)_mm_cvtsi128_si64(v))
#define Moonbit_v128_hi(v) ((uint64_t)_mm_cvtsi128_si64(_mm_srli_si128((v), 8)))
#define Moonbit_v128_load_storage(p) _mm_loadu_si128((const __m128i *)(p))
#define Moonbit_v128_store_storage(p, v) _mm_storeu_si128((__m128i *)(p), (v))
#else
#define Moonbit_v128_make(lo, hi) ((moonbit_v128_t){(lo), (hi)})
#define Moonbit_v128_lo(v) ((v).lo)
#define Moonbit_v128_hi(v) ((v).hi)
#define Moonbit_v128_load_storage(p) (*(p))
#define Moonbit_v128_store_storage(p, v) (*(p) = (v))
#endif

// detect whether compiler builtins exist for advanced bitwise operations
#ifdef __has_builtin

#if __has_builtin(__builtin_clz)
#define HAS_BUILTIN_CLZ
#endif

#if __has_builtin(__builtin_ctz)
#define HAS_BUILTIN_CTZ
#endif

#if __has_builtin(__builtin_popcount)
#define HAS_BUILTIN_POPCNT
#endif

#if __has_builtin(__builtin_sqrt)
#define HAS_BUILTIN_SQRT
#endif

#if __has_builtin(__builtin_sqrtf)
#define HAS_BUILTIN_SQRTF
#endif

#if __has_builtin(__builtin_fabs)
#define HAS_BUILTIN_FABS
#endif

#if __has_builtin(__builtin_fabsf)
#define HAS_BUILTIN_FABSF
#endif

#endif

// if there is no builtin operators, use software implementation
#ifdef HAS_BUILTIN_CLZ
static inline int32_t moonbit_clz32(int32_t x) {
  return x == 0 ? 32 : __builtin_clz(x);
}

static inline int32_t moonbit_clz64(int64_t x) {
  return x == 0 ? 64 : __builtin_clzll(x);
}

#undef HAS_BUILTIN_CLZ
#else
// table for [clz] value of 4bit integer.
static const uint8_t moonbit_clz4[] = {4, 3, 2, 2, 1, 1, 1, 1,
                                       0, 0, 0, 0, 0, 0, 0, 0};

int32_t moonbit_clz32(uint32_t x) {
  /* The ideas is to:

     1. narrow down the 4bit block where the most signficant "1" bit lies,
        using binary search
     2. find the number of leading zeros in that 4bit block via table lookup

     Different time/space tradeoff can be made here by enlarging the table
     and do less binary search.
     One benefit of the 4bit lookup table is that it can fit into a single cache
     line.
  */
  int32_t result = 0;
  if (x > 0xffff) {
    x >>= 16;
  } else {
    result += 16;
  }
  if (x > 0xff) {
    x >>= 8;
  } else {
    result += 8;
  }
  if (x > 0xf) {
    x >>= 4;
  } else {
    result += 4;
  }
  return result + moonbit_clz4[x];
}

int32_t moonbit_clz64(uint64_t x) {
  int32_t result = 0;
  if (x > 0xffffffff) {
    x >>= 32;
  } else {
    result += 32;
  }
  return result + moonbit_clz32((uint32_t)x);
}
#endif

#ifdef HAS_BUILTIN_CTZ
static inline int32_t moonbit_ctz32(int32_t x) {
  return x == 0 ? 32 : __builtin_ctz(x);
}

static inline int32_t moonbit_ctz64(int64_t x) {
  return x == 0 ? 64 : __builtin_ctzll(x);
}

#undef HAS_BUILTIN_CTZ
#else
int32_t moonbit_ctz32(int32_t x) {
  /* The algorithm comes from:

       Leiserson, Charles E. et al. “Using de Bruijn Sequences to Index a 1 in a
     Computer Word.” (1998).

     The ideas is:

     1. leave only the least significant "1" bit in the input,
        set all other bits to "0". This is achieved via [x & -x]
     2. now we have [x * n == n << ctz(x)], if [n] is a de bruijn sequence
        (every 5bit pattern occurn exactly once when you cycle through the bit
     string), we can find [ctz(x)] from the most significant 5 bits of [x * n]
 */
  static const uint32_t de_bruijn_32 = 0x077CB531;
  static const uint8_t index32[] = {0,  1,  28, 2,  29, 14, 24, 3,  30, 22, 20,
                                    15, 25, 17, 4,  8,  31, 27, 13, 23, 21, 19,
                                    16, 7,  26, 12, 18, 6,  11, 5,  10, 9};
  return (x == 0) * 32 + index32[(de_bruijn_32 * (x & -x)) >> 27];
}

int32_t moonbit_ctz64(int64_t x) {
  static const uint64_t de_bruijn_64 = 0x0218A392CD3D5DBF;
  static const uint8_t index64[] = {
      0,  1,  2,  7,  3,  13, 8,  19, 4,  25, 14, 28, 9,  34, 20, 40,
      5,  17, 26, 38, 15, 46, 29, 48, 10, 31, 35, 54, 21, 50, 41, 57,
      63, 6,  12, 18, 24, 27, 33, 39, 16, 37, 45, 47, 30, 53, 49, 56,
      62, 11, 23, 32, 36, 44, 52, 55, 61, 22, 43, 51, 60, 42, 59, 58};
  return (x == 0) * 64 + index64[(de_bruijn_64 * (x & -x)) >> 58];
}
#endif

#ifdef HAS_BUILTIN_POPCNT

#define moonbit_popcnt32 __builtin_popcount
#define moonbit_popcnt64 __builtin_popcountll
#undef HAS_BUILTIN_POPCNT

#else
int32_t moonbit_popcnt32(uint32_t x) {
  /* The classic SIMD Within A Register algorithm.
     ref: [https://nimrod.blog/posts/algorithms-behind-popcount/]
 */
  x = x - ((x >> 1) & 0x55555555);
  x = (x & 0x33333333) + ((x >> 2) & 0x33333333);
  x = (x + (x >> 4)) & 0x0F0F0F0F;
  return (x * 0x01010101) >> 24;
}

int32_t moonbit_popcnt64(uint64_t x) {
  x = x - ((x >> 1) & 0x5555555555555555);
  x = (x & 0x3333333333333333) + ((x >> 2) & 0x3333333333333333);
  x = (x + (x >> 4)) & 0x0F0F0F0F0F0F0F0F;
  return (x * 0x0101010101010101) >> 56;
}
#endif

/* Full 64x64->128 multiplication. Write directly into the destination value
   struct so the generated code does not depend on a matching runtime struct
   layout. Compilers without native 128-bit integers (e.g. tcc, MSVC) use the
   32x32 schoolbook decomposition. */
static inline void moonbit_umul_wide(uint64_t *out_lo, uint64_t *out_hi,
                                     uint64_t a, uint64_t b) {
#if defined(__SIZEOF_INT128__)
  unsigned __int128 r = (unsigned __int128)a * (unsigned __int128)b;
  *out_lo = (uint64_t)r;
  *out_hi = (uint64_t)(r >> 64);
#else
  uint64_t alo = a & 0xffffffff, ahi = a >> 32;
  uint64_t blo = b & 0xffffffff, bhi = b >> 32;
  uint64_t ll = alo * blo;
  uint64_t lh = alo * bhi;
  uint64_t hl = ahi * blo;
  uint64_t hh = ahi * bhi;
  uint64_t mid = (ll >> 32) + (lh & 0xffffffff) + (hl & 0xffffffff);
  *out_lo = a * b;
  *out_hi = hh + (lh >> 32) + (hl >> 32) + (mid >> 32);
#endif
}

static inline void moonbit_smul_wide(uint64_t *out_lo, int64_t *out_hi,
                                     int64_t a, int64_t b) {
#if defined(__SIZEOF_INT128__)
  __int128 r = (__int128)a * (__int128)b;
  *out_lo = (uint64_t)r;
  *out_hi = (int64_t)(r >> 64);
#else
  uint64_t hi;
  moonbit_umul_wide(out_lo, &hi, (uint64_t)a, (uint64_t)b);
  uint64_t correction_a = a < 0 ? (uint64_t)b : 0;
  uint64_t correction_b = b < 0 ? (uint64_t)a : 0;
  *out_hi = (int64_t)(hi - correction_a - correction_b);
#endif
}

/* The following sqrt implementation comes from
   [musl](https://git.musl-libc.org/cgit/musl),
   with some helpers inlined to make it zero dependency.
 */
#ifdef MOONBIT_NATIVE_NO_SYS_HEADER
const uint16_t __rsqrt_tab[128] = {
    0xb451, 0xb2f0, 0xb196, 0xb044, 0xaef9, 0xadb6, 0xac79, 0xab43, 0xaa14,
    0xa8eb, 0xa7c8, 0xa6aa, 0xa592, 0xa480, 0xa373, 0xa26b, 0xa168, 0xa06a,
    0x9f70, 0x9e7b, 0x9d8a, 0x9c9d, 0x9bb5, 0x9ad1, 0x99f0, 0x9913, 0x983a,
    0x9765, 0x9693, 0x95c4, 0x94f8, 0x9430, 0x936b, 0x92a9, 0x91ea, 0x912e,
    0x9075, 0x8fbe, 0x8f0a, 0x8e59, 0x8daa, 0x8cfe, 0x8c54, 0x8bac, 0x8b07,
    0x8a64, 0x89c4, 0x8925, 0x8889, 0x87ee, 0x8756, 0x86c0, 0x862b, 0x8599,
    0x8508, 0x8479, 0x83ec, 0x8361, 0x82d8, 0x8250, 0x81c9, 0x8145, 0x80c2,
    0x8040, 0xff02, 0xfd0e, 0xfb25, 0xf947, 0xf773, 0xf5aa, 0xf3ea, 0xf234,
    0xf087, 0xeee3, 0xed47, 0xebb3, 0xea27, 0xe8a3, 0xe727, 0xe5b2, 0xe443,
    0xe2dc, 0xe17a, 0xe020, 0xdecb, 0xdd7d, 0xdc34, 0xdaf1, 0xd9b3, 0xd87b,
    0xd748, 0xd61a, 0xd4f1, 0xd3cd, 0xd2ad, 0xd192, 0xd07b, 0xcf69, 0xce5b,
    0xcd51, 0xcc4a, 0xcb48, 0xca4a, 0xc94f, 0xc858, 0xc764, 0xc674, 0xc587,
    0xc49d, 0xc3b7, 0xc2d4, 0xc1f4, 0xc116, 0xc03c, 0xbf65, 0xbe90, 0xbdbe,
    0xbcef, 0xbc23, 0xbb59, 0xba91, 0xb9cc, 0xb90a, 0xb84a, 0xb78c, 0xb6d0,
    0xb617, 0xb560,
};

/* returns a*b*2^-32 - e, with error 0 <= e < 1.  */
static inline uint32_t mul32(uint32_t a, uint32_t b) {
  return (uint64_t)a * b >> 32;
}
#endif

#ifdef MOONBIT_NATIVE_NO_SYS_HEADER
float sqrtf(float x) {
  uint32_t ix, m, m1, m0, even, ey;

  ix = *(uint32_t *)&x;
  if (ix - 0x00800000 >= 0x7f800000 - 0x00800000) {
    /* x < 0x1p-126 or inf or nan.  */
    if (ix * 2 == 0)
      return x;
    if (ix == 0x7f800000)
      return x;
    if (ix > 0x7f800000)
      return (x - x) / (x - x);
    /* x is subnormal, normalize it.  */
    x *= 0x1p23f;
    ix = *(uint32_t *)&x;
    ix -= 23 << 23;
  }

  /* x = 4^e m; with int e and m in [1, 4).  */
  even = ix & 0x00800000;
  m1 = (ix << 8) | 0x80000000;
  m0 = (ix << 7) & 0x7fffffff;
  m = even ? m0 : m1;

  /* 2^e is the exponent part of the return value.  */
  ey = ix >> 1;
  ey += 0x3f800000 >> 1;
  ey &= 0x7f800000;

  /* compute r ~ 1/sqrt(m), s ~ sqrt(m) with 2 goldschmidt iterations.  */
  static const uint32_t three = 0xc0000000;
  uint32_t r, s, d, u, i;
  i = (ix >> 17) % 128;
  r = (uint32_t)__rsqrt_tab[i] << 16;
  /* |r*sqrt(m) - 1| < 0x1p-8 */
  s = mul32(m, r);
  /* |s/sqrt(m) - 1| < 0x1p-8 */
  d = mul32(s, r);
  u = three - d;
  r = mul32(r, u) << 1;
  /* |r*sqrt(m) - 1| < 0x1.7bp-16 */
  s = mul32(s, u) << 1;
  /* |s/sqrt(m) - 1| < 0x1.7bp-16 */
  d = mul32(s, r);
  u = three - d;
  s = mul32(s, u);
  /* -0x1.03p-28 < s/sqrt(m) - 1 < 0x1.fp-31 */
  s = (s - 1) >> 6;
  /* s < sqrt(m) < s + 0x1.08p-23 */

  /* compute nearest rounded result.  */
  uint32_t d0, d1, d2;
  float y, t;
  d0 = (m << 16) - s * s;
  d1 = s - d0;
  d2 = d1 + s + 1;
  s += d1 >> 31;
  s &= 0x007fffff;
  s |= ey;
  y = *(float *)&s;
  /* handle rounding and inexact exception. */
  uint32_t tiny = d2 == 0 ? 0 : 0x01000000;
  tiny |= (d1 ^ d2) & 0x80000000;
  t = *(float *)&tiny;
  y = y + t;
  return y;
}
#endif

#ifdef MOONBIT_NATIVE_NO_SYS_HEADER
/* returns a*b*2^-64 - e, with error 0 <= e < 3.  */
static inline uint64_t mul64(uint64_t a, uint64_t b) {
  uint64_t ahi = a >> 32;
  uint64_t alo = a & 0xffffffff;
  uint64_t bhi = b >> 32;
  uint64_t blo = b & 0xffffffff;
  return ahi * bhi + (ahi * blo >> 32) + (alo * bhi >> 32);
}

double sqrt(double x) {
  uint64_t ix, top, m;

  /* special case handling.  */
  ix = *(uint64_t *)&x;
  top = ix >> 52;
  if (top - 0x001 >= 0x7ff - 0x001) {
    /* x < 0x1p-1022 or inf or nan.  */
    if (ix * 2 == 0)
      return x;
    if (ix == 0x7ff0000000000000)
      return x;
    if (ix > 0x7ff0000000000000)
      return (x - x) / (x - x);
    /* x is subnormal, normalize it.  */
    x *= 0x1p52;
    ix = *(uint64_t *)&x;
    top = ix >> 52;
    top -= 52;
  }

  /* argument reduction:
     x = 4^e m; with integer e, and m in [1, 4)
     m: fixed point representation [2.62]
     2^e is the exponent part of the result.  */
  int even = top & 1;
  m = (ix << 11) | 0x8000000000000000;
  if (even)
    m >>= 1;
  top = (top + 0x3ff) >> 1;

  /* approximate r ~ 1/sqrt(m) and s ~ sqrt(m) when m in [1,4)

     initial estimate:
     7bit table lookup (1bit exponent and 6bit significand).

     iterative approximation:
     using 2 goldschmidt iterations with 32bit int arithmetics
     and a final iteration with 64bit int arithmetics.

     details:

     the relative error (e = r0 sqrt(m)-1) of a linear estimate
     (r0 = a m + b) is |e| < 0.085955 ~ 0x1.6p-4 at best,
     a table lookup is faster and needs one less iteration
     6 bit lookup table (128b) gives |e| < 0x1.f9p-8
     7 bit lookup table (256b) gives |e| < 0x1.fdp-9
     for single and double prec 6bit is enough but for quad
     prec 7bit is needed (or modified iterations). to avoid
     one more iteration >=13bit table would be needed (16k).

     a newton-raphson iteration for r is
       w = r*r
       u = 3 - m*w
       r = r*u/2
     can use a goldschmidt iteration for s at the end or
       s = m*r

     first goldschmidt iteration is
       s = m*r
       u = 3 - s*r
       r = r*u/2
       s = s*u/2
     next goldschmidt iteration is
       u = 3 - s*r
       r = r*u/2
       s = s*u/2
     and at the end r is not computed only s.

     they use the same amount of operations and converge at the
     same quadratic rate, i.e. if
       r1 sqrt(m) - 1 = e, then
       r2 sqrt(m) - 1 = -3/2 e^2 - 1/2 e^3
     the advantage of goldschmidt is that the mul for s and r
     are independent (computed in parallel), however it is not
     "self synchronizing": it only uses the input m in the
     first iteration so rounding errors accumulate. at the end
     or when switching to larger precision arithmetics rounding
     errors dominate so the first iteration should be used.

     the fixed point representations are
       m: 2.30 r: 0.32, s: 2.30, d: 2.30, u: 2.30, three: 2.30
     and after switching to 64 bit
       m: 2.62 r: 0.64, s: 2.62, d: 2.62, u: 2.62, three: 2.62  */

  static const uint64_t three = 0xc0000000;
  uint64_t r, s, d, u, i;

  i = (ix >> 46) % 128;
  r = (uint32_t)__rsqrt_tab[i] << 16;
  /* |r sqrt(m) - 1| < 0x1.fdp-9 */
  s = mul32(m >> 32, r);
  /* |s/sqrt(m) - 1| < 0x1.fdp-9 */
  d = mul32(s, r);
  u = three - d;
  r = mul32(r, u) << 1;
  /* |r sqrt(m) - 1| < 0x1.7bp-16 */
  s = mul32(s, u) << 1;
  /* |s/sqrt(m) - 1| < 0x1.7bp-16 */
  d = mul32(s, r);
  u = three - d;
  r = mul32(r, u) << 1;
  /* |r sqrt(m) - 1| < 0x1.3704p-29 (measured worst-case) */
  r = r << 32;
  s = mul64(m, r);
  d = mul64(s, r);
  u = (three << 32) - d;
  s = mul64(s, u); /* repr: 3.61 */
  /* -0x1p-57 < s - sqrt(m) < 0x1.8001p-61 */
  s = (s - 2) >> 9; /* repr: 12.52 */
  /* -0x1.09p-52 < s - sqrt(m) < -0x1.fffcp-63 */

  /* s < sqrt(m) < s + 0x1.09p-52,
     compute nearest rounded result:
     the nearest result to 52 bits is either s or s+0x1p-52,
     we can decide by comparing (2^52 s + 0.5)^2 to 2^104 m.  */
  uint64_t d0, d1, d2;
  double y, t;
  d0 = (m << 42) - s * s;
  d1 = s - d0;
  d2 = d1 + s + 1;
  s += d1 >> 63;
  s &= 0x000fffffffffffff;
  s |= top << 52;
  y = *(double *)&s;
  return y;
}
#endif

#ifdef MOONBIT_NATIVE_NO_SYS_HEADER
double fabs(double x) {
  union {
    double f;
    uint64_t i;
  } u = {x};
  u.i &= 0x7fffffffffffffffULL;
  return u.f;
}
#endif

#ifdef MOONBIT_NATIVE_NO_SYS_HEADER
float fabsf(float x) {
  union {
    float f;
    uint32_t i;
  } u = {x};
  u.i &= 0x7fffffff;
  return u.f;
}
#endif

#ifdef _MSC_VER
/* MSVC treats syntactic division by zero as fatal error,
   even for float point numbers,
   so we have to use a constant variable to work around this */
static const int MOONBIT_ZERO = 0;
#else
#define MOONBIT_ZERO 0
#endif

#ifdef __cplusplus
}
#endif
#ifndef Moonbit_simd_v128_load_u16
#define Moonbit_simd_v128_load_u16 _M0FPB17v128__load__i16x8
#endif

#ifndef Moonbit_simd_i16x8_eq
#define Moonbit_simd_i16x8_eq _M0FPB9i16x8__eq
#endif

#ifndef Moonbit_simd_v128_any_true
#define Moonbit_simd_v128_any_true _M0FPB15v128__any__true
#endif

#ifndef Moonbit_simd_i16x8_splat
#define Moonbit_simd_i16x8_splat _M0FPB12i16x8__splat
#endif

struct _M0R111_24walkzzz_2fmcp__server__blackbox__test_2emoonbit__test__driver__internal__do__execute_2ehandle__result_7c1899;

struct _M0DTPC16result6ResultGRPB5ArrayGRPC15debug13ContentParensERPB7NoErrorE3Err;

struct _M0TPB5ArrayGRPC16string10StringViewE;

struct _M0TPB5ArrayGRPB5ArrayGsEE;

struct _M0DTPC15error5Error48moonbitlang_2fcore_2fbuiltin_2eFailure_2eFailure;

struct _M0TWRPC15error5ErrorEs;

struct _M0R110_24walkzzz_2fmcp__server__blackbox__test_2emoonbit__test__driver__internal__do__execute_2ehandle__start_7c1894;

struct _M0TWssbEu;

struct _M0TUsiE;

struct _M0DTPC15debug9ReprDelta6Extra2;

struct _M0TPB17FloatingDecimal64;

struct _M0R93_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3aprune__info_2einner_2ego_7c260_2eanon__u3653__l62__;

struct _M0DTPC16result6ResultGbRPB7NoErrorE2Ok;

struct _M0TWEuQRPC15error5Error;

struct _M0DTPC16result6ResultGRPB5ArrayGRPC15debug9ReprDeltaERPB7NoErrorE3Err;

struct _M0DTPC15debug9ReprDelta6Extra1;

struct _M0R68_24moonbitlang_2fcore_2fdebug_2ewith__resizing_2eanon__u3640__l460__;

struct _M0DTPC15debug4Repr11RecordField;

struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE;

struct _M0DTPC15debug4Repr5Tuple;

struct _M0TPB6Logger;

struct _M0TPB9ArrayViewGRPC15debug4ReprE;

struct _M0TUsRPB3MapGiUWEuQRPC15error5ErrorNsEEE;

struct _M0TPB5ArrayGUsiEE;

struct _M0R77_24moonbitlang_2fcore_2fdebug_2eprune__delta_2ego_7c115_2eanon__u3862__l184__;

struct _M0DTPC16result6ResultGOuRPC15error5ErrorE2Ok;

struct _M0DTPC15debug4Repr7Integer;

struct _M0TPB19MulShiftAll64Result;

struct _M0TURPB6LoggerRPC16string10StringViewE;

struct _M0TPB5ArrayGRP27walkzzz11mcp__server8CategoryE;

struct _M0TUiUWEuQRPC15error5ErrorNsEE;

struct _M0DTPC16result6ResultGRPB5ArrayGRPB5ArrayGsEERPB7NoErrorE2Ok;

struct _M0DTPC15error5Error60moonbitlang_2fcore_2fbuiltin_2eSnapshotError_2eSnapshotError;

struct _M0R93_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3aprune__info_2einner_2ego_7c260_2eanon__u3648__l54__;

struct _M0DTPC16result6ResultGRPC15debug9ReprDeltaRPB7NoErrorE3Err;

struct _M0R60_24moonbitlang_2fcore_2fdebug_2eindent_2eanon__u3475__l236__;

struct _M0DTPC16result6ResultGRPC15debug13ContentParensRPB7NoErrorE2Ok;

struct _M0TWRPC15debug9ReprDeltaERPC15debug9ReprDelta;

struct _M0R77_24moonbitlang_2fcore_2fdebug_2eprune__delta_2ego_7c115_2eanon__u3882__l194__;

struct _M0DTPC16result6ResultGRPC15debug4ReprRPB7NoErrorE2Ok;

struct _M0TPB4Show;

struct _M0DTPC15debug4Repr3Map;

struct _M0DTPC15debug9ReprDelta9Different;

struct _M0DTPC16result6ResultGRPB5ArrayGsERPB7NoErrorE2Ok;

struct _M0TPB9ArrayViewGRPC16string10StringViewE;

struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE;

struct _M0DTPC15debug4Repr5Array;

struct _M0TWsEs;

struct _M0DTPC16result6ResultGsRPB7NoErrorE3Err;

struct _M0DTPC16result6ResultGRPC15debug7ContentRPB7NoErrorE3Err;

struct _M0TWRPC15debug4ReprERPC15debug7Content;

struct _M0TPB9ArrayViewGUiUWEuQRPC15error5ErrorNsEEE;

struct _M0DTPC16result6ResultGRPB5ArrayGRPB5ArrayGsEERPB7NoErrorE3Err;

struct _M0DTPC16result6ResultGuRPB7FailureE2Ok;

struct _M0DTPC15debug4Repr8FloatLit;

struct _M0KTPB6LoggerTPB13StringBuilder;

struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE;

struct _M0DTPC16result6ResultGRPB5ArrayGRPC15debug9ReprDeltaERPB7NoErrorE2Ok;

struct _M0TWRPC15debug7ContentERPC15debug13ContentParens;

struct _M0DTPC16option6OptionGdE4Some;

struct _M0DTPC16result6ResultGRPB5ArrayGRPC15debug4ReprERPB7NoErrorE3Err;

struct _M0TWEu;

struct _M0TPB9ArrayViewGsE;

struct _M0TPB5ArrayGRPC15debug13ContentParensE;

struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE;

struct _M0R67_24moonbitlang_2fcore_2fdebug_2erender__delta_2eanon__u3912__l259__;

struct _M0DTPC16result6ResultGRPB5ArrayGRPC15debug7ContentERPB7NoErrorE2Ok;

struct _M0DTPC15debug4Repr7Literal;

struct _M0R191_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver_3a_3arun__test_7c_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver__Internal__No__Args_7c_2eanon__u3979__l477__;

struct _M0DTPC16result6ResultGRPC15debug13ContentParensRPB7NoErrorE3Err;

struct _M0R191_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver_3a_3arun__test_7c_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver__Internal__No__Args_7c_2eanon__u3975__l478__;

struct _M0R62_24moonbitlang_2fcore_2fdebug_2esurround_2eanon__u3401__l108__;

struct _M0R65Iter_3a_3amap_7c_5bString_2c_20String_5d_7c_2eanon__u2606__l367__;

struct _M0DTPC15error5Error58moonbitlang_2fcore_2fbuiltin_2eInspectError_2eInspectError;

struct _M0TPB4IterGsE;

struct _M0R59ArrayView_3a_3aiter_7c_5bString_5d_7c_2eanon__u2613__l717__;

struct _M0TPB13StringBuilder;

struct _M0DTPC16option6OptionGRPC16string10StringViewE4Some;

struct _M0R76_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3arender__repr_2eanon__u3815__l232__;

struct _M0DTPC16result6ResultGRPC15debug9ReprDeltaRPB7NoErrorE2Ok;

struct _M0TWsEb;

struct _M0DTPC15debug4Repr7CharLit;

struct _M0BTPB6Logger;

struct _M0TPC15debug7Content;

struct _M0DTPC15error5Error107walkzzz_2fmcp__server__blackbox__test_2eMoonBitTestDriverInternalJsError_2eMoonBitTestDriverInternalJsError;

struct _M0TWRPC15debug9ReprDeltaERPC15debug7Content;

struct _M0TPB5ArrayGRPC15debug4ReprE;

struct _M0DTPC16result6ResultGRPB5ArrayGRPC15debug13ContentParensERPB7NoErrorE2Ok;

struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE;

struct _M0DTPC16result6ResultGsRPB7NoErrorE2Ok;

struct _M0DTPC16result6ResultGuRPB7FailureE3Err;

struct _M0TWRPC15debug4ReprERPC15debug4Repr;

struct _M0TWRPC15debug13ContentParensERPB5ArrayGsE;

struct _M0TWRPC15error5ErrorEu;

struct _M0TPC15debug13ContentParens;

struct _M0DTPC15debug4Repr9StringLit;

struct _M0TPB5ArrayGRPC15debug7ContentE;

struct _M0TPB8MutLocalGiE;

struct _M0DTPC16result6ResultGRPB5ArrayGRPC15debug4ReprERPB7NoErrorE2Ok;

struct _M0DTPC16result6ResultGRPB5ArrayGRPC15debug7ContentERPB7NoErrorE3Err;

struct _M0DTPC15debug4Repr7BoolLit;

struct _M0DTPC15debug4Repr8MapEntry;

struct _M0DTPC15debug4Repr6Record;

struct _M0R60_24moonbitlang_2fcore_2fdebug_2eindent_2eanon__u3471__l236__;

struct _M0DTPC16result6ResultGRPC15debug7ContentRPB7NoErrorE2Ok;

struct _M0DTPC16result6ResultGuRPC15error5ErrorE2Ok;

struct _M0DTPC16result6ResultGRPC15debug4ReprRPB7NoErrorE3Err;

struct _M0DTPC16result6ResultGRPB5ArrayGsERPB7NoErrorE3Err;

struct _M0TWWuEuWRPC15error5ErrorEuEOuQRPC15error5Error;

struct _M0TWRPB5ArrayGsEERPB5ArrayGsE;

struct _M0TWRPC15debug9ReprDeltaEb;

struct _M0DTPC15debug4Repr4Enum;

struct _M0DTPC16result6ResultGOuRPC15error5ErrorE3Err;

struct _M0BTPB4Show;

struct _M0DTPC15error5Error109walkzzz_2fmcp__server__blackbox__test_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTest;

struct _M0TWuEu;

struct _M0TPC16string10StringView;

struct _M0DTPC15debug4Repr6Opaque;

struct _M0DTPC16result6ResultGbRP27walkzzz27mcp__server__blackbox__test33MoonBitTestDriverInternalSkipTestE3Err;

struct _M0DTPC16result6ResultGbRPB7NoErrorE3Err;

struct _M0DTPC15debug9ReprDelta4Same;

struct _M0TPB5ArrayGsE;

struct _M0TUWEuQRPC15error5ErrorNsE;

struct _M0DTPC15debug4Repr14EnumLabeledArg;

struct _M0TPB5ArrayGRPC15debug9ReprDeltaE;

struct _M0DTPC15debug4Repr9DoubleLit;

struct _M0DTPC16result6ResultGbRP27walkzzz27mcp__server__blackbox__test33MoonBitTestDriverInternalSkipTestE2Ok;

struct _M0TWEOs;

struct _M0TPB9ArrayViewGUsRPB3MapGiUWEuQRPC15error5ErrorNsEEEE;

struct _M0DTPC16result6ResultGuRPC15error5ErrorE3Err;

struct _M0TPB7Umul128;

struct _M0TPB8Pow5Pair;

struct _M0R111_24walkzzz_2fmcp__server__blackbox__test_2emoonbit__test__driver__internal__do__execute_2ehandle__result_7c1899 {
  int32_t(* code)(
    struct _M0TWssbEu*,
    moonbit_string_t,
    moonbit_string_t,
    int32_t
  );
  int32_t $0;
  moonbit_string_t $1;
  
};

struct _M0DTPC16result6ResultGRPB5ArrayGRPC15debug13ContentParensERPB7NoErrorE3Err {
  int32_t $0;
  
};

struct _M0TPB5ArrayGRPC16string10StringViewE {
  struct _M0TPC16string10StringView* $0;
  int32_t $1;
  
};

struct _M0TPB5ArrayGRPB5ArrayGsEE {
  struct _M0TPB5ArrayGsE** $0;
  int32_t $1;
  
};

struct _M0DTPC15error5Error48moonbitlang_2fcore_2fbuiltin_2eFailure_2eFailure {
  moonbit_string_t $0;
  
};

struct _M0TWRPC15error5ErrorEs {
  moonbit_string_t(* code)(struct _M0TWRPC15error5ErrorEs*, void*);
  
};

struct _M0R110_24walkzzz_2fmcp__server__blackbox__test_2emoonbit__test__driver__internal__do__execute_2ehandle__start_7c1894 {
  int32_t(* code)(struct _M0TWEu*);
  int32_t $0;
  moonbit_string_t $1;
  
};

struct _M0TWssbEu {
  int32_t(* code)(
    struct _M0TWssbEu*,
    moonbit_string_t,
    moonbit_string_t,
    int32_t
  );
  
};

struct _M0TUsiE {
  moonbit_string_t $0;
  int32_t $1;
  
};

struct _M0DTPC15debug9ReprDelta6Extra2 {
  void* $0;
  
};

struct _M0TPB17FloatingDecimal64 {
  uint64_t $0;
  int32_t $1;
  
};

struct _M0R93_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3aprune__info_2einner_2ego_7c260_2eanon__u3653__l62__ {
  void*(* code)(struct _M0TWRPC15debug4ReprERPC15debug4Repr*, void*);
  int32_t $0;
  void* $1;
  
};

struct _M0DTPC16result6ResultGbRPB7NoErrorE2Ok {
  int32_t $0;
  
};

struct _M0TWEuQRPC15error5Error {
  struct moonbit_result_0(* code)(struct _M0TWEuQRPC15error5Error*);
  
};

struct _M0DTPC16result6ResultGRPB5ArrayGRPC15debug9ReprDeltaERPB7NoErrorE3Err {
  int32_t $0;
  
};

struct _M0DTPC15debug9ReprDelta6Extra1 {
  void* $0;
  
};

struct _M0R68_24moonbitlang_2fcore_2fdebug_2ewith__resizing_2eanon__u3640__l460__ {
  int32_t(* code)(struct _M0TWsEb*, moonbit_string_t);
  int32_t $0;
  
};

struct _M0DTPC15debug4Repr11RecordField {
  moonbit_string_t $0;
  void* $1;
  
};

struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE {
  int32_t $0;
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* $1;
  int32_t $2;
  int32_t $3;
  moonbit_string_t $4;
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* $5;
  
};

struct _M0DTPC15debug4Repr5Tuple {
  struct _M0TPB5ArrayGRPC15debug4ReprE* $0;
  
};

struct _M0TPB6Logger {
  struct _M0BTPB6Logger* $0;
  void* $1;
  
};

struct _M0TPB9ArrayViewGRPC15debug4ReprE {
  void** $0;
  int32_t $1;
  int32_t $2;
  
};

struct _M0TUsRPB3MapGiUWEuQRPC15error5ErrorNsEEE {
  moonbit_string_t $0;
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* $1;
  
};

struct _M0TPB5ArrayGUsiEE {
  struct _M0TUsiE** $0;
  int32_t $1;
  
};

struct _M0R77_24moonbitlang_2fcore_2fdebug_2eprune__delta_2ego_7c115_2eanon__u3862__l184__ {
  void*(* code)(
    struct _M0TWRPC15debug9ReprDeltaERPC15debug9ReprDelta*,
    void*
  );
  int32_t $0;
  
};

struct _M0DTPC16result6ResultGOuRPC15error5ErrorE2Ok {
  int32_t $0;
  
};

struct _M0DTPC15debug4Repr7Integer {
  moonbit_string_t $0;
  
};

struct _M0TPB19MulShiftAll64Result {
  uint64_t $0;
  uint64_t $1;
  uint64_t $2;
  
};

struct _M0TPC16string10StringView {
  moonbit_string_t $0;
  int32_t $1;
  int32_t $2;
  
};

struct _M0TURPB6LoggerRPC16string10StringViewE {
  struct _M0TPB6Logger $0;
  struct _M0TPC16string10StringView $1;
  
};

struct _M0TPB5ArrayGRP27walkzzz11mcp__server8CategoryE {
  int32_t* $0;
  int32_t $1;
  
};

struct _M0TUiUWEuQRPC15error5ErrorNsEE {
  int32_t $0;
  struct _M0TUWEuQRPC15error5ErrorNsE* $1;
  
};

struct _M0DTPC16result6ResultGRPB5ArrayGRPB5ArrayGsEERPB7NoErrorE2Ok {
  struct _M0TPB5ArrayGRPB5ArrayGsEE* $0;
  
};

struct _M0DTPC15error5Error60moonbitlang_2fcore_2fbuiltin_2eSnapshotError_2eSnapshotError {
  moonbit_string_t $0;
  
};

struct _M0R93_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3aprune__info_2einner_2ego_7c260_2eanon__u3648__l54__ {
  void*(* code)(struct _M0TWRPC15debug4ReprERPC15debug4Repr*, void*);
  void* $0;
  int32_t $1;
  
};

struct _M0DTPC16result6ResultGRPC15debug9ReprDeltaRPB7NoErrorE3Err {
  int32_t $0;
  
};

struct _M0R60_24moonbitlang_2fcore_2fdebug_2eindent_2eanon__u3475__l236__ {
  moonbit_string_t(* code)(struct _M0TWsEs*, moonbit_string_t);
  moonbit_string_t $0;
  
};

struct _M0DTPC16result6ResultGRPC15debug13ContentParensRPB7NoErrorE2Ok {
  struct _M0TPC15debug13ContentParens* $0;
  
};

struct _M0TWRPC15debug9ReprDeltaERPC15debug9ReprDelta {
  void*(* code)(
    struct _M0TWRPC15debug9ReprDeltaERPC15debug9ReprDelta*,
    void*
  );
  
};

struct _M0R77_24moonbitlang_2fcore_2fdebug_2eprune__delta_2ego_7c115_2eanon__u3882__l194__ {
  void*(* code)(
    struct _M0TWRPC15debug9ReprDeltaERPC15debug9ReprDelta*,
    void*
  );
  int32_t $0;
  
};

struct _M0DTPC16result6ResultGRPC15debug4ReprRPB7NoErrorE2Ok {
  void* $0;
  
};

struct _M0TPB4Show {
  struct _M0BTPB4Show* $0;
  void* $1;
  
};

struct _M0DTPC15debug4Repr3Map {
  struct _M0TPB5ArrayGRPC15debug4ReprE* $0;
  
};

struct _M0DTPC15debug9ReprDelta9Different {
  void* $0;
  void* $1;
  
};

struct _M0DTPC16result6ResultGRPB5ArrayGsERPB7NoErrorE2Ok {
  struct _M0TPB5ArrayGsE* $0;
  
};

struct _M0TPB9ArrayViewGRPC16string10StringViewE {
  struct _M0TPC16string10StringView* $0;
  int32_t $1;
  int32_t $2;
  
};

struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE {
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE** $0;
  int32_t $1;
  int32_t $2;
  int32_t $3;
  int32_t $4;
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* $5;
  int32_t $6;
  
};

struct _M0DTPC15debug4Repr5Array {
  struct _M0TPB5ArrayGRPC15debug4ReprE* $0;
  
};

struct _M0TWsEs {
  moonbit_string_t(* code)(struct _M0TWsEs*, moonbit_string_t);
  
};

struct _M0DTPC16result6ResultGsRPB7NoErrorE3Err {
  int32_t $0;
  
};

struct _M0DTPC16result6ResultGRPC15debug7ContentRPB7NoErrorE3Err {
  int32_t $0;
  
};

struct _M0TWRPC15debug4ReprERPC15debug7Content {
  struct _M0TPC15debug7Content*(* code)(
    struct _M0TWRPC15debug4ReprERPC15debug7Content*,
    void*
  );
  
};

struct _M0TPB9ArrayViewGUiUWEuQRPC15error5ErrorNsEEE {
  struct _M0TUiUWEuQRPC15error5ErrorNsEE** $0;
  int32_t $1;
  int32_t $2;
  
};

struct _M0DTPC16result6ResultGRPB5ArrayGRPB5ArrayGsEERPB7NoErrorE3Err {
  int32_t $0;
  
};

struct _M0DTPC16result6ResultGuRPB7FailureE2Ok {
  int32_t $0;
  
};

struct _M0DTPC15debug4Repr8FloatLit {
  float $0;
  
};

struct _M0KTPB6LoggerTPB13StringBuilder {
  struct _M0BTPB6Logger* $0;
  void* $1;
  
};

struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE {
  int32_t $0;
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* $1;
  int32_t $2;
  int32_t $3;
  int32_t $4;
  struct _M0TUWEuQRPC15error5ErrorNsE* $5;
  
};

struct _M0DTPC16result6ResultGRPB5ArrayGRPC15debug9ReprDeltaERPB7NoErrorE2Ok {
  struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* $0;
  
};

struct _M0TWRPC15debug7ContentERPC15debug13ContentParens {
  struct _M0TPC15debug13ContentParens*(* code)(
    struct _M0TWRPC15debug7ContentERPC15debug13ContentParens*,
    struct _M0TPC15debug7Content*
  );
  
};

struct _M0DTPC16option6OptionGdE4Some {
  double $0;
  
};

struct _M0DTPC16result6ResultGRPB5ArrayGRPC15debug4ReprERPB7NoErrorE3Err {
  int32_t $0;
  
};

struct _M0TWEu {
  int32_t(* code)(struct _M0TWEu*);
  
};

struct _M0TPB9ArrayViewGsE {
  moonbit_string_t* $0;
  int32_t $1;
  int32_t $2;
  
};

struct _M0TPB5ArrayGRPC15debug13ContentParensE {
  struct _M0TPC15debug13ContentParens** $0;
  int32_t $1;
  
};

struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE {
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE** $0;
  int32_t $1;
  int32_t $2;
  int32_t $3;
  int32_t $4;
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* $5;
  int32_t $6;
  
};

struct _M0R67_24moonbitlang_2fcore_2fdebug_2erender__delta_2eanon__u3912__l259__ {
  struct _M0TPC15debug7Content*(* code)(
    struct _M0TWRPC15debug9ReprDeltaERPC15debug7Content*,
    void*
  );
  int32_t $0;
  int32_t $1;
  
};

struct _M0DTPC16result6ResultGRPB5ArrayGRPC15debug7ContentERPB7NoErrorE2Ok {
  struct _M0TPB5ArrayGRPC15debug7ContentE* $0;
  
};

struct _M0DTPC15debug4Repr7Literal {
  moonbit_string_t $0;
  
};

struct _M0R191_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver_3a_3arun__test_7c_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver__Internal__No__Args_7c_2eanon__u3979__l477__ {
  int32_t(* code)(struct _M0TWEu*);
  struct _M0TWssbEu* $0;
  moonbit_string_t $1;
  
};

struct _M0DTPC16result6ResultGRPC15debug13ContentParensRPB7NoErrorE3Err {
  int32_t $0;
  
};

struct _M0R191_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver_3a_3arun__test_7c_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver__Internal__No__Args_7c_2eanon__u3975__l478__ {
  int32_t(* code)(struct _M0TWRPC15error5ErrorEu*, void*);
  struct _M0TWRPC15error5ErrorEs* $0;
  struct _M0TWssbEu* $1;
  moonbit_string_t $2;
  
};

struct _M0R62_24moonbitlang_2fcore_2fdebug_2esurround_2eanon__u3401__l108__ {
  struct _M0TPB5ArrayGsE*(* code)(
    struct _M0TWRPB5ArrayGsEERPB5ArrayGsE*,
    struct _M0TPB5ArrayGsE*
  );
  moonbit_string_t $0;
  moonbit_string_t $1;
  
};

struct _M0R65Iter_3a_3amap_7c_5bString_2c_20String_5d_7c_2eanon__u2606__l367__ {
  moonbit_string_t(* code)(struct _M0TWEOs*);
  struct _M0TWsEs* $0;
  struct _M0TPB4IterGsE* $1;
  
};

struct _M0DTPC15error5Error58moonbitlang_2fcore_2fbuiltin_2eInspectError_2eInspectError {
  moonbit_string_t $0;
  
};

struct _M0TPB4IterGsE {
  struct _M0TWEOs* $0;
  int64_t $1;
  
};

struct _M0R59ArrayView_3a_3aiter_7c_5bString_5d_7c_2eanon__u2613__l717__ {
  moonbit_string_t(* code)(struct _M0TWEOs*);
  struct _M0TPB9ArrayViewGsE $0;
  int32_t $1;
  struct _M0TPB8MutLocalGiE* $2;
  
};

struct _M0TPB13StringBuilder {
  uint16_t* $0;
  int32_t $1;
  
};

struct _M0DTPC16option6OptionGRPC16string10StringViewE4Some {
  struct _M0TPC16string10StringView $0;
  
};

struct _M0R76_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3arender__repr_2eanon__u3815__l232__ {
  struct _M0TPC15debug7Content*(* code)(
    struct _M0TWRPC15debug4ReprERPC15debug7Content*,
    void*
  );
  int32_t $0;
  
};

struct _M0DTPC16result6ResultGRPC15debug9ReprDeltaRPB7NoErrorE2Ok {
  void* $0;
  
};

struct _M0TWsEb {
  int32_t(* code)(struct _M0TWsEb*, moonbit_string_t);
  
};

struct _M0DTPC15debug4Repr7CharLit {
  int32_t $0;
  
};

struct _M0BTPB6Logger {
  int32_t(* $method_0)(void*, moonbit_string_t);
  int32_t(* $method_1)(void*, moonbit_string_t, int32_t, int32_t);
  int32_t(* $method_2)(void*, struct _M0TPC16string10StringView);
  int32_t(* $method_3)(void*, int32_t);
  int32_t(* $method_4)(void*, struct _M0TPB4Show);
  int32_t(* $method_5)(void*, struct _M0TPB4Show);
  
};

struct _M0TPC15debug7Content {
  int32_t $0;
  struct _M0TPB5ArrayGsE* $1;
  int32_t $2;
  
};

struct _M0DTPC15error5Error107walkzzz_2fmcp__server__blackbox__test_2eMoonBitTestDriverInternalJsError_2eMoonBitTestDriverInternalJsError {
  moonbit_string_t $0;
  
};

struct _M0TWRPC15debug9ReprDeltaERPC15debug7Content {
  struct _M0TPC15debug7Content*(* code)(
    struct _M0TWRPC15debug9ReprDeltaERPC15debug7Content*,
    void*
  );
  
};

struct _M0TPB5ArrayGRPC15debug4ReprE {
  void** $0;
  int32_t $1;
  
};

struct _M0DTPC16result6ResultGRPB5ArrayGRPC15debug13ContentParensERPB7NoErrorE2Ok {
  struct _M0TPB5ArrayGRPC15debug13ContentParensE* $0;
  
};

struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE {
  struct _M0TWWuEuWRPC15error5ErrorEuEOuQRPC15error5Error** $0;
  int32_t $1;
  
};

struct _M0DTPC16result6ResultGsRPB7NoErrorE2Ok {
  moonbit_string_t $0;
  
};

struct _M0DTPC16result6ResultGuRPB7FailureE3Err {
  void* $0;
  
};

struct _M0TWRPC15debug4ReprERPC15debug4Repr {
  void*(* code)(struct _M0TWRPC15debug4ReprERPC15debug4Repr*, void*);
  
};

struct _M0TWRPC15debug13ContentParensERPB5ArrayGsE {
  struct _M0TPB5ArrayGsE*(* code)(
    struct _M0TWRPC15debug13ContentParensERPB5ArrayGsE*,
    struct _M0TPC15debug13ContentParens*
  );
  
};

struct _M0TWRPC15error5ErrorEu {
  int32_t(* code)(struct _M0TWRPC15error5ErrorEu*, void*);
  
};

struct _M0TPC15debug13ContentParens {
  int32_t $0;
  struct _M0TPB5ArrayGsE* $1;
  
};

struct _M0DTPC15debug4Repr9StringLit {
  moonbit_string_t $0;
  
};

struct _M0TPB5ArrayGRPC15debug7ContentE {
  struct _M0TPC15debug7Content** $0;
  int32_t $1;
  
};

struct _M0TPB8MutLocalGiE {
  int32_t $0;
  
};

struct _M0DTPC16result6ResultGRPB5ArrayGRPC15debug4ReprERPB7NoErrorE2Ok {
  struct _M0TPB5ArrayGRPC15debug4ReprE* $0;
  
};

struct _M0DTPC16result6ResultGRPB5ArrayGRPC15debug7ContentERPB7NoErrorE3Err {
  int32_t $0;
  
};

struct _M0DTPC15debug4Repr7BoolLit {
  int32_t $0;
  
};

struct _M0DTPC15debug4Repr8MapEntry {
  void* $0;
  void* $1;
  
};

struct _M0DTPC15debug4Repr6Record {
  struct _M0TPB5ArrayGRPC15debug4ReprE* $0;
  
};

struct _M0R60_24moonbitlang_2fcore_2fdebug_2eindent_2eanon__u3471__l236__ {
  struct _M0TPB5ArrayGsE*(* code)(
    struct _M0TWRPB5ArrayGsEERPB5ArrayGsE*,
    struct _M0TPB5ArrayGsE*
  );
  moonbit_string_t $0;
  
};

struct _M0DTPC16result6ResultGRPC15debug7ContentRPB7NoErrorE2Ok {
  struct _M0TPC15debug7Content* $0;
  
};

struct _M0DTPC16result6ResultGuRPC15error5ErrorE2Ok {
  int32_t $0;
  
};

struct _M0DTPC16result6ResultGRPC15debug4ReprRPB7NoErrorE3Err {
  int32_t $0;
  
};

struct _M0DTPC16result6ResultGRPB5ArrayGsERPB7NoErrorE3Err {
  int32_t $0;
  
};

struct _M0TWWuEuWRPC15error5ErrorEuEOuQRPC15error5Error {
  struct moonbit_result_0(* code)(
    struct _M0TWWuEuWRPC15error5ErrorEuEOuQRPC15error5Error*,
    struct _M0TWuEu*,
    struct _M0TWRPC15error5ErrorEu*
  );
  
};

struct _M0TWRPB5ArrayGsEERPB5ArrayGsE {
  struct _M0TPB5ArrayGsE*(* code)(
    struct _M0TWRPB5ArrayGsEERPB5ArrayGsE*,
    struct _M0TPB5ArrayGsE*
  );
  
};

struct _M0TWRPC15debug9ReprDeltaEb {
  int32_t(* code)(struct _M0TWRPC15debug9ReprDeltaEb*, void*);
  
};

struct _M0DTPC15debug4Repr4Enum {
  moonbit_string_t $0;
  struct _M0TPB5ArrayGRPC15debug4ReprE* $1;
  
};

struct _M0DTPC16result6ResultGOuRPC15error5ErrorE3Err {
  void* $0;
  
};

struct _M0BTPB4Show {
  int32_t(* $method_0)(void*, struct _M0TPB6Logger);
  moonbit_string_t(* $method_1)(void*);
  
};

struct _M0DTPC15error5Error109walkzzz_2fmcp__server__blackbox__test_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTest {
  moonbit_string_t $0;
  
};

struct _M0TWuEu {
  int32_t(* code)(struct _M0TWuEu*, int32_t);
  
};

struct _M0DTPC15debug4Repr6Opaque {
  moonbit_string_t $0;
  void* $1;
  
};

struct _M0DTPC16result6ResultGbRP27walkzzz27mcp__server__blackbox__test33MoonBitTestDriverInternalSkipTestE3Err {
  void* $0;
  
};

struct _M0DTPC16result6ResultGbRPB7NoErrorE3Err {
  int32_t $0;
  
};

struct _M0DTPC15debug9ReprDelta4Same {
  void* $0;
  struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* $1;
  
};

struct _M0TPB5ArrayGsE {
  moonbit_string_t* $0;
  int32_t $1;
  
};

struct _M0TUWEuQRPC15error5ErrorNsE {
  struct _M0TWEuQRPC15error5Error* $0;
  moonbit_string_t* $1;
  
};

struct _M0DTPC15debug4Repr14EnumLabeledArg {
  moonbit_string_t $0;
  void* $1;
  
};

struct _M0TPB5ArrayGRPC15debug9ReprDeltaE {
  void** $0;
  int32_t $1;
  
};

struct _M0DTPC15debug4Repr9DoubleLit {
  double $0;
  
};

struct _M0DTPC16result6ResultGbRP27walkzzz27mcp__server__blackbox__test33MoonBitTestDriverInternalSkipTestE2Ok {
  int32_t $0;
  
};

struct _M0TWEOs {
  moonbit_string_t(* code)(struct _M0TWEOs*);
  
};

struct _M0TPB9ArrayViewGUsRPB3MapGiUWEuQRPC15error5ErrorNsEEEE {
  struct _M0TUsRPB3MapGiUWEuQRPC15error5ErrorNsEEE** $0;
  int32_t $1;
  int32_t $2;
  
};

struct _M0DTPC16result6ResultGuRPC15error5ErrorE3Err {
  void* $0;
  
};

struct _M0TPB7Umul128 {
  uint64_t $0;
  uint64_t $1;
  
};

struct _M0TPB8Pow5Pair {
  uint64_t $0;
  uint64_t $1;
  
};

struct moonbit_result_0 {
  int tag;
  union { int32_t ok; void* err;  } data;
  
};

struct _M0TPB5ArrayGsE* _M0FPC15debug24compact__lines_2edyncall(
  struct _M0TWRPB5ArrayGsEERPB5ArrayGsE*,
  struct _M0TPB5ArrayGsE*
);

struct moonbit_result_0 _M0FP27walkzzz27mcp__server__blackbox__test45____test__657870656e73652e6d6274__0_2edyncall(
  struct _M0TWEuQRPC15error5Error*
);

int32_t _M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test28MoonBit__Async__Test__Driver30is__being__cancelled_2edyncallGRP27walkzzz27mcp__server__blackbox__test34MoonBit__Async__Test__Driver__ImplE(
  struct _M0TWEu*
);

int32_t _M0FP27walkzzz27mcp__server__blackbox__test44moonbit__test__driver__internal__do__execute(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE*,
  moonbit_string_t,
  int32_t
);

moonbit_string_t _M0FP27walkzzz27mcp__server__blackbox__test44moonbit__test__driver__internal__do__executeN17error__to__stringS1906(
  struct _M0TWRPC15error5ErrorEs*,
  void*
);

int32_t _M0FP27walkzzz27mcp__server__blackbox__test44moonbit__test__driver__internal__do__executeN14handle__resultS1899(
  struct _M0TWssbEu*,
  moonbit_string_t,
  moonbit_string_t,
  int32_t
);

int32_t _M0FP27walkzzz27mcp__server__blackbox__test44moonbit__test__driver__internal__do__executeN13handle__startS1894(
  struct _M0TWEu*
);

struct moonbit_result_0 _M0IP27walkzzz27mcp__server__blackbox__test41MoonBit__Test__Driver__Internal__No__ArgsP27walkzzz27mcp__server__blackbox__test21MoonBit__Test__Driver9run__test(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE*,
  moonbit_string_t,
  int32_t,
  struct _M0TWEu*,
  struct _M0TWssbEu*,
  struct _M0TWRPC15error5ErrorEs*
);

int32_t _M0IP27walkzzz27mcp__server__blackbox__test41MoonBit__Test__Driver__Internal__No__ArgsP27walkzzz27mcp__server__blackbox__test21MoonBit__Test__Driver9run__testC3979l477(
  struct _M0TWEu*
);

int32_t _M0IP27walkzzz27mcp__server__blackbox__test41MoonBit__Test__Driver__Internal__No__ArgsP27walkzzz27mcp__server__blackbox__test21MoonBit__Test__Driver9run__testC3975l478(
  struct _M0TWRPC15error5ErrorEu*,
  void*
);

int32_t _M0FP27walkzzz27mcp__server__blackbox__test45moonbit__test__driver__internal__catch__error(
  struct _M0TWEuQRPC15error5Error*,
  struct _M0TWEu*,
  struct _M0TWRPC15error5ErrorEu*
);

struct _M0TPB5ArrayGUsiEE* _M0FP27walkzzz27mcp__server__blackbox__test52moonbit__test__driver__internal__native__parse__args(
  
);

struct _M0TPB5ArrayGsE* _M0FP27walkzzz27mcp__server__blackbox__test52moonbit__test__driver__internal__native__parse__argsN51moonbit__test__driver__internal__split__mbt__stringS1827(
  int32_t,
  moonbit_string_t,
  int32_t
);

int32_t _M0FP27walkzzz27mcp__server__blackbox__test52moonbit__test__driver__internal__native__parse__argsN45moonbit__test__driver__internal__parse__int__S1820(
  int32_t,
  moonbit_string_t
);

#define _M0FP27walkzzz27mcp__server__blackbox__test52moonbit__test__driver__internal__get__cli__args__ffi moonbit_rt_get_cli_args

moonbit_string_t _M0MP27walkzzz27mcp__server__blackbox__test33MoonBitTestDriverInternalOsString10to__string(
  moonbit_string_t
);

struct moonbit_result_0 _M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test21MoonBit__Test__Driver9run__testGRP27walkzzz27mcp__server__blackbox__test43MoonBit__Test__Driver__Internal__With__ArgsE(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE*,
  moonbit_string_t,
  int32_t,
  struct _M0TWEu*,
  struct _M0TWssbEu*,
  struct _M0TWRPC15error5ErrorEs*
);

struct moonbit_result_0 _M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test21MoonBit__Test__Driver9run__testGRP27walkzzz27mcp__server__blackbox__test48MoonBit__Test__Driver__Internal__Async__No__ArgsE(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE*,
  moonbit_string_t,
  int32_t,
  struct _M0TWEu*,
  struct _M0TWssbEu*,
  struct _M0TWRPC15error5ErrorEs*
);

struct moonbit_result_0 _M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test21MoonBit__Test__Driver9run__testGRP27walkzzz27mcp__server__blackbox__test50MoonBit__Test__Driver__Internal__Async__With__ArgsE(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE*,
  moonbit_string_t,
  int32_t,
  struct _M0TWEu*,
  struct _M0TWssbEu*,
  struct _M0TWRPC15error5ErrorEs*
);

struct moonbit_result_0 _M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test21MoonBit__Test__Driver9run__testGRP27walkzzz27mcp__server__blackbox__test50MoonBit__Test__Driver__Internal__With__Bench__ArgsE(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE*,
  moonbit_string_t,
  int32_t,
  struct _M0TWEu*,
  struct _M0TWssbEu*,
  struct _M0TWRPC15error5ErrorEs*
);

int32_t _M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test28MoonBit__Async__Test__Driver20is__being__cancelledGRP27walkzzz27mcp__server__blackbox__test34MoonBit__Async__Test__Driver__ImplE(
  
);

int32_t _M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test28MoonBit__Async__Test__Driver17run__async__testsGRP27walkzzz27mcp__server__blackbox__test34MoonBit__Async__Test__Driver__ImplE(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE*
);

struct moonbit_result_0 _M0FP27walkzzz27mcp__server__blackbox__test35____test__657870656e73652e6d6274__0(
  
);

struct _M0TPB5ArrayGRP27walkzzz11mcp__server8CategoryE* _M0FP27walkzzz11mcp__server15all__categories(
  
);

struct moonbit_result_0 _M0FPC15debug10assert__eqGiE(
  int32_t,
  int32_t,
  moonbit_string_t,
  moonbit_string_t
);

void* _M0IPC13int3IntPC15debug5Debug8to__repr(int32_t);

moonbit_string_t _M0FPC15debug20pretty__print__delta(
  void*,
  int64_t,
  int64_t,
  int32_t
);

moonbit_string_t _M0FPC15debug28pretty__print__delta_2einner(
  void*,
  int64_t,
  int32_t,
  int32_t
);

struct _M0TPC15debug7Content* _M0FPC15debug13render__delta(
  int32_t,
  int32_t,
  void*
);

struct _M0TPC15debug7Content* _M0FPC15debug13render__deltaC3912l259(
  struct _M0TWRPC15debug9ReprDeltaERPC15debug7Content*,
  void*
);

struct _M0TPC15debug13ContentParens* _M0FPC15debug13mark__removed(
  int32_t,
  struct _M0TPC15debug13ContentParens*
);

struct _M0TPC15debug13ContentParens* _M0FPC15debug11mark__added(
  int32_t,
  struct _M0TPC15debug13ContentParens*
);

int32_t _M0FPC15debug17delta__root__size(void*);

void* _M0FPC15debug12prune__delta(int64_t, void*);

void* _M0FPC15debug12prune__deltaN2goS115(int32_t, void*);

void* _M0FPC15debug12prune__deltaN2goS115C3882l194(
  struct _M0TWRPC15debug9ReprDeltaERPC15debug9ReprDelta*,
  void*
);

void* _M0FPC15debug12prune__deltaN2goS115C3862l184(
  struct _M0TWRPC15debug9ReprDeltaERPC15debug9ReprDelta*,
  void*
);

void* _M0FPC15debug10diff__repr(void*, void*, void*);

void* _M0FPC15debug18diff__repr_2einner(void*, void*, double);

void* _M0FPC15debug16diff__info__with(void*, void*, double);

void* _M0FPC15debug16diff__info__withN2goS142(double, void*, void*);

int32_t _M0FPC15debug16diff__info__withN2goS142C3850l122(
  struct _M0TWRPC15debug9ReprDeltaEb*,
  void*
);

int32_t _M0FPC15debug21info__is__unimportant(void*);

int32_t _M0FPC15debug16info__approx__eq(double, void*, void*);

double _M0FPC15debug15relative__error(double, double);

double _M0FPC15debug11double__max(double, double);

double _M0FPC15debug11double__abs(double);

moonbit_string_t _M0FPC15debug6render(void*, int64_t);

struct _M0TPC15debug7Content* _M0MPC15debug4Repr12render__repr(
  void*,
  int32_t
);

struct _M0TPC15debug7Content* _M0MPC15debug4Repr12render__reprC3815l232(
  struct _M0TWRPC15debug4ReprERPC15debug7Content*,
  void*
);

struct _M0TPC15debug7Content* _M0MPC15debug4Repr13pretty__print(
  void*,
  struct _M0TPB5ArrayGRPC15debug7ContentE*
);

struct _M0TPC15debug13ContentParens* _M0MPC15debug4Repr13pretty__printC3793l147(
  struct _M0TWRPC15debug7ContentERPC15debug13ContentParens*,
  struct _M0TPC15debug7Content*
);

struct _M0TPC15debug13ContentParens* _M0MPC15debug4Repr13pretty__printC3789l155(
  struct _M0TWRPC15debug7ContentERPC15debug13ContentParens*,
  struct _M0TPC15debug7Content*
);

struct _M0TPC15debug13ContentParens* _M0MPC15debug4Repr13pretty__printC3784l153(
  struct _M0TWRPC15debug7ContentERPC15debug13ContentParens*,
  struct _M0TPC15debug7Content*
);

struct _M0TPC15debug13ContentParens* _M0MPC15debug4Repr13pretty__printC3778l158(
  struct _M0TWRPC15debug7ContentERPC15debug13ContentParens*,
  struct _M0TPC15debug7Content*
);

struct _M0TPC15debug13ContentParens* _M0MPC15debug4Repr13pretty__printC3774l159(
  struct _M0TWRPC15debug7ContentERPC15debug13ContentParens*,
  struct _M0TPC15debug7Content*
);

struct _M0TPC15debug13ContentParens* _M0MPC15debug4Repr13pretty__printC3769l167(
  struct _M0TWRPC15debug7ContentERPC15debug13ContentParens*,
  struct _M0TPC15debug7Content*
);

struct _M0TPC15debug13ContentParens* _M0MPC15debug4Repr13pretty__printC3757l172(
  struct _M0TWRPC15debug7ContentERPC15debug13ContentParens*,
  struct _M0TPC15debug7Content*
);

moonbit_string_t _M0FPC15debug20pretty__print__label(moonbit_string_t);

int32_t _M0FPC15debug17is__unquoted__key(moonbit_string_t);

int32_t _M0FPC15debug10info__size(void*);

void* _M0MPC15debug4Repr11prune__info(void*, void*, int64_t);

void* _M0MPC15debug4Repr19prune__info_2einner(void*, void*, int64_t);

void* _M0MPC15debug4Repr19prune__info_2einnerN2goS260(void*, int32_t, void*);

void* _M0MPC15debug4Repr19prune__info_2einnerN2goS260C3653l62(
  struct _M0TWRPC15debug4ReprERPC15debug4Repr*,
  void*
);

void* _M0MPC15debug4Repr19prune__info_2einnerN2goS260C3648l54(
  struct _M0TWRPC15debug4ReprERPC15debug4Repr*,
  void*
);

int32_t _M0MPC15debug4Repr17info__adds__depth(void*);

struct _M0TPC15debug7Content* _M0FPC15debug14with__resizing(
  int32_t,
  int32_t,
  struct _M0TPC15debug7Content*
);

int32_t _M0FPC15debug14with__resizingC3640l460(
  struct _M0TWsEb*,
  moonbit_string_t
);

moonbit_string_t _M0FPC15debug14print__content(
  struct _M0TPC15debug13ContentParens*
);

struct _M0TPC15debug7Content* _M0FPC15debug10comma__seq(
  moonbit_string_t,
  moonbit_string_t,
  struct _M0TPB5ArrayGRPC15debug13ContentParensE*
);

struct _M0TPB5ArrayGsE* _M0FPC15debug10comma__seqC3633l427(
  struct _M0TWRPC15debug13ContentParensERPB5ArrayGsE*,
  struct _M0TPC15debug13ContentParens*
);

struct _M0TPB5ArrayGsE* _M0FPC15debug17comma__seq__lines(
  moonbit_string_t,
  moonbit_string_t,
  struct _M0TPB5ArrayGRPB5ArrayGsEE*
);

int32_t _M0FPC15debug17comma__seq__linesC3621l395(
  struct _M0TWsEb*,
  moonbit_string_t
);

int32_t _M0FPC15debug17comma__seq__linesC3597l379(
  struct _M0TWsEb*,
  moonbit_string_t
);

moonbit_string_t _M0FPC15debug17comma__seq__linesC3583l386(
  struct _M0TWsEs*,
  moonbit_string_t
);

int32_t _M0FPC15debug17comma__seq__linesC3542l365(
  struct _M0TWsEb*,
  moonbit_string_t
);

struct _M0TPB5ArrayGsE* _M0FPC15debug19bracket__seq__lines(
  moonbit_string_t,
  moonbit_string_t,
  int32_t,
  struct _M0TPB5ArrayGRPB5ArrayGsEE*
);

int32_t _M0FPC15debug19bracket__seq__linesC3536l309(
  struct _M0TWsEb*,
  moonbit_string_t
);

struct _M0TPC15debug13ContentParens* _M0FPC15debug14indent__spaces(
  int32_t,
  struct _M0TPC15debug13ContentParens*
);

struct _M0TPC15debug13ContentParens* _M0FPC15debug6indent(
  moonbit_string_t,
  struct _M0TPC15debug13ContentParens*
);

struct _M0TPB5ArrayGsE* _M0FPC15debug6indentC3471l236(
  struct _M0TWRPB5ArrayGsEERPB5ArrayGsE*,
  struct _M0TPB5ArrayGsE*
);

moonbit_string_t _M0FPC15debug6indentC3475l236(
  struct _M0TWsEs*,
  moonbit_string_t
);

struct _M0TPC15debug7Content* _M0MPC15debug7Content7compact(
  struct _M0TPC15debug7Content*
);

struct _M0TPB5ArrayGsE* _M0FPC15debug14compact__lines(
  struct _M0TPB5ArrayGsE*
);

struct _M0TPC15debug7Content* _M0FPC15debug10no__parens(
  struct _M0TPC15debug13ContentParens*
);

struct _M0TPC15debug7Content* _M0FPC15debug6parens(
  struct _M0TPC15debug13ContentParens*
);

struct _M0TPC15debug13ContentParens* _M0MPC15debug7Content8no__wrap(
  struct _M0TPC15debug7Content*
);

struct _M0TPC15debug13ContentParens* _M0FPC15debug8surround(
  moonbit_string_t,
  moonbit_string_t,
  struct _M0TPC15debug13ContentParens*
);

struct _M0TPB5ArrayGsE* _M0FPC15debug8surroundC3401l108(
  struct _M0TWRPB5ArrayGsEERPB5ArrayGsE*,
  struct _M0TPB5ArrayGsE*
);

struct _M0TPB5ArrayGsE* _M0FPC15debug15surround__lines(
  moonbit_string_t,
  moonbit_string_t,
  struct _M0TPB5ArrayGsE*
);

struct _M0TPC15debug7Content* _M0MPC15debug7Content20with__lines__content(
  struct _M0TPC15debug7Content*,
  struct _M0TWRPB5ArrayGsEERPB5ArrayGsE*
);

struct _M0TPC15debug13ContentParens* _M0FPC15debug11with__lines(
  struct _M0TPC15debug13ContentParens*,
  struct _M0TWRPB5ArrayGsEERPB5ArrayGsE*
);

struct _M0TPC15debug7Content* _M0FPC15debug12leaf_2einner(
  moonbit_string_t,
  int32_t
);

struct _M0TPC15debug13ContentParens* _M0FPC15debug15content__parens(
  int32_t,
  struct _M0TPB5ArrayGsE*
);

struct _M0TPC15debug13ContentParens* _M0FPC15debug8verbatim(moonbit_string_t);

struct _M0TPC15debug7Content* _M0FPC15debug14empty__content();

struct _M0TPC15debug13ContentParens* _M0IPC15debug13ContentParensPB3Add3add(
  struct _M0TPC15debug13ContentParens*,
  struct _M0TPC15debug13ContentParens*
);

void* _M0MPC15debug4Repr7shallow(void*);

void* _M0MPC15debug4Repr7omitted();

void* _M0MPC15debug4Repr7integer(moonbit_string_t);

void* _M0MPC15debug4Repr14with__children(
  void*,
  struct _M0TPB5ArrayGRPC15debug4ReprE*
);

struct _M0TPB5ArrayGRPC15debug4ReprE* _M0MPC15debug4Repr8children(void*);

void* _M0MPC15debug4Repr4ReprGiE(int32_t);

moonbit_string_t _M0IPC15float5FloatPB4Show10to__string(float);

moonbit_string_t _M0MPC15array5Array4joinGsE(
  struct _M0TPB5ArrayGsE*,
  struct _M0TPC16string10StringView
);

moonbit_string_t _M0MPC15array5Array4joinGRPC16string10StringViewE(
  struct _M0TPB5ArrayGRPC16string10StringViewE*,
  struct _M0TPC16string10StringView
);

int32_t _M0MPC15array5Array10push__iterGsE(
  struct _M0TPB5ArrayGsE*,
  struct _M0TPB4IterGsE*
);

struct _M0TPB5ArrayGsE* _M0MPC15array5Array6filterGsE(
  struct _M0TPB5ArrayGsE*,
  struct _M0TWsEb*
);

int32_t _M0MPC15array5Array9is__emptyGRPC15debug7ContentE(
  struct _M0TPB5ArrayGRPC15debug7ContentE*
);

int32_t _M0MPC15array5Array9is__emptyGRPC15debug9ReprDeltaE(
  struct _M0TPB5ArrayGRPC15debug9ReprDeltaE*
);

int32_t _M0MPC15array5Array9is__emptyGRPC15debug4ReprE(
  struct _M0TPB5ArrayGRPC15debug4ReprE*
);

int32_t _M0MPC15array5Array9is__emptyGsE(struct _M0TPB5ArrayGsE*);

int32_t _M0MPC15array5Array3allGsE(struct _M0TPB5ArrayGsE*, struct _M0TWsEb*);

int32_t _M0MPC15array5Array3allGRPC15debug9ReprDeltaE(
  struct _M0TPB5ArrayGRPC15debug9ReprDeltaE*,
  struct _M0TWRPC15debug9ReprDeltaEb*
);

struct _M0TPB5ArrayGsE* _M0IPC15array5ArrayPB3Add3addGsE(
  struct _M0TPB5ArrayGsE*,
  struct _M0TPB5ArrayGsE*
);

int32_t _M0MPC15array5Array6appendGsE(
  struct _M0TPB5ArrayGsE*,
  struct _M0TPB9ArrayViewGsE
);

int32_t _M0MPC15array5Array17reserve__capacityGsE(
  struct _M0TPB5ArrayGsE*,
  int32_t
);

moonbit_string_t _M0MPC15array5Array2atGsE(struct _M0TPB5ArrayGsE*, int32_t);

struct _M0TPB9ArrayViewGRPC15debug4ReprE _M0MPC15array5Array12view_2einnerGRPC15debug4ReprE(
  struct _M0TPB5ArrayGRPC15debug4ReprE*,
  int32_t,
  int64_t
);

int32_t _M0IPB9SourceLocPB4Show6output(
  moonbit_string_t,
  struct _M0TPB6Logger
);

moonbit_string_t _M0MPC14char4Char14escape_2einner(int32_t, int32_t);

int32_t _M0MPC14char4Char18escape__to_2einner(
  int32_t,
  struct _M0TPB6Logger,
  int32_t
);

int32_t _M0MPC14char4Char13is__printable(int32_t);

int32_t _M0MPC14char4Char11is__control(int32_t);

moonbit_string_t _M0MPC14char4Char7to__hex(int32_t);

int32_t _M0FPB7printlnGsE(moonbit_string_t);

moonbit_string_t _M0MPC16double6Double10to__string(double);

moonbit_string_t _M0FPB15ryu__to__string(double);

struct _M0TPB17FloatingDecimal64* _M0FPB15d2d__small__int(uint64_t, int32_t);

moonbit_string_t _M0FPB9to__chars(struct _M0TPB17FloatingDecimal64*, int32_t);

struct _M0TPB17FloatingDecimal64* _M0FPB3d2d(uint64_t, uint32_t);

uint64_t _M0MPC14bool4Bool10to__uint64(int32_t);

int64_t _M0MPC14bool4Bool9to__int64(int32_t);

int32_t _M0MPC14bool4Bool7to__int(int32_t);

int32_t _M0FPB17decimal__length17(uint64_t);

struct _M0TPB8Pow5Pair _M0FPB22double__computeInvPow5(int32_t);

struct _M0TPB8Pow5Pair _M0FPB19double__computePow5(int32_t);

struct _M0TPB19MulShiftAll64Result _M0FPB13mulShiftAll64(
  uint64_t,
  struct _M0TPB8Pow5Pair,
  int32_t,
  int32_t
);

int32_t _M0FPB18multipleOfPowerOf2(uint64_t, int32_t);

int32_t _M0FPB18multipleOfPowerOf5(uint64_t, int32_t);

int32_t _M0FPB10pow5Factor(uint64_t);

uint64_t _M0FPB13shiftright128(uint64_t, uint64_t, int32_t);

struct _M0TPB7Umul128 _M0FPB7umul128(uint64_t, uint64_t);

moonbit_string_t _M0FPB19string__from__bytes(
  moonbit_bytes_t,
  int32_t,
  int32_t
);

int32_t _M0FPB9log10Pow2(int32_t);

int32_t _M0FPB9log10Pow5(int32_t);

moonbit_string_t _M0FPB18copy__special__str(int32_t, int32_t, int32_t);

int32_t _M0FPB8pow5bits(int32_t);

int32_t _M0IPC13int3IntPB4Hash4hash(int32_t);

int32_t _M0IPC16string6StringPB4Hash4hash(moonbit_string_t);

int32_t _M0MPC13int3Int13is__surrogate(int32_t);

struct _M0TPB4IterGsE* _M0MPB4Iter4iterGsE(struct _M0TPB4IterGsE*);

int64_t _M0MPB4Iter10size__hintGsE(struct _M0TPB4IterGsE*);

struct _M0TPB5ArrayGRPC15debug7ContentE* _M0MPC15array5Array3mapGRPC15debug4ReprRPC15debug7ContentE(
  struct _M0TPB5ArrayGRPC15debug4ReprE*,
  struct _M0TWRPC15debug4ReprERPC15debug7Content*
);

struct _M0TPB5ArrayGRPC15debug7ContentE* _M0MPC15array5Array3mapGRPC15debug9ReprDeltaRPC15debug7ContentE(
  struct _M0TPB5ArrayGRPC15debug9ReprDeltaE*,
  struct _M0TWRPC15debug9ReprDeltaERPC15debug7Content*
);

struct _M0TPB5ArrayGRPC15debug13ContentParensE* _M0MPC15array5Array3mapGRPC15debug7ContentRPC15debug13ContentParensE(
  struct _M0TPB5ArrayGRPC15debug7ContentE*,
  struct _M0TWRPC15debug7ContentERPC15debug13ContentParens*
);

struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* _M0MPC15array5Array3mapGRPC15debug9ReprDeltaRPC15debug9ReprDeltaE(
  struct _M0TPB5ArrayGRPC15debug9ReprDeltaE*,
  struct _M0TWRPC15debug9ReprDeltaERPC15debug9ReprDelta*
);

struct _M0TPB5ArrayGRPC15debug4ReprE* _M0MPC15array5Array3mapGRPC15debug4ReprRPC15debug4ReprE(
  struct _M0TPB5ArrayGRPC15debug4ReprE*,
  struct _M0TWRPC15debug4ReprERPC15debug4Repr*
);

struct _M0TPB5ArrayGRPB5ArrayGsEE* _M0MPC15array5Array3mapGRPC15debug13ContentParensRPB5ArrayGsEE(
  struct _M0TPB5ArrayGRPC15debug13ContentParensE*,
  struct _M0TWRPC15debug13ContentParensERPB5ArrayGsE*
);

struct _M0TPB5ArrayGsE* _M0MPC15array5Array3mapGssE(
  struct _M0TPB5ArrayGsE*,
  struct _M0TWsEs*
);

struct _M0TUWEuQRPC15error5ErrorNsE* _M0MPB3Map3getGiUWEuQRPC15error5ErrorNsEE(
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE*,
  int32_t
);

struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0MPB3Map3getGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(
  struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*,
  moonbit_string_t
);

struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0MPB3Map3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(
  struct _M0TPB9ArrayViewGUsRPB3MapGiUWEuQRPC15error5ErrorNsEEEE,
  int64_t
);

struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0MPB3Map3MapGiUWEuQRPC15error5ErrorNsEE(
  struct _M0TPB9ArrayViewGUiUWEuQRPC15error5ErrorNsEEE,
  int64_t
);

int32_t _M0MPB3Map3setGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(
  struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*,
  moonbit_string_t,
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE*
);

int32_t _M0MPB3Map3setGiUWEuQRPC15error5ErrorNsEE(
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE*,
  int32_t,
  struct _M0TUWEuQRPC15error5ErrorNsE*
);

int32_t _M0MPB3Map15set__with__hashGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(
  struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*,
  moonbit_string_t,
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE*,
  int32_t
);

int32_t _M0MPB3Map15set__with__hashGiUWEuQRPC15error5ErrorNsEE(
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE*,
  int32_t,
  struct _M0TUWEuQRPC15error5ErrorNsE*,
  int32_t
);

int32_t _M0MPB3Map4growGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(
  struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*
);

int32_t _M0MPB3Map4growGiUWEuQRPC15error5ErrorNsEE(
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE*
);

int32_t _M0MPB3Map20rehash__place__entryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(
  struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*,
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*
);

int32_t _M0MPB3Map20rehash__place__entryGiUWEuQRPC15error5ErrorNsEE(
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE*,
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE*
);

int32_t _M0MPB3Map10push__awayGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(
  struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*,
  int32_t,
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*
);

int32_t _M0MPB3Map10push__awayGiUWEuQRPC15error5ErrorNsEE(
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE*,
  int32_t,
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE*
);

int32_t _M0MPB3Map10set__entryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(
  struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*,
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*,
  int32_t
);

int32_t _M0MPB3Map10set__entryGiUWEuQRPC15error5ErrorNsEE(
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE*,
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE*,
  int32_t
);

int32_t _M0MPB3Map20add__entry__to__tailGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(
  struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*,
  int32_t,
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*
);

int32_t _M0MPB3Map20add__entry__to__tailGiUWEuQRPC15error5ErrorNsEE(
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE*,
  int32_t,
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE*
);

int32_t _M0MPC13int3Int3max(int32_t, int32_t);

int32_t _M0FPB21capacity__for__length(int32_t);

struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0FPB8new__mapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(
  int32_t
);

struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0FPB8new__mapGiUWEuQRPC15error5ErrorNsEE(
  int32_t
);

int32_t _M0MPC13int3Int20next__power__of__two(int32_t);

int32_t _M0FPB21calc__grow__threshold(int32_t);

struct _M0TPB5ArrayGsE* _M0MPC15array5Array31unsafe__make__and__blit_2einnerGsE(
  moonbit_string_t*,
  int32_t,
  int32_t,
  int32_t,
  int32_t
);

struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0MPC16option6Option6unwrapGRPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEEE(
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*
);

struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0MPC16option6Option6unwrapGRPB5EntryGiUWEuQRPC15error5ErrorNsEEE(
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE*
);

moonbit_string_t _M0MPC15array9ArrayView4joinGsE(
  struct _M0TPB9ArrayViewGsE,
  struct _M0TPC16string10StringView
);

moonbit_string_t _M0MPC15array9ArrayView4joinGRPC16string10StringViewE(
  struct _M0TPB9ArrayViewGRPC16string10StringViewE,
  struct _M0TPC16string10StringView
);

struct _M0TPB5ArrayGRPC15debug7ContentE* _M0MPC15array5Array12make__uninitGRPC15debug7ContentE(
  int32_t
);

struct _M0TPB5ArrayGRPC15debug13ContentParensE* _M0MPC15array5Array12make__uninitGRPC15debug13ContentParensE(
  int32_t
);

struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* _M0MPC15array5Array12make__uninitGRPC15debug9ReprDeltaE(
  int32_t
);

struct _M0TPB5ArrayGRPC15debug4ReprE* _M0MPC15array5Array12make__uninitGRPC15debug4ReprE(
  int32_t
);

struct _M0TPB5ArrayGRPB5ArrayGsEE* _M0MPC15array5Array12make__uninitGRPB5ArrayGsEE(
  int32_t
);

struct _M0TPB5ArrayGsE* _M0MPC15array5Array12make__uninitGsE(int32_t);

struct _M0TPB4IterGsE* _M0MPC15array13ReadOnlyArray4iterGsE(
  moonbit_string_t*
);

uint64_t _M0MPC15array13ReadOnlyArray2atGmE(uint64_t*, int32_t);

uint32_t _M0MPC15array13ReadOnlyArray2atGjE(uint32_t*, int32_t);

struct _M0TPB4IterGsE* _M0MPC15array5Array4iterGsE(struct _M0TPB5ArrayGsE*);

struct _M0TPB4IterGsE* _M0MPC15array10FixedArray4iterGsE(moonbit_string_t*);

struct _M0TPB4IterGsE* _M0MPC15array9ArrayView4iterGsE(
  struct _M0TPB9ArrayViewGsE
);

moonbit_string_t _M0MPC15array9ArrayView4iterGsEC2613l717(struct _M0TWEOs*);

moonbit_string_t _M0IPC16uint646UInt64PB4Show10to__string(uint64_t);

moonbit_string_t _M0IPC13int3IntPB4Show10to__string(int32_t);

moonbit_string_t _M0IPC14bool4BoolPB4Show10to__string(int32_t);

uint64_t _M0MPC14uint4UInt10to__uint64(uint32_t);

struct _M0TPC16string10StringView _M0IPC16string10StringViewPB12ToStringView16to__string__view(
  struct _M0TPC16string10StringView
);

struct _M0TPC16string10StringView _M0IPC16string6StringPB12ToStringView16to__string__view(
  moonbit_string_t
);

struct _M0TPB4IterGsE* _M0MPB4Iter3mapGssE(
  struct _M0TPB4IterGsE*,
  struct _M0TWsEs*
);

moonbit_string_t _M0MPB4Iter3mapGssEC2606l367(struct _M0TWEOs*);

struct _M0TPC16string10StringView _M0MPC16string6String4trim(
  moonbit_string_t,
  void*
);

struct _M0TPC16string10StringView _M0MPC16string6String12trim_2einner(
  moonbit_string_t,
  struct _M0TPC16string10StringView
);

struct _M0TPC16string10StringView _M0MPC16string10StringView12trim_2einner(
  struct _M0TPC16string10StringView,
  struct _M0TPC16string10StringView
);

struct _M0TPC16string10StringView _M0MPC16string10StringView17trim__end_2einner(
  struct _M0TPC16string10StringView,
  struct _M0TPC16string10StringView
);

struct _M0TPC16string10StringView _M0MPC16string10StringView19trim__start_2einner(
  struct _M0TPC16string10StringView,
  struct _M0TPC16string10StringView
);

int32_t _M0MPC16string10StringView14contains__char(
  struct _M0TPC16string10StringView,
  int32_t
);

int32_t _M0MPC16string10StringView20contains__code__unit(
  struct _M0TPC16string10StringView,
  int32_t
);

int32_t _M0FPB28string__contains__code__unit(
  moonbit_string_t,
  int32_t,
  int32_t,
  int32_t
);

int32_t _M0FPB15v128__any__true(moonbit_v128_t);

int32_t _M0FPB36string__contains__code__unit__scalar(
  moonbit_string_t,
  int32_t,
  int32_t,
  int32_t
);

int32_t _M0MPC15array5Array4pushGsE(
  struct _M0TPB5ArrayGsE*,
  moonbit_string_t
);

int32_t _M0MPC15array5Array4pushGUsiEE(
  struct _M0TPB5ArrayGUsiEE*,
  struct _M0TUsiE*
);

int32_t _M0MPC15array5Array4pushGRPC15debug9ReprDeltaE(
  struct _M0TPB5ArrayGRPC15debug9ReprDeltaE*,
  void*
);

int32_t _M0MPC15array5Array4pushGRPC16string10StringViewE(
  struct _M0TPB5ArrayGRPC16string10StringViewE*,
  struct _M0TPC16string10StringView
);

int32_t _M0MPC15array5Array7reallocGsE(struct _M0TPB5ArrayGsE*, int32_t);

int32_t _M0MPC15array5Array7reallocGUsiEE(
  struct _M0TPB5ArrayGUsiEE*,
  int32_t
);

int32_t _M0MPC15array5Array7reallocGRPC15debug9ReprDeltaE(
  struct _M0TPB5ArrayGRPC15debug9ReprDeltaE*,
  int32_t
);

int32_t _M0MPC15array5Array7reallocGRPC16string10StringViewE(
  struct _M0TPB5ArrayGRPC16string10StringViewE*,
  int32_t
);

int32_t _M0MPC15array5Array14resize__bufferGsE(
  struct _M0TPB5ArrayGsE*,
  int32_t
);

int32_t _M0MPC15array5Array14resize__bufferGUsiEE(
  struct _M0TPB5ArrayGUsiEE*,
  int32_t
);

int32_t _M0MPC15array5Array14resize__bufferGRPC15debug9ReprDeltaE(
  struct _M0TPB5ArrayGRPC15debug9ReprDeltaE*,
  int32_t
);

int32_t _M0MPC15array5Array14resize__bufferGRPC16string10StringViewE(
  struct _M0TPB5ArrayGRPC16string10StringViewE*,
  int32_t
);

int32_t _M0MPC15array5Array8capacityGsE(struct _M0TPB5ArrayGsE*);

int32_t _M0MPC15array5Array8capacityGUsiEE(struct _M0TPB5ArrayGUsiEE*);

int32_t _M0MPC15array5Array8capacityGRPC15debug9ReprDeltaE(
  struct _M0TPB5ArrayGRPC15debug9ReprDeltaE*
);

int32_t _M0MPC15array5Array8capacityGRPC16string10StringViewE(
  struct _M0TPB5ArrayGRPC16string10StringViewE*
);

int32_t _M0FPB23array__growth__capacity(int32_t, int32_t, int32_t);

int32_t _M0MPC15array5Array6lengthGRP27walkzzz11mcp__server8CategoryE(
  struct _M0TPB5ArrayGRP27walkzzz11mcp__server8CategoryE*
);

moonbit_string_t* _M0MPC15array5Array6bufferGsE(struct _M0TPB5ArrayGsE*);

struct _M0TUsiE** _M0MPC15array5Array6bufferGUsiEE(
  struct _M0TPB5ArrayGUsiEE*
);

void** _M0MPC15array5Array6bufferGRPC15debug9ReprDeltaE(
  struct _M0TPB5ArrayGRPC15debug9ReprDeltaE*
);

void** _M0MPC15array5Array6bufferGRPC15debug4ReprE(
  struct _M0TPB5ArrayGRPC15debug4ReprE*
);

struct _M0TPC16string10StringView* _M0MPC15array5Array6bufferGRPC16string10StringViewE(
  struct _M0TPB5ArrayGRPC16string10StringViewE*
);

void* _M0MPC16string10StringView13strip__prefix(
  struct _M0TPC16string10StringView,
  struct _M0TPC16string10StringView
);

void* _M0MPC16string6String13strip__suffix(
  moonbit_string_t,
  struct _M0TPC16string10StringView
);

void* _M0MPC16string10StringView13strip__suffix(
  struct _M0TPC16string10StringView,
  struct _M0TPC16string10StringView
);

int32_t _M0MPC16string6String11has__suffix(
  moonbit_string_t,
  struct _M0TPC16string10StringView
);

int32_t _M0MPC16string10StringView11has__suffix(
  struct _M0TPC16string10StringView,
  struct _M0TPC16string10StringView
);

moonbit_string_t _M0MPC16string6String6repeat(moonbit_string_t, int32_t);

moonbit_string_t _M0IPC16string6StringPB4Show10to__string(moonbit_string_t);

moonbit_v128_t _M0FPB17v128__load__i16x8(moonbit_string_t, int32_t);

moonbit_v128_t _M0FPB12i16x8__splat(int32_t);

moonbit_v128_t _M0FPB9i16x8__eq(moonbit_v128_t, moonbit_v128_t);

uint64_t _M0FPB18u64__u16__eq__mask(uint64_t, uint64_t);

int32_t _M0IPB13StringBuilderPB6Logger11write__view(
  struct _M0TPB13StringBuilder*,
  struct _M0TPC16string10StringView
);

int64_t _M0MPC16string6String29offset__of__nth__char_2einner(
  moonbit_string_t,
  int32_t,
  int32_t,
  int64_t
);

int64_t _M0MPC16string6String30offset__of__nth__char__forward(
  moonbit_string_t,
  int32_t,
  int32_t,
  int32_t
);

int64_t _M0MPC16string6String31offset__of__nth__char__backward(
  moonbit_string_t,
  int32_t,
  int32_t,
  int32_t
);

int32_t _M0IPC16string10StringViewPB2Eq5equal(
  struct _M0TPC16string10StringView,
  struct _M0TPC16string10StringView
);

int32_t _M0MPC16string6String20unsafe__range__equal(
  moonbit_string_t,
  int32_t,
  moonbit_string_t,
  int32_t,
  int32_t
);

int32_t _M0IPC16string10StringViewPB4Show6output(
  struct _M0TPC16string10StringView,
  struct _M0TPB6Logger
);

moonbit_string_t _M0MPC16string6String17unsafe__substring(
  moonbit_string_t,
  int32_t,
  int32_t
);

moonbit_string_t _M0MPC15bytes5Bytes29to__unchecked__string_2einner(
  moonbit_bytes_t,
  int32_t,
  int64_t
);

#define _M0FPB19unsafe__sub__string moonbit_unsafe_bytes_sub_string

int32_t _M0MPC15array10FixedArray18blit__from__string(
  moonbit_bytes_t,
  int32_t,
  moonbit_string_t,
  int32_t,
  int32_t
);

int32_t _M0MPC14uint4UInt8to__byte(uint32_t);

struct _M0TPB4IterGsE* _M0MPB4Iter3newGsE(struct _M0TWEOs*, int64_t);

struct moonbit_result_0 _M0FPB4failGuE(
  struct _M0TPC16string10StringView,
  moonbit_string_t
);

moonbit_string_t _M0MPC16uint646UInt6418to__string_2einner(uint64_t, int32_t);

int32_t _M0FPB22int64__to__string__dec(uint16_t*, uint64_t, int32_t, int32_t);

int32_t _M0FPB26int64__to__string__generic(
  uint16_t*,
  uint64_t,
  int32_t,
  int32_t,
  int32_t
);

int32_t _M0FPB22int64__to__string__hex(uint16_t*, uint64_t, int32_t, int32_t);

int32_t _M0FPB14radix__count64(uint64_t, int32_t);

int32_t _M0FPB12hex__count64(uint64_t);

int32_t _M0FPB12dec__count64(uint64_t);

moonbit_string_t _M0MPC13int3Int18to__string_2einner(int32_t, int32_t);

int32_t _M0FPB14radix__count32(uint32_t, int32_t);

int32_t _M0FPB12hex__count32(uint32_t);

int32_t _M0FPB12dec__count32(uint32_t);

int32_t _M0FPB20int__to__string__dec(uint16_t*, uint32_t, int32_t, int32_t);

int32_t _M0FPB24int__to__string__generic(
  uint16_t*,
  uint32_t,
  int32_t,
  int32_t,
  int32_t
);

int32_t _M0FPB20int__to__string__hex(uint16_t*, uint32_t, int32_t, int32_t);

moonbit_string_t _M0MPB4Iter4nextGsE(struct _M0TPB4IterGsE*);

moonbit_string_t _M0IP016_24default__implPB4Show10to__stringGRPB7FailureE(
  void*
);

int32_t _M0IP016_24default__implPB4Show6outputGsE(
  moonbit_string_t,
  struct _M0TPB6Logger
);

int32_t _M0IP016_24default__implPB4Show6outputGiE(
  int32_t,
  struct _M0TPB6Logger
);

int32_t _M0IP016_24default__implPB4Show6outputGmE(
  uint64_t,
  struct _M0TPB6Logger
);

int32_t _M0MPC16string10StringView13start__offset(
  struct _M0TPC16string10StringView
);

moonbit_string_t _M0MPC16string10StringView4data(
  struct _M0TPC16string10StringView
);

int32_t _M0IP016_24default__implPB6Logger16write__substringGRPB13StringBuilderE(
  struct _M0TPB13StringBuilder*,
  moonbit_string_t,
  int32_t,
  int32_t
);

struct _M0TPC16string10StringView _M0MPC16string6String11sub_2einner(
  moonbit_string_t,
  int32_t,
  int64_t
);

int32_t _M0IP016_24default__implPB6Logger5writeGRPB13StringBuilderE(
  struct _M0TPB13StringBuilder*,
  struct _M0TPB4Show
);

int32_t _M0IP016_24default__implPB6Logger28write__string__interpolationGRPB13StringBuilderE(
  struct _M0TPB13StringBuilder*,
  struct _M0TPB4Show
);

int32_t _M0FPB13finalize__acc(uint32_t);

uint32_t _M0FPB14avalanche__acc(uint32_t);

int32_t _M0IP016_24default__implPB2Eq10not__equalGRPC16string10StringViewE(
  struct _M0TPC16string10StringView,
  struct _M0TPC16string10StringView
);

int32_t _M0IP016_24default__implPB2Eq10not__equalGsE(
  moonbit_string_t,
  moonbit_string_t
);

uint64_t _M0MPC16uint166UInt1610to__uint64(int32_t);

uint64_t _M0MPC13int3Int10to__uint64(int32_t);

int32_t _M0IPC16uint166UInt16PB7Default7default();

int32_t _M0IPB13StringBuilderPB6Logger13write__string(
  struct _M0TPB13StringBuilder*,
  moonbit_string_t
);

int32_t _M0MPC15array10FixedArray26unsafe__blit__from__string(
  uint16_t*,
  int32_t,
  moonbit_string_t,
  int32_t,
  int32_t
);

struct _M0TPC16string10StringView _M0MPC16string10StringView12view_2einner(
  struct _M0TPC16string10StringView,
  int32_t,
  int64_t
);

moonbit_string_t _M0MPC16string6String14escape_2einner(
  moonbit_string_t,
  int32_t
);

int32_t _M0MPC16string10StringView18escape__to_2einner(
  struct _M0TPC16string10StringView,
  struct _M0TPB6Logger,
  int32_t
);

int32_t _M0MPC16string10StringView18escape__to_2einnerN14flush__segmentS4266(
  struct _M0TURPB6LoggerRPC16string10StringViewE*,
  int32_t,
  int32_t
);

struct _M0TPC16string10StringView _M0MPC16string10StringView11sub_2einner(
  struct _M0TPC16string10StringView,
  int32_t,
  int64_t
);

moonbit_string_t _M0MPC14byte4Byte7to__hex(int32_t);

int32_t _M0MPC14byte4Byte7to__hexN14to__hex__digitS4281(int32_t);

int32_t _M0IPC14byte4BytePB3Sub3sub(int32_t, int32_t);

int32_t _M0IPC14byte4BytePB3Mod3mod(int32_t, int32_t);

int32_t _M0IPC14byte4BytePB3Div3div(int32_t, int32_t);

int32_t _M0IPC14byte4BytePB3Add3add(int32_t, int32_t);

int32_t _M0MPC16string6String16unsafe__char__at(moonbit_string_t, int32_t);

int32_t _M0MPC16uint166UInt1616unsafe__to__char(int32_t);

int32_t _M0FPB32code__point__of__surrogate__pair(int32_t, int32_t);

int32_t _M0MPC16uint166UInt1623is__trailing__surrogate(int32_t);

int32_t _M0MPC16uint166UInt1622is__leading__surrogate(int32_t);

int32_t _M0IPB13StringBuilderPB6Logger11write__char(
  struct _M0TPB13StringBuilder*,
  int32_t
);

int32_t _M0MPB13StringBuilder4grow(struct _M0TPB13StringBuilder*, int32_t);

int32_t _M0FPB31stringbuilder__growth__capacity(int32_t, int32_t, int32_t);

int32_t _M0MPC14uint4UInt10to__uint16(uint32_t);

uint32_t _M0MPC14char4Char8to__uint(int32_t);

moonbit_string_t _M0MPB13StringBuilder10to__string(
  struct _M0TPB13StringBuilder*
);

uint16_t* _M0MPC15array10FixedArray23make__and__blit_2einnerGkE(
  uint16_t*,
  int32_t,
  int32_t,
  int32_t,
  int32_t,
  int32_t
);

uint16_t* _M0MPC15array10FixedArray23unsafe__make__and__blitGkE(
  uint16_t*,
  int32_t,
  int32_t,
  int32_t,
  int32_t,
  int32_t
);

struct _M0TPB13StringBuilder* _M0MPB13StringBuilder21StringBuilder_2einner(
  int32_t
);

int32_t _M0MPC14byte4Byte8to__char(int32_t);

moonbit_string_t* _M0MPB18UninitializedArray23make__and__blit_2einnerGsE(
  moonbit_string_t*,
  int32_t,
  int32_t,
  int32_t,
  int32_t
);

struct _M0TUsiE** _M0MPB18UninitializedArray23make__and__blit_2einnerGUsiEE(
  struct _M0TUsiE**,
  int32_t,
  int32_t,
  int32_t,
  int32_t
);

void** _M0MPB18UninitializedArray23make__and__blit_2einnerGRPC15debug9ReprDeltaE(
  void**,
  int32_t,
  int32_t,
  int32_t,
  int32_t
);

struct _M0TPC16string10StringView* _M0MPB18UninitializedArray23make__and__blit_2einnerGRPC16string10StringViewE(
  struct _M0TPC16string10StringView*,
  int32_t,
  int32_t,
  int32_t,
  int32_t
);

int32_t _M0MPB13StringBuilder13write__objectGsE(
  struct _M0TPB13StringBuilder*,
  moonbit_string_t
);

int32_t _M0MPB13StringBuilder13write__objectGiE(
  struct _M0TPB13StringBuilder*,
  int32_t
);

int32_t _M0MPB13StringBuilder13write__objectGRPB9SourceLocE(
  struct _M0TPB13StringBuilder*,
  moonbit_string_t
);

int32_t _M0MPB13StringBuilder13write__objectGRPC16string10StringViewE(
  struct _M0TPB13StringBuilder*,
  struct _M0TPC16string10StringView
);

int32_t _M0MPB13StringBuilder13write__objectGmE(
  struct _M0TPB13StringBuilder*,
  uint64_t
);

moonbit_string_t* _M0MPB18UninitializedArray23unsafe__make__and__blitGsE(
  moonbit_string_t*,
  int32_t,
  int32_t,
  int32_t,
  int32_t
);

struct _M0TUsiE** _M0MPB18UninitializedArray23unsafe__make__and__blitGUsiEE(
  struct _M0TUsiE**,
  int32_t,
  int32_t,
  int32_t,
  int32_t
);

void** _M0MPB18UninitializedArray23unsafe__make__and__blitGRPC15debug9ReprDeltaE(
  void**,
  int32_t,
  int32_t,
  int32_t,
  int32_t
);

struct _M0TPC16string10StringView* _M0MPB18UninitializedArray23unsafe__make__and__blitGRPC16string10StringViewE(
  struct _M0TPC16string10StringView*,
  int32_t,
  int32_t,
  int32_t,
  int32_t
);

int32_t _M0MPB18UninitializedArray12unsafe__blitGsE(
  moonbit_string_t*,
  int32_t,
  moonbit_string_t*,
  int32_t,
  int32_t
);

int32_t _M0MPB18UninitializedArray12unsafe__blitGUsiEE(
  struct _M0TUsiE**,
  int32_t,
  struct _M0TUsiE**,
  int32_t,
  int32_t
);

int32_t _M0MPB18UninitializedArray12unsafe__blitGRPC15debug9ReprDeltaE(
  void**,
  int32_t,
  void**,
  int32_t,
  int32_t
);

int32_t _M0MPB18UninitializedArray12unsafe__blitGRPC16string10StringViewE(
  struct _M0TPC16string10StringView*,
  int32_t,
  struct _M0TPC16string10StringView*,
  int32_t,
  int32_t
);

int32_t _M0MPC15array10FixedArray12unsafe__blitGkE(
  uint16_t*,
  int32_t,
  uint16_t*,
  int32_t,
  int32_t
);

int32_t _M0MPC15array10FixedArray12unsafe__blitGRPB17UnsafeMaybeUninitGsEE(
  moonbit_string_t*,
  int32_t,
  moonbit_string_t*,
  int32_t,
  int32_t
);

int32_t _M0MPC15array10FixedArray12unsafe__blitGRPB17UnsafeMaybeUninitGUsiEEE(
  struct _M0TUsiE**,
  int32_t,
  struct _M0TUsiE**,
  int32_t,
  int32_t
);

int32_t _M0MPC15array10FixedArray12unsafe__blitGRPB17UnsafeMaybeUninitGRPC15debug9ReprDeltaEE(
  void**,
  int32_t,
  void**,
  int32_t,
  int32_t
);

int32_t _M0MPC15array10FixedArray12unsafe__blitGRPB17UnsafeMaybeUninitGRPC16string10StringViewEE(
  struct _M0TPC16string10StringView*,
  int32_t,
  struct _M0TPC16string10StringView*,
  int32_t,
  int32_t
);

int32_t _M0MPB18UninitializedArray6lengthGsE(moonbit_string_t*);

int32_t _M0MPB18UninitializedArray6lengthGUsiEE(struct _M0TUsiE**);

int32_t _M0MPB18UninitializedArray6lengthGRPC15debug9ReprDeltaE(void**);

int32_t _M0MPB18UninitializedArray6lengthGRPC16string10StringViewE(
  struct _M0TPC16string10StringView*
);

uint32_t _M0FPB13consume4__acc(uint32_t, uint32_t);

uint32_t _M0FPB4rotl(uint32_t, int32_t);

int32_t _M0IPB7FailurePB4Show6output(void*, struct _M0TPB6Logger);

int32_t _M0MPB6Logger13write__objectGsE(
  struct _M0TPB6Logger,
  moonbit_string_t
);

int32_t _M0FPC15abort5abortGuE(moonbit_string_t);

uint16_t* _M0FPC15abort5abortGAkE(moonbit_string_t);

moonbit_string_t* _M0FPC15abort5abortGRPB18UninitializedArrayGsEE(
  moonbit_string_t
);

struct _M0TUsiE** _M0FPC15abort5abortGRPB18UninitializedArrayGUsiEEE(
  moonbit_string_t
);

struct _M0TPB9ArrayViewGRPC15debug4ReprE _M0FPC15abort5abortGRPB9ArrayViewGRPC15debug4ReprEE(
  moonbit_string_t
);

moonbit_string_t _M0FPC15abort5abortGsE(moonbit_string_t);

struct _M0TPC16string10StringView _M0FPC15abort5abortGRPC16string10StringViewE(
  moonbit_string_t
);

void** _M0FPC15abort5abortGRPB18UninitializedArrayGRPC15debug9ReprDeltaEE(
  moonbit_string_t
);

int32_t _M0FPC15abort5abortGiE(moonbit_string_t);

struct _M0TPC16string10StringView* _M0FPC15abort5abortGRPB18UninitializedArrayGRPC16string10StringViewEE(
  moonbit_string_t
);

int64_t _M0FPC15abort5abortGOiE(moonbit_string_t);

moonbit_string_t _M0FP15Error10to__string(void*);

int32_t _M0IP016_24default__implPB6Logger61write_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLoggerGRPB13StringBuilderE(
  void*,
  struct _M0TPB4Show
);

int32_t _M0IP016_24default__implPB6Logger84write__string__interpolation_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLoggerGRPB13StringBuilderE(
  void*,
  struct _M0TPB4Show
);

int32_t _M0IPB13StringBuilderPB6Logger67write__char_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLogger(
  void*,
  int32_t
);

int32_t _M0IPB13StringBuilderPB6Logger67write__view_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLogger(
  void*,
  struct _M0TPC16string10StringView
);

int32_t _M0IP016_24default__implPB6Logger72write__substring_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLoggerGRPB13StringBuilderE(
  void*,
  moonbit_string_t,
  int32_t,
  int32_t
);

int32_t _M0IPB13StringBuilderPB6Logger69write__string_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLogger(
  void*,
  moonbit_string_t
);

moonbit_string_t* moonbit_rt_get_cli_args();

struct { int32_t rc; uint32_t meta; uint16_t const data[25]; 
} const moonbit_string_literal_38 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 24, 86, 105, 
    101, 119, 32, 105, 110, 100, 101, 120, 32, 111, 117, 116, 32, 111, 
    102, 32, 98, 111, 117, 110, 100, 115, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[13]; 
} const moonbit_string_literal_6 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 12, 115, 107, 
    105, 112, 112, 101, 100, 32, 116, 101, 115, 116, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[1]; 
} const moonbit_string_literal_1 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 0, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[3]; 
} const moonbit_string_literal_32 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 2, 58, 32, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[3]; 
} const moonbit_string_literal_35 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 2, 123, 125, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[2]; 
} const moonbit_string_literal_3 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 1, 44, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[53]; 
} const moonbit_string_literal_69 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 52, 109, 111, 
    111, 110, 98, 105, 116, 108, 97, 110, 103, 47, 99, 111, 114, 101, 
    47, 98, 117, 105, 108, 116, 105, 110, 46, 83, 110, 97, 112, 115, 
    104, 111, 116, 69, 114, 114, 111, 114, 46, 83, 110, 97, 112, 115, 
    104, 111, 116, 69, 114, 114, 111, 114, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[3]; 
} const moonbit_string_literal_39 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 2, 92, 110, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[31]; 
} const moonbit_string_literal_56 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 30, 114, 97, 
    100, 105, 120, 32, 109, 117, 115, 116, 32, 98, 101, 32, 98, 101, 
    116, 119, 101, 101, 110, 32, 50, 32, 97, 110, 100, 32, 51, 54, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[9]; 
} const moonbit_string_literal_47 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 8, 73, 110, 
    102, 105, 110, 105, 116, 121, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[4]; 
} const moonbit_string_literal_46 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 3, 78, 97, 78, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[25]; 
} const moonbit_string_literal_8 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 24, 123, 34, 
    116, 121, 112, 101, 34, 58, 34, 114, 101, 115, 117, 108, 116, 34, 
    44, 34, 102, 105, 108, 101, 34, 58, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[10]; 
} const moonbit_string_literal_55 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 9, 32, 70, 
    65, 73, 76, 69, 68, 58, 32, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[2]; 
} const moonbit_string_literal_44 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 1, 48, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[9]; 
} const moonbit_string_literal_64 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 8, 44, 32, 
    108, 101, 110, 32, 61, 32, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[6]; 
} const moonbit_string_literal_50 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 5, 102, 97, 
    108, 115, 101, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[101]; 
} const moonbit_string_literal_70 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 100, 119, 97, 
    108, 107, 122, 122, 122, 47, 109, 99, 112, 95, 115, 101, 114, 118, 
    101, 114, 95, 98, 108, 97, 99, 107, 98, 111, 120, 95, 116, 101, 115, 
    116, 46, 77, 111, 111, 110, 66, 105, 116, 84, 101, 115, 116, 68, 
    114, 105, 118, 101, 114, 73, 110, 116, 101, 114, 110, 97, 108, 83, 
    107, 105, 112, 84, 101, 115, 116, 46, 77, 111, 111, 110, 66, 105, 
    116, 84, 101, 115, 116, 68, 114, 105, 118, 101, 114, 73, 110, 116, 
    101, 114, 110, 97, 108, 83, 107, 105, 112, 84, 101, 115, 116, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[37]; 
} const moonbit_string_literal_61 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 36, 98, 111, 
    117, 110, 100, 115, 32, 99, 104, 101, 99, 107, 32, 102, 97, 105, 
    108, 101, 100, 58, 32, 97, 108, 108, 111, 99, 97, 116, 101, 95, 108, 
    101, 110, 32, 61, 32, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[18]; 
} const moonbit_string_literal_71 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 17, 97, 108, 
    108, 95, 99, 97, 116, 101, 103, 111, 114, 105, 101, 115, 32, 38271,
    24230, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[5]; 
} const moonbit_string_literal_0 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 4, 9, 10, 13, 32, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[3]; 
} const moonbit_string_literal_36 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 2, 123, 32, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[2]; 
} const moonbit_string_literal_25 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 1, 91, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[2]; 
} const moonbit_string_literal_23 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 1, 41, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[37]; 
} const moonbit_string_literal_57 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 36, 48, 49, 
    50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102, 103, 104, 
    105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 
    118, 119, 120, 121, 122, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[2]; 
} const moonbit_string_literal_2 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 1, 32, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[51]; 
} const moonbit_string_literal_67 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 50, 109, 111, 
    111, 110, 98, 105, 116, 108, 97, 110, 103, 47, 99, 111, 114, 101, 
    47, 98, 117, 105, 108, 116, 105, 110, 46, 73, 110, 115, 112, 101, 
    99, 116, 69, 114, 114, 111, 114, 46, 73, 110, 115, 112, 101, 99, 
    116, 69, 114, 114, 111, 114, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[16]; 
} const moonbit_string_literal_65 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 15, 44, 32, 
    115, 114, 99, 46, 108, 101, 110, 103, 116, 104, 32, 61, 32, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[2]; 
} const moonbit_string_literal_5 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 1, 10, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[2]; 
} const moonbit_string_literal_33 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 1, 61, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[3]; 
} const moonbit_string_literal_31 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 2, 32, 32, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[33]; 
} const moonbit_string_literal_12 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 32, 45, 45, 
    45, 45, 45, 32, 69, 78, 68, 32, 77, 79, 79, 78, 32, 84, 69, 83, 84, 
    32, 82, 69, 83, 85, 76, 84, 32, 45, 45, 45, 45, 45, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[16]; 
} const moonbit_string_literal_62 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 15, 44, 32, 
    115, 114, 99, 95, 111, 102, 102, 115, 101, 116, 32, 61, 32, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[2]; 
} const moonbit_string_literal_30 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 1, 58, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[44]; 
} const moonbit_string_literal_14 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 43, 101, 120, 
    112, 101, 110, 115, 101, 46, 109, 98, 116, 58, 49, 51, 50, 58, 55, 
    45, 49, 51, 50, 58, 53, 56, 64, 119, 97, 108, 107, 122, 122, 122, 
    47, 109, 99, 112, 95, 115, 101, 114, 118, 101, 114, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[24]; 
} const moonbit_string_literal_13 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 23, 123, 34, 
    116, 121, 112, 101, 34, 58, 34, 115, 116, 97, 114, 116, 34, 44, 34, 
    102, 105, 108, 101, 34, 58, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[24]; 
} const moonbit_string_literal_51 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 23, 65, 114, 
    114, 97, 121, 32, 99, 97, 112, 97, 99, 105, 116, 121, 32, 111, 118, 
    101, 114, 102, 108, 111, 119, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[10]; 
} const moonbit_string_literal_9 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 9, 44, 34, 
    105, 110, 100, 101, 120, 34, 58, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[26]; 
} const moonbit_string_literal_45 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 25, 73, 108, 
    108, 101, 103, 97, 108, 65, 114, 103, 117, 109, 101, 110, 116, 69, 
    120, 99, 101, 112, 116, 105, 111, 110, 32, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[9]; 
} const moonbit_string_literal_66 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 8, 70, 97, 
    105, 108, 117, 114, 101, 40, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[32]; 
} const moonbit_string_literal_60 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 31, 83, 116, 
    114, 105, 110, 103, 66, 117, 105, 108, 100, 101, 114, 32, 99, 97, 
    112, 97, 99, 105, 116, 121, 32, 111, 118, 101, 114, 102, 108, 111, 
    119, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[2]; 
} const moonbit_string_literal_29 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 1, 62, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[24]; 
} const moonbit_string_literal_53 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 23, 114, 101, 
    112, 101, 97, 116, 32, 114, 101, 115, 117, 108, 116, 32, 116, 111, 
    111, 32, 108, 97, 114, 103, 101, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[2]; 
} const moonbit_string_literal_11 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 1, 125, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[12]; 
} const moonbit_string_literal_72 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 11, 101, 120, 
    112, 101, 110, 115, 101, 46, 109, 98, 116, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[2]; 
} const moonbit_string_literal_22 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 1, 43, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[35]; 
} const moonbit_string_literal_7 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 34, 45, 45, 
    45, 45, 45, 32, 66, 69, 71, 73, 78, 32, 77, 79, 79, 78, 32, 84, 69, 
    83, 84, 32, 82, 69, 83, 85, 76, 84, 32, 45, 45, 45, 45, 45, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[3]; 
} const moonbit_string_literal_42 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 2, 92, 116, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[3]; 
} const moonbit_string_literal_40 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 2, 92, 114, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[4]; 
} const moonbit_string_literal_34 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 3, 46, 46, 46, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[16]; 
} const moonbit_string_literal_63 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 15, 44, 32, 
    100, 115, 116, 95, 111, 102, 102, 115, 101, 116, 32, 61, 32, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[19]; 
} const moonbit_string_literal_59 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 18, 105, 110, 
    118, 97, 108, 105, 100, 32, 99, 111, 100, 101, 32, 112, 111, 105, 
    110, 116, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[2]; 
} const moonbit_string_literal_20 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 1, 45, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[12]; 
} const moonbit_string_literal_10 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 11, 44, 34, 
    109, 101, 115, 115, 97, 103, 101, 34, 58, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[23]; 
} const moonbit_string_literal_58 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 22, 73, 110, 
    118, 97, 108, 105, 100, 32, 105, 110, 100, 101, 120, 32, 102, 111, 
    114, 32, 86, 105, 101, 119, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[2]; 
} const moonbit_string_literal_15 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 1, 96, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[4]; 
} const moonbit_string_literal_43 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 3, 92, 117, 123, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[6]; 
} const moonbit_string_literal_24 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 5, 84, 117, 
    112, 108, 101, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[5]; 
} const moonbit_string_literal_19 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 4, 27, 91, 
    48, 109, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[3]; 
} const moonbit_string_literal_37 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 2, 32, 125, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[2]; 
} const moonbit_string_literal_26 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 1, 93, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[5]; 
} const moonbit_string_literal_49 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 4, 116, 114, 
    117, 101, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[20]; 
} const moonbit_string_literal_54 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 19, 73, 110, 
    118, 97, 108, 105, 100, 32, 115, 116, 97, 114, 116, 32, 105, 110, 
    100, 101, 120, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[3]; 
} const moonbit_string_literal_41 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 2, 92, 98, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[2]; 
} const moonbit_string_literal_27 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 1, 123, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[7]; 
} const moonbit_string_literal_21 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 6, 27, 91, 
    51, 50, 109, 43, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[2]; 
} const moonbit_string_literal_4 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 1, 40, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[2]; 
} const moonbit_string_literal_28 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 1, 60, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[7]; 
} const moonbit_string_literal_18 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 6, 27, 91, 
    51, 49, 109, 45, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[22]; 
} const moonbit_string_literal_52 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 21, 110, 101, 
    103, 97, 116, 105, 118, 101, 32, 114, 101, 112, 101, 97, 116, 32, 
    99, 111, 117, 110, 116, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[9]; 
} const moonbit_string_literal_17 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 8, 96, 10, 
    100, 105, 102, 102, 58, 10, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[5]; 
} const moonbit_string_literal_16 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 4, 32, 33, 
    61, 32, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[99]; 
} const moonbit_string_literal_68 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 98, 119, 97, 
    108, 107, 122, 122, 122, 47, 109, 99, 112, 95, 115, 101, 114, 118, 
    101, 114, 95, 98, 108, 97, 99, 107, 98, 111, 120, 95, 116, 101, 115, 
    116, 46, 77, 111, 111, 110, 66, 105, 116, 84, 101, 115, 116, 68, 
    114, 105, 118, 101, 114, 73, 110, 116, 101, 114, 110, 97, 108, 74, 
    115, 69, 114, 114, 111, 114, 46, 77, 111, 111, 110, 66, 105, 116, 
    84, 101, 115, 116, 68, 114, 105, 118, 101, 114, 73, 110, 116, 101, 
    114, 110, 97, 108, 74, 115, 69, 114, 114, 111, 114, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[4]; 
} const moonbit_string_literal_48 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 3, 48, 46, 48, 0};

struct moonbit_object const moonbit_constant_constructor_0 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0)
  };

struct moonbit_object const moonbit_constant_constructor_17 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 17)
  };

struct { int32_t rc; uint32_t meta; struct _M0TWRPC15debug9ReprDeltaEb data; 
} const _M0FPC15debug16diff__info__withN2goS142C3850l122$closure =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0),
    _M0FPC15debug16diff__info__withN2goS142C3850l122
  };

struct { int32_t rc; uint32_t meta; struct _M0TWRPC15error5ErrorEs data; 
} const _M0FP27walkzzz27mcp__server__blackbox__test44moonbit__test__driver__internal__do__executeN17error__to__stringS1906$closure =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0),
    _M0FP27walkzzz27mcp__server__blackbox__test44moonbit__test__driver__internal__do__executeN17error__to__stringS1906
  };

struct {
  int32_t rc;
  uint32_t meta;
  struct _M0TWRPC15debug7ContentERPC15debug13ContentParens data;
  
} const _M0MPC15debug4Repr13pretty__printC3769l167$closure =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0),
    _M0MPC15debug4Repr13pretty__printC3769l167
  };

struct {
  int32_t rc;
  uint32_t meta;
  struct _M0TWRPC15debug13ContentParensERPB5ArrayGsE data;
  
} const _M0FPC15debug10comma__seqC3633l427$closure =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0),
    _M0FPC15debug10comma__seqC3633l427
  };

struct {
  int32_t rc;
  uint32_t meta;
  struct _M0TWRPC15debug7ContentERPC15debug13ContentParens data;
  
} const _M0MPC15debug4Repr13pretty__printC3778l158$closure =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0),
    _M0MPC15debug4Repr13pretty__printC3778l158
  };

struct { int32_t rc; uint32_t meta; struct _M0TWEu data; 
} const _M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test28MoonBit__Async__Test__Driver30is__being__cancelled_2edyncallGRP27walkzzz27mcp__server__blackbox__test34MoonBit__Async__Test__Driver__ImplE$closure =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0),
    _M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test28MoonBit__Async__Test__Driver30is__being__cancelled_2edyncallGRP27walkzzz27mcp__server__blackbox__test34MoonBit__Async__Test__Driver__ImplE
  };

struct { int32_t rc; uint32_t meta; struct _M0TWsEb data; 
} const _M0FPC15debug19bracket__seq__linesC3536l309$closure =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0),
    _M0FPC15debug19bracket__seq__linesC3536l309
  };

struct { int32_t rc; uint32_t meta; struct _M0TWsEs data; 
} const _M0FPC15debug17comma__seq__linesC3583l386$closure =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0),
    _M0FPC15debug17comma__seq__linesC3583l386
  };

struct {
  int32_t rc;
  uint32_t meta;
  struct _M0TWRPC15debug7ContentERPC15debug13ContentParens data;
  
} const _M0MPC15debug4Repr13pretty__printC3784l153$closure =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0),
    _M0MPC15debug4Repr13pretty__printC3784l153
  };

struct {
  int32_t rc;
  uint32_t meta;
  struct _M0TWRPC15debug7ContentERPC15debug13ContentParens data;
  
} const _M0MPC15debug4Repr13pretty__printC3789l155$closure =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0),
    _M0MPC15debug4Repr13pretty__printC3789l155
  };

struct {
  int32_t rc;
  uint32_t meta;
  struct _M0TWRPC15debug7ContentERPC15debug13ContentParens data;
  
} const _M0MPC15debug4Repr13pretty__printC3757l172$closure =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0),
    _M0MPC15debug4Repr13pretty__printC3757l172
  };

struct { int32_t rc; uint32_t meta; struct _M0TWsEb data; 
} const _M0FPC15debug17comma__seq__linesC3597l379$closure =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0),
    _M0FPC15debug17comma__seq__linesC3597l379
  };

struct { int32_t rc; uint32_t meta; struct _M0TWsEb data; 
} const _M0FPC15debug17comma__seq__linesC3621l395$closure =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0),
    _M0FPC15debug17comma__seq__linesC3621l395
  };

struct {
  int32_t rc;
  uint32_t meta;
  struct _M0TWRPC15debug7ContentERPC15debug13ContentParens data;
  
} const _M0MPC15debug4Repr13pretty__printC3774l159$closure =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0),
    _M0MPC15debug4Repr13pretty__printC3774l159
  };

struct {
  int32_t rc;
  uint32_t meta;
  struct _M0TWRPC15debug7ContentERPC15debug13ContentParens data;
  
} const _M0MPC15debug4Repr13pretty__printC3793l147$closure =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0),
    _M0MPC15debug4Repr13pretty__printC3793l147
  };

struct {
  int32_t rc;
  uint32_t meta;
  struct _M0TWRPB5ArrayGsEERPB5ArrayGsE data;
  
} const _M0FPC15debug24compact__lines_2edyncall$closure =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0),
    _M0FPC15debug24compact__lines_2edyncall
  };

struct { int32_t rc; uint32_t meta; struct _M0TWEuQRPC15error5Error data; 
} const _M0FP27walkzzz27mcp__server__blackbox__test45____test__657870656e73652e6d6274__0_2edyncall$closure =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0),
    _M0FP27walkzzz27mcp__server__blackbox__test45____test__657870656e73652e6d6274__0_2edyncall
  };

struct { int32_t rc; uint32_t meta; struct _M0TWsEb data; 
} const _M0FPC15debug17comma__seq__linesC3542l365$closure =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0),
    _M0FPC15debug17comma__seq__linesC3542l365
  };

uint32_t const moonbit_layout_table_data[185] =
  {
    sizeof(struct _M0R110_24walkzzz_2fmcp__server__blackbox__test_2emoonbit__test__driver__internal__do__execute_2ehandle__start_7c1894)
    / 4, 1,
    offsetof(struct _M0R110_24walkzzz_2fmcp__server__blackbox__test_2emoonbit__test__driver__internal__do__execute_2ehandle__start_7c1894, $1)
    / 4
    * 2,
    sizeof(struct _M0R111_24walkzzz_2fmcp__server__blackbox__test_2emoonbit__test__driver__internal__do__execute_2ehandle__result_7c1899)
    / 4, 1,
    offsetof(struct _M0R111_24walkzzz_2fmcp__server__blackbox__test_2emoonbit__test__driver__internal__do__execute_2ehandle__result_7c1899, $1)
    / 4
    * 2,
    sizeof(struct _M0DTPC15error5Error109walkzzz_2fmcp__server__blackbox__test_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTest)
    / 4, 1,
    offsetof(struct _M0DTPC15error5Error109walkzzz_2fmcp__server__blackbox__test_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTest, $0)
    / 4
    * 2,
    sizeof(struct _M0R191_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver_3a_3arun__test_7c_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver__Internal__No__Args_7c_2eanon__u3979__l477__)
    / 4, 2,
    offsetof(struct _M0R191_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver_3a_3arun__test_7c_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver__Internal__No__Args_7c_2eanon__u3979__l477__, $0)
    / 4
    * 2,
    offsetof(struct _M0R191_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver_3a_3arun__test_7c_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver__Internal__No__Args_7c_2eanon__u3979__l477__, $1)
    / 4
    * 2,
    sizeof(struct _M0R191_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver_3a_3arun__test_7c_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver__Internal__No__Args_7c_2eanon__u3975__l478__)
    / 4, 3,
    offsetof(struct _M0R191_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver_3a_3arun__test_7c_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver__Internal__No__Args_7c_2eanon__u3975__l478__, $0)
    / 4
    * 2,
    offsetof(struct _M0R191_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver_3a_3arun__test_7c_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver__Internal__No__Args_7c_2eanon__u3975__l478__, $1)
    / 4
    * 2,
    offsetof(struct _M0R191_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver_3a_3arun__test_7c_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver__Internal__No__Args_7c_2eanon__u3975__l478__, $2)
    / 4
    * 2, sizeof(struct _M0TPB5ArrayGUsiEE) / 4, 1,
    offsetof(struct _M0TPB5ArrayGUsiEE, $0) / 4 * 2,
    sizeof(struct _M0TUsiE) / 4, 1, offsetof(struct _M0TUsiE, $0) / 4 * 2,
    sizeof(struct _M0TPB5ArrayGsE) / 4, 1,
    offsetof(struct _M0TPB5ArrayGsE, $0) / 4 * 2,
    sizeof(struct _M0TPB5ArrayGRP27walkzzz11mcp__server8CategoryE) / 4, 
    1,
    offsetof(struct _M0TPB5ArrayGRP27walkzzz11mcp__server8CategoryE, $0)
    / 4
    * 2, sizeof(struct _M0DTPC15debug9ReprDelta4Same) / 4, 2,
    offsetof(struct _M0DTPC15debug9ReprDelta4Same, $0) / 4 * 2,
    offsetof(struct _M0DTPC15debug9ReprDelta4Same, $1) / 4 * 2,
    sizeof(struct _M0TPB5ArrayGRPC15debug9ReprDeltaE) / 4, 1,
    offsetof(struct _M0TPB5ArrayGRPC15debug9ReprDeltaE, $0) / 4 * 2,
    sizeof(struct _M0DTPC15debug9ReprDelta9Different) / 4, 2,
    offsetof(struct _M0DTPC15debug9ReprDelta9Different, $0) / 4 * 2,
    offsetof(struct _M0DTPC15debug9ReprDelta9Different, $1) / 4 * 2,
    sizeof(struct _M0DTPC15debug9ReprDelta6Extra1) / 4, 1,
    offsetof(struct _M0DTPC15debug9ReprDelta6Extra1, $0) / 4 * 2,
    sizeof(struct _M0DTPC15debug9ReprDelta6Extra2) / 4, 1,
    offsetof(struct _M0DTPC15debug9ReprDelta6Extra2, $0) / 4 * 2,
    sizeof(struct _M0TPB5ArrayGRPC15debug13ContentParensE) / 4, 1,
    offsetof(struct _M0TPB5ArrayGRPC15debug13ContentParensE, $0) / 4 * 2,
    sizeof(struct _M0R93_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3aprune__info_2einner_2ego_7c260_2eanon__u3648__l54__)
    / 4, 1,
    offsetof(struct _M0R93_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3aprune__info_2einner_2ego_7c260_2eanon__u3648__l54__, $0)
    / 4
    * 2,
    sizeof(struct _M0R93_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3aprune__info_2einner_2ego_7c260_2eanon__u3653__l62__)
    / 4, 1,
    offsetof(struct _M0R93_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3aprune__info_2einner_2ego_7c260_2eanon__u3653__l62__, $1)
    / 4
    * 2, sizeof(struct _M0TPC15debug7Content) / 4, 1,
    offsetof(struct _M0TPC15debug7Content, $1) / 4 * 2,
    sizeof(struct _M0TPC15debug13ContentParens) / 4, 1,
    offsetof(struct _M0TPC15debug13ContentParens, $1) / 4 * 2,
    sizeof(struct _M0R60_24moonbitlang_2fcore_2fdebug_2eindent_2eanon__u3471__l236__)
    / 4, 1,
    offsetof(struct _M0R60_24moonbitlang_2fcore_2fdebug_2eindent_2eanon__u3471__l236__, $0)
    / 4
    * 2,
    sizeof(struct _M0R60_24moonbitlang_2fcore_2fdebug_2eindent_2eanon__u3475__l236__)
    / 4, 1,
    offsetof(struct _M0R60_24moonbitlang_2fcore_2fdebug_2eindent_2eanon__u3475__l236__, $0)
    / 4
    * 2, sizeof(struct _M0TPB5ArrayGRPC16string10StringViewE) / 4, 1,
    offsetof(struct _M0TPB5ArrayGRPC16string10StringViewE, $0) / 4 * 2,
    sizeof(struct _M0TPC16string10StringView) / 4, 1,
    offsetof(struct _M0TPC16string10StringView, $0) / 4 * 2,
    sizeof(struct _M0R62_24moonbitlang_2fcore_2fdebug_2esurround_2eanon__u3401__l108__)
    / 4, 2,
    offsetof(struct _M0R62_24moonbitlang_2fcore_2fdebug_2esurround_2eanon__u3401__l108__, $0)
    / 4
    * 2,
    offsetof(struct _M0R62_24moonbitlang_2fcore_2fdebug_2esurround_2eanon__u3401__l108__, $1)
    / 4
    * 2, sizeof(struct _M0TPB5ArrayGRPC15debug4ReprE) / 4, 1,
    offsetof(struct _M0TPB5ArrayGRPC15debug4ReprE, $0) / 4 * 2,
    sizeof(struct _M0DTPC15debug4Repr5Tuple) / 4, 1,
    offsetof(struct _M0DTPC15debug4Repr5Tuple, $0) / 4 * 2,
    sizeof(struct _M0DTPC15debug4Repr5Array) / 4, 1,
    offsetof(struct _M0DTPC15debug4Repr5Array, $0) / 4 * 2,
    sizeof(struct _M0DTPC15debug4Repr6Record) / 4, 1,
    offsetof(struct _M0DTPC15debug4Repr6Record, $0) / 4 * 2,
    sizeof(struct _M0DTPC15debug4Repr4Enum) / 4, 2,
    offsetof(struct _M0DTPC15debug4Repr4Enum, $0) / 4 * 2,
    offsetof(struct _M0DTPC15debug4Repr4Enum, $1) / 4 * 2,
    sizeof(struct _M0DTPC15debug4Repr6Opaque) / 4, 2,
    offsetof(struct _M0DTPC15debug4Repr6Opaque, $0) / 4 * 2,
    offsetof(struct _M0DTPC15debug4Repr6Opaque, $1) / 4 * 2,
    sizeof(struct _M0DTPC15debug4Repr3Map) / 4, 1,
    offsetof(struct _M0DTPC15debug4Repr3Map, $0) / 4 * 2,
    sizeof(struct _M0DTPC15debug4Repr11RecordField) / 4, 2,
    offsetof(struct _M0DTPC15debug4Repr11RecordField, $0) / 4 * 2,
    offsetof(struct _M0DTPC15debug4Repr11RecordField, $1) / 4 * 2,
    sizeof(struct _M0DTPC15debug4Repr14EnumLabeledArg) / 4, 2,
    offsetof(struct _M0DTPC15debug4Repr14EnumLabeledArg, $0) / 4 * 2,
    offsetof(struct _M0DTPC15debug4Repr14EnumLabeledArg, $1) / 4 * 2,
    sizeof(struct _M0DTPC15debug4Repr8MapEntry) / 4, 2,
    offsetof(struct _M0DTPC15debug4Repr8MapEntry, $0) / 4 * 2,
    offsetof(struct _M0DTPC15debug4Repr8MapEntry, $1) / 4 * 2,
    sizeof(struct _M0DTPC15debug4Repr7Integer) / 4, 1,
    offsetof(struct _M0DTPC15debug4Repr7Integer, $0) / 4 * 2,
    sizeof(struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE) / 4, 
    3,
    offsetof(struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE, $1)
    / 4
    * 2,
    offsetof(struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE, $4)
    / 4
    * 2,
    offsetof(struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE, $5)
    / 4
    * 2, sizeof(struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE) / 4, 
    2, offsetof(struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE, $1) / 4 * 2,
    offsetof(struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE, $5) / 4 * 2,
    sizeof(struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE) / 4, 
    2,
    offsetof(struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE, $0)
    / 4
    * 2,
    offsetof(struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE, $5)
    / 4
    * 2, sizeof(struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE) / 4, 2,
    offsetof(struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE, $0) / 4 * 2,
    offsetof(struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE, $5) / 4 * 2,
    sizeof(struct _M0TPB5ArrayGRPC15debug7ContentE) / 4, 1,
    offsetof(struct _M0TPB5ArrayGRPC15debug7ContentE, $0) / 4 * 2,
    sizeof(struct _M0TPB5ArrayGRPB5ArrayGsEE) / 4, 1,
    offsetof(struct _M0TPB5ArrayGRPB5ArrayGsEE, $0) / 4 * 2,
    sizeof(struct _M0TPB9ArrayViewGsE) / 4, 1,
    offsetof(struct _M0TPB9ArrayViewGsE, $0) / 4 * 2,
    sizeof(struct _M0R59ArrayView_3a_3aiter_7c_5bString_5d_7c_2eanon__u2613__l717__)
    / 4, 2,
    (offsetof(struct _M0R59ArrayView_3a_3aiter_7c_5bString_5d_7c_2eanon__u2613__l717__, $0)
     + offsetof(struct _M0TPB9ArrayViewGsE, $0))
    / 4
    * 2,
    offsetof(struct _M0R59ArrayView_3a_3aiter_7c_5bString_5d_7c_2eanon__u2613__l717__, $2)
    / 4
    * 2,
    sizeof(struct _M0R65Iter_3a_3amap_7c_5bString_2c_20String_5d_7c_2eanon__u2606__l367__)
    / 4, 2,
    offsetof(struct _M0R65Iter_3a_3amap_7c_5bString_2c_20String_5d_7c_2eanon__u2606__l367__, $0)
    / 4
    * 2,
    offsetof(struct _M0R65Iter_3a_3amap_7c_5bString_2c_20String_5d_7c_2eanon__u2606__l367__, $1)
    / 4
    * 2, sizeof(struct _M0TPB4IterGsE) / 4, 1,
    offsetof(struct _M0TPB4IterGsE, $0) / 4 * 2,
    sizeof(struct _M0DTPC16option6OptionGRPC16string10StringViewE4Some) / 4,
    1,
    (offsetof(struct _M0DTPC16option6OptionGRPC16string10StringViewE4Some, $0)
     + offsetof(struct _M0TPC16string10StringView, $0))
    / 4
    * 2,
    sizeof(struct _M0DTPC15error5Error48moonbitlang_2fcore_2fbuiltin_2eFailure_2eFailure)
    / 4, 1,
    offsetof(struct _M0DTPC15error5Error48moonbitlang_2fcore_2fbuiltin_2eFailure_2eFailure, $0)
    / 4
    * 2, sizeof(struct _M0TPB6Logger) / 4, 2,
    offsetof(struct _M0TPB6Logger, $0) / 4 * 2,
    offsetof(struct _M0TPB6Logger, $1) / 4 * 2,
    sizeof(struct _M0TURPB6LoggerRPC16string10StringViewE) / 4, 3,
    (offsetof(struct _M0TURPB6LoggerRPC16string10StringViewE, $0)
     + offsetof(struct _M0TPB6Logger, $0))
    / 4
    * 2,
    (offsetof(struct _M0TURPB6LoggerRPC16string10StringViewE, $0)
     + offsetof(struct _M0TPB6Logger, $1))
    / 4
    * 2,
    (offsetof(struct _M0TURPB6LoggerRPC16string10StringViewE, $1)
     + offsetof(struct _M0TPC16string10StringView, $0))
    / 4
    * 2, sizeof(struct _M0TPB13StringBuilder) / 4, 1,
    offsetof(struct _M0TPB13StringBuilder, $0) / 4 * 2,
    sizeof(struct _M0TUWEuQRPC15error5ErrorNsE) / 4, 2,
    offsetof(struct _M0TUWEuQRPC15error5ErrorNsE, $0) / 4 * 2,
    offsetof(struct _M0TUWEuQRPC15error5ErrorNsE, $1) / 4 * 2,
    sizeof(struct _M0TUiUWEuQRPC15error5ErrorNsEE) / 4, 1,
    offsetof(struct _M0TUiUWEuQRPC15error5ErrorNsEE, $1) / 4 * 2,
    sizeof(struct _M0TUsRPB3MapGiUWEuQRPC15error5ErrorNsEEE) / 4, 2,
    offsetof(struct _M0TUsRPB3MapGiUWEuQRPC15error5ErrorNsEEE, $0) / 4 * 2,
    offsetof(struct _M0TUsRPB3MapGiUWEuQRPC15error5ErrorNsEEE, $1) / 4 * 2,
    sizeof(struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE) / 4, 1,
    offsetof(struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE, $0) / 4 * 2
  };

struct _M0TWEu* _M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test28MoonBit__Async__Test__Driver26is__being__cancelled_2ecloGRP27walkzzz27mcp__server__blackbox__test34MoonBit__Async__Test__Driver__ImplE =
  (struct _M0TWEu*)&_M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test28MoonBit__Async__Test__Driver30is__being__cancelled_2edyncallGRP27walkzzz27mcp__server__blackbox__test34MoonBit__Async__Test__Driver__ImplE$closure.data;

struct _M0TWEuQRPC15error5Error* _M0FP27walkzzz27mcp__server__blackbox__test41____test__657870656e73652e6d6274__0_2eclo =
  (struct _M0TWEuQRPC15error5Error*)&_M0FP27walkzzz27mcp__server__blackbox__test45____test__657870656e73652e6d6274__0_2edyncall$closure.data;

struct _M0TWRPB5ArrayGsEERPB5ArrayGsE* _M0FPC15debug20compact__lines_2eclo =
  (struct _M0TWRPB5ArrayGsEERPB5ArrayGsE*)&_M0FPC15debug24compact__lines_2edyncall$closure.data;

struct { int32_t rc; uint32_t meta; struct _M0BTPB6Logger data; 
} _M0FP0119moonbitlang_2fcore_2fbuiltin_2fStringBuilder_2eas___40moonbitlang_2fcore_2fbuiltin_2eLogger_2estatic__method__table__id$object =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0),
    {.$method_0 = _M0IPB13StringBuilderPB6Logger69write__string_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLogger,
       .$method_1 = _M0IP016_24default__implPB6Logger72write__substring_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLoggerGRPB13StringBuilderE,
       .$method_2 = _M0IPB13StringBuilderPB6Logger67write__view_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLogger,
       .$method_3 = _M0IPB13StringBuilderPB6Logger67write__char_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLogger,
       .$method_4 = _M0IP016_24default__implPB6Logger84write__string__interpolation_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLoggerGRPB13StringBuilderE,
       .$method_5 = _M0IP016_24default__implPB6Logger61write_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLoggerGRPB13StringBuilderE}
  };

struct _M0BTPB6Logger* _M0FP0119moonbitlang_2fcore_2fbuiltin_2fStringBuilder_2eas___40moonbitlang_2fcore_2fbuiltin_2eLogger_2estatic__method__table__id =
  &_M0FP0119moonbitlang_2fcore_2fbuiltin_2fStringBuilder_2eas___40moonbitlang_2fcore_2fbuiltin_2eLogger_2estatic__method__table__id$object.data;

moonbit_string_t _M0MPC16string6String4trimN7_2abindS7401 =
  (moonbit_string_t)moonbit_string_literal_0.data;

struct { int32_t rc; uint32_t meta; uint64_t data[30]; 
} _M0FPB26gDOUBLE__POW5__INV__SPLIT2$object =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 30, 1ull,
    2305843009213693952ull, 5955668970331000884ull, 1784059615882449851ull,
    8982663654677661702ull, 1380349269358112757ull, 7286864317269821294ull,
    2135987035920910082ull, 7005857020398200553ull, 1652639921975621497ull,
    17965325103354776697ull, 1278668206209430417ull, 8928596168509315048ull,
    1978643211784836272ull, 10075671573058298858ull, 1530901034580419511ull,
    597001226353042382ull, 1184477304306571148ull, 1527430471115325346ull,
    1832889850782397517ull, 12533209867169019542ull, 1418129833677084982ull,
    5577825024675947042ull, 2194449627517475473ull, 11006974540203867551ull,
    1697873161311732311ull, 10313493231639821582ull, 1313665730009899186ull,
    12701016819766672773ull, 2032799256770390445ull
  };

uint64_t* _M0FPB26gDOUBLE__POW5__INV__SPLIT2 =
  _M0FPB26gDOUBLE__POW5__INV__SPLIT2$object.data;

struct { int32_t rc; uint32_t meta; uint32_t data[19]; 
} _M0FPB19gPOW5__INV__OFFSETS$object =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 19, 1414808916u,
    67458373u, 268701696u, 4195348u, 1073807360u, 1091917141u, 1108u, 
    65604u, 1073741824u, 1140850753u, 1346716752u, 1431634004u, 1365595476u,
    1073758208u, 16777217u, 66816u, 1364284433u, 89478484u, 0u
  };

uint32_t* _M0FPB19gPOW5__INV__OFFSETS =
  _M0FPB19gPOW5__INV__OFFSETS$object.data;

struct { int32_t rc; uint32_t meta; uint64_t data[26]; 
} _M0FPB21gDOUBLE__POW5__SPLIT2$object =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 26, 0ull,
    1152921504606846976ull, 0ull, 1490116119384765625ull,
    1032610780636961552ull, 1925929944387235853ull, 7910200175544436838ull,
    1244603055572228341ull, 16941905809032713930ull, 1608611746708759036ull,
    13024893955298202172ull, 2079081953128979843ull, 6607496772837067824ull,
    1343575221513417750ull, 17332926989895652603ull, 1736530273035216783ull,
    13037379183483547984ull, 2244412773384604712ull, 1605989338741628675ull,
    1450417759929778918ull, 9630225068416591280ull, 1874621017369538693ull,
    665883850346957067ull, 1211445438634777304ull, 14931890668723713708ull,
    1565756531257009982ull
  };

uint64_t* _M0FPB21gDOUBLE__POW5__SPLIT2 =
  _M0FPB21gDOUBLE__POW5__SPLIT2$object.data;

struct { int32_t rc; uint32_t meta; uint32_t data[21]; 
} _M0FPB14gPOW5__OFFSETS$object =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 21, 0u, 0u, 
    0u, 0u, 1073741824u, 1500076437u, 1431590229u, 1448432917u, 1091896580u,
    1079333904u, 1146442053u, 1146111296u, 1163220304u, 1073758208u,
    2521039936u, 1431721317u, 1413824581u, 1075134801u, 1431671125u,
    1363170645u, 261u
  };

uint32_t* _M0FPB14gPOW5__OFFSETS = _M0FPB14gPOW5__OFFSETS$object.data;

struct { int32_t rc; uint32_t meta; uint64_t data[26]; 
} _M0FPB20gDOUBLE__POW5__TABLE$object =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 26, 1ull, 5ull,
    25ull, 125ull, 625ull, 3125ull, 15625ull, 78125ull, 390625ull,
    1953125ull, 9765625ull, 48828125ull, 244140625ull, 1220703125ull,
    6103515625ull, 30517578125ull, 152587890625ull, 762939453125ull,
    3814697265625ull, 19073486328125ull, 95367431640625ull,
    476837158203125ull, 2384185791015625ull, 11920928955078125ull,
    59604644775390625ull, 298023223876953125ull
  };

uint64_t* _M0FPB20gDOUBLE__POW5__TABLE =
  _M0FPB20gDOUBLE__POW5__TABLE$object.data;

int64_t _M0MPB4Iter4nextN6constrS10368GsE = 0ll;

int64_t _M0MPB4Iter4nextN6constrS10369GsE = 0ll;

int64_t _M0MPB4Iter3newN6constrS10376GsE = 0ll;

moonbit_string_t _M0FPC15debug14compact__linesN7_2abindS1177 =
  (moonbit_string_t)moonbit_string_literal_1.data;

moonbit_string_t _M0FPC15debug14compact__linesN7_2abindS1200 =
  (moonbit_string_t)moonbit_string_literal_2.data;

moonbit_string_t _M0FPC15debug14compact__linesN7_2abindS1194 =
  (moonbit_string_t)moonbit_string_literal_3.data;

moonbit_string_t _M0FPC15debug14compact__linesN7_2abindS1187 =
  (moonbit_string_t)moonbit_string_literal_2.data;

moonbit_string_t _M0FPC15debug14compact__linesN7_2abindS1181 =
  (moonbit_string_t)moonbit_string_literal_2.data;

moonbit_string_t _M0FPC15debug14compact__linesN7_2abindS1179 =
  (moonbit_string_t)moonbit_string_literal_1.data;

moonbit_string_t _M0FPC15debug14compact__linesN7_2abindS1201 =
  (moonbit_string_t)moonbit_string_literal_4.data;

moonbit_string_t _M0FPC15debug14compact__linesN7_2abindS1205 =
  (moonbit_string_t)moonbit_string_literal_1.data;

moonbit_string_t _M0FPC15debug14compact__linesN7_2abindS1214 =
  (moonbit_string_t)moonbit_string_literal_2.data;

moonbit_string_t _M0FPC15debug14compact__linesN7_2abindS1208 =
  (moonbit_string_t)moonbit_string_literal_3.data;

moonbit_string_t _M0FPC15debug14compact__linesN7_2abindS1219 =
  (moonbit_string_t)moonbit_string_literal_2.data;

moonbit_string_t _M0FPC15debug19bracket__seq__linesN7_2abindS1229 =
  (moonbit_string_t)moonbit_string_literal_1.data;

moonbit_string_t _M0FPC15debug14print__contentN7_2abindS1298 =
  (moonbit_string_t)moonbit_string_literal_5.data;

int64_t _M0FPC15debug28pretty__print__delta_2einnerN6constrS1768 = 16ll;

int64_t _M0FPC15debug6renderN6constrS1767 = 16ll;

int32_t _M0FPC15debug10assert__eqN6constrS1770GiE = 0;

struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0FP27walkzzz27mcp__server__blackbox__test48moonbit__test__driver__internal__no__args__tests;

struct _M0TPB5ArrayGsE* _M0FPC15debug24compact__lines_2edyncall(
  struct _M0TWRPB5ArrayGsEERPB5ArrayGsE* _M0L6_2aenvS4004,
  struct _M0TPB5ArrayGsE* _M0L5linesS1376
) {
  return _M0FPC15debug14compact__lines(_M0L5linesS1376);
}

struct moonbit_result_0 _M0FP27walkzzz27mcp__server__blackbox__test45____test__657870656e73652e6d6274__0_2edyncall(
  struct _M0TWEuQRPC15error5Error* _M0L6_2aenvS4003
) {
  return _M0FP27walkzzz27mcp__server__blackbox__test35____test__657870656e73652e6d6274__0();
}

int32_t _M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test28MoonBit__Async__Test__Driver30is__being__cancelled_2edyncallGRP27walkzzz27mcp__server__blackbox__test34MoonBit__Async__Test__Driver__ImplE(
  struct _M0TWEu* _M0L6_2aenvS4002
) {
  return _M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test28MoonBit__Async__Test__Driver20is__being__cancelledGRP27walkzzz27mcp__server__blackbox__test34MoonBit__Async__Test__Driver__ImplE();
}

int32_t _M0FP27walkzzz27mcp__server__blackbox__test44moonbit__test__driver__internal__do__execute(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE* _M0L12async__testsS1927,
  moonbit_string_t _M0L8filenameS1896,
  int32_t _M0L5indexS1898
) {
  struct _M0R110_24walkzzz_2fmcp__server__blackbox__test_2emoonbit__test__driver__internal__do__execute_2ehandle__start_7c1894* _closure_4250;
  struct _M0TWEu* _M0L13handle__startS1894;
  struct _M0R111_24walkzzz_2fmcp__server__blackbox__test_2emoonbit__test__driver__internal__do__execute_2ehandle__result_7c1899* _closure_4251;
  struct _M0TWssbEu* _M0L14handle__resultS1899;
  struct _M0TWRPC15error5ErrorEs* _M0L17error__to__stringS1906;
  void* _M0L11_2atry__errS1921;
  struct moonbit_result_0 _tmp_4253;
  int32_t _handle__error__result_4254;
  int32_t _M0L6_2atmpS3990;
  void* _M0L3errS1922;
  moonbit_string_t _M0L4nameS1924;
  struct _M0DTPC15error5Error109walkzzz_2fmcp__server__blackbox__test_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTest* _M0L36_2aMoonBitTestDriverInternalSkipTestS1925;
  moonbit_string_t _M0L7_2anameS1926;
  int32_t _M0L6_2acntS4218;
  #line 606 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  moonbit_incref(_M0L8filenameS1896);
  _closure_4250
  = (struct _M0R110_24walkzzz_2fmcp__server__blackbox__test_2emoonbit__test__driver__internal__do__execute_2ehandle__start_7c1894*)moonbit_malloc(sizeof(struct _M0R110_24walkzzz_2fmcp__server__blackbox__test_2emoonbit__test__driver__internal__do__execute_2ehandle__start_7c1894));
  Moonbit_object_header(_closure_4250)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 0, 0);
  _closure_4250->code
  = &_M0FP27walkzzz27mcp__server__blackbox__test44moonbit__test__driver__internal__do__executeN13handle__startS1894;
  _closure_4250->$0 = _M0L5indexS1898;
  _closure_4250->$1 = _M0L8filenameS1896;
  _M0L13handle__startS1894 = (struct _M0TWEu*)_closure_4250;
  moonbit_incref(_M0L8filenameS1896);
  _closure_4251
  = (struct _M0R111_24walkzzz_2fmcp__server__blackbox__test_2emoonbit__test__driver__internal__do__execute_2ehandle__result_7c1899*)moonbit_malloc(sizeof(struct _M0R111_24walkzzz_2fmcp__server__blackbox__test_2emoonbit__test__driver__internal__do__execute_2ehandle__result_7c1899));
  Moonbit_object_header(_closure_4251)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 3, 0);
  _closure_4251->code
  = &_M0FP27walkzzz27mcp__server__blackbox__test44moonbit__test__driver__internal__do__executeN14handle__resultS1899;
  _closure_4251->$0 = _M0L5indexS1898;
  _closure_4251->$1 = _M0L8filenameS1896;
  _M0L14handle__resultS1899 = (struct _M0TWssbEu*)_closure_4251;
  _M0L17error__to__stringS1906
  = (struct _M0TWRPC15error5ErrorEs*)&_M0FP27walkzzz27mcp__server__blackbox__test44moonbit__test__driver__internal__do__executeN17error__to__stringS1906$closure.data;
  #line 648 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _tmp_4253
  = _M0IP27walkzzz27mcp__server__blackbox__test41MoonBit__Test__Driver__Internal__No__ArgsP27walkzzz27mcp__server__blackbox__test21MoonBit__Test__Driver9run__test(_M0L12async__testsS1927, _M0L8filenameS1896, _M0L5indexS1898, _M0L13handle__startS1894, _M0L14handle__resultS1899, _M0L17error__to__stringS1906);
  if (_tmp_4253.tag) {
    int32_t const _M0L5_2aokS3999 = _tmp_4253.data.ok;
    _handle__error__result_4254 = _M0L5_2aokS3999;
  } else {
    void* const _M0L6_2aerrS4000 = _tmp_4253.data.err;
    moonbit_decref(_M0L17error__to__stringS1906);
    moonbit_decref(_M0L13handle__startS1894);
    _M0L11_2atry__errS1921 = _M0L6_2aerrS4000;
    goto join_1920;
  }
  if (_handle__error__result_4254) {
    moonbit_decref(_M0L17error__to__stringS1906);
    moonbit_decref(_M0L13handle__startS1894);
    _M0L6_2atmpS3990 = 1;
  } else {
    struct moonbit_result_0 _tmp_4255;
    int32_t _handle__error__result_4256;
    #line 651 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
    _tmp_4255
    = _M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test21MoonBit__Test__Driver9run__testGRP27walkzzz27mcp__server__blackbox__test43MoonBit__Test__Driver__Internal__With__ArgsE(_M0L12async__testsS1927, _M0L8filenameS1896, _M0L5indexS1898, _M0L13handle__startS1894, _M0L14handle__resultS1899, _M0L17error__to__stringS1906);
    if (_tmp_4255.tag) {
      int32_t const _M0L5_2aokS3997 = _tmp_4255.data.ok;
      _handle__error__result_4256 = _M0L5_2aokS3997;
    } else {
      void* const _M0L6_2aerrS3998 = _tmp_4255.data.err;
      moonbit_decref(_M0L17error__to__stringS1906);
      moonbit_decref(_M0L13handle__startS1894);
      _M0L11_2atry__errS1921 = _M0L6_2aerrS3998;
      goto join_1920;
    }
    if (_handle__error__result_4256) {
      moonbit_decref(_M0L17error__to__stringS1906);
      moonbit_decref(_M0L13handle__startS1894);
      _M0L6_2atmpS3990 = 1;
    } else {
      struct moonbit_result_0 _tmp_4257;
      int32_t _handle__error__result_4258;
      #line 654 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
      _tmp_4257
      = _M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test21MoonBit__Test__Driver9run__testGRP27walkzzz27mcp__server__blackbox__test48MoonBit__Test__Driver__Internal__Async__No__ArgsE(_M0L12async__testsS1927, _M0L8filenameS1896, _M0L5indexS1898, _M0L13handle__startS1894, _M0L14handle__resultS1899, _M0L17error__to__stringS1906);
      if (_tmp_4257.tag) {
        int32_t const _M0L5_2aokS3995 = _tmp_4257.data.ok;
        _handle__error__result_4258 = _M0L5_2aokS3995;
      } else {
        void* const _M0L6_2aerrS3996 = _tmp_4257.data.err;
        moonbit_decref(_M0L17error__to__stringS1906);
        moonbit_decref(_M0L13handle__startS1894);
        _M0L11_2atry__errS1921 = _M0L6_2aerrS3996;
        goto join_1920;
      }
      if (_handle__error__result_4258) {
        moonbit_decref(_M0L17error__to__stringS1906);
        moonbit_decref(_M0L13handle__startS1894);
        _M0L6_2atmpS3990 = 1;
      } else {
        struct moonbit_result_0 _tmp_4259;
        int32_t _handle__error__result_4260;
        #line 657 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
        _tmp_4259
        = _M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test21MoonBit__Test__Driver9run__testGRP27walkzzz27mcp__server__blackbox__test50MoonBit__Test__Driver__Internal__Async__With__ArgsE(_M0L12async__testsS1927, _M0L8filenameS1896, _M0L5indexS1898, _M0L13handle__startS1894, _M0L14handle__resultS1899, _M0L17error__to__stringS1906);
        if (_tmp_4259.tag) {
          int32_t const _M0L5_2aokS3993 = _tmp_4259.data.ok;
          _handle__error__result_4260 = _M0L5_2aokS3993;
        } else {
          void* const _M0L6_2aerrS3994 = _tmp_4259.data.err;
          moonbit_decref(_M0L17error__to__stringS1906);
          moonbit_decref(_M0L13handle__startS1894);
          _M0L11_2atry__errS1921 = _M0L6_2aerrS3994;
          goto join_1920;
        }
        if (_handle__error__result_4260) {
          moonbit_decref(_M0L17error__to__stringS1906);
          moonbit_decref(_M0L13handle__startS1894);
          _M0L6_2atmpS3990 = 1;
        } else {
          struct moonbit_result_0 _tmp_4261;
          #line 660 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
          _tmp_4261
          = _M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test21MoonBit__Test__Driver9run__testGRP27walkzzz27mcp__server__blackbox__test50MoonBit__Test__Driver__Internal__With__Bench__ArgsE(_M0L12async__testsS1927, _M0L8filenameS1896, _M0L5indexS1898, _M0L13handle__startS1894, _M0L14handle__resultS1899, _M0L17error__to__stringS1906);
          moonbit_decref(_M0L13handle__startS1894);
          moonbit_decref(_M0L17error__to__stringS1906);
          if (_tmp_4261.tag) {
            int32_t const _M0L5_2aokS3991 = _tmp_4261.data.ok;
            _M0L6_2atmpS3990 = _M0L5_2aokS3991;
          } else {
            void* const _M0L6_2aerrS3992 = _tmp_4261.data.err;
            _M0L11_2atry__errS1921 = _M0L6_2aerrS3992;
            goto join_1920;
          }
        }
      }
    }
  }
  if (!_M0L6_2atmpS3990) {
    void* _M0L109walkzzz_2fmcp__server__blackbox__test_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTestS4001 =
      (void*)moonbit_malloc(sizeof(struct _M0DTPC15error5Error109walkzzz_2fmcp__server__blackbox__test_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTest));
    Moonbit_object_header(_M0L109walkzzz_2fmcp__server__blackbox__test_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTestS4001)->meta
    = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 6, 1);
    ((struct _M0DTPC15error5Error109walkzzz_2fmcp__server__blackbox__test_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTest*)_M0L109walkzzz_2fmcp__server__blackbox__test_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTestS4001)->$0
    = (moonbit_string_t)moonbit_string_literal_1.data;
    _M0L11_2atry__errS1921
    = _M0L109walkzzz_2fmcp__server__blackbox__test_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTestS4001;
    goto join_1920;
  } else {
    moonbit_decref(_M0L14handle__resultS1899);
  }
  goto joinlet_4252;
  join_1920:;
  _M0L3errS1922 = _M0L11_2atry__errS1921;
  _M0L36_2aMoonBitTestDriverInternalSkipTestS1925
  = (struct _M0DTPC15error5Error109walkzzz_2fmcp__server__blackbox__test_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTest*)_M0L3errS1922;
  _M0L7_2anameS1926 = _M0L36_2aMoonBitTestDriverInternalSkipTestS1925->$0;
  _M0L6_2acntS4218
  = Moonbit_rc_count(Moonbit_object_header(_M0L36_2aMoonBitTestDriverInternalSkipTestS1925));
  if (_M0L6_2acntS4218 > 1) {
    int32_t _M0L11_2anew__cntS4219 = _M0L6_2acntS4218 - 1;
    Moonbit_set_rc_count(Moonbit_object_header(_M0L36_2aMoonBitTestDriverInternalSkipTestS1925), _M0L11_2anew__cntS4219);
    moonbit_incref(_M0L7_2anameS1926);
  } else if (_M0L6_2acntS4218 == 1) {
    #line 667 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
    moonbit_free(_M0L36_2aMoonBitTestDriverInternalSkipTestS1925);
  }
  _M0L4nameS1924 = _M0L7_2anameS1926;
  goto join_1923;
  goto joinlet_4262;
  join_1923:;
  #line 668 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0FP27walkzzz27mcp__server__blackbox__test44moonbit__test__driver__internal__do__executeN14handle__resultS1899(_M0L14handle__resultS1899, _M0L4nameS1924, (moonbit_string_t)moonbit_string_literal_6.data, 1);
  moonbit_decref(_M0L14handle__resultS1899);
  moonbit_decref(_M0L4nameS1924);
  joinlet_4262:;
  joinlet_4252:;
  return 0;
}

moonbit_string_t _M0FP27walkzzz27mcp__server__blackbox__test44moonbit__test__driver__internal__do__executeN17error__to__stringS1906(
  struct _M0TWRPC15error5ErrorEs* _M0L6_2aenvS3989,
  void* _M0L3errS1907
) {
  void* _M0L1eS1909;
  moonbit_string_t _M0L1eS1911;
  moonbit_string_t _result_4265;
  #line 637 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  switch (Moonbit_object_tag(_M0L3errS1907)) {
    case 0: {
      struct _M0DTPC15error5Error48moonbitlang_2fcore_2fbuiltin_2eFailure_2eFailure* _M0L10_2aFailureS1912 =
        (struct _M0DTPC15error5Error48moonbitlang_2fcore_2fbuiltin_2eFailure_2eFailure*)_M0L3errS1907;
      moonbit_string_t _M0L4_2aeS1913 = _M0L10_2aFailureS1912->$0;
      moonbit_incref(_M0L4_2aeS1913);
      _M0L1eS1911 = _M0L4_2aeS1913;
      goto join_1910;
      break;
    }
    
    case 2: {
      struct _M0DTPC15error5Error58moonbitlang_2fcore_2fbuiltin_2eInspectError_2eInspectError* _M0L15_2aInspectErrorS1914 =
        (struct _M0DTPC15error5Error58moonbitlang_2fcore_2fbuiltin_2eInspectError_2eInspectError*)_M0L3errS1907;
      moonbit_string_t _M0L4_2aeS1915 = _M0L15_2aInspectErrorS1914->$0;
      moonbit_incref(_M0L4_2aeS1915);
      _M0L1eS1911 = _M0L4_2aeS1915;
      goto join_1910;
      break;
    }
    
    case 3: {
      struct _M0DTPC15error5Error60moonbitlang_2fcore_2fbuiltin_2eSnapshotError_2eSnapshotError* _M0L16_2aSnapshotErrorS1916 =
        (struct _M0DTPC15error5Error60moonbitlang_2fcore_2fbuiltin_2eSnapshotError_2eSnapshotError*)_M0L3errS1907;
      moonbit_string_t _M0L4_2aeS1917 = _M0L16_2aSnapshotErrorS1916->$0;
      moonbit_incref(_M0L4_2aeS1917);
      _M0L1eS1911 = _M0L4_2aeS1917;
      goto join_1910;
      break;
    }
    
    case 4: {
      struct _M0DTPC15error5Error107walkzzz_2fmcp__server__blackbox__test_2eMoonBitTestDriverInternalJsError_2eMoonBitTestDriverInternalJsError* _M0L35_2aMoonBitTestDriverInternalJsErrorS1918 =
        (struct _M0DTPC15error5Error107walkzzz_2fmcp__server__blackbox__test_2eMoonBitTestDriverInternalJsError_2eMoonBitTestDriverInternalJsError*)_M0L3errS1907;
      moonbit_string_t _M0L4_2aeS1919 =
        _M0L35_2aMoonBitTestDriverInternalJsErrorS1918->$0;
      moonbit_incref(_M0L4_2aeS1919);
      _M0L1eS1911 = _M0L4_2aeS1919;
      goto join_1910;
      break;
    }
    default: {
      moonbit_incref(_M0L3errS1907);
      _M0L1eS1909 = _M0L3errS1907;
      goto join_1908;
      break;
    }
  }
  join_1910:;
  return _M0L1eS1911;
  join_1908:;
  #line 643 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _result_4265 = _M0FP15Error10to__string(_M0L1eS1909);
  moonbit_decref(_M0L1eS1909);
  return _result_4265;
}

int32_t _M0FP27walkzzz27mcp__server__blackbox__test44moonbit__test__driver__internal__do__executeN14handle__resultS1899(
  struct _M0TWssbEu* _M0L6_2aenvS3986,
  moonbit_string_t _M0L10__testnameS1900,
  moonbit_string_t _M0L7messageS1901,
  int32_t _M0L7skippedS1902
) {
  struct _M0R111_24walkzzz_2fmcp__server__blackbox__test_2emoonbit__test__driver__internal__do__execute_2ehandle__result_7c1899* _M0L14_2acasted__envS3987;
  moonbit_string_t _M0L8filenameS1896;
  int32_t _M0L5indexS1898;
  int32_t _if__result_4266;
  moonbit_string_t _M0L10file__nameS1903;
  moonbit_string_t _M0L7messageS1904;
  struct _M0TPB13StringBuilder* _M0L18_2astring__builderS1905;
  moonbit_string_t _M0L6_2atmpS3988;
  #line 622 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L14_2acasted__envS3987
  = (struct _M0R111_24walkzzz_2fmcp__server__blackbox__test_2emoonbit__test__driver__internal__do__execute_2ehandle__result_7c1899*)_M0L6_2aenvS3986;
  _M0L8filenameS1896 = _M0L14_2acasted__envS3987->$1;
  _M0L5indexS1898 = _M0L14_2acasted__envS3987->$0;
  if (!_M0L7skippedS1902) {
    _if__result_4266 = 1;
  } else {
    _if__result_4266 = 0;
  }
  if (_if__result_4266) {
    
  }
  #line 628 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L10file__nameS1903
  = _M0MPC16string6String14escape_2einner(_M0L8filenameS1896, 1);
  #line 629 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L7messageS1904
  = _M0MPC16string6String14escape_2einner(_M0L7messageS1901, 1);
  #line 630 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0FPB7printlnGsE((moonbit_string_t)moonbit_string_literal_7.data);
  #line 632 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L18_2astring__builderS1905
  = _M0MPB13StringBuilder21StringBuilder_2einner(45);
  #line 632 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS1905, (moonbit_string_t)moonbit_string_literal_8.data);
  #line 632 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0MPB13StringBuilder13write__objectGsE(_M0L18_2astring__builderS1905, _M0L10file__nameS1903);
  moonbit_decref(_M0L10file__nameS1903);
  #line 632 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS1905, (moonbit_string_t)moonbit_string_literal_9.data);
  #line 632 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS1905, _M0L5indexS1898);
  #line 632 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS1905, (moonbit_string_t)moonbit_string_literal_10.data);
  #line 632 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0MPB13StringBuilder13write__objectGsE(_M0L18_2astring__builderS1905, _M0L7messageS1904);
  moonbit_decref(_M0L7messageS1904);
  #line 632 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS1905, (moonbit_string_t)moonbit_string_literal_11.data);
  #line 632 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L6_2atmpS3988
  = _M0MPB13StringBuilder10to__string(_M0L18_2astring__builderS1905);
  moonbit_decref(_M0L18_2astring__builderS1905);
  #line 631 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0FPB7printlnGsE(_M0L6_2atmpS3988);
  moonbit_decref(_M0L6_2atmpS3988);
  #line 634 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0FPB7printlnGsE((moonbit_string_t)moonbit_string_literal_12.data);
  return 0;
}

int32_t _M0FP27walkzzz27mcp__server__blackbox__test44moonbit__test__driver__internal__do__executeN13handle__startS1894(
  struct _M0TWEu* _M0L6_2aenvS3983
) {
  struct _M0R110_24walkzzz_2fmcp__server__blackbox__test_2emoonbit__test__driver__internal__do__execute_2ehandle__start_7c1894* _M0L14_2acasted__envS3984;
  moonbit_string_t _M0L8filenameS1896;
  int32_t _M0L5indexS1898;
  moonbit_string_t _M0L10file__nameS1895;
  struct _M0TPB13StringBuilder* _M0L18_2astring__builderS1897;
  moonbit_string_t _M0L6_2atmpS3985;
  #line 613 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L14_2acasted__envS3984
  = (struct _M0R110_24walkzzz_2fmcp__server__blackbox__test_2emoonbit__test__driver__internal__do__execute_2ehandle__start_7c1894*)_M0L6_2aenvS3983;
  _M0L8filenameS1896 = _M0L14_2acasted__envS3984->$1;
  _M0L5indexS1898 = _M0L14_2acasted__envS3984->$0;
  #line 614 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L10file__nameS1895
  = _M0MPC16string6String14escape_2einner(_M0L8filenameS1896, 1);
  #line 615 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0FPB7printlnGsE((moonbit_string_t)moonbit_string_literal_7.data);
  #line 617 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L18_2astring__builderS1897
  = _M0MPB13StringBuilder21StringBuilder_2einner(33);
  #line 617 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS1897, (moonbit_string_t)moonbit_string_literal_13.data);
  #line 617 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0MPB13StringBuilder13write__objectGsE(_M0L18_2astring__builderS1897, _M0L10file__nameS1895);
  moonbit_decref(_M0L10file__nameS1895);
  #line 617 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS1897, (moonbit_string_t)moonbit_string_literal_9.data);
  #line 617 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS1897, _M0L5indexS1898);
  #line 617 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS1897, (moonbit_string_t)moonbit_string_literal_11.data);
  #line 617 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L6_2atmpS3985
  = _M0MPB13StringBuilder10to__string(_M0L18_2astring__builderS1897);
  moonbit_decref(_M0L18_2astring__builderS1897);
  #line 616 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0FPB7printlnGsE(_M0L6_2atmpS3985);
  moonbit_decref(_M0L6_2atmpS3985);
  #line 619 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0FPB7printlnGsE((moonbit_string_t)moonbit_string_literal_12.data);
  return 0;
}

struct moonbit_result_0 _M0IP27walkzzz27mcp__server__blackbox__test41MoonBit__Test__Driver__Internal__No__ArgsP27walkzzz27mcp__server__blackbox__test21MoonBit__Test__Driver9run__test(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE* _M0L12_2adiscard__S1893,
  moonbit_string_t _M0L8filenameS1890,
  int32_t _M0L5indexS1884,
  struct _M0TWEu* _M0L13handle__startS1879,
  struct _M0TWssbEu* _M0L14handle__resultS1880,
  struct _M0TWRPC15error5ErrorEs* _M0L17error__to__stringS1882
) {
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0L10index__mapS1859;
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0L7_2abindS1889;
  struct _M0TWEuQRPC15error5Error* _M0L1fS1861;
  moonbit_string_t* _M0L5attrsS1862;
  struct _M0TUWEuQRPC15error5ErrorNsE* _M0L7_2abindS1883;
  moonbit_string_t _M0L4nameS1865;
  moonbit_string_t _M0L4nameS1863;
  int32_t _M0L6_2atmpS3982;
  struct _M0TPB4IterGsE* _M0L5_2aitS1867;
  struct _M0R191_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver_3a_3arun__test_7c_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver__Internal__No__Args_7c_2eanon__u3979__l477__* _closure_4275;
  struct _M0TWEu* _M0L6_2atmpS3973;
  struct _M0R191_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver_3a_3arun__test_7c_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver__Internal__No__Args_7c_2eanon__u3975__l478__* _closure_4276;
  struct _M0TWRPC15error5ErrorEu* _M0L6_2atmpS3974;
  struct moonbit_result_0 _result_4277;
  #line 455 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  #line 463 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L7_2abindS1889
  = _M0MPB3Map3getGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(_M0FP27walkzzz27mcp__server__blackbox__test48moonbit__test__driver__internal__no__args__tests, _M0L8filenameS1890);
  if (_M0L7_2abindS1889 == 0) {
    struct moonbit_result_0 _result_4268;
    if (_M0L7_2abindS1889) {
      moonbit_decref(_M0L7_2abindS1889);
    }
    _result_4268.tag = 1;
    _result_4268.data.ok = 0;
    return _result_4268;
  } else {
    struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0L7_2aSomeS1891 =
      _M0L7_2abindS1889;
    struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0L13_2aindex__mapS1892 =
      _M0L7_2aSomeS1891;
    _M0L10index__mapS1859 = _M0L13_2aindex__mapS1892;
    goto join_1858;
  }
  join_1858:;
  #line 465 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L7_2abindS1883
  = _M0MPB3Map3getGiUWEuQRPC15error5ErrorNsEE(_M0L10index__mapS1859, _M0L5indexS1884);
  moonbit_decref(_M0L10index__mapS1859);
  if (_M0L7_2abindS1883 == 0) {
    struct moonbit_result_0 _result_4270;
    if (_M0L7_2abindS1883) {
      moonbit_decref(_M0L7_2abindS1883);
    }
    _result_4270.tag = 1;
    _result_4270.data.ok = 0;
    return _result_4270;
  } else {
    struct _M0TUWEuQRPC15error5ErrorNsE* _M0L7_2aSomeS1885 =
      _M0L7_2abindS1883;
    struct _M0TUWEuQRPC15error5ErrorNsE* _M0L4_2axS1886 = _M0L7_2aSomeS1885;
    struct _M0TWEuQRPC15error5Error* _M0L4_2afS1887 = _M0L4_2axS1886->$0;
    moonbit_string_t* _M0L8_2aattrsS1888 = _M0L4_2axS1886->$1;
    int32_t _M0L6_2acntS4220 =
      Moonbit_rc_count(Moonbit_object_header(_M0L4_2axS1886));
    if (_M0L6_2acntS4220 > 1) {
      int32_t _M0L11_2anew__cntS4221 = _M0L6_2acntS4220 - 1;
      Moonbit_set_rc_count(Moonbit_object_header(_M0L4_2axS1886), _M0L11_2anew__cntS4221);
      moonbit_incref(_M0L8_2aattrsS1888);
      moonbit_incref(_M0L4_2afS1887);
    } else if (_M0L6_2acntS4220 == 1) {
      #line 463 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
      moonbit_free(_M0L4_2axS1886);
    }
    _M0L1fS1861 = _M0L4_2afS1887;
    _M0L5attrsS1862 = _M0L8_2aattrsS1888;
    goto join_1860;
  }
  join_1860:;
  _M0L6_2atmpS3982 = Moonbit_array_length(_M0L5attrsS1862);
  if (_M0L6_2atmpS3982 >= 1) {
    moonbit_string_t _M0L7_2anameS1866 = (moonbit_string_t)_M0L5attrsS1862[0];
    moonbit_incref(_M0L7_2anameS1866);
    _M0L4nameS1865 = _M0L7_2anameS1866;
    goto join_1864;
  } else {
    _M0L4nameS1863 = (moonbit_string_t)moonbit_string_literal_1.data;
  }
  goto joinlet_4271;
  join_1864:;
  _M0L4nameS1863 = _M0L4nameS1865;
  joinlet_4271:;
  #line 466 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L5_2aitS1867 = _M0MPC15array13ReadOnlyArray4iterGsE(_M0L5attrsS1862);
  moonbit_decref(_M0L5attrsS1862);
  while (1) {
    moonbit_string_t _M0L4attrS1869;
    moonbit_string_t _M0L7_2abindS1876;
    int32_t _M0L6_2atmpS3966;
    #line 468 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
    _M0L7_2abindS1876 = _M0MPB4Iter4nextGsE(_M0L5_2aitS1867);
    if (_M0L7_2abindS1876 == 0) {
      if (_M0L7_2abindS1876) {
        moonbit_decref(_M0L7_2abindS1876);
      }
      moonbit_decref(_M0L5_2aitS1867);
    } else {
      moonbit_string_t _M0L7_2aSomeS1877 = _M0L7_2abindS1876;
      moonbit_string_t _M0L7_2aattrS1878 = _M0L7_2aSomeS1877;
      _M0L4attrS1869 = _M0L7_2aattrS1878;
      goto join_1868;
    }
    goto joinlet_4273;
    join_1868:;
    _M0L6_2atmpS3966 = Moonbit_array_length(_M0L4attrS1869);
    if (_M0L6_2atmpS3966 >= 5) {
      int32_t _M0L6_2atmpS3972 = _M0L4attrS1869[0];
      int32_t _M0L4_2axS1870 = _M0L6_2atmpS3972;
      if (_M0L4_2axS1870 == 112) {
        int32_t _M0L6_2atmpS3971 = _M0L4attrS1869[1];
        int32_t _M0L4_2axS1871 = _M0L6_2atmpS3971;
        if (_M0L4_2axS1871 == 97) {
          int32_t _M0L6_2atmpS3970 = _M0L4attrS1869[2];
          int32_t _M0L4_2axS1872 = _M0L6_2atmpS3970;
          if (_M0L4_2axS1872 == 110) {
            int32_t _M0L6_2atmpS3969 = _M0L4attrS1869[3];
            int32_t _M0L4_2axS1873 = _M0L6_2atmpS3969;
            if (_M0L4_2axS1873 == 105) {
              int32_t _M0L6_2atmpS3968 = _M0L4attrS1869[4];
              int32_t _M0L4_2axS1874;
              moonbit_decref(_M0L4attrS1869);
              _M0L4_2axS1874 = _M0L6_2atmpS3968;
              if (_M0L4_2axS1874 == 99) {
                void* _M0L109walkzzz_2fmcp__server__blackbox__test_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTestS3967;
                struct moonbit_result_0 _result_4274;
                moonbit_decref(_M0L5_2aitS1867);
                moonbit_decref(_M0L1fS1861);
                _M0L109walkzzz_2fmcp__server__blackbox__test_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTestS3967
                = (void*)moonbit_malloc(sizeof(struct _M0DTPC15error5Error109walkzzz_2fmcp__server__blackbox__test_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTest));
                Moonbit_object_header(_M0L109walkzzz_2fmcp__server__blackbox__test_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTestS3967)->meta
                = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 6, 1);
                ((struct _M0DTPC15error5Error109walkzzz_2fmcp__server__blackbox__test_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTest*)_M0L109walkzzz_2fmcp__server__blackbox__test_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTestS3967)->$0
                = _M0L4nameS1863;
                _result_4274.tag = 0;
                _result_4274.data.err
                = _M0L109walkzzz_2fmcp__server__blackbox__test_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTestS3967;
                return _result_4274;
              }
            } else {
              moonbit_decref(_M0L4attrS1869);
            }
          } else {
            moonbit_decref(_M0L4attrS1869);
          }
        } else {
          moonbit_decref(_M0L4attrS1869);
        }
      } else {
        moonbit_decref(_M0L4attrS1869);
      }
    } else {
      moonbit_decref(_M0L4attrS1869);
    }
    continue;
    joinlet_4273:;
    break;
  }
  #line 474 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L13handle__startS1879->code(_M0L13handle__startS1879);
  moonbit_incref(_M0L14handle__resultS1880);
  moonbit_incref(_M0L4nameS1863);
  _closure_4275
  = (struct _M0R191_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver_3a_3arun__test_7c_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver__Internal__No__Args_7c_2eanon__u3979__l477__*)moonbit_malloc(sizeof(struct _M0R191_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver_3a_3arun__test_7c_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver__Internal__No__Args_7c_2eanon__u3979__l477__));
  Moonbit_object_header(_closure_4275)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 9, 0);
  _closure_4275->code
  = &_M0IP27walkzzz27mcp__server__blackbox__test41MoonBit__Test__Driver__Internal__No__ArgsP27walkzzz27mcp__server__blackbox__test21MoonBit__Test__Driver9run__testC3979l477;
  _closure_4275->$0 = _M0L14handle__resultS1880;
  _closure_4275->$1 = _M0L4nameS1863;
  _M0L6_2atmpS3973 = (struct _M0TWEu*)_closure_4275;
  moonbit_incref(_M0L17error__to__stringS1882);
  moonbit_incref(_M0L14handle__resultS1880);
  _closure_4276
  = (struct _M0R191_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver_3a_3arun__test_7c_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver__Internal__No__Args_7c_2eanon__u3975__l478__*)moonbit_malloc(sizeof(struct _M0R191_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver_3a_3arun__test_7c_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver__Internal__No__Args_7c_2eanon__u3975__l478__));
  Moonbit_object_header(_closure_4276)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 13, 0);
  _closure_4276->code
  = &_M0IP27walkzzz27mcp__server__blackbox__test41MoonBit__Test__Driver__Internal__No__ArgsP27walkzzz27mcp__server__blackbox__test21MoonBit__Test__Driver9run__testC3975l478;
  _closure_4276->$0 = _M0L17error__to__stringS1882;
  _closure_4276->$1 = _M0L14handle__resultS1880;
  _closure_4276->$2 = _M0L4nameS1863;
  _M0L6_2atmpS3974 = (struct _M0TWRPC15error5ErrorEu*)_closure_4276;
  #line 475 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0FP27walkzzz27mcp__server__blackbox__test45moonbit__test__driver__internal__catch__error(_M0L1fS1861, _M0L6_2atmpS3973, _M0L6_2atmpS3974);
  moonbit_decref(_M0L1fS1861);
  moonbit_decref(_M0L6_2atmpS3973);
  moonbit_decref(_M0L6_2atmpS3974);
  _result_4277.tag = 1;
  _result_4277.data.ok = 1;
  return _result_4277;
}

int32_t _M0IP27walkzzz27mcp__server__blackbox__test41MoonBit__Test__Driver__Internal__No__ArgsP27walkzzz27mcp__server__blackbox__test21MoonBit__Test__Driver9run__testC3979l477(
  struct _M0TWEu* _M0L6_2aenvS3980
) {
  struct _M0R191_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver_3a_3arun__test_7c_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver__Internal__No__Args_7c_2eanon__u3979__l477__* _M0L14_2acasted__envS3981;
  moonbit_string_t _M0L4nameS1863;
  struct _M0TWssbEu* _M0L14handle__resultS1880;
  #line 477 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L14_2acasted__envS3981
  = (struct _M0R191_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver_3a_3arun__test_7c_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver__Internal__No__Args_7c_2eanon__u3979__l477__*)_M0L6_2aenvS3980;
  _M0L4nameS1863 = _M0L14_2acasted__envS3981->$1;
  _M0L14handle__resultS1880 = _M0L14_2acasted__envS3981->$0;
  #line 477 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L14handle__resultS1880->code(_M0L14handle__resultS1880, _M0L4nameS1863, (moonbit_string_t)moonbit_string_literal_1.data, 0);
  return 0;
}

int32_t _M0IP27walkzzz27mcp__server__blackbox__test41MoonBit__Test__Driver__Internal__No__ArgsP27walkzzz27mcp__server__blackbox__test21MoonBit__Test__Driver9run__testC3975l478(
  struct _M0TWRPC15error5ErrorEu* _M0L6_2aenvS3976,
  void* _M0L3errS1881
) {
  struct _M0R191_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver_3a_3arun__test_7c_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver__Internal__No__Args_7c_2eanon__u3975__l478__* _M0L14_2acasted__envS3977;
  moonbit_string_t _M0L4nameS1863;
  struct _M0TWssbEu* _M0L14handle__resultS1880;
  struct _M0TWRPC15error5ErrorEs* _M0L17error__to__stringS1882;
  moonbit_string_t _M0L6_2atmpS3978;
  #line 478 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L14_2acasted__envS3977
  = (struct _M0R191_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver_3a_3arun__test_7c_40walkzzz_2fmcp__server__blackbox__test_2eMoonBit__Test__Driver__Internal__No__Args_7c_2eanon__u3975__l478__*)_M0L6_2aenvS3976;
  _M0L4nameS1863 = _M0L14_2acasted__envS3977->$2;
  _M0L14handle__resultS1880 = _M0L14_2acasted__envS3977->$1;
  _M0L17error__to__stringS1882 = _M0L14_2acasted__envS3977->$0;
  #line 478 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L6_2atmpS3978
  = _M0L17error__to__stringS1882->code(_M0L17error__to__stringS1882, _M0L3errS1881);
  #line 478 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L14handle__resultS1880->code(_M0L14handle__resultS1880, _M0L4nameS1863, _M0L6_2atmpS3978, 0);
  moonbit_decref(_M0L6_2atmpS3978);
  return 0;
}

int32_t _M0FP27walkzzz27mcp__server__blackbox__test45moonbit__test__driver__internal__catch__error(
  struct _M0TWEuQRPC15error5Error* _M0L1fS1854,
  struct _M0TWEu* _M0L6on__okS1855,
  struct _M0TWRPC15error5ErrorEu* _M0L7on__errS1852
) {
  void* _M0L11_2atry__errS1850;
  struct moonbit_result_0 _tmp_4279;
  void* _M0L3errS1851;
  #line 425 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  #line 432 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _tmp_4279 = _M0L1fS1854->code(_M0L1fS1854);
  if (_tmp_4279.tag) {
    int32_t const _M0L5_2aokS3964 = _tmp_4279.data.ok;
  } else {
    void* const _M0L6_2aerrS3965 = _tmp_4279.data.err;
    _M0L11_2atry__errS1850 = _M0L6_2aerrS3965;
    goto join_1849;
  }
  #line 432 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L6on__okS1855->code(_M0L6on__okS1855);
  goto joinlet_4278;
  join_1849:;
  _M0L3errS1851 = _M0L11_2atry__errS1850;
  #line 433 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L7on__errS1852->code(_M0L7on__errS1852, _M0L3errS1851);
  moonbit_decref(_M0L3errS1851);
  joinlet_4278:;
  return 0;
}

struct _M0TPB5ArrayGUsiEE* _M0FP27walkzzz27mcp__server__blackbox__test52moonbit__test__driver__internal__native__parse__args(
  
) {
  int32_t _M0L45moonbit__test__driver__internal__parse__int__S1820;
  int32_t _M0L51moonbit__test__driver__internal__split__mbt__stringS1827;
  struct _M0TUsiE** _M0L6_2atmpS3963;
  struct _M0TPB5ArrayGUsiEE* _M0L16file__and__indexS1834;
  moonbit_string_t* _M0L9cli__argsS1835;
  moonbit_string_t _M0L6_2atmpS4007;
  moonbit_string_t _M0L6_2atmpS3962;
  moonbit_string_t _M0L6_2atmpS3961;
  struct _M0TPB5ArrayGsE* _M0L10test__argsS1836;
  int32_t _M0L7_2abindS1837;
  int32_t _M0L2__S1838;
  #line 295 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L45moonbit__test__driver__internal__parse__int__S1820 = 0;
  _M0L51moonbit__test__driver__internal__split__mbt__stringS1827 = 0;
  _M0L6_2atmpS3963 = (struct _M0TUsiE**)moonbit_empty_ref_array;
  _M0L16file__and__indexS1834
  = (struct _M0TPB5ArrayGUsiEE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGUsiEE));
  Moonbit_object_header(_M0L16file__and__indexS1834)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 18, 0);
  _M0L16file__and__indexS1834->$0 = _M0L6_2atmpS3963;
  _M0L16file__and__indexS1834->$1 = 0;
  #line 329 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L9cli__argsS1835
  = _M0FP27walkzzz27mcp__server__blackbox__test52moonbit__test__driver__internal__get__cli__args__ffi();
  if (1 < 0 || 1 >= Moonbit_array_length(_M0L9cli__argsS1835)) {
    #line 331 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
    moonbit_panic();
  }
  _M0L6_2atmpS4007 = (moonbit_string_t)_M0L9cli__argsS1835[1];
  moonbit_incref(_M0L6_2atmpS4007);
  moonbit_decref(_M0L9cli__argsS1835);
  _M0L6_2atmpS3962 = _M0L6_2atmpS4007;
  #line 331 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L6_2atmpS3961
  = _M0MP27walkzzz27mcp__server__blackbox__test33MoonBitTestDriverInternalOsString10to__string(_M0L6_2atmpS3962);
  moonbit_decref(_M0L6_2atmpS3962);
  #line 330 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L10test__argsS1836
  = _M0FP27walkzzz27mcp__server__blackbox__test52moonbit__test__driver__internal__native__parse__argsN51moonbit__test__driver__internal__split__mbt__stringS1827(_M0L51moonbit__test__driver__internal__split__mbt__stringS1827, _M0L6_2atmpS3961, 47);
  moonbit_decref(_M0L6_2atmpS3961);
  _M0L7_2abindS1837 = _M0L10test__argsS1836->$1;
  _M0L2__S1838 = 0;
  while (1) {
    if (_M0L2__S1838 < _M0L7_2abindS1837) {
      moonbit_string_t* _M0L3bufS3960 = _M0L10test__argsS1836->$0;
      moonbit_string_t _M0L3argS1839 =
        (moonbit_string_t)_M0L3bufS3960[_M0L2__S1838];
      struct _M0TPB5ArrayGsE* _M0L16file__and__rangeS1840;
      moonbit_string_t _M0L4fileS1841;
      moonbit_string_t _M0L5rangeS1842;
      struct _M0TPB5ArrayGsE* _M0L15start__and__endS1843;
      moonbit_string_t _M0L6_2atmpS3958;
      int32_t _M0L5startS1844;
      moonbit_string_t _M0L6_2atmpS3957;
      int32_t _M0L3endS1845;
      int32_t _M0L1iS1846;
      int32_t _M0L6_2atmpS3959;
      moonbit_incref(_M0L3argS1839);
      #line 335 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
      _M0L16file__and__rangeS1840
      = _M0FP27walkzzz27mcp__server__blackbox__test52moonbit__test__driver__internal__native__parse__argsN51moonbit__test__driver__internal__split__mbt__stringS1827(_M0L51moonbit__test__driver__internal__split__mbt__stringS1827, _M0L3argS1839, 58);
      moonbit_decref(_M0L3argS1839);
      #line 336 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
      _M0L4fileS1841
      = _M0MPC15array5Array2atGsE(_M0L16file__and__rangeS1840, 0);
      #line 337 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
      _M0L5rangeS1842
      = _M0MPC15array5Array2atGsE(_M0L16file__and__rangeS1840, 1);
      moonbit_decref(_M0L16file__and__rangeS1840);
      #line 338 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
      _M0L15start__and__endS1843
      = _M0FP27walkzzz27mcp__server__blackbox__test52moonbit__test__driver__internal__native__parse__argsN51moonbit__test__driver__internal__split__mbt__stringS1827(_M0L51moonbit__test__driver__internal__split__mbt__stringS1827, _M0L5rangeS1842, 45);
      moonbit_decref(_M0L5rangeS1842);
      #line 341 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
      _M0L6_2atmpS3958
      = _M0MPC15array5Array2atGsE(_M0L15start__and__endS1843, 0);
      #line 341 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
      _M0L5startS1844
      = _M0FP27walkzzz27mcp__server__blackbox__test52moonbit__test__driver__internal__native__parse__argsN45moonbit__test__driver__internal__parse__int__S1820(_M0L45moonbit__test__driver__internal__parse__int__S1820, _M0L6_2atmpS3958);
      moonbit_decref(_M0L6_2atmpS3958);
      #line 342 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
      _M0L6_2atmpS3957
      = _M0MPC15array5Array2atGsE(_M0L15start__and__endS1843, 1);
      moonbit_decref(_M0L15start__and__endS1843);
      #line 342 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
      _M0L3endS1845
      = _M0FP27walkzzz27mcp__server__blackbox__test52moonbit__test__driver__internal__native__parse__argsN45moonbit__test__driver__internal__parse__int__S1820(_M0L45moonbit__test__driver__internal__parse__int__S1820, _M0L6_2atmpS3957);
      moonbit_decref(_M0L6_2atmpS3957);
      _M0L1iS1846 = _M0L5startS1844;
      while (1) {
        if (_M0L1iS1846 < _M0L3endS1845) {
          struct _M0TUsiE* _M0L8_2atupleS3955;
          int32_t _M0L6_2atmpS3956;
          moonbit_incref(_M0L4fileS1841);
          _M0L8_2atupleS3955
          = (struct _M0TUsiE*)moonbit_malloc(sizeof(struct _M0TUsiE));
          Moonbit_object_header(_M0L8_2atupleS3955)->meta
          = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 21, 0);
          _M0L8_2atupleS3955->$0 = _M0L4fileS1841;
          _M0L8_2atupleS3955->$1 = _M0L1iS1846;
          #line 344 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
          _M0MPC15array5Array4pushGUsiEE(_M0L16file__and__indexS1834, _M0L8_2atupleS3955);
          _M0L6_2atmpS3956 = _M0L1iS1846 + 1;
          _M0L1iS1846 = _M0L6_2atmpS3956;
          continue;
        } else {
          moonbit_decref(_M0L4fileS1841);
        }
        break;
      }
      _M0L6_2atmpS3959 = _M0L2__S1838 + 1;
      _M0L2__S1838 = _M0L6_2atmpS3959;
      continue;
    } else {
      moonbit_decref(_M0L10test__argsS1836);
    }
    break;
  }
  return _M0L16file__and__indexS1834;
}

struct _M0TPB5ArrayGsE* _M0FP27walkzzz27mcp__server__blackbox__test52moonbit__test__driver__internal__native__parse__argsN51moonbit__test__driver__internal__split__mbt__stringS1827(
  int32_t _M0L6_2aenvS3936,
  moonbit_string_t _M0L1sS1828,
  int32_t _M0L3sepS1829
) {
  moonbit_string_t* _M0L6_2atmpS3954;
  struct _M0TPB5ArrayGsE* _M0L3resS1830;
  struct _M0TPB8MutLocalGiE* _M0L1iS1831;
  struct _M0TPB8MutLocalGiE* _M0L5startS1832;
  int32_t _M0L3valS3949;
  int32_t _M0L6_2atmpS3950;
  #line 308 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L6_2atmpS3954 = (moonbit_string_t*)moonbit_empty_ref_array;
  _M0L3resS1830
  = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
  Moonbit_object_header(_M0L3resS1830)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
  _M0L3resS1830->$0 = _M0L6_2atmpS3954;
  _M0L3resS1830->$1 = 0;
  _M0L1iS1831
  = (struct _M0TPB8MutLocalGiE*)moonbit_malloc(sizeof(struct _M0TPB8MutLocalGiE));
  Moonbit_object_header(_M0L1iS1831)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0);
  _M0L1iS1831->$0 = 0;
  _M0L5startS1832
  = (struct _M0TPB8MutLocalGiE*)moonbit_malloc(sizeof(struct _M0TPB8MutLocalGiE));
  Moonbit_object_header(_M0L5startS1832)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0);
  _M0L5startS1832->$0 = 0;
  while (1) {
    int32_t _M0L3valS3937 = _M0L1iS1831->$0;
    int32_t _M0L6_2atmpS3938 = Moonbit_array_length(_M0L1sS1828);
    if (_M0L3valS3937 < _M0L6_2atmpS3938) {
      int32_t _M0L3valS3941 = _M0L1iS1831->$0;
      int32_t _M0L6_2atmpS3940;
      int32_t _M0L6_2atmpS3939;
      int32_t _M0L3valS3948;
      int32_t _M0L6_2atmpS3947;
      if (
        _M0L3valS3941 < 0
        || _M0L3valS3941 >= Moonbit_array_length(_M0L1sS1828)
      ) {
        #line 316 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
        moonbit_panic();
      }
      _M0L6_2atmpS3940 = _M0L1sS1828[_M0L3valS3941];
      _M0L6_2atmpS3939 = _M0L6_2atmpS3940;
      if (_M0L6_2atmpS3939 == _M0L3sepS1829) {
        int32_t _M0L3valS3943 = _M0L5startS1832->$0;
        int32_t _M0L3valS3944 = _M0L1iS1831->$0;
        moonbit_string_t _M0L6_2atmpS3942;
        int32_t _M0L3valS3946;
        int32_t _M0L6_2atmpS3945;
        #line 317 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
        _M0L6_2atmpS3942
        = _M0MPC16string6String17unsafe__substring(_M0L1sS1828, _M0L3valS3943, _M0L3valS3944);
        #line 317 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
        _M0MPC15array5Array4pushGsE(_M0L3resS1830, _M0L6_2atmpS3942);
        _M0L3valS3946 = _M0L1iS1831->$0;
        _M0L6_2atmpS3945 = _M0L3valS3946 + 1;
        _M0L5startS1832->$0 = _M0L6_2atmpS3945;
      }
      _M0L3valS3948 = _M0L1iS1831->$0;
      _M0L6_2atmpS3947 = _M0L3valS3948 + 1;
      _M0L1iS1831->$0 = _M0L6_2atmpS3947;
      continue;
    } else {
      moonbit_decref(_M0L1iS1831);
    }
    break;
  }
  _M0L3valS3949 = _M0L5startS1832->$0;
  _M0L6_2atmpS3950 = Moonbit_array_length(_M0L1sS1828);
  if (_M0L3valS3949 < _M0L6_2atmpS3950) {
    int32_t _M0L3valS3952 = _M0L5startS1832->$0;
    int32_t _M0L6_2atmpS3953;
    moonbit_string_t _M0L6_2atmpS3951;
    moonbit_decref(_M0L5startS1832);
    _M0L6_2atmpS3953 = Moonbit_array_length(_M0L1sS1828);
    #line 323 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
    _M0L6_2atmpS3951
    = _M0MPC16string6String17unsafe__substring(_M0L1sS1828, _M0L3valS3952, _M0L6_2atmpS3953);
    #line 323 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
    _M0MPC15array5Array4pushGsE(_M0L3resS1830, _M0L6_2atmpS3951);
  } else {
    moonbit_decref(_M0L5startS1832);
  }
  return _M0L3resS1830;
}

int32_t _M0FP27walkzzz27mcp__server__blackbox__test52moonbit__test__driver__internal__native__parse__argsN45moonbit__test__driver__internal__parse__int__S1820(
  int32_t _M0L6_2aenvS3929,
  moonbit_string_t _M0L1sS1821
) {
  struct _M0TPB8MutLocalGiE* _M0L3resS1822;
  int32_t _M0L3lenS1823;
  int32_t _M0L7_2abindS1824;
  int32_t _M0L1iS1825;
  int32_t _result_4284;
  #line 299 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L3resS1822
  = (struct _M0TPB8MutLocalGiE*)moonbit_malloc(sizeof(struct _M0TPB8MutLocalGiE));
  Moonbit_object_header(_M0L3resS1822)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0);
  _M0L3resS1822->$0 = 0;
  _M0L3lenS1823 = Moonbit_array_length(_M0L1sS1821);
  _M0L7_2abindS1824 = 0;
  _M0L1iS1825 = _M0L7_2abindS1824;
  while (1) {
    if (_M0L1iS1825 < _M0L3lenS1823) {
      int32_t _M0L3valS3934 = _M0L3resS1822->$0;
      int32_t _M0L6_2atmpS3931 = _M0L3valS3934 * 10;
      int32_t _M0L6_2atmpS3933;
      int32_t _M0L6_2atmpS3932;
      int32_t _M0L6_2atmpS3930;
      int32_t _M0L6_2atmpS3935;
      if (
        _M0L1iS1825 < 0 || _M0L1iS1825 >= Moonbit_array_length(_M0L1sS1821)
      ) {
        #line 303 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
        moonbit_panic();
      }
      _M0L6_2atmpS3933 = _M0L1sS1821[_M0L1iS1825];
      _M0L6_2atmpS3932 = _M0L6_2atmpS3933 - 48;
      _M0L6_2atmpS3930 = _M0L6_2atmpS3931 + _M0L6_2atmpS3932;
      _M0L3resS1822->$0 = _M0L6_2atmpS3930;
      _M0L6_2atmpS3935 = _M0L1iS1825 + 1;
      _M0L1iS1825 = _M0L6_2atmpS3935;
      continue;
    }
    break;
  }
  _result_4284 = _M0L3resS1822->$0;
  moonbit_decref(_M0L3resS1822);
  return _result_4284;
}

moonbit_string_t _M0MP27walkzzz27mcp__server__blackbox__test33MoonBitTestDriverInternalOsString10to__string(
  moonbit_string_t _M0L4selfS1819
) {
  #line 164 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  moonbit_incref(_M0L4selfS1819);
  return _M0L4selfS1819;
}

struct moonbit_result_0 _M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test21MoonBit__Test__Driver9run__testGRP27walkzzz27mcp__server__blackbox__test43MoonBit__Test__Driver__Internal__With__ArgsE(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE* _M0L12_2adiscard__S1795,
  moonbit_string_t _M0L12_2adiscard__S1796,
  int32_t _M0L12_2adiscard__S1797,
  struct _M0TWEu* _M0L12_2adiscard__S1798,
  struct _M0TWssbEu* _M0L12_2adiscard__S1799,
  struct _M0TWRPC15error5ErrorEs* _M0L12_2adiscard__S1800
) {
  struct moonbit_result_0 _result_4285;
  #line 35 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _result_4285.tag = 1;
  _result_4285.data.ok = 0;
  return _result_4285;
}

struct moonbit_result_0 _M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test21MoonBit__Test__Driver9run__testGRP27walkzzz27mcp__server__blackbox__test48MoonBit__Test__Driver__Internal__Async__No__ArgsE(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE* _M0L12_2adiscard__S1801,
  moonbit_string_t _M0L12_2adiscard__S1802,
  int32_t _M0L12_2adiscard__S1803,
  struct _M0TWEu* _M0L12_2adiscard__S1804,
  struct _M0TWssbEu* _M0L12_2adiscard__S1805,
  struct _M0TWRPC15error5ErrorEs* _M0L12_2adiscard__S1806
) {
  struct moonbit_result_0 _result_4286;
  #line 35 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _result_4286.tag = 1;
  _result_4286.data.ok = 0;
  return _result_4286;
}

struct moonbit_result_0 _M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test21MoonBit__Test__Driver9run__testGRP27walkzzz27mcp__server__blackbox__test50MoonBit__Test__Driver__Internal__Async__With__ArgsE(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE* _M0L12_2adiscard__S1807,
  moonbit_string_t _M0L12_2adiscard__S1808,
  int32_t _M0L12_2adiscard__S1809,
  struct _M0TWEu* _M0L12_2adiscard__S1810,
  struct _M0TWssbEu* _M0L12_2adiscard__S1811,
  struct _M0TWRPC15error5ErrorEs* _M0L12_2adiscard__S1812
) {
  struct moonbit_result_0 _result_4287;
  #line 35 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _result_4287.tag = 1;
  _result_4287.data.ok = 0;
  return _result_4287;
}

struct moonbit_result_0 _M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test21MoonBit__Test__Driver9run__testGRP27walkzzz27mcp__server__blackbox__test50MoonBit__Test__Driver__Internal__With__Bench__ArgsE(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE* _M0L12_2adiscard__S1813,
  moonbit_string_t _M0L12_2adiscard__S1814,
  int32_t _M0L12_2adiscard__S1815,
  struct _M0TWEu* _M0L12_2adiscard__S1816,
  struct _M0TWssbEu* _M0L12_2adiscard__S1817,
  struct _M0TWRPC15error5ErrorEs* _M0L12_2adiscard__S1818
) {
  struct moonbit_result_0 _result_4288;
  #line 35 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _result_4288.tag = 1;
  _result_4288.data.ok = 0;
  return _result_4288;
}

int32_t _M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test28MoonBit__Async__Test__Driver20is__being__cancelledGRP27walkzzz27mcp__server__blackbox__test34MoonBit__Async__Test__Driver__ImplE(
  
) {
  #line 17 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  return 0;
}

int32_t _M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test28MoonBit__Async__Test__Driver17run__async__testsGRP27walkzzz27mcp__server__blackbox__test34MoonBit__Async__Test__Driver__ImplE(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE* _M0L12_2adiscard__S1794
) {
  #line 12 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  return 0;
}

struct moonbit_result_0 _M0FP27walkzzz27mcp__server__blackbox__test35____test__657870656e73652e6d6274__0(
  
) {
  struct _M0TPB5ArrayGRP27walkzzz11mcp__server8CategoryE* _M0L6_2atmpS3928;
  int32_t _M0L6_2atmpS3926;
  moonbit_string_t _M0L6_2atmpS3927;
  struct moonbit_result_0 _result_4289;
  #line 131 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\expense.mbt"
  #line 132 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\expense.mbt"
  _M0L6_2atmpS3928 = _M0FP27walkzzz11mcp__server15all__categories();
  #line 132 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\expense.mbt"
  _M0L6_2atmpS3926
  = _M0MPC15array5Array6lengthGRP27walkzzz11mcp__server8CategoryE(_M0L6_2atmpS3928);
  moonbit_decref(_M0L6_2atmpS3928);
  _M0L6_2atmpS3927 = 0;
  #line 132 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\expense.mbt"
  _result_4289
  = _M0FPC15debug10assert__eqGiE(_M0L6_2atmpS3926, 5, _M0L6_2atmpS3927, (moonbit_string_t)moonbit_string_literal_14.data);
  if (_M0L6_2atmpS3927) {
    moonbit_decref(_M0L6_2atmpS3927);
  }
  return _result_4289;
}

struct _M0TPB5ArrayGRP27walkzzz11mcp__server8CategoryE* _M0FP27walkzzz11mcp__server15all__categories(
  
) {
  int32_t* _M0L6_2atmpS3925;
  struct _M0TPB5ArrayGRP27walkzzz11mcp__server8CategoryE* _block_4290;
  #line 135 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\expense.mbt"
  _M0L6_2atmpS3925 = (int32_t*)moonbit_make_int32_array_raw(5);
  _M0L6_2atmpS3925[0] = 0;
  _M0L6_2atmpS3925[1] = 1;
  _M0L6_2atmpS3925[2] = 2;
  _M0L6_2atmpS3925[3] = 3;
  _M0L6_2atmpS3925[4] = 4;
  _block_4290
  = (struct _M0TPB5ArrayGRP27walkzzz11mcp__server8CategoryE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGRP27walkzzz11mcp__server8CategoryE));
  Moonbit_object_header(_block_4290)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 27, 0);
  _block_4290->$0 = _M0L6_2atmpS3925;
  _block_4290->$1 = 5;
  return _block_4290;
}

struct moonbit_result_0 _M0FPC15debug10assert__eqGiE(
  int32_t _M0L1aS1784,
  int32_t _M0L1bS1785,
  moonbit_string_t _M0L3msgS1787,
  moonbit_string_t _M0L3locS1793
) {
  #line 256 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\debug.mbt"
  if (_M0L1aS1784 != _M0L1bS1785) {
    moonbit_string_t _M0L9fail__msgS1786;
    int32_t _M0L6_2atmpS3919;
    struct _M0TPC16string10StringView _M0L6_2atmpS3918;
    struct moonbit_result_0 _result_4291;
    if (_M0L3msgS1787 == 0) {
      void* _M0L7repr__aS1789;
      void* _M0L7repr__bS1790;
      void* _M0L4NoneS3923;
      void* _M0L6_2atmpS3922;
      moonbit_string_t _M0L4diffS1791;
      struct _M0TPB13StringBuilder* _M0L18_2astring__builderS1792;
      moonbit_string_t _M0L6_2atmpS3920;
      moonbit_string_t _M0L6_2atmpS3921;
      #line 267 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\debug.mbt"
      _M0L7repr__aS1789 = _M0MPC15debug4Repr4ReprGiE(_M0L1aS1784);
      #line 268 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\debug.mbt"
      _M0L7repr__bS1790 = _M0MPC15debug4Repr4ReprGiE(_M0L1bS1785);
      _M0L4NoneS3923
      = (struct moonbit_object*)&moonbit_constant_constructor_0 + 1;
      #line 269 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\debug.mbt"
      _M0L6_2atmpS3922
      = _M0FPC15debug10diff__repr(_M0L7repr__aS1789, _M0L7repr__bS1790, _M0L4NoneS3923);
      moonbit_decref(_M0L4NoneS3923);
      #line 269 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\debug.mbt"
      _M0L4diffS1791
      = _M0FPC15debug20pretty__print__delta(_M0L6_2atmpS3922, 4294967296ll, 4294967296ll, _M0FPC15debug10assert__eqN6constrS1770GiE);
      moonbit_decref(_M0L6_2atmpS3922);
      #line 271 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\debug.mbt"
      _M0L18_2astring__builderS1792
      = _M0MPB13StringBuilder21StringBuilder_2einner(13);
      #line 271 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\debug.mbt"
      _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS1792, (moonbit_string_t)moonbit_string_literal_15.data);
      #line 271 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\debug.mbt"
      _M0L6_2atmpS3920
      = _M0FPC15debug6render(_M0L7repr__aS1789, 4294967296ll);
      moonbit_decref(_M0L7repr__aS1789);
      #line 271 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\debug.mbt"
      _M0MPB13StringBuilder13write__objectGsE(_M0L18_2astring__builderS1792, _M0L6_2atmpS3920);
      moonbit_decref(_M0L6_2atmpS3920);
      #line 271 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\debug.mbt"
      _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS1792, (moonbit_string_t)moonbit_string_literal_16.data);
      #line 271 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\debug.mbt"
      _M0L6_2atmpS3921
      = _M0FPC15debug6render(_M0L7repr__bS1790, 4294967296ll);
      moonbit_decref(_M0L7repr__bS1790);
      #line 271 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\debug.mbt"
      _M0MPB13StringBuilder13write__objectGsE(_M0L18_2astring__builderS1792, _M0L6_2atmpS3921);
      moonbit_decref(_M0L6_2atmpS3921);
      #line 271 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\debug.mbt"
      _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS1792, (moonbit_string_t)moonbit_string_literal_17.data);
      #line 273 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\debug.mbt"
      _M0MPB13StringBuilder13write__objectGsE(_M0L18_2astring__builderS1792, _M0L4diffS1791);
      moonbit_decref(_M0L4diffS1791);
      #line 271 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\debug.mbt"
      _M0L9fail__msgS1786
      = _M0MPB13StringBuilder10to__string(_M0L18_2astring__builderS1792);
      moonbit_decref(_M0L18_2astring__builderS1792);
    } else {
      moonbit_string_t _M0L7_2aSomeS1788 = _M0L3msgS1787;
      if (_M0L7_2aSomeS1788) {
        moonbit_incref(_M0L7_2aSomeS1788);
      }
      _M0L9fail__msgS1786 = _M0L7_2aSomeS1788;
    }
    _M0L6_2atmpS3919 = Moonbit_array_length(_M0L9fail__msgS1786);
    _M0L6_2atmpS3918
    = (struct _M0TPC16string10StringView){
      .$0 = _M0L9fail__msgS1786, .$1 = 0, .$2 = _M0L6_2atmpS3919
    };
    #line 277 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\debug.mbt"
    _result_4291 = _M0FPB4failGuE(_M0L6_2atmpS3918, _M0L3locS1793);
    moonbit_decref(_M0L6_2atmpS3918.$0);
    return _result_4291;
  } else {
    int32_t _M0L6_2atmpS3924 = 0;
    struct moonbit_result_0 _result_4292;
    _result_4292.tag = 1;
    _result_4292.data.ok = _M0L6_2atmpS3924;
    return _result_4292;
  }
}

void* _M0IPC13int3IntPC15debug5Debug8to__repr(int32_t _M0L4selfS1783) {
  moonbit_string_t _M0L6_2atmpS3917;
  void* _result_4293;
  #line 23 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\debug.mbt"
  #line 24 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\debug.mbt"
  _M0L6_2atmpS3917 = _M0MPC13int3Int18to__string_2einner(_M0L4selfS1783, 10);
  #line 24 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\debug.mbt"
  _result_4293 = _M0MPC15debug4Repr7integer(_M0L6_2atmpS3917);
  moonbit_decref(_M0L6_2atmpS3917);
  return _result_4293;
}

moonbit_string_t _M0FPC15debug20pretty__print__delta(
  void* _M0L1dS1781,
  int64_t _M0L10max__depthS1782,
  int64_t _M0L24compact__threshold_2eoptS1776,
  int32_t _M0L15use__ansi_2eoptS1779
) {
  int32_t _M0L18compact__thresholdS1775;
  int32_t _M0L9use__ansiS1778;
  if (_M0L24compact__threshold_2eoptS1776 == 4294967296ll) {
    _M0L18compact__thresholdS1775 = 70;
  } else {
    int64_t _M0L7_2aSomeS1777 = _M0L24compact__threshold_2eoptS1776;
    _M0L18compact__thresholdS1775 = (int32_t)_M0L7_2aSomeS1777;
  }
  if (_M0L15use__ansi_2eoptS1779 == -1) {
    _M0L9use__ansiS1778 = 1;
  } else {
    _M0L9use__ansiS1778 = _M0L15use__ansi_2eoptS1779;
  }
  return _M0FPC15debug28pretty__print__delta_2einner(_M0L1dS1781, _M0L10max__depthS1782, _M0L18compact__thresholdS1775, _M0L9use__ansiS1778);
}

moonbit_string_t _M0FPC15debug28pretty__print__delta_2einner(
  void* _M0L1dS1772,
  int64_t _M0L10max__depthS1770,
  int32_t _M0L18compact__thresholdS1773,
  int32_t _M0L9use__ansiS1774
) {
  int64_t _M0L10max__depthS1769;
  void* _M0L5deltaS1771;
  struct _M0TPC15debug7Content* _M0L6_2atmpS3916;
  struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3915;
  moonbit_string_t _result_4294;
  #line 160 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  if (_M0L10max__depthS1770 == 4294967296ll) {
    _M0L10max__depthS1769
    = _M0FPC15debug28pretty__print__delta_2einnerN6constrS1768;
  } else {
    _M0L10max__depthS1769 = _M0L10max__depthS1770;
  }
  #line 170 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  _M0L5deltaS1771
  = _M0FPC15debug12prune__delta(_M0L10max__depthS1769, _M0L1dS1772);
  #line 171 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  _M0L6_2atmpS3916
  = _M0FPC15debug13render__delta(_M0L18compact__thresholdS1773, _M0L9use__ansiS1774, _M0L5deltaS1771);
  moonbit_decref(_M0L5deltaS1771);
  #line 171 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  _M0L6_2atmpS3915 = _M0MPC15debug7Content8no__wrap(_M0L6_2atmpS3916);
  moonbit_decref(_M0L6_2atmpS3916);
  #line 171 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  _result_4294 = _M0FPC15debug14print__content(_M0L6_2atmpS3915);
  moonbit_decref(_M0L6_2atmpS3915);
  return _result_4294;
}

struct _M0TPC15debug7Content* _M0FPC15debug13render__delta(
  int32_t _M0L9thresholdS1750,
  int32_t _M0L9use__ansiS1751,
  void* _M0L5deltaS1744
) {
  #line 256 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  switch (Moonbit_object_tag(_M0L5deltaS1744)) {
    case 0: {
      struct _M0DTPC15debug9ReprDelta4Same* _M0L7_2aSameS1745 =
        (struct _M0DTPC15debug9ReprDelta4Same*)_M0L5deltaS1744;
      void* _M0L8_2alabelS1746 = _M0L7_2aSameS1745->$0;
      struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* _M0L18_2achildren__deltaS1747 =
        _M0L7_2aSameS1745->$1;
      struct _M0R67_24moonbitlang_2fcore_2fdebug_2erender__delta_2eanon__u3912__l259__* _closure_4295 =
        (struct _M0R67_24moonbitlang_2fcore_2fdebug_2erender__delta_2eanon__u3912__l259__*)moonbit_malloc(sizeof(struct _M0R67_24moonbitlang_2fcore_2fdebug_2erender__delta_2eanon__u3912__l259__));
      struct _M0TWRPC15debug9ReprDeltaERPC15debug7Content* _M0L6_2atmpS3911;
      struct _M0TPB5ArrayGRPC15debug7ContentE* _M0L8childrenS1748;
      int32_t _M0L6_2atmpS3909;
      struct _M0TPC15debug7Content* _M0L6_2atmpS3910;
      struct _M0TPC15debug7Content* _result_4296;
      Moonbit_object_header(_closure_4295)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0);
      _closure_4295->code = &_M0FPC15debug13render__deltaC3912l259;
      _closure_4295->$0 = _M0L9use__ansiS1751;
      _closure_4295->$1 = _M0L9thresholdS1750;
      _M0L6_2atmpS3911
      = (struct _M0TWRPC15debug9ReprDeltaERPC15debug7Content*)_closure_4295;
      #line 259 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
      _M0L8childrenS1748
      = _M0MPC15array5Array3mapGRPC15debug9ReprDeltaRPC15debug7ContentE(_M0L18_2achildren__deltaS1747, _M0L6_2atmpS3911);
      moonbit_decref(_M0L6_2atmpS3911);
      #line 263 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
      _M0L6_2atmpS3909 = _M0FPC15debug17delta__root__size(_M0L5deltaS1744);
      #line 265 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
      _M0L6_2atmpS3910
      = _M0MPC15debug4Repr13pretty__print(_M0L8_2alabelS1746, _M0L8childrenS1748);
      moonbit_decref(_M0L8childrenS1748);
      #line 262 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
      _result_4296
      = _M0FPC15debug14with__resizing(_M0L6_2atmpS3909, _M0L9thresholdS1750, _M0L6_2atmpS3910);
      moonbit_decref(_M0L6_2atmpS3910);
      return _result_4296;
      break;
    }
    
    case 1: {
      struct _M0DTPC15debug9ReprDelta9Different* _M0L12_2aDifferentS1752 =
        (struct _M0DTPC15debug9ReprDelta9Different*)_M0L5deltaS1744;
      void* _M0L7_2aleftS1753 = _M0L12_2aDifferentS1752->$0;
      void* _M0L8_2arightS1754 = _M0L12_2aDifferentS1752->$1;
      struct _M0TPC15debug7Content* _M0L6_2atmpS3907;
      struct _M0TPC15debug7Content* _M0L6_2atmpS3908;
      struct _M0TPC15debug7Content** _M0Lm13children__bufS1755;
      int32_t _M0Lm13children__lenS1756;
      int32_t _M0L6_2atmpS3899;
      struct _M0TPC15debug7Content* _M0L6_2atmpS3898;
      struct _M0TPC15debug7Content* _result_4297;
      #line 270 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
      _M0L6_2atmpS3907
      = _M0MPC15debug4Repr12render__repr(_M0L7_2aleftS1753, _M0L9thresholdS1750);
      #line 271 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
      _M0L6_2atmpS3908
      = _M0MPC15debug4Repr12render__repr(_M0L8_2arightS1754, _M0L9thresholdS1750);
      _M0Lm13children__bufS1755
      = (struct _M0TPC15debug7Content**)moonbit_make_ref_array_raw(2);
      _M0Lm13children__bufS1755[0] = _M0L6_2atmpS3907;
      _M0Lm13children__bufS1755[1] = _M0L6_2atmpS3908;
      _M0Lm13children__lenS1756 = 2;
      _M0L6_2atmpS3899 = _M0Lm13children__lenS1756;
      if (_M0L6_2atmpS3899 == 2) {
        struct _M0TPC15debug7Content** _M0L6_2atmpS3906 =
          _M0Lm13children__bufS1755;
        struct _M0TPC15debug7Content* _M0L7_2aleftS1757 =
          (struct _M0TPC15debug7Content*)_M0L6_2atmpS3906[0];
        struct _M0TPC15debug7Content** _M0L6_2atmpS3905 =
          _M0Lm13children__bufS1755;
        struct _M0TPC15debug7Content* _M0L6_2atmpS4008 =
          (struct _M0TPC15debug7Content*)_M0L6_2atmpS3905[1];
        struct _M0TPC15debug7Content* _M0L8_2arightS1758;
        struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3904;
        struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3901;
        struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3903;
        struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3902;
        struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3900;
        if (_M0L6_2atmpS4008) {
          moonbit_incref(_M0L6_2atmpS4008);
        }
        moonbit_incref(_M0L7_2aleftS1757);
        moonbit_decref(_M0L6_2atmpS3905);
        _M0L8_2arightS1758 = _M0L6_2atmpS4008;
        #line 279 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0L6_2atmpS3904 = _M0MPC15debug7Content8no__wrap(_M0L7_2aleftS1757);
        moonbit_decref(_M0L7_2aleftS1757);
        #line 279 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0L6_2atmpS3901
        = _M0FPC15debug13mark__removed(_M0L9use__ansiS1751, _M0L6_2atmpS3904);
        moonbit_decref(_M0L6_2atmpS3904);
        #line 280 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0L6_2atmpS3903 = _M0MPC15debug7Content8no__wrap(_M0L8_2arightS1758);
        moonbit_decref(_M0L8_2arightS1758);
        #line 280 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0L6_2atmpS3902
        = _M0FPC15debug11mark__added(_M0L9use__ansiS1751, _M0L6_2atmpS3903);
        moonbit_decref(_M0L6_2atmpS3903);
        #line 279 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0L6_2atmpS3900
        = _M0IPC15debug13ContentParensPB3Add3add(_M0L6_2atmpS3901, _M0L6_2atmpS3902);
        moonbit_decref(_M0L6_2atmpS3901);
        moonbit_decref(_M0L6_2atmpS3902);
        #line 278 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0L6_2atmpS3898 = _M0FPC15debug10no__parens(_M0L6_2atmpS3900);
        moonbit_decref(_M0L6_2atmpS3900);
      } else {
        moonbit_decref(_M0Lm13children__bufS1755);
        #line 282 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0L6_2atmpS3898 = _M0FPC15debug14empty__content();
      }
      #line 273 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
      _result_4297
      = _M0FPC15debug14with__resizing(0, _M0L9thresholdS1750, _M0L6_2atmpS3898);
      moonbit_decref(_M0L6_2atmpS3898);
      return _result_4297;
      break;
    }
    
    case 2: {
      struct _M0DTPC15debug9ReprDelta6Extra1* _M0L9_2aExtra1S1759 =
        (struct _M0DTPC15debug9ReprDelta6Extra1*)_M0L5deltaS1744;
      void* _M0L4_2axS1760 = _M0L9_2aExtra1S1759->$0;
      struct _M0TPC15debug7Content* _M0L6_2atmpS3897;
      struct _M0TPC15debug7Content** _M0Lm13children__bufS1761;
      int32_t _M0Lm13children__lenS1762;
      int32_t _M0L6_2atmpS3893;
      struct _M0TPC15debug7Content* _M0L6_2atmpS3892;
      struct _M0TPC15debug7Content* _result_4298;
      #line 287 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
      _M0L6_2atmpS3897
      = _M0MPC15debug4Repr12render__repr(_M0L4_2axS1760, _M0L9thresholdS1750);
      _M0Lm13children__bufS1761
      = (struct _M0TPC15debug7Content**)moonbit_make_ref_array_raw(1);
      _M0Lm13children__bufS1761[0] = _M0L6_2atmpS3897;
      _M0Lm13children__lenS1762 = 1;
      _M0L6_2atmpS3893 = _M0Lm13children__lenS1762;
      if (_M0L6_2atmpS3893 == 1) {
        struct _M0TPC15debug7Content** _M0L6_2atmpS3896 =
          _M0Lm13children__bufS1761;
        struct _M0TPC15debug7Content* _M0L6_2atmpS4010 =
          (struct _M0TPC15debug7Content*)_M0L6_2atmpS3896[0];
        struct _M0TPC15debug7Content* _M0L4_2axS1763;
        struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3895;
        struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3894;
        if (_M0L6_2atmpS4010) {
          moonbit_incref(_M0L6_2atmpS4010);
        }
        moonbit_decref(_M0L6_2atmpS3896);
        _M0L4_2axS1763 = _M0L6_2atmpS4010;
        #line 292 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0L6_2atmpS3895 = _M0MPC15debug7Content8no__wrap(_M0L4_2axS1763);
        moonbit_decref(_M0L4_2axS1763);
        #line 292 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0L6_2atmpS3894
        = _M0FPC15debug13mark__removed(_M0L9use__ansiS1751, _M0L6_2atmpS3895);
        moonbit_decref(_M0L6_2atmpS3895);
        #line 292 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0L6_2atmpS3892 = _M0FPC15debug10no__parens(_M0L6_2atmpS3894);
        moonbit_decref(_M0L6_2atmpS3894);
      } else {
        moonbit_decref(_M0Lm13children__bufS1761);
        #line 293 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0L6_2atmpS3892 = _M0FPC15debug14empty__content();
      }
      #line 288 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
      _result_4298
      = _M0FPC15debug14with__resizing(0, _M0L9thresholdS1750, _M0L6_2atmpS3892);
      moonbit_decref(_M0L6_2atmpS3892);
      return _result_4298;
      break;
    }
    default: {
      struct _M0DTPC15debug9ReprDelta6Extra2* _M0L9_2aExtra2S1764 =
        (struct _M0DTPC15debug9ReprDelta6Extra2*)_M0L5deltaS1744;
      void* _M0L4_2axS1765 = _M0L9_2aExtra2S1764->$0;
      struct _M0TPC15debug7Content* _M0L6_2atmpS3891;
      struct _M0TPC15debug7Content** _M0Lm13children__bufS1766;
      int32_t _M0Lm13children__lenS1767;
      int32_t _M0L6_2atmpS3887;
      struct _M0TPC15debug7Content* _M0L6_2atmpS3886;
      struct _M0TPC15debug7Content* _result_4299;
      #line 298 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
      _M0L6_2atmpS3891
      = _M0MPC15debug4Repr12render__repr(_M0L4_2axS1765, _M0L9thresholdS1750);
      _M0Lm13children__bufS1766
      = (struct _M0TPC15debug7Content**)moonbit_make_ref_array_raw(1);
      _M0Lm13children__bufS1766[0] = _M0L6_2atmpS3891;
      _M0Lm13children__lenS1767 = 1;
      _M0L6_2atmpS3887 = _M0Lm13children__lenS1767;
      if (_M0L6_2atmpS3887 == 1) {
        struct _M0TPC15debug7Content** _M0L6_2atmpS3890 =
          _M0Lm13children__bufS1766;
        struct _M0TPC15debug7Content* _M0L6_2atmpS4011 =
          (struct _M0TPC15debug7Content*)_M0L6_2atmpS3890[0];
        struct _M0TPC15debug7Content* _M0L4_2axS1768;
        struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3889;
        struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3888;
        if (_M0L6_2atmpS4011) {
          moonbit_incref(_M0L6_2atmpS4011);
        }
        moonbit_decref(_M0L6_2atmpS3890);
        _M0L4_2axS1768 = _M0L6_2atmpS4011;
        #line 303 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0L6_2atmpS3889 = _M0MPC15debug7Content8no__wrap(_M0L4_2axS1768);
        moonbit_decref(_M0L4_2axS1768);
        #line 303 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0L6_2atmpS3888
        = _M0FPC15debug11mark__added(_M0L9use__ansiS1751, _M0L6_2atmpS3889);
        moonbit_decref(_M0L6_2atmpS3889);
        #line 303 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0L6_2atmpS3886 = _M0FPC15debug10no__parens(_M0L6_2atmpS3888);
        moonbit_decref(_M0L6_2atmpS3888);
      } else {
        moonbit_decref(_M0Lm13children__bufS1766);
        #line 304 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0L6_2atmpS3886 = _M0FPC15debug14empty__content();
      }
      #line 299 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
      _result_4299
      = _M0FPC15debug14with__resizing(0, _M0L9thresholdS1750, _M0L6_2atmpS3886);
      moonbit_decref(_M0L6_2atmpS3886);
      return _result_4299;
      break;
    }
  }
}

struct _M0TPC15debug7Content* _M0FPC15debug13render__deltaC3912l259(
  struct _M0TWRPC15debug9ReprDeltaERPC15debug7Content* _M0L6_2aenvS3913,
  void* _M0L5childS1749
) {
  struct _M0R67_24moonbitlang_2fcore_2fdebug_2erender__delta_2eanon__u3912__l259__* _M0L14_2acasted__envS3914;
  int32_t _M0L9thresholdS1750;
  int32_t _M0L9use__ansiS1751;
  #line 259 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  _M0L14_2acasted__envS3914
  = (struct _M0R67_24moonbitlang_2fcore_2fdebug_2erender__delta_2eanon__u3912__l259__*)_M0L6_2aenvS3913;
  _M0L9thresholdS1750 = _M0L14_2acasted__envS3914->$1;
  _M0L9use__ansiS1751 = _M0L14_2acasted__envS3914->$0;
  #line 260 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  return _M0FPC15debug13render__delta(_M0L9thresholdS1750, _M0L9use__ansiS1751, _M0L5childS1749);
}

struct _M0TPC15debug13ContentParens* _M0FPC15debug13mark__removed(
  int32_t _M0L9use__ansiS1742,
  struct _M0TPC15debug13ContentParens* _M0L1xS1743
) {
  #line 236 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  if (_M0L9use__ansiS1742) {
    #line 238 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
    return _M0FPC15debug8surround((moonbit_string_t)moonbit_string_literal_18.data, (moonbit_string_t)moonbit_string_literal_19.data, _M0L1xS1743);
  } else {
    #line 240 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
    return _M0FPC15debug8surround((moonbit_string_t)moonbit_string_literal_20.data, (moonbit_string_t)moonbit_string_literal_1.data, _M0L1xS1743);
  }
}

struct _M0TPC15debug13ContentParens* _M0FPC15debug11mark__added(
  int32_t _M0L9use__ansiS1740,
  struct _M0TPC15debug13ContentParens* _M0L1xS1741
) {
  #line 246 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  if (_M0L9use__ansiS1740) {
    #line 248 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
    return _M0FPC15debug8surround((moonbit_string_t)moonbit_string_literal_21.data, (moonbit_string_t)moonbit_string_literal_19.data, _M0L1xS1741);
  } else {
    #line 250 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
    return _M0FPC15debug8surround((moonbit_string_t)moonbit_string_literal_22.data, (moonbit_string_t)moonbit_string_literal_1.data, _M0L1xS1741);
  }
}

int32_t _M0FPC15debug17delta__root__size(void* _M0L5deltaS1737) {
  #line 215 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  switch (Moonbit_object_tag(_M0L5deltaS1737)) {
    case 0: {
      struct _M0DTPC15debug9ReprDelta4Same* _M0L7_2aSameS1738 =
        (struct _M0DTPC15debug9ReprDelta4Same*)_M0L5deltaS1737;
      void* _M0L8_2alabelS1739 = _M0L7_2aSameS1738->$0;
      #line 217 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
      return _M0FPC15debug10info__size(_M0L8_2alabelS1739);
      break;
    }
    default: {
      return 0;
      break;
    }
  }
}

void* _M0FPC15debug12prune__delta(
  int64_t _M0L10max__depthS1733,
  void* _M0L5deltaS1734
) {
  #line 176 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  if (_M0L10max__depthS1733 == 4294967296ll) {
    moonbit_incref(_M0L5deltaS1734);
    return _M0L5deltaS1734;
  } else {
    int64_t _M0L7_2aSomeS1735 = _M0L10max__depthS1733;
    int32_t _M0L8_2adepthS1736 = (int32_t)_M0L7_2aSomeS1735;
    int32_t _M0L6_2atmpS3885;
    #line 209 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
    _M0L6_2atmpS3885 = _M0MPC13int3Int3max(1, _M0L8_2adepthS1736);
    #line 209 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
    return _M0FPC15debug12prune__deltaN2goS115(_M0L6_2atmpS3885, _M0L5deltaS1734);
  }
}

void* _M0FPC15debug12prune__deltaN2goS115(
  int32_t _M0L1dS1714,
  void* _M0L4nodeS1716
) {
  #line 177 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  if (_M0L1dS1714 <= 0) {
    void* _M0L6_2atmpS3856;
    void** _M0L6_2atmpS3858;
    struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* _M0L6_2atmpS3857;
    void* _block_4304;
    switch (Moonbit_object_tag(_M0L4nodeS1716)) {
      case 0: {
        struct _M0DTPC15debug9ReprDelta4Same* _M0L7_2aSameS1717 =
          (struct _M0DTPC15debug9ReprDelta4Same*)_M0L4nodeS1716;
        void* _M0L8_2alabelS1718 = _M0L7_2aSameS1717->$0;
        struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* _M0L11_2achildrenS1719 =
          _M0L7_2aSameS1717->$1;
        #line 181 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        if (
          _M0MPC15array5Array9is__emptyGRPC15debug9ReprDeltaE(_M0L11_2achildrenS1719)
        ) {
          moonbit_incref(_M0L4nodeS1716);
          return _M0L4nodeS1716;
        } else {
          int32_t _M0L6_2atmpS3859;
          #line 183 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
          _M0L6_2atmpS3859
          = _M0MPC15debug4Repr17info__adds__depth(_M0L8_2alabelS1718);
          if (!_M0L6_2atmpS3859) {
            struct _M0R77_24moonbitlang_2fcore_2fdebug_2eprune__delta_2ego_7c115_2eanon__u3862__l184__* _closure_4301 =
              (struct _M0R77_24moonbitlang_2fcore_2fdebug_2eprune__delta_2ego_7c115_2eanon__u3862__l184__*)moonbit_malloc(sizeof(struct _M0R77_24moonbitlang_2fcore_2fdebug_2eprune__delta_2ego_7c115_2eanon__u3862__l184__));
            struct _M0TWRPC15debug9ReprDeltaERPC15debug9ReprDelta* _M0L6_2atmpS3861;
            struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* _M0L6_2atmpS3860;
            void* _block_4302;
            Moonbit_object_header(_closure_4301)->meta
            = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0);
            _closure_4301->code
            = &_M0FPC15debug12prune__deltaN2goS115C3862l184;
            _closure_4301->$0 = _M0L1dS1714;
            _M0L6_2atmpS3861
            = (struct _M0TWRPC15debug9ReprDeltaERPC15debug9ReprDelta*)_closure_4301;
            #line 184 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
            _M0L6_2atmpS3860
            = _M0MPC15array5Array3mapGRPC15debug9ReprDeltaRPC15debug9ReprDeltaE(_M0L11_2achildrenS1719, _M0L6_2atmpS3861);
            moonbit_decref(_M0L6_2atmpS3861);
            moonbit_incref(_M0L8_2alabelS1718);
            _block_4302
            = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug9ReprDelta4Same));
            Moonbit_object_header(_block_4302)->meta
            = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 30, 0);
            set_cycle_capable(_block_4302);
            ((struct _M0DTPC15debug9ReprDelta4Same*)_block_4302)->$0
            = _M0L8_2alabelS1718;
            ((struct _M0DTPC15debug9ReprDelta4Same*)_block_4302)->$1
            = _M0L6_2atmpS3860;
            return _block_4302;
          } else {
            void* _M0L6_2atmpS3865;
            void** _M0L6_2atmpS3867;
            struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* _M0L6_2atmpS3866;
            void* _block_4303;
            #line 186 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
            _M0L6_2atmpS3865 = _M0MPC15debug4Repr7omitted();
            _M0L6_2atmpS3867 = (void**)moonbit_empty_ref_array;
            _M0L6_2atmpS3866
            = (struct _M0TPB5ArrayGRPC15debug9ReprDeltaE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGRPC15debug9ReprDeltaE));
            Moonbit_object_header(_M0L6_2atmpS3866)->meta
            = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 34, 0);
            set_cycle_capable(_M0L6_2atmpS3866);
            _M0L6_2atmpS3866->$0 = _M0L6_2atmpS3867;
            _M0L6_2atmpS3866->$1 = 0;
            _block_4303
            = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug9ReprDelta4Same));
            Moonbit_object_header(_block_4303)->meta
            = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 30, 0);
            set_cycle_capable(_block_4303);
            ((struct _M0DTPC15debug9ReprDelta4Same*)_block_4303)->$0
            = _M0L6_2atmpS3865;
            ((struct _M0DTPC15debug9ReprDelta4Same*)_block_4303)->$1
            = _M0L6_2atmpS3866;
            return _block_4303;
          }
        }
        break;
      }
      
      case 1: {
        goto join_1715;
        break;
      }
      
      case 2: {
        goto join_1715;
        break;
      }
      default: {
        goto join_1715;
        break;
      }
    }
    join_1715:;
    #line 188 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
    _M0L6_2atmpS3856 = _M0MPC15debug4Repr7omitted();
    _M0L6_2atmpS3858 = (void**)moonbit_empty_ref_array;
    _M0L6_2atmpS3857
    = (struct _M0TPB5ArrayGRPC15debug9ReprDeltaE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGRPC15debug9ReprDeltaE));
    Moonbit_object_header(_M0L6_2atmpS3857)->meta
    = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 34, 0);
    set_cycle_capable(_M0L6_2atmpS3857);
    _M0L6_2atmpS3857->$0 = _M0L6_2atmpS3858;
    _M0L6_2atmpS3857->$1 = 0;
    _block_4304
    = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug9ReprDelta4Same));
    Moonbit_object_header(_block_4304)->meta
    = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 30, 0);
    set_cycle_capable(_block_4304);
    ((struct _M0DTPC15debug9ReprDelta4Same*)_block_4304)->$0
    = _M0L6_2atmpS3856;
    ((struct _M0DTPC15debug9ReprDelta4Same*)_block_4304)->$1
    = _M0L6_2atmpS3857;
    return _block_4304;
  } else {
    switch (Moonbit_object_tag(_M0L4nodeS1716)) {
      case 0: {
        struct _M0DTPC15debug9ReprDelta4Same* _M0L7_2aSameS1721 =
          (struct _M0DTPC15debug9ReprDelta4Same*)_M0L4nodeS1716;
        void* _M0L8_2alabelS1722 = _M0L7_2aSameS1721->$0;
        struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* _M0L11_2achildrenS1723 =
          _M0L7_2aSameS1721->$1;
        int32_t _M0L11next__depthS1724;
        struct _M0R77_24moonbitlang_2fcore_2fdebug_2eprune__delta_2ego_7c115_2eanon__u3882__l194__* _closure_4305;
        struct _M0TWRPC15debug9ReprDeltaERPC15debug9ReprDelta* _M0L6_2atmpS3881;
        struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* _M0L6_2atmpS3880;
        void* _block_4306;
        #line 193 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        if (_M0MPC15debug4Repr17info__adds__depth(_M0L8_2alabelS1722)) {
          _M0L11next__depthS1724 = _M0L1dS1714 - 1;
        } else {
          _M0L11next__depthS1724 = _M0L1dS1714;
        }
        _closure_4305
        = (struct _M0R77_24moonbitlang_2fcore_2fdebug_2eprune__delta_2ego_7c115_2eanon__u3882__l194__*)moonbit_malloc(sizeof(struct _M0R77_24moonbitlang_2fcore_2fdebug_2eprune__delta_2ego_7c115_2eanon__u3882__l194__));
        Moonbit_object_header(_closure_4305)->meta
        = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0);
        _closure_4305->code = &_M0FPC15debug12prune__deltaN2goS115C3882l194;
        _closure_4305->$0 = _M0L11next__depthS1724;
        _M0L6_2atmpS3881
        = (struct _M0TWRPC15debug9ReprDeltaERPC15debug9ReprDelta*)_closure_4305;
        #line 194 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0L6_2atmpS3880
        = _M0MPC15array5Array3mapGRPC15debug9ReprDeltaRPC15debug9ReprDeltaE(_M0L11_2achildrenS1723, _M0L6_2atmpS3881);
        moonbit_decref(_M0L6_2atmpS3881);
        moonbit_incref(_M0L8_2alabelS1722);
        _block_4306
        = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug9ReprDelta4Same));
        Moonbit_object_header(_block_4306)->meta
        = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 30, 0);
        set_cycle_capable(_block_4306);
        ((struct _M0DTPC15debug9ReprDelta4Same*)_block_4306)->$0
        = _M0L8_2alabelS1722;
        ((struct _M0DTPC15debug9ReprDelta4Same*)_block_4306)->$1
        = _M0L6_2atmpS3880;
        return _block_4306;
        break;
      }
      
      case 1: {
        struct _M0DTPC15debug9ReprDelta9Different* _M0L12_2aDifferentS1726 =
          (struct _M0DTPC15debug9ReprDelta9Different*)_M0L4nodeS1716;
        void* _M0L7_2aleftS1727 = _M0L12_2aDifferentS1726->$0;
        void* _M0L8_2arightS1728 = _M0L12_2aDifferentS1726->$1;
        void* _M0L6_2atmpS3878 = 0;
        int64_t _M0L6_2atmpS3879 = (int64_t)_M0L1dS1714;
        void* _M0L6_2atmpS3874;
        void* _M0L6_2atmpS3876;
        int64_t _M0L6_2atmpS3877;
        void* _M0L6_2atmpS3875;
        void* _block_4307;
        #line 198 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0L6_2atmpS3874
        = _M0MPC15debug4Repr11prune__info(_M0L7_2aleftS1727, _M0L6_2atmpS3878, _M0L6_2atmpS3879);
        if (_M0L6_2atmpS3878) {
          moonbit_decref(_M0L6_2atmpS3878);
        }
        _M0L6_2atmpS3876 = 0;
        _M0L6_2atmpS3877 = (int64_t)_M0L1dS1714;
        #line 199 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0L6_2atmpS3875
        = _M0MPC15debug4Repr11prune__info(_M0L8_2arightS1728, _M0L6_2atmpS3876, _M0L6_2atmpS3877);
        if (_M0L6_2atmpS3876) {
          moonbit_decref(_M0L6_2atmpS3876);
        }
        _block_4307
        = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug9ReprDelta9Different));
        Moonbit_object_header(_block_4307)->meta
        = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 37, 1);
        ((struct _M0DTPC15debug9ReprDelta9Different*)_block_4307)->$0
        = _M0L6_2atmpS3874;
        ((struct _M0DTPC15debug9ReprDelta9Different*)_block_4307)->$1
        = _M0L6_2atmpS3875;
        return _block_4307;
        break;
      }
      
      case 2: {
        struct _M0DTPC15debug9ReprDelta6Extra1* _M0L9_2aExtra1S1729 =
          (struct _M0DTPC15debug9ReprDelta6Extra1*)_M0L4nodeS1716;
        void* _M0L4_2axS1730 = _M0L9_2aExtra1S1729->$0;
        void* _M0L6_2atmpS3872 = 0;
        int64_t _M0L6_2atmpS3873 = (int64_t)_M0L1dS1714;
        void* _M0L6_2atmpS3871;
        void* _block_4308;
        #line 201 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0L6_2atmpS3871
        = _M0MPC15debug4Repr11prune__info(_M0L4_2axS1730, _M0L6_2atmpS3872, _M0L6_2atmpS3873);
        if (_M0L6_2atmpS3872) {
          moonbit_decref(_M0L6_2atmpS3872);
        }
        _block_4308
        = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug9ReprDelta6Extra1));
        Moonbit_object_header(_block_4308)->meta
        = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 41, 2);
        ((struct _M0DTPC15debug9ReprDelta6Extra1*)_block_4308)->$0
        = _M0L6_2atmpS3871;
        return _block_4308;
        break;
      }
      default: {
        struct _M0DTPC15debug9ReprDelta6Extra2* _M0L9_2aExtra2S1731 =
          (struct _M0DTPC15debug9ReprDelta6Extra2*)_M0L4nodeS1716;
        void* _M0L4_2axS1732 = _M0L9_2aExtra2S1731->$0;
        void* _M0L6_2atmpS3869 = 0;
        int64_t _M0L6_2atmpS3870 = (int64_t)_M0L1dS1714;
        void* _M0L6_2atmpS3868;
        void* _block_4309;
        #line 202 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0L6_2atmpS3868
        = _M0MPC15debug4Repr11prune__info(_M0L4_2axS1732, _M0L6_2atmpS3869, _M0L6_2atmpS3870);
        if (_M0L6_2atmpS3869) {
          moonbit_decref(_M0L6_2atmpS3869);
        }
        _block_4309
        = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug9ReprDelta6Extra2));
        Moonbit_object_header(_block_4309)->meta
        = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 44, 3);
        ((struct _M0DTPC15debug9ReprDelta6Extra2*)_block_4309)->$0
        = _M0L6_2atmpS3868;
        return _block_4309;
        break;
      }
    }
  }
}

void* _M0FPC15debug12prune__deltaN2goS115C3882l194(
  struct _M0TWRPC15debug9ReprDeltaERPC15debug9ReprDelta* _M0L6_2aenvS3883,
  void* _M0L5childS1725
) {
  struct _M0R77_24moonbitlang_2fcore_2fdebug_2eprune__delta_2ego_7c115_2eanon__u3882__l194__* _M0L14_2acasted__envS3884;
  int32_t _M0L11next__depthS1724;
  #line 194 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  _M0L14_2acasted__envS3884
  = (struct _M0R77_24moonbitlang_2fcore_2fdebug_2eprune__delta_2ego_7c115_2eanon__u3882__l194__*)_M0L6_2aenvS3883;
  _M0L11next__depthS1724 = _M0L14_2acasted__envS3884->$0;
  #line 194 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  return _M0FPC15debug12prune__deltaN2goS115(_M0L11next__depthS1724, _M0L5childS1725);
}

void* _M0FPC15debug12prune__deltaN2goS115C3862l184(
  struct _M0TWRPC15debug9ReprDeltaERPC15debug9ReprDelta* _M0L6_2aenvS3863,
  void* _M0L5childS1720
) {
  struct _M0R77_24moonbitlang_2fcore_2fdebug_2eprune__delta_2ego_7c115_2eanon__u3862__l184__* _M0L14_2acasted__envS3864;
  int32_t _M0L1dS1714;
  #line 184 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  _M0L14_2acasted__envS3864
  = (struct _M0R77_24moonbitlang_2fcore_2fdebug_2eprune__delta_2ego_7c115_2eanon__u3862__l184__*)_M0L6_2aenvS3863;
  _M0L1dS1714 = _M0L14_2acasted__envS3864->$0;
  #line 184 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  return _M0FPC15debug12prune__deltaN2goS115(_M0L1dS1714, _M0L5childS1720);
}

void* _M0FPC15debug10diff__repr(
  void* _M0L1xS1712,
  void* _M0L1yS1713,
  void* _M0L26max__relative__error_2eoptS1710
) {
  double _M0L20max__relative__errorS1709;
  switch (Moonbit_object_tag(_M0L26max__relative__error_2eoptS1710)) {
    case 1: {
      struct _M0DTPC16option6OptionGdE4Some* _M0L7_2aSomeS1711 =
        (struct _M0DTPC16option6OptionGdE4Some*)_M0L26max__relative__error_2eoptS1710;
      _M0L20max__relative__errorS1709 = _M0L7_2aSomeS1711->$0;
      break;
    }
    default: {
      _M0L20max__relative__errorS1709 = 0x1.19799812dea11p-40;
      break;
    }
  }
  return _M0FPC15debug18diff__repr_2einner(_M0L1xS1712, _M0L1yS1713, _M0L20max__relative__errorS1709);
}

void* _M0FPC15debug18diff__repr_2einner(
  void* _M0L1xS1706,
  void* _M0L1yS1707,
  double _M0L20max__relative__errorS1708
) {
  #line 142 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  #line 147 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  return _M0FPC15debug16diff__info__with(_M0L1xS1706, _M0L1yS1707, _M0L20max__relative__errorS1708);
}

void* _M0FPC15debug16diff__info__with(
  void* _M0L4leftS1704,
  void* _M0L5rightS1705,
  double _M0L20max__relative__errorS1703
) {
  #line 98 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  #line 132 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  return _M0FPC15debug16diff__info__withN2goS142(_M0L20max__relative__errorS1703, _M0L4leftS1704, _M0L5rightS1705);
}

void* _M0FPC15debug16diff__info__withN2goS142(
  double _M0L20max__relative__errorS1681,
  void* _M0L10left__nodeS1682,
  void* _M0L11right__nodeS1683
) {
  #line 103 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  #line 104 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  if (
    _M0FPC15debug16info__approx__eq(_M0L20max__relative__errorS1681, _M0L10left__nodeS1682, _M0L11right__nodeS1683)
  ) {
    struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L2xsS1684;
    struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L2ysS1685;
    int32_t _M0L4xlenS1686;
    int32_t _M0L4ylenS1687;
    int32_t _M0L8min__lenS1688;
    void** _M0L6_2atmpS3855;
    struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* _M0L8childrenS1689;
    int32_t _M0L1iS1690;
    struct _M0TPB9ArrayViewGRPC15debug4ReprE _M0L7_2abindS1692;
    int32_t _M0L3endS3840;
    int32_t _M0L5startS3841;
    int32_t _M0L7_2abindS1693;
    int32_t _M0L2__S1694;
    struct _M0TPB9ArrayViewGRPC15debug4ReprE _M0L7_2abindS1697;
    int32_t _M0L3endS3847;
    int32_t _M0L5startS3848;
    int32_t _M0L7_2abindS1698;
    int32_t _M0L2__S1699;
    int32_t _if__result_4315;
    #line 105 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
    _M0L2xsS1684 = _M0MPC15debug4Repr8children(_M0L10left__nodeS1682);
    #line 106 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
    _M0L2ysS1685 = _M0MPC15debug4Repr8children(_M0L11right__nodeS1683);
    _M0L4xlenS1686 = _M0L2xsS1684->$1;
    _M0L4ylenS1687 = _M0L2ysS1685->$1;
    if (_M0L4xlenS1686 < _M0L4ylenS1687) {
      _M0L8min__lenS1688 = _M0L4xlenS1686;
    } else {
      _M0L8min__lenS1688 = _M0L4ylenS1687;
    }
    _M0L6_2atmpS3855 = (void**)moonbit_empty_ref_array;
    _M0L8childrenS1689
    = (struct _M0TPB5ArrayGRPC15debug9ReprDeltaE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGRPC15debug9ReprDeltaE));
    Moonbit_object_header(_M0L8childrenS1689)->meta
    = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 34, 0);
    set_cycle_capable(_M0L8childrenS1689);
    _M0L8childrenS1689->$0 = _M0L6_2atmpS3855;
    _M0L8childrenS1689->$1 = 0;
    _M0L1iS1690 = 0;
    while (1) {
      if (_M0L1iS1690 < _M0L8min__lenS1688) {
        int32_t _if__result_4311;
        void** _M0L3bufS3833;
        void* _M0L6_2atmpS3828;
        int32_t _if__result_4312;
        void** _M0L3bufS3831;
        void* _M0L6_2atmpS3829;
        void* _M0L6_2atmpS3827;
        int32_t _M0L6_2atmpS3834;
        if (_M0L1iS1690 < 0) {
          _if__result_4311 = 1;
        } else {
          int32_t _M0L3lenS3832 = _M0L2xsS1684->$1;
          _if__result_4311 = _M0L1iS1690 >= _M0L3lenS3832;
        }
        if (_if__result_4311) {
          #line 112 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
          moonbit_panic();
        }
        _M0L3bufS3833 = _M0L2xsS1684->$0;
        _M0L6_2atmpS3828 = (void*)_M0L3bufS3833[_M0L1iS1690];
        if (_M0L1iS1690 < 0) {
          _if__result_4312 = 1;
        } else {
          int32_t _M0L3lenS3830 = _M0L2ysS1685->$1;
          _if__result_4312 = _M0L1iS1690 >= _M0L3lenS3830;
        }
        if (_if__result_4312) {
          #line 112 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
          moonbit_panic();
        }
        _M0L3bufS3831 = _M0L2ysS1685->$0;
        _M0L6_2atmpS3829 = (void*)_M0L3bufS3831[_M0L1iS1690];
        moonbit_incref(_M0L6_2atmpS3829);
        moonbit_incref(_M0L6_2atmpS3828);
        #line 112 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0L6_2atmpS3827
        = _M0FPC15debug16diff__info__withN2goS142(_M0L20max__relative__errorS1681, _M0L6_2atmpS3828, _M0L6_2atmpS3829);
        moonbit_decref(_M0L6_2atmpS3828);
        moonbit_decref(_M0L6_2atmpS3829);
        #line 112 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0MPC15array5Array4pushGRPC15debug9ReprDeltaE(_M0L8childrenS1689, _M0L6_2atmpS3827);
        _M0L6_2atmpS3834 = _M0L1iS1690 + 1;
        _M0L1iS1690 = _M0L6_2atmpS3834;
        continue;
      }
      break;
    }
    #line 114 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
    _M0L7_2abindS1692
    = _M0MPC15array5Array12view_2einnerGRPC15debug4ReprE(_M0L2xsS1684, _M0L8min__lenS1688, 4294967296ll);
    moonbit_decref(_M0L2xsS1684);
    _M0L3endS3840 = _M0L7_2abindS1692.$2;
    _M0L5startS3841 = _M0L7_2abindS1692.$1;
    _M0L7_2abindS1693 = _M0L3endS3840 - _M0L5startS3841;
    _M0L2__S1694 = 0;
    while (1) {
      if (_M0L2__S1694 < _M0L7_2abindS1693) {
        void** _M0L3bufS3837 = _M0L7_2abindS1692.$0;
        int32_t _M0L5startS3839 = _M0L7_2abindS1692.$1;
        int32_t _M0L6_2atmpS3838 = _M0L5startS3839 + _M0L2__S1694;
        void* _M0L1tS1695 = (void*)_M0L3bufS3837[_M0L6_2atmpS3838];
        void* _M0L6Extra1S3835;
        int32_t _M0L6_2atmpS3836;
        moonbit_incref(_M0L1tS1695);
        _M0L6Extra1S3835
        = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug9ReprDelta6Extra1));
        Moonbit_object_header(_M0L6Extra1S3835)->meta
        = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 41, 2);
        ((struct _M0DTPC15debug9ReprDelta6Extra1*)_M0L6Extra1S3835)->$0
        = _M0L1tS1695;
        #line 115 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0MPC15array5Array4pushGRPC15debug9ReprDeltaE(_M0L8childrenS1689, _M0L6Extra1S3835);
        _M0L6_2atmpS3836 = _M0L2__S1694 + 1;
        _M0L2__S1694 = _M0L6_2atmpS3836;
        continue;
      } else {
        moonbit_decref(_M0L7_2abindS1692.$0);
      }
      break;
    }
    #line 117 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
    _M0L7_2abindS1697
    = _M0MPC15array5Array12view_2einnerGRPC15debug4ReprE(_M0L2ysS1685, _M0L8min__lenS1688, 4294967296ll);
    moonbit_decref(_M0L2ysS1685);
    _M0L3endS3847 = _M0L7_2abindS1697.$2;
    _M0L5startS3848 = _M0L7_2abindS1697.$1;
    _M0L7_2abindS1698 = _M0L3endS3847 - _M0L5startS3848;
    _M0L2__S1699 = 0;
    while (1) {
      if (_M0L2__S1699 < _M0L7_2abindS1698) {
        void** _M0L3bufS3844 = _M0L7_2abindS1697.$0;
        int32_t _M0L5startS3846 = _M0L7_2abindS1697.$1;
        int32_t _M0L6_2atmpS3845 = _M0L5startS3846 + _M0L2__S1699;
        void* _M0L1tS1700 = (void*)_M0L3bufS3844[_M0L6_2atmpS3845];
        void* _M0L6Extra2S3842;
        int32_t _M0L6_2atmpS3843;
        moonbit_incref(_M0L1tS1700);
        _M0L6Extra2S3842
        = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug9ReprDelta6Extra2));
        Moonbit_object_header(_M0L6Extra2S3842)->meta
        = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 44, 3);
        ((struct _M0DTPC15debug9ReprDelta6Extra2*)_M0L6Extra2S3842)->$0
        = _M0L1tS1700;
        #line 118 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _M0MPC15array5Array4pushGRPC15debug9ReprDeltaE(_M0L8childrenS1689, _M0L6Extra2S3842);
        _M0L6_2atmpS3843 = _M0L2__S1699 + 1;
        _M0L2__S1699 = _M0L6_2atmpS3843;
        continue;
      } else {
        moonbit_decref(_M0L7_2abindS1697.$0);
      }
      break;
    }
    #line 120 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
    if (_M0FPC15debug21info__is__unimportant(_M0L10left__nodeS1682)) {
      int32_t _M0L6_2atmpS3853;
      #line 121 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
      _M0L6_2atmpS3853
      = _M0MPC15array5Array9is__emptyGRPC15debug9ReprDeltaE(_M0L8childrenS1689);
      if (!_M0L6_2atmpS3853) {
        struct _M0TWRPC15debug9ReprDeltaEb* _M0L6_2atmpS3849 =
          (struct _M0TWRPC15debug9ReprDeltaEb*)&_M0FPC15debug16diff__info__withN2goS142C3850l122$closure.data;
        #line 122 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
        _if__result_4315
        = _M0MPC15array5Array3allGRPC15debug9ReprDeltaE(_M0L8childrenS1689, _M0L6_2atmpS3849);
        moonbit_decref(_M0L6_2atmpS3849);
      } else {
        _if__result_4315 = 0;
      }
    } else {
      _if__result_4315 = 0;
    }
    if (_if__result_4315) {
      void* _block_4316;
      moonbit_decref(_M0L8childrenS1689);
      moonbit_incref(_M0L10left__nodeS1682);
      moonbit_incref(_M0L11right__nodeS1683);
      _block_4316
      = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug9ReprDelta9Different));
      Moonbit_object_header(_block_4316)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 37, 1);
      ((struct _M0DTPC15debug9ReprDelta9Different*)_block_4316)->$0
      = _M0L10left__nodeS1682;
      ((struct _M0DTPC15debug9ReprDelta9Different*)_block_4316)->$1
      = _M0L11right__nodeS1683;
      return _block_4316;
    } else {
      void* _M0L6_2atmpS3854;
      void* _block_4317;
      #line 125 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
      _M0L6_2atmpS3854 = _M0MPC15debug4Repr7shallow(_M0L10left__nodeS1682);
      _block_4317
      = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug9ReprDelta4Same));
      Moonbit_object_header(_block_4317)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 30, 0);
      set_cycle_capable(_block_4317);
      ((struct _M0DTPC15debug9ReprDelta4Same*)_block_4317)->$0
      = _M0L6_2atmpS3854;
      ((struct _M0DTPC15debug9ReprDelta4Same*)_block_4317)->$1
      = _M0L8childrenS1689;
      return _block_4317;
    }
  } else {
    void* _block_4318;
    moonbit_incref(_M0L10left__nodeS1682);
    moonbit_incref(_M0L11right__nodeS1683);
    _block_4318
    = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug9ReprDelta9Different));
    Moonbit_object_header(_block_4318)->meta
    = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 37, 1);
    ((struct _M0DTPC15debug9ReprDelta9Different*)_block_4318)->$0
    = _M0L10left__nodeS1682;
    ((struct _M0DTPC15debug9ReprDelta9Different*)_block_4318)->$1
    = _M0L11right__nodeS1683;
    return _block_4318;
  }
}

int32_t _M0FPC15debug16diff__info__withN2goS142C3850l122(
  struct _M0TWRPC15debug9ReprDeltaEb* _M0L6_2aenvS3851,
  void* _M0L1dS1702
) {
  int32_t _M0L6_2atmpS3852;
  #line 122 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  switch (Moonbit_object_tag(_M0L1dS1702)) {
    case 0: {
      _M0L6_2atmpS3852 = 1;
      break;
    }
    default: {
      _M0L6_2atmpS3852 = 0;
      break;
    }
  }
  return !_M0L6_2atmpS3852;
}

int32_t _M0FPC15debug21info__is__unimportant(void* _M0L4infoS1680) {
  #line 92 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  switch (Moonbit_object_tag(_M0L4infoS1680)) {
    case 16: {
      return 1;
      break;
    }
    
    case 7: {
      return 1;
      break;
    }
    
    case 8: {
      return 1;
      break;
    }
    
    case 9: {
      return 1;
      break;
    }
    default: {
      return 0;
      break;
    }
  }
}

int32_t _M0FPC15debug16info__approx__eq(
  double _M0L20max__relative__errorS1643,
  void* _M0L1xS1633,
  void* _M0L1yS1634
) {
  #line 65 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  switch (Moonbit_object_tag(_M0L1xS1633)) {
    case 0: {
      switch (Moonbit_object_tag(_M0L1yS1634)) {
        case 0: {
          return 1;
          break;
        }
        default: {
          return 0;
          break;
        }
      }
      break;
    }
    
    case 1: {
      struct _M0DTPC15debug4Repr7Integer* _M0L10_2aIntegerS1635 =
        (struct _M0DTPC15debug4Repr7Integer*)_M0L1xS1633;
      moonbit_string_t _M0L5_2ax1S1636 = _M0L10_2aIntegerS1635->$0;
      switch (Moonbit_object_tag(_M0L1yS1634)) {
        case 1: {
          struct _M0DTPC15debug4Repr7Integer* _M0L10_2aIntegerS1637 =
            (struct _M0DTPC15debug4Repr7Integer*)_M0L1yS1634;
          moonbit_string_t _M0L5_2ay1S1638 = _M0L10_2aIntegerS1637->$0;
          #line 68 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
          return _M0L5_2ax1S1636 == _M0L5_2ay1S1638
                 || Moonbit_array_length(_M0L5_2ax1S1636)
                    == Moonbit_array_length(_M0L5_2ay1S1638)
                    && 0
                       == memcmp(_M0L5_2ax1S1636, _M0L5_2ay1S1638, Moonbit_array_length(_M0L5_2ax1S1636) * 2);
          break;
        }
        default: {
          return 0;
          break;
        }
      }
      break;
    }
    
    case 2: {
      struct _M0DTPC15debug4Repr9DoubleLit* _M0L12_2aDoubleLitS1639 =
        (struct _M0DTPC15debug4Repr9DoubleLit*)_M0L1xS1633;
      double _M0L5_2ax1S1640 = _M0L12_2aDoubleLitS1639->$0;
      switch (Moonbit_object_tag(_M0L1yS1634)) {
        case 2: {
          struct _M0DTPC15debug4Repr9DoubleLit* _M0L12_2aDoubleLitS1641 =
            (struct _M0DTPC15debug4Repr9DoubleLit*)_M0L1yS1634;
          double _M0L5_2ay1S1642 = _M0L12_2aDoubleLitS1641->$0;
          double _M0L6_2atmpS3826;
          #line 70 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
          _M0L6_2atmpS3826
          = _M0FPC15debug15relative__error(_M0L5_2ax1S1640, _M0L5_2ay1S1642);
          return _M0L6_2atmpS3826 <= _M0L20max__relative__errorS1643;
          break;
        }
        default: {
          return 0;
          break;
        }
      }
      break;
    }
    
    case 3: {
      struct _M0DTPC15debug4Repr8FloatLit* _M0L11_2aFloatLitS1644 =
        (struct _M0DTPC15debug4Repr8FloatLit*)_M0L1xS1633;
      float _M0L5_2ax1S1645 = _M0L11_2aFloatLitS1644->$0;
      switch (Moonbit_object_tag(_M0L1yS1634)) {
        case 3: {
          struct _M0DTPC15debug4Repr8FloatLit* _M0L11_2aFloatLitS1646 =
            (struct _M0DTPC15debug4Repr8FloatLit*)_M0L1yS1634;
          float _M0L5_2ay1S1647 = _M0L11_2aFloatLitS1646->$0;
          return _M0L5_2ax1S1645 == _M0L5_2ay1S1647;
          break;
        }
        default: {
          return 0;
          break;
        }
      }
      break;
    }
    
    case 4: {
      struct _M0DTPC15debug4Repr7BoolLit* _M0L10_2aBoolLitS1648 =
        (struct _M0DTPC15debug4Repr7BoolLit*)_M0L1xS1633;
      int32_t _M0L5_2ax1S1649 = _M0L10_2aBoolLitS1648->$0;
      switch (Moonbit_object_tag(_M0L1yS1634)) {
        case 4: {
          struct _M0DTPC15debug4Repr7BoolLit* _M0L10_2aBoolLitS1650 =
            (struct _M0DTPC15debug4Repr7BoolLit*)_M0L1yS1634;
          int32_t _M0L5_2ay1S1651 = _M0L10_2aBoolLitS1650->$0;
          return _M0L5_2ax1S1649 == _M0L5_2ay1S1651;
          break;
        }
        default: {
          return 0;
          break;
        }
      }
      break;
    }
    
    case 5: {
      struct _M0DTPC15debug4Repr7CharLit* _M0L10_2aCharLitS1652 =
        (struct _M0DTPC15debug4Repr7CharLit*)_M0L1xS1633;
      int32_t _M0L5_2ax1S1653 = _M0L10_2aCharLitS1652->$0;
      switch (Moonbit_object_tag(_M0L1yS1634)) {
        case 5: {
          struct _M0DTPC15debug4Repr7CharLit* _M0L10_2aCharLitS1654 =
            (struct _M0DTPC15debug4Repr7CharLit*)_M0L1yS1634;
          int32_t _M0L5_2ay1S1655 = _M0L10_2aCharLitS1654->$0;
          return _M0L5_2ax1S1653 == _M0L5_2ay1S1655;
          break;
        }
        default: {
          return 0;
          break;
        }
      }
      break;
    }
    
    case 6: {
      struct _M0DTPC15debug4Repr9StringLit* _M0L12_2aStringLitS1656 =
        (struct _M0DTPC15debug4Repr9StringLit*)_M0L1xS1633;
      moonbit_string_t _M0L5_2ax1S1657 = _M0L12_2aStringLitS1656->$0;
      switch (Moonbit_object_tag(_M0L1yS1634)) {
        case 6: {
          struct _M0DTPC15debug4Repr9StringLit* _M0L12_2aStringLitS1658 =
            (struct _M0DTPC15debug4Repr9StringLit*)_M0L1yS1634;
          moonbit_string_t _M0L5_2ay1S1659 = _M0L12_2aStringLitS1658->$0;
          #line 74 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
          return _M0L5_2ax1S1657 == _M0L5_2ay1S1659
                 || Moonbit_array_length(_M0L5_2ax1S1657)
                    == Moonbit_array_length(_M0L5_2ay1S1659)
                    && 0
                       == memcmp(_M0L5_2ax1S1657, _M0L5_2ay1S1659, Moonbit_array_length(_M0L5_2ax1S1657) * 2);
          break;
        }
        default: {
          return 0;
          break;
        }
      }
      break;
    }
    
    case 7: {
      switch (Moonbit_object_tag(_M0L1yS1634)) {
        case 7: {
          return 1;
          break;
        }
        default: {
          return 0;
          break;
        }
      }
      break;
    }
    
    case 8: {
      switch (Moonbit_object_tag(_M0L1yS1634)) {
        case 8: {
          return 1;
          break;
        }
        default: {
          return 0;
          break;
        }
      }
      break;
    }
    
    case 9: {
      switch (Moonbit_object_tag(_M0L1yS1634)) {
        case 9: {
          return 1;
          break;
        }
        default: {
          return 0;
          break;
        }
      }
      break;
    }
    
    case 10: {
      struct _M0DTPC15debug4Repr4Enum* _M0L7_2aEnumS1660 =
        (struct _M0DTPC15debug4Repr4Enum*)_M0L1xS1633;
      moonbit_string_t _M0L5_2an1S1661 = _M0L7_2aEnumS1660->$0;
      switch (Moonbit_object_tag(_M0L1yS1634)) {
        case 10: {
          struct _M0DTPC15debug4Repr4Enum* _M0L7_2aEnumS1662 =
            (struct _M0DTPC15debug4Repr4Enum*)_M0L1yS1634;
          moonbit_string_t _M0L5_2an2S1663 = _M0L7_2aEnumS1662->$0;
          #line 78 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
          return _M0L5_2an1S1661 == _M0L5_2an2S1663
                 || Moonbit_array_length(_M0L5_2an1S1661)
                    == Moonbit_array_length(_M0L5_2an2S1663)
                    && 0
                       == memcmp(_M0L5_2an1S1661, _M0L5_2an2S1663, Moonbit_array_length(_M0L5_2an1S1661) * 2);
          break;
        }
        default: {
          return 0;
          break;
        }
      }
      break;
    }
    
    case 11: {
      switch (Moonbit_object_tag(_M0L1yS1634)) {
        case 11: {
          return 1;
          break;
        }
        default: {
          return 0;
          break;
        }
      }
      break;
    }
    
    case 12: {
      struct _M0DTPC15debug4Repr11RecordField* _M0L14_2aRecordFieldS1664 =
        (struct _M0DTPC15debug4Repr11RecordField*)_M0L1xS1633;
      moonbit_string_t _M0L5_2an1S1665 = _M0L14_2aRecordFieldS1664->$0;
      switch (Moonbit_object_tag(_M0L1yS1634)) {
        case 12: {
          struct _M0DTPC15debug4Repr11RecordField* _M0L14_2aRecordFieldS1666 =
            (struct _M0DTPC15debug4Repr11RecordField*)_M0L1yS1634;
          moonbit_string_t _M0L5_2an2S1667 = _M0L14_2aRecordFieldS1666->$0;
          #line 80 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
          return _M0L5_2an1S1665 == _M0L5_2an2S1667
                 || Moonbit_array_length(_M0L5_2an1S1665)
                    == Moonbit_array_length(_M0L5_2an2S1667)
                    && 0
                       == memcmp(_M0L5_2an1S1665, _M0L5_2an2S1667, Moonbit_array_length(_M0L5_2an1S1665) * 2);
          break;
        }
        default: {
          return 0;
          break;
        }
      }
      break;
    }
    
    case 13: {
      struct _M0DTPC15debug4Repr14EnumLabeledArg* _M0L17_2aEnumLabeledArgS1668 =
        (struct _M0DTPC15debug4Repr14EnumLabeledArg*)_M0L1xS1633;
      moonbit_string_t _M0L5_2an1S1669 = _M0L17_2aEnumLabeledArgS1668->$0;
      switch (Moonbit_object_tag(_M0L1yS1634)) {
        case 13: {
          struct _M0DTPC15debug4Repr14EnumLabeledArg* _M0L17_2aEnumLabeledArgS1670 =
            (struct _M0DTPC15debug4Repr14EnumLabeledArg*)_M0L1yS1634;
          moonbit_string_t _M0L5_2an2S1671 = _M0L17_2aEnumLabeledArgS1670->$0;
          #line 81 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
          return _M0L5_2an1S1669 == _M0L5_2an2S1671
                 || Moonbit_array_length(_M0L5_2an1S1669)
                    == Moonbit_array_length(_M0L5_2an2S1671)
                    && 0
                       == memcmp(_M0L5_2an1S1669, _M0L5_2an2S1671, Moonbit_array_length(_M0L5_2an1S1669) * 2);
          break;
        }
        default: {
          return 0;
          break;
        }
      }
      break;
    }
    
    case 14: {
      struct _M0DTPC15debug4Repr6Opaque* _M0L9_2aOpaqueS1672 =
        (struct _M0DTPC15debug4Repr6Opaque*)_M0L1xS1633;
      moonbit_string_t _M0L5_2an1S1673 = _M0L9_2aOpaqueS1672->$0;
      switch (Moonbit_object_tag(_M0L1yS1634)) {
        case 14: {
          struct _M0DTPC15debug4Repr6Opaque* _M0L9_2aOpaqueS1674 =
            (struct _M0DTPC15debug4Repr6Opaque*)_M0L1yS1634;
          moonbit_string_t _M0L5_2an2S1675 = _M0L9_2aOpaqueS1674->$0;
          #line 82 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
          return _M0L5_2an1S1673 == _M0L5_2an2S1675
                 || Moonbit_array_length(_M0L5_2an1S1673)
                    == Moonbit_array_length(_M0L5_2an2S1675)
                    && 0
                       == memcmp(_M0L5_2an1S1673, _M0L5_2an2S1675, Moonbit_array_length(_M0L5_2an1S1673) * 2);
          break;
        }
        default: {
          return 0;
          break;
        }
      }
      break;
    }
    
    case 15: {
      struct _M0DTPC15debug4Repr7Literal* _M0L10_2aLiteralS1676 =
        (struct _M0DTPC15debug4Repr7Literal*)_M0L1xS1633;
      moonbit_string_t _M0L5_2ax1S1677 = _M0L10_2aLiteralS1676->$0;
      switch (Moonbit_object_tag(_M0L1yS1634)) {
        case 15: {
          struct _M0DTPC15debug4Repr7Literal* _M0L10_2aLiteralS1678 =
            (struct _M0DTPC15debug4Repr7Literal*)_M0L1yS1634;
          moonbit_string_t _M0L5_2ay1S1679 = _M0L10_2aLiteralS1678->$0;
          #line 83 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
          return _M0L5_2ax1S1677 == _M0L5_2ay1S1679
                 || Moonbit_array_length(_M0L5_2ax1S1677)
                    == Moonbit_array_length(_M0L5_2ay1S1679)
                    && 0
                       == memcmp(_M0L5_2ax1S1677, _M0L5_2ay1S1679, Moonbit_array_length(_M0L5_2ax1S1677) * 2);
          break;
        }
        default: {
          return 0;
          break;
        }
      }
      break;
    }
    
    case 16: {
      switch (Moonbit_object_tag(_M0L1yS1634)) {
        case 16: {
          return 1;
          break;
        }
        default: {
          return 0;
          break;
        }
      }
      break;
    }
    default: {
      switch (Moonbit_object_tag(_M0L1yS1634)) {
        case 17: {
          return 1;
          break;
        }
        default: {
          return 0;
          break;
        }
      }
      break;
    }
  }
}

double _M0FPC15debug15relative__error(double _M0L1xS1630, double _M0L1yS1631) {
  #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  if (_M0L1xS1630 == _M0L1yS1631) {
    return 0x0p+0;
  } else {
    double _M0L6_2atmpS3824;
    double _M0L6_2atmpS3825;
    double _M0L5denomS1632;
    #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
    _M0L6_2atmpS3824 = _M0FPC15debug11double__abs(_M0L1xS1630);
    #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
    _M0L6_2atmpS3825 = _M0FPC15debug11double__abs(_M0L1yS1631);
    #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
    _M0L5denomS1632
    = _M0FPC15debug11double__max(_M0L6_2atmpS3824, _M0L6_2atmpS3825);
    if (_M0L5denomS1632 == 0x0p+0) {
      double _M0L6_2atmpS3821 = _M0L1xS1630 - _M0L1yS1631;
      #line 56 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
      return _M0FPC15debug11double__abs(_M0L6_2atmpS3821);
    } else {
      double _M0L6_2atmpS3823 = _M0L1xS1630 - _M0L1yS1631;
      double _M0L6_2atmpS3822;
      #line 58 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
      _M0L6_2atmpS3822 = _M0FPC15debug11double__abs(_M0L6_2atmpS3823);
      return _M0L6_2atmpS3822 / _M0L5denomS1632;
    }
  }
}

double _M0FPC15debug11double__max(double _M0L1xS1628, double _M0L1yS1629) {
  #line 40 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  if (_M0L1xS1628 > _M0L1yS1629) {
    return _M0L1xS1628;
  } else {
    return _M0L1yS1629;
  }
}

double _M0FPC15debug11double__abs(double _M0L1xS1627) {
  #line 30 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\delta.mbt"
  if (_M0L1xS1627 < 0x0p+0) {
    return -_M0L1xS1627;
  } else {
    return _M0L1xS1627;
  }
}

moonbit_string_t _M0FPC15debug6render(
  void* _M0L1rS1626,
  int64_t _M0L10max__depthS1624
) {
  int64_t _M0L10max__depthS1623;
  void* _M0L6_2atmpS3820;
  void* _M0L4infoS1625;
  struct _M0TPC15debug7Content* _M0L6_2atmpS3819;
  struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3818;
  moonbit_string_t _result_4319;
  #line 247 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  if (_M0L10max__depthS1624 == 4294967296ll) {
    _M0L10max__depthS1623 = _M0FPC15debug6renderN6constrS1767;
  } else {
    _M0L10max__depthS1623 = _M0L10max__depthS1624;
  }
  _M0L6_2atmpS3820 = 0;
  #line 253 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  _M0L4infoS1625
  = _M0MPC15debug4Repr11prune__info(_M0L1rS1626, _M0L6_2atmpS3820, _M0L10max__depthS1623);
  if (_M0L6_2atmpS3820) {
    moonbit_decref(_M0L6_2atmpS3820);
  }
  #line 254 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  _M0L6_2atmpS3819 = _M0MPC15debug4Repr12render__repr(_M0L4infoS1625, 70);
  moonbit_decref(_M0L4infoS1625);
  #line 254 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  _M0L6_2atmpS3818 = _M0MPC15debug7Content8no__wrap(_M0L6_2atmpS3819);
  moonbit_decref(_M0L6_2atmpS3819);
  #line 254 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  _result_4319 = _M0FPC15debug14print__content(_M0L6_2atmpS3818);
  moonbit_decref(_M0L6_2atmpS3818);
  return _result_4319;
}

struct _M0TPC15debug7Content* _M0MPC15debug4Repr12render__repr(
  void* _M0L4selfS1619,
  int32_t _M0L9thresholdS1622
) {
  void* _M0L5labelS1618;
  struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L6_2atmpS3813;
  struct _M0R76_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3arender__repr_2eanon__u3815__l232__* _closure_4320;
  struct _M0TWRPC15debug4ReprERPC15debug7Content* _M0L6_2atmpS3814;
  struct _M0TPB5ArrayGRPC15debug7ContentE* _M0L8childrenS1620;
  int32_t _M0L6_2atmpS3811;
  struct _M0TPC15debug7Content* _M0L6_2atmpS3812;
  struct _M0TPC15debug7Content* _result_4321;
  #line 230 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  #line 231 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  _M0L5labelS1618 = _M0MPC15debug4Repr7shallow(_M0L4selfS1619);
  #line 232 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  _M0L6_2atmpS3813 = _M0MPC15debug4Repr8children(_M0L4selfS1619);
  _closure_4320
  = (struct _M0R76_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3arender__repr_2eanon__u3815__l232__*)moonbit_malloc(sizeof(struct _M0R76_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3arender__repr_2eanon__u3815__l232__));
  Moonbit_object_header(_closure_4320)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0);
  _closure_4320->code = &_M0MPC15debug4Repr12render__reprC3815l232;
  _closure_4320->$0 = _M0L9thresholdS1622;
  _M0L6_2atmpS3814
  = (struct _M0TWRPC15debug4ReprERPC15debug7Content*)_closure_4320;
  #line 232 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  _M0L8childrenS1620
  = _M0MPC15array5Array3mapGRPC15debug4ReprRPC15debug7ContentE(_M0L6_2atmpS3813, _M0L6_2atmpS3814);
  moonbit_decref(_M0L6_2atmpS3813);
  moonbit_decref(_M0L6_2atmpS3814);
  #line 233 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  _M0L6_2atmpS3811 = _M0FPC15debug10info__size(_M0L5labelS1618);
  #line 233 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  _M0L6_2atmpS3812
  = _M0MPC15debug4Repr13pretty__print(_M0L5labelS1618, _M0L8childrenS1620);
  moonbit_decref(_M0L5labelS1618);
  moonbit_decref(_M0L8childrenS1620);
  #line 233 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  _result_4321
  = _M0FPC15debug14with__resizing(_M0L6_2atmpS3811, _M0L9thresholdS1622, _M0L6_2atmpS3812);
  moonbit_decref(_M0L6_2atmpS3812);
  return _result_4321;
}

struct _M0TPC15debug7Content* _M0MPC15debug4Repr12render__reprC3815l232(
  struct _M0TWRPC15debug4ReprERPC15debug7Content* _M0L6_2aenvS3816,
  void* _M0L5childS1621
) {
  struct _M0R76_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3arender__repr_2eanon__u3815__l232__* _M0L14_2acasted__envS3817;
  int32_t _M0L9thresholdS1622;
  #line 232 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  _M0L14_2acasted__envS3817
  = (struct _M0R76_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3arender__repr_2eanon__u3815__l232__*)_M0L6_2aenvS3816;
  _M0L9thresholdS1622 = _M0L14_2acasted__envS3817->$0;
  #line 232 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  return _M0MPC15debug4Repr12render__repr(_M0L5childS1621, _M0L9thresholdS1622);
}

struct _M0TPC15debug7Content* _M0MPC15debug4Repr13pretty__print(
  void* _M0L4selfS1559,
  struct _M0TPB5ArrayGRPC15debug7ContentE* _M0L8childrenS1575
) {
  #line 131 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  switch (Moonbit_object_tag(_M0L4selfS1559)) {
    case 0: {
      struct _M0TPC15debug13ContentParens** _M0L6_2atmpS3810 =
        (struct _M0TPC15debug13ContentParens**)moonbit_empty_ref_array;
      struct _M0TPB5ArrayGRPC15debug13ContentParensE* _M0L6_2atmpS3809 =
        (struct _M0TPB5ArrayGRPC15debug13ContentParensE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGRPC15debug13ContentParensE));
      struct _M0TPC15debug7Content* _result_4322;
      Moonbit_object_header(_M0L6_2atmpS3809)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 47, 0);
      _M0L6_2atmpS3809->$0 = _M0L6_2atmpS3810;
      _M0L6_2atmpS3809->$1 = 0;
      #line 133 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _result_4322
      = _M0FPC15debug10comma__seq((moonbit_string_t)moonbit_string_literal_4.data, (moonbit_string_t)moonbit_string_literal_23.data, _M0L6_2atmpS3809);
      moonbit_decref(_M0L6_2atmpS3809);
      return _result_4322;
      break;
    }
    
    case 1: {
      struct _M0DTPC15debug4Repr7Integer* _M0L10_2aIntegerS1560 =
        (struct _M0DTPC15debug4Repr7Integer*)_M0L4selfS1559;
      moonbit_string_t _M0L4_2asS1561 = _M0L10_2aIntegerS1560->$0;
      int32_t _M0L6_2atmpS3807 = Moonbit_array_length(_M0L4_2asS1561);
      int32_t _M0L6_2atmpS3804;
      moonbit_string_t* _M0L6_2atmpS3806;
      struct _M0TPB5ArrayGsE* _M0L6_2atmpS3805;
      struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3803;
      struct _M0TPC15debug7Content* _result_4323;
      if (_M0L6_2atmpS3807 >= 1) {
        int32_t _M0L6_2atmpS3808 = _M0L4_2asS1561[0];
        int32_t _M0L4_2axS1562 = _M0L6_2atmpS3808;
        if (_M0L4_2axS1562 == 45) {
          _M0L6_2atmpS3804 = 1;
        } else {
          _M0L6_2atmpS3804 = 0;
        }
      } else {
        _M0L6_2atmpS3804 = 0;
      }
      moonbit_incref(_M0L4_2asS1561);
      _M0L6_2atmpS3806 = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
      _M0L6_2atmpS3806[0] = _M0L4_2asS1561;
      _M0L6_2atmpS3805
      = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
      Moonbit_object_header(_M0L6_2atmpS3805)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
      _M0L6_2atmpS3805->$0 = _M0L6_2atmpS3806;
      _M0L6_2atmpS3805->$1 = 1;
      #line 135 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _M0L6_2atmpS3803
      = _M0FPC15debug15content__parens(_M0L6_2atmpS3804, _M0L6_2atmpS3805);
      moonbit_decref(_M0L6_2atmpS3805);
      #line 135 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _result_4323 = _M0FPC15debug10no__parens(_M0L6_2atmpS3803);
      moonbit_decref(_M0L6_2atmpS3803);
      return _result_4323;
      break;
    }
    
    case 2: {
      struct _M0DTPC15debug4Repr9DoubleLit* _M0L12_2aDoubleLitS1563 =
        (struct _M0DTPC15debug4Repr9DoubleLit*)_M0L4selfS1559;
      double _M0L4_2axS1564 = _M0L12_2aDoubleLitS1563->$0;
      double _M0L6_2atmpS3802 = 0x1p+0 / _M0L4_2axS1564;
      int32_t _M0L13needs__parensS1565 = _M0L6_2atmpS3802 < 0x0p+0;
      moonbit_string_t _M0L6_2atmpS3801;
      struct _M0TPC15debug7Content* _result_4324;
      #line 138 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _M0L6_2atmpS3801 = _M0MPC16double6Double10to__string(_M0L4_2axS1564);
      #line 138 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _result_4324
      = _M0FPC15debug12leaf_2einner(_M0L6_2atmpS3801, _M0L13needs__parensS1565);
      moonbit_decref(_M0L6_2atmpS3801);
      return _result_4324;
      break;
    }
    
    case 3: {
      struct _M0DTPC15debug4Repr8FloatLit* _M0L11_2aFloatLitS1566 =
        (struct _M0DTPC15debug4Repr8FloatLit*)_M0L4selfS1559;
      float _M0L4_2axS1567 = _M0L11_2aFloatLitS1566->$0;
      float _M0L6_2atmpS3800 = 0x1p+0f / _M0L4_2axS1567;
      int32_t _M0L13needs__parensS1568 = _M0L6_2atmpS3800 < 0x0p+0f;
      moonbit_string_t _M0L6_2atmpS3799;
      struct _M0TPC15debug7Content* _result_4325;
      #line 142 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _M0L6_2atmpS3799
      = _M0IPC15float5FloatPB4Show10to__string(_M0L4_2axS1567);
      #line 142 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _result_4325
      = _M0FPC15debug12leaf_2einner(_M0L6_2atmpS3799, _M0L13needs__parensS1568);
      moonbit_decref(_M0L6_2atmpS3799);
      return _result_4325;
      break;
    }
    
    case 4: {
      struct _M0DTPC15debug4Repr7BoolLit* _M0L10_2aBoolLitS1569 =
        (struct _M0DTPC15debug4Repr7BoolLit*)_M0L4selfS1559;
      int32_t _M0L4_2axS1570 = _M0L10_2aBoolLitS1569->$0;
      moonbit_string_t _M0L6_2atmpS3798;
      struct _M0TPC15debug7Content* _result_4326;
      #line 144 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _M0L6_2atmpS3798 = _M0IPC14bool4BoolPB4Show10to__string(_M0L4_2axS1570);
      #line 144 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _result_4326 = _M0FPC15debug12leaf_2einner(_M0L6_2atmpS3798, 0);
      moonbit_decref(_M0L6_2atmpS3798);
      return _result_4326;
      break;
    }
    
    case 5: {
      struct _M0DTPC15debug4Repr7CharLit* _M0L10_2aCharLitS1571 =
        (struct _M0DTPC15debug4Repr7CharLit*)_M0L4selfS1559;
      int32_t _M0L4_2axS1572 = _M0L10_2aCharLitS1571->$0;
      moonbit_string_t _M0L6_2atmpS3797;
      struct _M0TPC15debug7Content* _result_4327;
      #line 145 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _M0L6_2atmpS3797 = _M0MPC14char4Char14escape_2einner(_M0L4_2axS1572, 1);
      #line 145 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _result_4327 = _M0FPC15debug12leaf_2einner(_M0L6_2atmpS3797, 0);
      moonbit_decref(_M0L6_2atmpS3797);
      return _result_4327;
      break;
    }
    
    case 6: {
      struct _M0DTPC15debug4Repr9StringLit* _M0L12_2aStringLitS1573 =
        (struct _M0DTPC15debug4Repr9StringLit*)_M0L4selfS1559;
      moonbit_string_t _M0L4_2axS1574 = _M0L12_2aStringLitS1573->$0;
      moonbit_string_t _M0L6_2atmpS3796;
      struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3795;
      struct _M0TPC15debug7Content* _result_4328;
      #line 146 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _M0L6_2atmpS3796
      = _M0MPC16string6String14escape_2einner(_M0L4_2axS1574, 1);
      #line 146 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _M0L6_2atmpS3795 = _M0FPC15debug8verbatim(_M0L6_2atmpS3796);
      moonbit_decref(_M0L6_2atmpS3796);
      #line 146 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _result_4328 = _M0FPC15debug10no__parens(_M0L6_2atmpS3795);
      moonbit_decref(_M0L6_2atmpS3795);
      return _result_4328;
      break;
    }
    
    case 7: {
      struct _M0TWRPC15debug7ContentERPC15debug13ContentParens* _M0L6_2atmpS3792 =
        (struct _M0TWRPC15debug7ContentERPC15debug13ContentParens*)&_M0MPC15debug4Repr13pretty__printC3793l147$closure.data;
      struct _M0TPB5ArrayGRPC15debug13ContentParensE* _M0L6_2atmpS3791;
      struct _M0TPC15debug7Content* _result_4329;
      #line 147 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _M0L6_2atmpS3791
      = _M0MPC15array5Array3mapGRPC15debug7ContentRPC15debug13ContentParensE(_M0L8childrenS1575, _M0L6_2atmpS3792);
      moonbit_decref(_M0L6_2atmpS3792);
      #line 147 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _result_4329
      = _M0FPC15debug10comma__seq((moonbit_string_t)moonbit_string_literal_4.data, (moonbit_string_t)moonbit_string_literal_23.data, _M0L6_2atmpS3791);
      moonbit_decref(_M0L6_2atmpS3791);
      return _result_4329;
      break;
    }
    
    case 10: {
      struct _M0DTPC15debug4Repr4Enum* _M0L7_2aEnumS1577 =
        (struct _M0DTPC15debug4Repr4Enum*)_M0L4selfS1559;
      moonbit_string_t _M0L7_2anameS1578 = _M0L7_2aEnumS1577->$0;
      int32_t _M0L3lenS3780 = _M0L8childrenS1575->$1;
      if (_M0L3lenS3780 == 0) {
        struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3781;
        struct _M0TPC15debug7Content* _result_4330;
        #line 150 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        _M0L6_2atmpS3781 = _M0FPC15debug8verbatim(_M0L7_2anameS1578);
        #line 150 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        _result_4330 = _M0FPC15debug10no__parens(_M0L6_2atmpS3781);
        moonbit_decref(_M0L6_2atmpS3781);
        return _result_4330;
      } else {
        #line 152 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        if (
          _M0L7_2anameS1578
          == (moonbit_string_t)moonbit_string_literal_24.data
          || Moonbit_array_length(_M0L7_2anameS1578)
             == Moonbit_array_length((moonbit_string_t)moonbit_string_literal_24.data)
             && 0
                == memcmp(_M0L7_2anameS1578, (moonbit_string_t)moonbit_string_literal_24.data, Moonbit_array_length(_M0L7_2anameS1578) * 2)
        ) {
          struct _M0TWRPC15debug7ContentERPC15debug13ContentParens* _M0L6_2atmpS3783 =
            (struct _M0TWRPC15debug7ContentERPC15debug13ContentParens*)&_M0MPC15debug4Repr13pretty__printC3784l153$closure.data;
          struct _M0TPB5ArrayGRPC15debug13ContentParensE* _M0L6_2atmpS3782;
          struct _M0TPC15debug7Content* _result_4331;
          #line 153 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
          _M0L6_2atmpS3782
          = _M0MPC15array5Array3mapGRPC15debug7ContentRPC15debug13ContentParensE(_M0L8childrenS1575, _M0L6_2atmpS3783);
          moonbit_decref(_M0L6_2atmpS3783);
          #line 153 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
          _result_4331
          = _M0FPC15debug10comma__seq((moonbit_string_t)moonbit_string_literal_4.data, (moonbit_string_t)moonbit_string_literal_23.data, _M0L6_2atmpS3782);
          moonbit_decref(_M0L6_2atmpS3782);
          return _result_4331;
        } else {
          moonbit_string_t _M0L6_2atmpS3786;
          struct _M0TWRPC15debug7ContentERPC15debug13ContentParens* _M0L6_2atmpS3788;
          struct _M0TPB5ArrayGRPC15debug13ContentParensE* _M0L6_2atmpS3787;
          struct _M0TPC15debug7Content* _result_4332;
          #line 155 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
          _M0L6_2atmpS3786
          = moonbit_add_string(_M0L7_2anameS1578, (moonbit_string_t)moonbit_string_literal_4.data);
          _M0L6_2atmpS3788
          = (struct _M0TWRPC15debug7ContentERPC15debug13ContentParens*)&_M0MPC15debug4Repr13pretty__printC3789l155$closure.data;
          #line 155 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
          _M0L6_2atmpS3787
          = _M0MPC15array5Array3mapGRPC15debug7ContentRPC15debug13ContentParensE(_M0L8childrenS1575, _M0L6_2atmpS3788);
          moonbit_decref(_M0L6_2atmpS3788);
          #line 155 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
          _result_4332
          = _M0FPC15debug10comma__seq(_M0L6_2atmpS3786, (moonbit_string_t)moonbit_string_literal_23.data, _M0L6_2atmpS3787);
          moonbit_decref(_M0L6_2atmpS3786);
          moonbit_decref(_M0L6_2atmpS3787);
          return _result_4332;
        }
      }
      break;
    }
    
    case 8: {
      struct _M0TWRPC15debug7ContentERPC15debug13ContentParens* _M0L6_2atmpS3777 =
        (struct _M0TWRPC15debug7ContentERPC15debug13ContentParens*)&_M0MPC15debug4Repr13pretty__printC3778l158$closure.data;
      struct _M0TPB5ArrayGRPC15debug13ContentParensE* _M0L6_2atmpS3776;
      struct _M0TPC15debug7Content* _result_4333;
      #line 158 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _M0L6_2atmpS3776
      = _M0MPC15array5Array3mapGRPC15debug7ContentRPC15debug13ContentParensE(_M0L8childrenS1575, _M0L6_2atmpS3777);
      moonbit_decref(_M0L6_2atmpS3777);
      #line 158 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _result_4333
      = _M0FPC15debug10comma__seq((moonbit_string_t)moonbit_string_literal_25.data, (moonbit_string_t)moonbit_string_literal_26.data, _M0L6_2atmpS3776);
      moonbit_decref(_M0L6_2atmpS3776);
      return _result_4333;
      break;
    }
    
    case 9: {
      struct _M0TWRPC15debug7ContentERPC15debug13ContentParens* _M0L6_2atmpS3773 =
        (struct _M0TWRPC15debug7ContentERPC15debug13ContentParens*)&_M0MPC15debug4Repr13pretty__printC3774l159$closure.data;
      struct _M0TPB5ArrayGRPC15debug13ContentParensE* _M0L6_2atmpS3772;
      struct _M0TPC15debug7Content* _result_4334;
      #line 159 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _M0L6_2atmpS3772
      = _M0MPC15array5Array3mapGRPC15debug7ContentRPC15debug13ContentParensE(_M0L8childrenS1575, _M0L6_2atmpS3773);
      moonbit_decref(_M0L6_2atmpS3773);
      #line 159 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _result_4334
      = _M0FPC15debug10comma__seq((moonbit_string_t)moonbit_string_literal_27.data, (moonbit_string_t)moonbit_string_literal_11.data, _M0L6_2atmpS3772);
      moonbit_decref(_M0L6_2atmpS3772);
      return _result_4334;
      break;
    }
    
    case 14: {
      struct _M0DTPC15debug4Repr6Opaque* _M0L9_2aOpaqueS1583 =
        (struct _M0DTPC15debug4Repr6Opaque*)_M0L4selfS1559;
      moonbit_string_t _M0L7_2anameS1584 = _M0L9_2aOpaqueS1583->$0;
      #line 161 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      if (
        _M0MPC15array5Array9is__emptyGRPC15debug7ContentE(_M0L8childrenS1575)
      ) {
        struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3761;
        struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3760;
        struct _M0TPC15debug7Content* _result_4335;
        #line 162 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        _M0L6_2atmpS3761 = _M0FPC15debug8verbatim(_M0L7_2anameS1584);
        #line 162 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        _M0L6_2atmpS3760
        = _M0FPC15debug8surround((moonbit_string_t)moonbit_string_literal_28.data, (moonbit_string_t)moonbit_string_literal_29.data, _M0L6_2atmpS3761);
        moonbit_decref(_M0L6_2atmpS3761);
        #line 162 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        _result_4335 = _M0FPC15debug10no__parens(_M0L6_2atmpS3760);
        moonbit_decref(_M0L6_2atmpS3760);
        return _result_4335;
      } else {
        moonbit_string_t _M0L6_2atmpS3771;
        struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3763;
        struct _M0TWRPC15debug7ContentERPC15debug13ContentParens* _M0L6_2atmpS3768;
        struct _M0TPB5ArrayGRPC15debug13ContentParensE* _M0L6_2atmpS3767;
        struct _M0TPC15debug7Content* _M0L6_2atmpS3766;
        struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3765;
        struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3764;
        struct _M0TPC15debug13ContentParens* _M0L4bodyS1585;
        struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3762;
        struct _M0TPC15debug7Content* _result_4336;
        #line 164 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        _M0L6_2atmpS3771
        = moonbit_add_string(_M0L7_2anameS1584, (moonbit_string_t)moonbit_string_literal_30.data);
        #line 164 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        _M0L6_2atmpS3763 = _M0FPC15debug8verbatim(_M0L6_2atmpS3771);
        moonbit_decref(_M0L6_2atmpS3771);
        _M0L6_2atmpS3768
        = (struct _M0TWRPC15debug7ContentERPC15debug13ContentParens*)&_M0MPC15debug4Repr13pretty__printC3769l167$closure.data;
        #line 167 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        _M0L6_2atmpS3767
        = _M0MPC15array5Array3mapGRPC15debug7ContentRPC15debug13ContentParensE(_M0L8childrenS1575, _M0L6_2atmpS3768);
        moonbit_decref(_M0L6_2atmpS3768);
        #line 167 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        _M0L6_2atmpS3766
        = _M0FPC15debug10comma__seq((moonbit_string_t)moonbit_string_literal_1.data, (moonbit_string_t)moonbit_string_literal_1.data, _M0L6_2atmpS3767);
        moonbit_decref(_M0L6_2atmpS3767);
        #line 167 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        _M0L6_2atmpS3765 = _M0MPC15debug7Content8no__wrap(_M0L6_2atmpS3766);
        moonbit_decref(_M0L6_2atmpS3766);
        #line 165 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        _M0L6_2atmpS3764
        = _M0FPC15debug6indent((moonbit_string_t)moonbit_string_literal_31.data, _M0L6_2atmpS3765);
        moonbit_decref(_M0L6_2atmpS3765);
        #line 164 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        _M0L4bodyS1585
        = _M0IPC15debug13ContentParensPB3Add3add(_M0L6_2atmpS3763, _M0L6_2atmpS3764);
        moonbit_decref(_M0L6_2atmpS3763);
        moonbit_decref(_M0L6_2atmpS3764);
        #line 169 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        _M0L6_2atmpS3762
        = _M0FPC15debug8surround((moonbit_string_t)moonbit_string_literal_28.data, (moonbit_string_t)moonbit_string_literal_29.data, _M0L4bodyS1585);
        moonbit_decref(_M0L4bodyS1585);
        #line 169 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        _result_4336 = _M0FPC15debug10no__parens(_M0L6_2atmpS3762);
        moonbit_decref(_M0L6_2atmpS3762);
        return _result_4336;
      }
      break;
    }
    
    case 15: {
      struct _M0DTPC15debug4Repr7Literal* _M0L10_2aLiteralS1587 =
        (struct _M0DTPC15debug4Repr7Literal*)_M0L4selfS1559;
      moonbit_string_t _M0L6_2astrS1588 = _M0L10_2aLiteralS1587->$0;
      struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3759;
      struct _M0TPC15debug7Content* _result_4337;
      #line 171 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _M0L6_2atmpS3759 = _M0FPC15debug8verbatim(_M0L6_2astrS1588);
      #line 171 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _result_4337 = _M0FPC15debug10no__parens(_M0L6_2atmpS3759);
      moonbit_decref(_M0L6_2atmpS3759);
      return _result_4337;
      break;
    }
    
    case 11: {
      struct _M0TWRPC15debug7ContentERPC15debug13ContentParens* _M0L6_2atmpS3756 =
        (struct _M0TWRPC15debug7ContentERPC15debug13ContentParens*)&_M0MPC15debug4Repr13pretty__printC3757l172$closure.data;
      struct _M0TPB5ArrayGRPC15debug13ContentParensE* _M0L6_2atmpS3755;
      struct _M0TPC15debug7Content* _result_4338;
      #line 172 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _M0L6_2atmpS3755
      = _M0MPC15array5Array3mapGRPC15debug7ContentRPC15debug13ContentParensE(_M0L8childrenS1575, _M0L6_2atmpS3756);
      moonbit_decref(_M0L6_2atmpS3756);
      #line 172 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _result_4338
      = _M0FPC15debug10comma__seq((moonbit_string_t)moonbit_string_literal_27.data, (moonbit_string_t)moonbit_string_literal_11.data, _M0L6_2atmpS3755);
      moonbit_decref(_M0L6_2atmpS3755);
      return _result_4338;
      break;
    }
    
    case 16: {
      int32_t _M0L3lenS3726 = _M0L8childrenS1575->$1;
      if (_M0L3lenS3726 == 2) {
        struct _M0TPC15debug7Content** _M0L3bufS3754 = _M0L8childrenS1575->$0;
        struct _M0TPC15debug7Content* _M0L6_2akeyS1590 =
          (struct _M0TPC15debug7Content*)_M0L3bufS3754[0];
        struct _M0TPC15debug7Content** _M0L3bufS3753 = _M0L8childrenS1575->$0;
        struct _M0TPC15debug7Content* _M0L6_2avalS1591 =
          (struct _M0TPC15debug7Content*)_M0L3bufS3753[1];
        struct _M0TPC15debug13ContentParens* _M0L1kS1592;
        struct _M0TPC15debug13ContentParens* _M0L1vS1593;
        struct _M0TPB5ArrayGsE* _M0L7_2abindS1594;
        int32_t _M0L3lenS3727;
        moonbit_incref(_M0L6_2avalS1591);
        moonbit_incref(_M0L6_2akeyS1590);
        #line 176 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        _M0L1kS1592 = _M0MPC15debug7Content8no__wrap(_M0L6_2akeyS1590);
        moonbit_decref(_M0L6_2akeyS1590);
        #line 177 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        _M0L1vS1593 = _M0MPC15debug7Content8no__wrap(_M0L6_2avalS1591);
        moonbit_decref(_M0L6_2avalS1591);
        _M0L7_2abindS1594 = _M0L1vS1593->$1;
        _M0L3lenS3727 = _M0L7_2abindS1594->$1;
        if (_M0L3lenS3727 == 0) {
          moonbit_decref(_M0L1vS1593);
          moonbit_decref(_M0L1kS1592);
          #line 179 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
          return _M0FPC15debug14empty__content();
        } else {
          int32_t _M0L3lenS3728 = _M0L7_2abindS1594->$1;
          if (_M0L3lenS3728 == 1) {
            moonbit_string_t* _M0L3bufS3739 = _M0L7_2abindS1594->$0;
            moonbit_string_t _M0L6_2aoneS1595 =
              (moonbit_string_t)_M0L3bufS3739[0];
            int32_t _M0L4sizeS3738 = _M0L1kS1592->$0;
            int32_t _M0L6_2atmpS3736 = 1 + _M0L4sizeS3738;
            int32_t _M0L4sizeS3737 = _M0L1vS1593->$0;
            int32_t _M0L6_2atmpS3730;
            struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3735;
            moonbit_string_t _M0L6_2atmpS3734;
            moonbit_string_t _M0L6_2atmpS3733;
            moonbit_string_t* _M0L6_2atmpS3732;
            struct _M0TPB5ArrayGsE* _M0L6_2atmpS3731;
            struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3729;
            struct _M0TPC15debug7Content* _result_4339;
            moonbit_incref(_M0L6_2aoneS1595);
            moonbit_decref(_M0L1vS1593);
            _M0L6_2atmpS3730 = _M0L6_2atmpS3736 + _M0L4sizeS3737;
            #line 183 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0L6_2atmpS3735
            = _M0FPC15debug8surround((moonbit_string_t)moonbit_string_literal_1.data, (moonbit_string_t)moonbit_string_literal_32.data, _M0L1kS1592);
            moonbit_decref(_M0L1kS1592);
            #line 183 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0L6_2atmpS3734
            = _M0FPC15debug14print__content(_M0L6_2atmpS3735);
            moonbit_decref(_M0L6_2atmpS3735);
            #line 183 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0L6_2atmpS3733
            = moonbit_add_string(_M0L6_2atmpS3734, _M0L6_2aoneS1595);
            moonbit_decref(_M0L6_2aoneS1595);
            moonbit_decref(_M0L6_2atmpS3734);
            _M0L6_2atmpS3732
            = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
            _M0L6_2atmpS3732[0] = _M0L6_2atmpS3733;
            _M0L6_2atmpS3731
            = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
            Moonbit_object_header(_M0L6_2atmpS3731)->meta
            = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
            _M0L6_2atmpS3731->$0 = _M0L6_2atmpS3732;
            _M0L6_2atmpS3731->$1 = 1;
            #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0L6_2atmpS3729
            = _M0FPC15debug15content__parens(_M0L6_2atmpS3730, _M0L6_2atmpS3731);
            moonbit_decref(_M0L6_2atmpS3731);
            #line 181 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _result_4339 = _M0FPC15debug10no__parens(_M0L6_2atmpS3729);
            moonbit_decref(_M0L6_2atmpS3729);
            return _result_4339;
          } else {
            moonbit_string_t* _M0L3bufS3752 = _M0L7_2abindS1594->$0;
            moonbit_string_t _M0L8_2afirstS1596 =
              (moonbit_string_t)_M0L3bufS3752[0];
            moonbit_string_t* _M0L3bufS3750 = _M0L7_2abindS1594->$0;
            int32_t _M0L3lenS3751 = _M0L7_2abindS1594->$1;
            struct _M0TPB9ArrayViewGsE _M0L4_2axS1597;
            struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3749;
            moonbit_string_t _M0L6_2atmpS3748;
            moonbit_string_t _M0L4headS1598;
            int32_t _M0L4sizeS3747;
            int32_t _M0L6_2atmpS3745;
            int32_t _M0L4sizeS3746;
            int32_t _M0L6_2atmpS3741;
            moonbit_string_t* _M0L6_2atmpS3744;
            struct _M0TPB5ArrayGsE* _M0L7_2aselfS1599;
            struct _M0TPB4IterGsE* _M0L6_2atmpS3743;
            struct _M0TPB5ArrayGsE* _M0L6_2atmpS3742;
            struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3740;
            struct _M0TPC15debug7Content* _result_4340;
            moonbit_incref(_M0L3bufS3750);
            _M0L4_2axS1597
            = (struct _M0TPB9ArrayViewGsE){
              .$0 = _M0L3bufS3750, .$1 = 1, .$2 = _M0L3lenS3751
            };
            moonbit_incref(_M0L8_2afirstS1596);
            #line 187 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0L6_2atmpS3749
            = _M0FPC15debug8surround((moonbit_string_t)moonbit_string_literal_1.data, (moonbit_string_t)moonbit_string_literal_32.data, _M0L1kS1592);
            #line 187 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0L6_2atmpS3748
            = _M0FPC15debug14print__content(_M0L6_2atmpS3749);
            moonbit_decref(_M0L6_2atmpS3749);
            #line 187 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0L4headS1598
            = moonbit_add_string(_M0L6_2atmpS3748, _M0L8_2afirstS1596);
            moonbit_decref(_M0L8_2afirstS1596);
            moonbit_decref(_M0L6_2atmpS3748);
            _M0L4sizeS3747 = _M0L1kS1592->$0;
            moonbit_decref(_M0L1kS1592);
            _M0L6_2atmpS3745 = 1 + _M0L4sizeS3747;
            _M0L4sizeS3746 = _M0L1vS1593->$0;
            moonbit_decref(_M0L1vS1593);
            _M0L6_2atmpS3741 = _M0L6_2atmpS3745 + _M0L4sizeS3746;
            _M0L6_2atmpS3744 = (moonbit_string_t*)moonbit_empty_ref_array;
            _M0L7_2aselfS1599
            = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
            Moonbit_object_header(_M0L7_2aselfS1599)->meta
            = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
            _M0L7_2aselfS1599->$0 = _M0L6_2atmpS3744;
            _M0L7_2aselfS1599->$1 = 0;
            #line 188 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0MPC15array5Array4pushGsE(_M0L7_2aselfS1599, _M0L4headS1598);
            #line 188 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0L6_2atmpS3743
            = _M0MPC15array9ArrayView4iterGsE(_M0L4_2axS1597);
            moonbit_decref(_M0L4_2axS1597.$0);
            #line 188 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0MPC15array5Array10push__iterGsE(_M0L7_2aselfS1599, _M0L6_2atmpS3743);
            moonbit_decref(_M0L6_2atmpS3743);
            _M0L6_2atmpS3742 = _M0L7_2aselfS1599;
            #line 188 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0L6_2atmpS3740
            = _M0FPC15debug15content__parens(_M0L6_2atmpS3741, _M0L6_2atmpS3742);
            moonbit_decref(_M0L6_2atmpS3742);
            #line 188 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _result_4340 = _M0FPC15debug10no__parens(_M0L6_2atmpS3740);
            moonbit_decref(_M0L6_2atmpS3740);
            return _result_4340;
          }
        }
      } else {
        #line 192 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        return _M0FPC15debug14empty__content();
      }
      break;
    }
    
    case 13: {
      struct _M0DTPC15debug4Repr14EnumLabeledArg* _M0L17_2aEnumLabeledArgS1600 =
        (struct _M0DTPC15debug4Repr14EnumLabeledArg*)_M0L4selfS1559;
      moonbit_string_t _M0L7_2anameS1601 = _M0L17_2aEnumLabeledArgS1600->$0;
      int32_t _M0L3lenS3703 = _M0L8childrenS1575->$1;
      if (_M0L3lenS3703 == 1) {
        struct _M0TPC15debug7Content** _M0L3bufS3725 = _M0L8childrenS1575->$0;
        struct _M0TPC15debug7Content* _M0L6_2avalS1602 =
          (struct _M0TPC15debug7Content*)_M0L3bufS3725[0];
        struct _M0TPB5ArrayGsE* _M0L7_2abindS1603 = _M0L6_2avalS1602->$1;
        int32_t _M0L3lenS3704 = _M0L7_2abindS1603->$1;
        if (_M0L3lenS3704 == 0) {
          #line 198 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
          return _M0FPC15debug14empty__content();
        } else {
          int32_t _M0L3lenS3705 = _M0L7_2abindS1603->$1;
          if (_M0L3lenS3705 == 1) {
            moonbit_string_t* _M0L3bufS3713 = _M0L7_2abindS1603->$0;
            moonbit_string_t _M0L8_2afirstS1604 =
              (moonbit_string_t)_M0L3bufS3713[0];
            int32_t _M0L4sizeS3712 = _M0L6_2avalS1602->$0;
            int32_t _M0L6_2atmpS3707 = 1 + _M0L4sizeS3712;
            moonbit_string_t _M0L6_2atmpS3711;
            moonbit_string_t _M0L6_2atmpS3710;
            moonbit_string_t* _M0L6_2atmpS3709;
            struct _M0TPB5ArrayGsE* _M0L6_2atmpS3708;
            struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3706;
            struct _M0TPC15debug7Content* _result_4341;
            #line 200 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0L6_2atmpS3711
            = moonbit_add_string(_M0L7_2anameS1601, (moonbit_string_t)moonbit_string_literal_33.data);
            #line 200 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0L6_2atmpS3710
            = moonbit_add_string(_M0L6_2atmpS3711, _M0L8_2afirstS1604);
            moonbit_decref(_M0L6_2atmpS3711);
            _M0L6_2atmpS3709
            = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
            _M0L6_2atmpS3709[0] = _M0L6_2atmpS3710;
            _M0L6_2atmpS3708
            = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
            Moonbit_object_header(_M0L6_2atmpS3708)->meta
            = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
            _M0L6_2atmpS3708->$0 = _M0L6_2atmpS3709;
            _M0L6_2atmpS3708->$1 = 1;
            #line 200 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0L6_2atmpS3706
            = _M0FPC15debug15content__parens(_M0L6_2atmpS3707, _M0L6_2atmpS3708);
            moonbit_decref(_M0L6_2atmpS3708);
            #line 200 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _result_4341 = _M0FPC15debug10no__parens(_M0L6_2atmpS3706);
            moonbit_decref(_M0L6_2atmpS3706);
            return _result_4341;
          } else {
            moonbit_string_t* _M0L3bufS3724 = _M0L7_2abindS1603->$0;
            moonbit_string_t _M0L8_2afirstS1605 =
              (moonbit_string_t)_M0L3bufS3724[0];
            moonbit_string_t* _M0L3bufS3722 = _M0L7_2abindS1603->$0;
            int32_t _M0L3lenS3723 = _M0L7_2abindS1603->$1;
            struct _M0TPB9ArrayViewGsE _M0L4_2axS1606;
            int32_t _M0L4sizeS3721;
            int32_t _M0L6_2atmpS3715;
            moonbit_string_t* _M0L6_2atmpS3720;
            struct _M0TPB5ArrayGsE* _M0L7_2aselfS1607;
            moonbit_string_t _M0L6_2atmpS3718;
            moonbit_string_t _M0L6_2atmpS3717;
            struct _M0TPB4IterGsE* _M0L6_2atmpS3719;
            struct _M0TPB5ArrayGsE* _M0L6_2atmpS3716;
            struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3714;
            struct _M0TPC15debug7Content* _result_4342;
            moonbit_incref(_M0L3bufS3722);
            _M0L4_2axS1606
            = (struct _M0TPB9ArrayViewGsE){
              .$0 = _M0L3bufS3722, .$1 = 1, .$2 = _M0L3lenS3723
            };
            _M0L4sizeS3721 = _M0L6_2avalS1602->$0;
            _M0L6_2atmpS3715 = 1 + _M0L4sizeS3721;
            _M0L6_2atmpS3720 = (moonbit_string_t*)moonbit_empty_ref_array;
            _M0L7_2aselfS1607
            = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
            Moonbit_object_header(_M0L7_2aselfS1607)->meta
            = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
            _M0L7_2aselfS1607->$0 = _M0L6_2atmpS3720;
            _M0L7_2aselfS1607->$1 = 0;
            #line 203 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0L6_2atmpS3718
            = moonbit_add_string(_M0L7_2anameS1601, (moonbit_string_t)moonbit_string_literal_33.data);
            #line 203 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0L6_2atmpS3717
            = moonbit_add_string(_M0L6_2atmpS3718, _M0L8_2afirstS1605);
            moonbit_decref(_M0L6_2atmpS3718);
            #line 203 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0MPC15array5Array4pushGsE(_M0L7_2aselfS1607, _M0L6_2atmpS3717);
            #line 203 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0L6_2atmpS3719
            = _M0MPC15array9ArrayView4iterGsE(_M0L4_2axS1606);
            moonbit_decref(_M0L4_2axS1606.$0);
            #line 203 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0MPC15array5Array10push__iterGsE(_M0L7_2aselfS1607, _M0L6_2atmpS3719);
            moonbit_decref(_M0L6_2atmpS3719);
            _M0L6_2atmpS3716 = _M0L7_2aselfS1607;
            #line 203 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0L6_2atmpS3714
            = _M0FPC15debug15content__parens(_M0L6_2atmpS3715, _M0L6_2atmpS3716);
            moonbit_decref(_M0L6_2atmpS3716);
            #line 202 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _result_4342 = _M0FPC15debug10no__parens(_M0L6_2atmpS3714);
            moonbit_decref(_M0L6_2atmpS3714);
            return _result_4342;
          }
        }
      } else {
        #line 206 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        return _M0FPC15debug14empty__content();
      }
      break;
    }
    
    case 12: {
      struct _M0DTPC15debug4Repr11RecordField* _M0L14_2aRecordFieldS1608 =
        (struct _M0DTPC15debug4Repr11RecordField*)_M0L4selfS1559;
      moonbit_string_t _M0L7_2anameS1609 = _M0L14_2aRecordFieldS1608->$0;
      int32_t _M0L3lenS3680 = _M0L8childrenS1575->$1;
      if (_M0L3lenS3680 == 1) {
        struct _M0TPC15debug7Content** _M0L3bufS3702 = _M0L8childrenS1575->$0;
        struct _M0TPC15debug7Content* _M0L6_2avalS1610 =
          (struct _M0TPC15debug7Content*)_M0L3bufS3702[0];
        moonbit_string_t _M0L5labelS1611;
        struct _M0TPC15debug13ContentParens* _M0L1vS1612;
        struct _M0TPB5ArrayGsE* _M0L7_2abindS1613;
        int32_t _M0L3lenS3681;
        moonbit_incref(_M0L6_2avalS1610);
        #line 211 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        _M0L5labelS1611
        = _M0FPC15debug20pretty__print__label(_M0L7_2anameS1609);
        #line 212 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        _M0L1vS1612 = _M0MPC15debug7Content8no__wrap(_M0L6_2avalS1610);
        moonbit_decref(_M0L6_2avalS1610);
        _M0L7_2abindS1613 = _M0L1vS1612->$1;
        _M0L3lenS3681 = _M0L7_2abindS1613->$1;
        if (_M0L3lenS3681 == 0) {
          moonbit_decref(_M0L1vS1612);
          moonbit_decref(_M0L5labelS1611);
          #line 214 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
          return _M0FPC15debug14empty__content();
        } else {
          int32_t _M0L3lenS3682 = _M0L7_2abindS1613->$1;
          if (_M0L3lenS3682 == 1) {
            moonbit_string_t* _M0L3bufS3690 = _M0L7_2abindS1613->$0;
            moonbit_string_t _M0L6_2aoneS1614 =
              (moonbit_string_t)_M0L3bufS3690[0];
            int32_t _M0L4sizeS3689 = _M0L1vS1612->$0;
            int32_t _M0L6_2atmpS3684;
            moonbit_string_t _M0L6_2atmpS3688;
            moonbit_string_t _M0L6_2atmpS3687;
            moonbit_string_t* _M0L6_2atmpS3686;
            struct _M0TPB5ArrayGsE* _M0L6_2atmpS3685;
            struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3683;
            struct _M0TPC15debug7Content* _result_4343;
            moonbit_incref(_M0L6_2aoneS1614);
            moonbit_decref(_M0L1vS1612);
            _M0L6_2atmpS3684 = 1 + _M0L4sizeS3689;
            #line 215 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0L6_2atmpS3688
            = moonbit_add_string(_M0L5labelS1611, (moonbit_string_t)moonbit_string_literal_32.data);
            moonbit_decref(_M0L5labelS1611);
            #line 215 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0L6_2atmpS3687
            = moonbit_add_string(_M0L6_2atmpS3688, _M0L6_2aoneS1614);
            moonbit_decref(_M0L6_2aoneS1614);
            moonbit_decref(_M0L6_2atmpS3688);
            _M0L6_2atmpS3686
            = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
            _M0L6_2atmpS3686[0] = _M0L6_2atmpS3687;
            _M0L6_2atmpS3685
            = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
            Moonbit_object_header(_M0L6_2atmpS3685)->meta
            = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
            _M0L6_2atmpS3685->$0 = _M0L6_2atmpS3686;
            _M0L6_2atmpS3685->$1 = 1;
            #line 215 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0L6_2atmpS3683
            = _M0FPC15debug15content__parens(_M0L6_2atmpS3684, _M0L6_2atmpS3685);
            moonbit_decref(_M0L6_2atmpS3685);
            #line 215 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _result_4343 = _M0FPC15debug10no__parens(_M0L6_2atmpS3683);
            moonbit_decref(_M0L6_2atmpS3683);
            return _result_4343;
          } else {
            moonbit_string_t* _M0L3bufS3701 = _M0L7_2abindS1613->$0;
            moonbit_string_t _M0L8_2afirstS1615 =
              (moonbit_string_t)_M0L3bufS3701[0];
            moonbit_string_t* _M0L3bufS3699 = _M0L7_2abindS1613->$0;
            int32_t _M0L3lenS3700 = _M0L7_2abindS1613->$1;
            struct _M0TPB9ArrayViewGsE _M0L4_2axS1616;
            int32_t _M0L4sizeS3698;
            int32_t _M0L6_2atmpS3692;
            moonbit_string_t* _M0L6_2atmpS3697;
            struct _M0TPB5ArrayGsE* _M0L7_2aselfS1617;
            moonbit_string_t _M0L6_2atmpS3695;
            moonbit_string_t _M0L6_2atmpS3694;
            struct _M0TPB4IterGsE* _M0L6_2atmpS3696;
            struct _M0TPB5ArrayGsE* _M0L6_2atmpS3693;
            struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3691;
            struct _M0TPC15debug7Content* _result_4344;
            moonbit_incref(_M0L3bufS3699);
            _M0L4_2axS1616
            = (struct _M0TPB9ArrayViewGsE){
              .$0 = _M0L3bufS3699, .$1 = 1, .$2 = _M0L3lenS3700
            };
            _M0L4sizeS3698 = _M0L1vS1612->$0;
            moonbit_incref(_M0L8_2afirstS1615);
            moonbit_decref(_M0L1vS1612);
            _M0L6_2atmpS3692 = 1 + _M0L4sizeS3698;
            _M0L6_2atmpS3697 = (moonbit_string_t*)moonbit_empty_ref_array;
            _M0L7_2aselfS1617
            = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
            Moonbit_object_header(_M0L7_2aselfS1617)->meta
            = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
            _M0L7_2aselfS1617->$0 = _M0L6_2atmpS3697;
            _M0L7_2aselfS1617->$1 = 0;
            #line 218 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0L6_2atmpS3695
            = moonbit_add_string(_M0L5labelS1611, (moonbit_string_t)moonbit_string_literal_32.data);
            moonbit_decref(_M0L5labelS1611);
            #line 218 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0L6_2atmpS3694
            = moonbit_add_string(_M0L6_2atmpS3695, _M0L8_2afirstS1615);
            moonbit_decref(_M0L8_2afirstS1615);
            moonbit_decref(_M0L6_2atmpS3695);
            #line 218 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0MPC15array5Array4pushGsE(_M0L7_2aselfS1617, _M0L6_2atmpS3694);
            #line 218 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0L6_2atmpS3696
            = _M0MPC15array9ArrayView4iterGsE(_M0L4_2axS1616);
            moonbit_decref(_M0L4_2axS1616.$0);
            #line 218 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0MPC15array5Array10push__iterGsE(_M0L7_2aselfS1617, _M0L6_2atmpS3696);
            moonbit_decref(_M0L6_2atmpS3696);
            _M0L6_2atmpS3693 = _M0L7_2aselfS1617;
            #line 218 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _M0L6_2atmpS3691
            = _M0FPC15debug15content__parens(_M0L6_2atmpS3692, _M0L6_2atmpS3693);
            moonbit_decref(_M0L6_2atmpS3693);
            #line 217 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
            _result_4344 = _M0FPC15debug10no__parens(_M0L6_2atmpS3691);
            moonbit_decref(_M0L6_2atmpS3691);
            return _result_4344;
          }
        }
      } else {
        #line 222 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        return _M0FPC15debug14empty__content();
      }
      break;
    }
    default: {
      struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3679;
      struct _M0TPC15debug7Content* _result_4345;
      #line 224 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _M0L6_2atmpS3679
      = _M0FPC15debug8verbatim((moonbit_string_t)moonbit_string_literal_34.data);
      #line 224 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _result_4345 = _M0FPC15debug6parens(_M0L6_2atmpS3679);
      moonbit_decref(_M0L6_2atmpS3679);
      return _result_4345;
      break;
    }
  }
}

struct _M0TPC15debug13ContentParens* _M0MPC15debug4Repr13pretty__printC3793l147(
  struct _M0TWRPC15debug7ContentERPC15debug13ContentParens* _M0L6_2aenvS3794,
  struct _M0TPC15debug7Content* _M0L1xS1576
) {
  #line 147 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  #line 147 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  return _M0MPC15debug7Content8no__wrap(_M0L1xS1576);
}

struct _M0TPC15debug13ContentParens* _M0MPC15debug4Repr13pretty__printC3789l155(
  struct _M0TWRPC15debug7ContentERPC15debug13ContentParens* _M0L6_2aenvS3790,
  struct _M0TPC15debug7Content* _M0L1xS1580
) {
  #line 155 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  #line 155 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  return _M0MPC15debug7Content8no__wrap(_M0L1xS1580);
}

struct _M0TPC15debug13ContentParens* _M0MPC15debug4Repr13pretty__printC3784l153(
  struct _M0TWRPC15debug7ContentERPC15debug13ContentParens* _M0L6_2aenvS3785,
  struct _M0TPC15debug7Content* _M0L1xS1579
) {
  #line 153 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  #line 153 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  return _M0MPC15debug7Content8no__wrap(_M0L1xS1579);
}

struct _M0TPC15debug13ContentParens* _M0MPC15debug4Repr13pretty__printC3778l158(
  struct _M0TWRPC15debug7ContentERPC15debug13ContentParens* _M0L6_2aenvS3779,
  struct _M0TPC15debug7Content* _M0L1xS1581
) {
  #line 158 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  #line 158 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  return _M0MPC15debug7Content8no__wrap(_M0L1xS1581);
}

struct _M0TPC15debug13ContentParens* _M0MPC15debug4Repr13pretty__printC3774l159(
  struct _M0TWRPC15debug7ContentERPC15debug13ContentParens* _M0L6_2aenvS3775,
  struct _M0TPC15debug7Content* _M0L1xS1582
) {
  #line 159 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  #line 159 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  return _M0MPC15debug7Content8no__wrap(_M0L1xS1582);
}

struct _M0TPC15debug13ContentParens* _M0MPC15debug4Repr13pretty__printC3769l167(
  struct _M0TWRPC15debug7ContentERPC15debug13ContentParens* _M0L6_2aenvS3770,
  struct _M0TPC15debug7Content* _M0L1xS1586
) {
  #line 167 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  #line 167 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  return _M0MPC15debug7Content8no__wrap(_M0L1xS1586);
}

struct _M0TPC15debug13ContentParens* _M0MPC15debug4Repr13pretty__printC3757l172(
  struct _M0TWRPC15debug7ContentERPC15debug13ContentParens* _M0L6_2aenvS3758,
  struct _M0TPC15debug7Content* _M0L1xS1589
) {
  #line 172 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  #line 172 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  return _M0MPC15debug7Content8no__wrap(_M0L1xS1589);
}

moonbit_string_t _M0FPC15debug20pretty__print__label(
  moonbit_string_t _M0L4nameS1558
) {
  #line 121 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  #line 122 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  if (_M0FPC15debug17is__unquoted__key(_M0L4nameS1558)) {
    moonbit_incref(_M0L4nameS1558);
    return _M0L4nameS1558;
  } else {
    #line 125 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
    return _M0MPC16string6String14escape_2einner(_M0L4nameS1558, 1);
  }
}

int32_t _M0FPC15debug17is__unquoted__key(moonbit_string_t _M0L3keyS1554) {
  struct _M0TPC16string10StringView _M0L4restS1542;
  int32_t _M0L6_2atmpS3675;
  moonbit_string_t _M0L3strS3672;
  int32_t _M0L5startS3673;
  int32_t _M0L3endS3674;
  moonbit_string_t _M0L9rest__strS1543;
  int32_t _M0L11rest__startS1544;
  int32_t _M0L9rest__endS1545;
  #line 108 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  _M0L6_2atmpS3675 = Moonbit_array_length(_M0L3keyS1554);
  if (_M0L6_2atmpS3675 >= 1) {
    int32_t _M0L6_2atmpS3678 = _M0L3keyS1554[0];
    int32_t _M0L4_2axS1555 = _M0L6_2atmpS3678;
    if (_M0L4_2axS1555 >= 97 && _M0L4_2axS1555 <= 122) {
      int32_t _M0L6_2atmpS3677 = Moonbit_array_length(_M0L3keyS1554);
      struct _M0TPC16string10StringView _M0L4_2axS1556;
      moonbit_incref(_M0L3keyS1554);
      _M0L4_2axS1556
      = (struct _M0TPC16string10StringView){
        .$0 = _M0L3keyS1554, .$1 = 1, .$2 = _M0L6_2atmpS3677
      };
      _M0L4restS1542 = _M0L4_2axS1556;
      goto join_1541;
    } else if (_M0L4_2axS1555 == 95) {
      int32_t _M0L6_2atmpS3676 = Moonbit_array_length(_M0L3keyS1554);
      struct _M0TPC16string10StringView _M0L4_2axS1557;
      moonbit_incref(_M0L3keyS1554);
      _M0L4_2axS1557
      = (struct _M0TPC16string10StringView){
        .$0 = _M0L3keyS1554, .$1 = 1, .$2 = _M0L6_2atmpS3676
      };
      _M0L4restS1542 = _M0L4_2axS1557;
      goto join_1541;
    } else {
      return 0;
    }
  } else {
    return 0;
  }
  join_1541:;
  _M0L3strS3672 = _M0L4restS1542.$0;
  _M0L5startS3673 = _M0L4restS1542.$1;
  _M0L3endS3674 = _M0L4restS1542.$2;
  _M0L9rest__strS1543 = _M0L3strS3672;
  _M0L11rest__startS1544 = _M0L5startS3673;
  _M0L9rest__endS1545 = _M0L3endS3674;
  while (1) {
    struct _M0TPC16string10StringView _M0L4restS1547;
    int32_t _M0L6_2atmpS3666 = _M0L9rest__endS1545 - _M0L11rest__startS1544;
    moonbit_string_t _M0L3strS3663;
    int32_t _M0L5startS3664;
    int32_t _M0L3endS3665;
    if (_M0L6_2atmpS3666 >= 1) {
      int32_t _M0L6_2atmpS3671 = _M0L9rest__strS1543[_M0L11rest__startS1544];
      int32_t _M0L4_2axS1549 = _M0L6_2atmpS3671;
      if (_M0L4_2axS1549 >= 97 && _M0L4_2axS1549 <= 122) {
        int32_t _M0L6_2atmpS3670 = _M0L11rest__startS1544 + 1;
        struct _M0TPC16string10StringView _M0L4_2axS1550 =
          (struct _M0TPC16string10StringView){.$0 = _M0L9rest__strS1543,
                                                .$1 = _M0L6_2atmpS3670,
                                                .$2 = _M0L9rest__endS1545};
        _M0L4restS1547 = _M0L4_2axS1550;
        goto join_1546;
      } else if (_M0L4_2axS1549 >= 65 && _M0L4_2axS1549 <= 90) {
        int32_t _M0L6_2atmpS3669 = _M0L11rest__startS1544 + 1;
        struct _M0TPC16string10StringView _M0L4_2axS1551 =
          (struct _M0TPC16string10StringView){.$0 = _M0L9rest__strS1543,
                                                .$1 = _M0L6_2atmpS3669,
                                                .$2 = _M0L9rest__endS1545};
        _M0L4restS1547 = _M0L4_2axS1551;
        goto join_1546;
      } else if (_M0L4_2axS1549 >= 48 && _M0L4_2axS1549 <= 57) {
        int32_t _M0L6_2atmpS3668 = _M0L11rest__startS1544 + 1;
        struct _M0TPC16string10StringView _M0L4_2axS1552 =
          (struct _M0TPC16string10StringView){.$0 = _M0L9rest__strS1543,
                                                .$1 = _M0L6_2atmpS3668,
                                                .$2 = _M0L9rest__endS1545};
        _M0L4restS1547 = _M0L4_2axS1552;
        goto join_1546;
      } else if (_M0L4_2axS1549 == 95) {
        int32_t _M0L6_2atmpS3667 = _M0L11rest__startS1544 + 1;
        struct _M0TPC16string10StringView _M0L4_2axS1553 =
          (struct _M0TPC16string10StringView){.$0 = _M0L9rest__strS1543,
                                                .$1 = _M0L6_2atmpS3667,
                                                .$2 = _M0L9rest__endS1545};
        _M0L4restS1547 = _M0L4_2axS1553;
        goto join_1546;
      } else {
        moonbit_decref(_M0L9rest__strS1543);
        return 0;
      }
    } else {
      moonbit_decref(_M0L9rest__strS1543);
      return 1;
    }
    join_1546:;
    _M0L3strS3663 = _M0L4restS1547.$0;
    _M0L5startS3664 = _M0L4restS1547.$1;
    _M0L3endS3665 = _M0L4restS1547.$2;
    _M0L9rest__strS1543 = _M0L3strS3663;
    _M0L11rest__startS1544 = _M0L5startS3664;
    _M0L9rest__endS1545 = _M0L3endS3665;
    continue;
    break;
  }
}

int32_t _M0FPC15debug10info__size(void* _M0L4infoS1528) {
  #line 83 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  switch (Moonbit_object_tag(_M0L4infoS1528)) {
    case 0: {
      return 1;
      break;
    }
    
    case 1: {
      return 1;
      break;
    }
    
    case 2: {
      return 1;
      break;
    }
    
    case 3: {
      return 1;
      break;
    }
    
    case 4: {
      return 1;
      break;
    }
    
    case 5: {
      return 1;
      break;
    }
    
    case 6: {
      struct _M0DTPC15debug4Repr9StringLit* _M0L12_2aStringLitS1529 =
        (struct _M0DTPC15debug4Repr9StringLit*)_M0L4infoS1528;
      moonbit_string_t _M0L4_2asS1530 = _M0L12_2aStringLitS1529->$0;
      int32_t _M0L6_2atmpS3662 = Moonbit_array_length(_M0L4_2asS1530);
      if (_M0L6_2atmpS3662 <= 15) {
        return 1;
      } else {
        return 2;
      }
      break;
    }
    
    case 7: {
      return 1;
      break;
    }
    
    case 8: {
      return 1;
      break;
    }
    
    case 9: {
      return 2;
      break;
    }
    
    case 12: {
      struct _M0DTPC15debug4Repr11RecordField* _M0L14_2aRecordFieldS1531 =
        (struct _M0DTPC15debug4Repr11RecordField*)_M0L4infoS1528;
      moonbit_string_t _M0L7_2anameS1532 = _M0L14_2aRecordFieldS1531->$0;
      int32_t _M0L6_2atmpS3661 = Moonbit_array_length(_M0L7_2anameS1532);
      if (_M0L6_2atmpS3661 <= 15) {
        return 0;
      } else {
        return 1;
      }
      break;
    }
    
    case 13: {
      struct _M0DTPC15debug4Repr14EnumLabeledArg* _M0L17_2aEnumLabeledArgS1533 =
        (struct _M0DTPC15debug4Repr14EnumLabeledArg*)_M0L4infoS1528;
      moonbit_string_t _M0L7_2anameS1534 = _M0L17_2aEnumLabeledArgS1533->$0;
      int32_t _M0L6_2atmpS3660 = Moonbit_array_length(_M0L7_2anameS1534);
      if (_M0L6_2atmpS3660 <= 15) {
        return 0;
      } else {
        return 1;
      }
      break;
    }
    
    case 10: {
      struct _M0DTPC15debug4Repr4Enum* _M0L7_2aEnumS1535 =
        (struct _M0DTPC15debug4Repr4Enum*)_M0L4infoS1528;
      moonbit_string_t _M0L7_2anameS1536 = _M0L7_2aEnumS1535->$0;
      int32_t _M0L6_2atmpS3659 = Moonbit_array_length(_M0L7_2anameS1536);
      if (_M0L6_2atmpS3659 <= 15) {
        return 1;
      } else {
        return 2;
      }
      break;
    }
    
    case 14: {
      struct _M0DTPC15debug4Repr6Opaque* _M0L9_2aOpaqueS1537 =
        (struct _M0DTPC15debug4Repr6Opaque*)_M0L4infoS1528;
      moonbit_string_t _M0L7_2anameS1538 = _M0L9_2aOpaqueS1537->$0;
      int32_t _M0L6_2atmpS3658 = Moonbit_array_length(_M0L7_2anameS1538);
      if (_M0L6_2atmpS3658 <= 15) {
        return 1;
      } else {
        return 2;
      }
      break;
    }
    
    case 15: {
      struct _M0DTPC15debug4Repr7Literal* _M0L10_2aLiteralS1539 =
        (struct _M0DTPC15debug4Repr7Literal*)_M0L4infoS1528;
      moonbit_string_t _M0L4_2asS1540 = _M0L10_2aLiteralS1539->$0;
      int32_t _M0L6_2atmpS3657 = Moonbit_array_length(_M0L4_2asS1540);
      if (_M0L6_2atmpS3657 <= 15) {
        return 1;
      } else {
        return 2;
      }
      break;
    }
    
    case 11: {
      return 2;
      break;
    }
    
    case 16: {
      return 0;
      break;
    }
    default: {
      return 0;
      break;
    }
  }
}

void* _M0MPC15debug4Repr11prune__info(
  void* _M0L4selfS1526,
  void* _M0L17replacement_2eoptS1524,
  int64_t _M0L10max__depthS1527
) {
  void* _M0L11replacementS1523;
  void* _result_4349;
  if (_M0L17replacement_2eoptS1524 == 0) {
    #line 42 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
    _M0L11replacementS1523 = _M0MPC15debug4Repr7omitted();
  } else {
    void* _M0L7_2aSomeS1525 = _M0L17replacement_2eoptS1524;
    if (_M0L7_2aSomeS1525) {
      moonbit_incref(_M0L7_2aSomeS1525);
    }
    _M0L11replacementS1523 = _M0L7_2aSomeS1525;
  }
  _result_4349
  = _M0MPC15debug4Repr19prune__info_2einner(_M0L4selfS1526, _M0L11replacementS1523, _M0L10max__depthS1527);
  moonbit_decref(_M0L11replacementS1523);
  return _result_4349;
}

void* _M0MPC15debug4Repr19prune__info_2einner(
  void* _M0L4selfS1519,
  void* _M0L11replacementS1522,
  int64_t _M0L10max__depthS1518
) {
  #line 40 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  if (_M0L10max__depthS1518 == 4294967296ll) {
    moonbit_incref(_M0L4selfS1519);
    return _M0L4selfS1519;
  } else {
    int64_t _M0L7_2aSomeS1520 = _M0L10max__depthS1518;
    int32_t _M0L8_2adepthS1521 = (int32_t)_M0L7_2aSomeS1520;
    int32_t _M0L6_2atmpS3656;
    #line 66 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
    _M0L6_2atmpS3656 = _M0MPC13int3Int3max(1, _M0L8_2adepthS1521);
    #line 66 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
    return _M0MPC15debug4Repr19prune__info_2einnerN2goS260(_M0L11replacementS1522, _M0L6_2atmpS3656, _M0L4selfS1519);
  }
}

void* _M0MPC15debug4Repr19prune__info_2einnerN2goS260(
  void* _M0L11replacementS1515,
  int32_t _M0L1dS1513,
  void* _M0L4nodeS1512
) {
  struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L8childrenS1511;
  #line 48 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  #line 49 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  _M0L8childrenS1511 = _M0MPC15debug4Repr8children(_M0L4nodeS1512);
  if (_M0L1dS1513 <= 0) {
    #line 51 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
    if (_M0MPC15array5Array9is__emptyGRPC15debug4ReprE(_M0L8childrenS1511)) {
      moonbit_decref(_M0L8childrenS1511);
      moonbit_incref(_M0L4nodeS1512);
      return _M0L4nodeS1512;
    } else {
      int32_t _M0L6_2atmpS3645;
      #line 53 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _M0L6_2atmpS3645
      = _M0MPC15debug4Repr17info__adds__depth(_M0L4nodeS1512);
      if (!_M0L6_2atmpS3645) {
        struct _M0R93_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3aprune__info_2einner_2ego_7c260_2eanon__u3648__l54__* _closure_4350;
        struct _M0TWRPC15debug4ReprERPC15debug4Repr* _M0L6_2atmpS3647;
        struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L6_2atmpS3646;
        void* _result_4351;
        moonbit_incref(_M0L11replacementS1515);
        _closure_4350
        = (struct _M0R93_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3aprune__info_2einner_2ego_7c260_2eanon__u3648__l54__*)moonbit_malloc(sizeof(struct _M0R93_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3aprune__info_2einner_2ego_7c260_2eanon__u3648__l54__));
        Moonbit_object_header(_closure_4350)->meta
        = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 50, 0);
        _closure_4350->code
        = &_M0MPC15debug4Repr19prune__info_2einnerN2goS260C3648l54;
        _closure_4350->$0 = _M0L11replacementS1515;
        _closure_4350->$1 = _M0L1dS1513;
        _M0L6_2atmpS3647
        = (struct _M0TWRPC15debug4ReprERPC15debug4Repr*)_closure_4350;
        #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        _M0L6_2atmpS3646
        = _M0MPC15array5Array3mapGRPC15debug4ReprRPC15debug4ReprE(_M0L8childrenS1511, _M0L6_2atmpS3647);
        moonbit_decref(_M0L8childrenS1511);
        moonbit_decref(_M0L6_2atmpS3647);
        #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
        _result_4351
        = _M0MPC15debug4Repr14with__children(_M0L4nodeS1512, _M0L6_2atmpS3646);
        moonbit_decref(_M0L6_2atmpS3646);
        return _result_4351;
      } else {
        moonbit_decref(_M0L8childrenS1511);
        moonbit_incref(_M0L11replacementS1515);
        return _M0L11replacementS1515;
      }
    }
  } else {
    #line 58 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
    if (_M0MPC15array5Array9is__emptyGRPC15debug4ReprE(_M0L8childrenS1511)) {
      moonbit_decref(_M0L8childrenS1511);
      moonbit_incref(_M0L4nodeS1512);
      return _M0L4nodeS1512;
    } else {
      int32_t _M0L11next__depthS1516;
      struct _M0R93_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3aprune__info_2einner_2ego_7c260_2eanon__u3653__l62__* _closure_4352;
      struct _M0TWRPC15debug4ReprERPC15debug4Repr* _M0L6_2atmpS3652;
      struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L6_2atmpS3651;
      void* _result_4353;
      #line 61 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      if (_M0MPC15debug4Repr17info__adds__depth(_M0L4nodeS1512)) {
        _M0L11next__depthS1516 = _M0L1dS1513 - 1;
      } else {
        _M0L11next__depthS1516 = _M0L1dS1513;
      }
      moonbit_incref(_M0L11replacementS1515);
      _closure_4352
      = (struct _M0R93_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3aprune__info_2einner_2ego_7c260_2eanon__u3653__l62__*)moonbit_malloc(sizeof(struct _M0R93_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3aprune__info_2einner_2ego_7c260_2eanon__u3653__l62__));
      Moonbit_object_header(_closure_4352)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 53, 0);
      _closure_4352->code
      = &_M0MPC15debug4Repr19prune__info_2einnerN2goS260C3653l62;
      _closure_4352->$0 = _M0L11next__depthS1516;
      _closure_4352->$1 = _M0L11replacementS1515;
      _M0L6_2atmpS3652
      = (struct _M0TWRPC15debug4ReprERPC15debug4Repr*)_closure_4352;
      #line 62 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _M0L6_2atmpS3651
      = _M0MPC15array5Array3mapGRPC15debug4ReprRPC15debug4ReprE(_M0L8childrenS1511, _M0L6_2atmpS3652);
      moonbit_decref(_M0L8childrenS1511);
      moonbit_decref(_M0L6_2atmpS3652);
      #line 62 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
      _result_4353
      = _M0MPC15debug4Repr14with__children(_M0L4nodeS1512, _M0L6_2atmpS3651);
      moonbit_decref(_M0L6_2atmpS3651);
      return _result_4353;
    }
  }
}

void* _M0MPC15debug4Repr19prune__info_2einnerN2goS260C3653l62(
  struct _M0TWRPC15debug4ReprERPC15debug4Repr* _M0L6_2aenvS3654,
  void* _M0L5childS1517
) {
  struct _M0R93_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3aprune__info_2einner_2ego_7c260_2eanon__u3653__l62__* _M0L14_2acasted__envS3655;
  void* _M0L11replacementS1515;
  int32_t _M0L11next__depthS1516;
  #line 62 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  _M0L14_2acasted__envS3655
  = (struct _M0R93_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3aprune__info_2einner_2ego_7c260_2eanon__u3653__l62__*)_M0L6_2aenvS3654;
  _M0L11replacementS1515 = _M0L14_2acasted__envS3655->$1;
  _M0L11next__depthS1516 = _M0L14_2acasted__envS3655->$0;
  #line 62 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  return _M0MPC15debug4Repr19prune__info_2einnerN2goS260(_M0L11replacementS1515, _M0L11next__depthS1516, _M0L5childS1517);
}

void* _M0MPC15debug4Repr19prune__info_2einnerN2goS260C3648l54(
  struct _M0TWRPC15debug4ReprERPC15debug4Repr* _M0L6_2aenvS3649,
  void* _M0L5childS1514
) {
  struct _M0R93_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3aprune__info_2einner_2ego_7c260_2eanon__u3648__l54__* _M0L14_2acasted__envS3650;
  int32_t _M0L1dS1513;
  void* _M0L11replacementS1515;
  #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  _M0L14_2acasted__envS3650
  = (struct _M0R93_40moonbitlang_2fcore_2fdebug_2eRepr_3a_3aprune__info_2einner_2ego_7c260_2eanon__u3648__l54__*)_M0L6_2aenvS3649;
  _M0L1dS1513 = _M0L14_2acasted__envS3650->$1;
  _M0L11replacementS1515 = _M0L14_2acasted__envS3650->$0;
  #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  return _M0MPC15debug4Repr19prune__info_2einnerN2goS260(_M0L11replacementS1515, _M0L1dS1513, _M0L5childS1514);
}

int32_t _M0MPC15debug4Repr17info__adds__depth(void* _M0L4infoS1510) {
  int32_t _M0L6_2atmpS3644;
  #line 77 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\pretty_print.mbt"
  switch (Moonbit_object_tag(_M0L4infoS1510)) {
    case 12: {
      _M0L6_2atmpS3644 = 1;
      break;
    }
    
    case 13: {
      _M0L6_2atmpS3644 = 1;
      break;
    }
    
    case 16: {
      _M0L6_2atmpS3644 = 1;
      break;
    }
    default: {
      _M0L6_2atmpS3644 = 0;
      break;
    }
  }
  return !_M0L6_2atmpS3644;
}

struct _M0TPC15debug7Content* _M0FPC15debug14with__resizing(
  int32_t _M0L12__root__sizeS1509,
  int32_t _M0L9thresholdS1505,
  struct _M0TPC15debug7Content* _M0L18rendered__childrenS1506
) {
  #line 445 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  if (_M0L9thresholdS1505 <= 0) {
    moonbit_incref(_M0L18rendered__childrenS1506);
    return _M0L18rendered__childrenS1506;
  } else {
    struct _M0TPC15debug7Content* _M0L9compactedS1507;
    struct _M0TPB5ArrayGsE* _M0L5linesS3638;
    struct _M0R68_24moonbitlang_2fcore_2fdebug_2ewith__resizing_2eanon__u3640__l460__* _closure_4354;
    struct _M0TWsEb* _M0L6_2atmpS3639;
    int32_t _result_4355;
    #line 455 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
    _M0L9compactedS1507
    = _M0MPC15debug7Content7compact(_M0L18rendered__childrenS1506);
    _M0L5linesS3638 = _M0L9compactedS1507->$1;
    _closure_4354
    = (struct _M0R68_24moonbitlang_2fcore_2fdebug_2ewith__resizing_2eanon__u3640__l460__*)moonbit_malloc(sizeof(struct _M0R68_24moonbitlang_2fcore_2fdebug_2ewith__resizing_2eanon__u3640__l460__));
    Moonbit_object_header(_closure_4354)->meta
    = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0);
    _closure_4354->code = &_M0FPC15debug14with__resizingC3640l460;
    _closure_4354->$0 = _M0L9thresholdS1505;
    _M0L6_2atmpS3639 = (struct _M0TWsEb*)_closure_4354;
    moonbit_incref(_M0L5linesS3638);
    #line 460 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
    _result_4355
    = _M0MPC15array5Array3allGsE(_M0L5linesS3638, _M0L6_2atmpS3639);
    moonbit_decref(_M0L5linesS3638);
    moonbit_decref(_M0L6_2atmpS3639);
    if (_result_4355) {
      return _M0L9compactedS1507;
    } else {
      moonbit_decref(_M0L9compactedS1507);
      moonbit_incref(_M0L18rendered__childrenS1506);
      return _M0L18rendered__childrenS1506;
    }
  }
}

int32_t _M0FPC15debug14with__resizingC3640l460(
  struct _M0TWsEb* _M0L6_2aenvS3641,
  moonbit_string_t _M0L4lineS1508
) {
  struct _M0R68_24moonbitlang_2fcore_2fdebug_2ewith__resizing_2eanon__u3640__l460__* _M0L14_2acasted__envS3642;
  int32_t _M0L9thresholdS1505;
  int32_t _M0L6_2atmpS3643;
  #line 460 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _M0L14_2acasted__envS3642
  = (struct _M0R68_24moonbitlang_2fcore_2fdebug_2ewith__resizing_2eanon__u3640__l460__*)_M0L6_2aenvS3641;
  _M0L9thresholdS1505 = _M0L14_2acasted__envS3642->$0;
  _M0L6_2atmpS3643 = Moonbit_array_length(_M0L4lineS1508);
  return _M0L6_2atmpS3643 <= _M0L9thresholdS1505;
}

moonbit_string_t _M0FPC15debug14print__content(
  struct _M0TPC15debug13ContentParens* _M0L1rS1504
) {
  struct _M0TPB5ArrayGsE* _M0L5linesS3635;
  int32_t _M0L6_2atmpS3637;
  struct _M0TPC16string10StringView _M0L6_2atmpS3636;
  moonbit_string_t _result_4356;
  #line 435 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _M0L5linesS3635 = _M0L1rS1504->$1;
  _M0L6_2atmpS3637
  = Moonbit_array_length(_M0FPC15debug14print__contentN7_2abindS1298);
  moonbit_incref(_M0FPC15debug14print__contentN7_2abindS1298);
  _M0L6_2atmpS3636
  = (struct _M0TPC16string10StringView){
    .$0 = _M0FPC15debug14print__contentN7_2abindS1298,
      .$1 = 0,
      .$2 = _M0L6_2atmpS3637
  };
  moonbit_incref(_M0L5linesS3635);
  #line 436 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _result_4356
  = _M0MPC15array5Array4joinGsE(_M0L5linesS3635, _M0L6_2atmpS3636);
  moonbit_decref(_M0L5linesS3635);
  moonbit_decref(_M0L6_2atmpS3636.$0);
  return _result_4356;
}

struct _M0TPC15debug7Content* _M0FPC15debug10comma__seq(
  moonbit_string_t _M0L5beginS1501,
  moonbit_string_t _M0L3endS1502,
  struct _M0TPB5ArrayGRPC15debug13ContentParensE* _M0L8contentsS1496
) {
  int32_t _M0L7_2abindS1495;
  int32_t _M0L2__S1497;
  int32_t _M0L4sizeS1498;
  #line 417 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _M0L7_2abindS1495 = _M0L8contentsS1496->$1;
  _M0L2__S1497 = 0;
  _M0L4sizeS1498 = 0;
  while (1) {
    if (_M0L2__S1497 < _M0L7_2abindS1495) {
      struct _M0TPC15debug13ContentParens** _M0L3bufS3629 =
        _M0L8contentsS1496->$0;
      struct _M0TPC15debug13ContentParens* _M0L1cS1499 =
        (struct _M0TPC15debug13ContentParens*)_M0L3bufS3629[_M0L2__S1497];
      int32_t _M0L6_2atmpS3626 = _M0L2__S1497 + 1;
      int32_t _M0L4sizeS3628 = _M0L1cS1499->$0;
      int32_t _M0L6_2atmpS3627 = _M0L4sizeS1498 + _M0L4sizeS3628;
      _M0L2__S1497 = _M0L6_2atmpS3626;
      _M0L4sizeS1498 = _M0L6_2atmpS3627;
      continue;
    } else {
      struct _M0TWRPC15debug13ContentParensERPB5ArrayGsE* _M0L6_2atmpS3632 =
        (struct _M0TWRPC15debug13ContentParensERPB5ArrayGsE*)&_M0FPC15debug10comma__seqC3633l427$closure.data;
      struct _M0TPB5ArrayGRPB5ArrayGsEE* _M0L6_2atmpS3631;
      struct _M0TPB5ArrayGsE* _M0L6_2atmpS3630;
      struct _M0TPC15debug7Content* _block_4358;
      #line 427 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
      _M0L6_2atmpS3631
      = _M0MPC15array5Array3mapGRPC15debug13ContentParensRPB5ArrayGsEE(_M0L8contentsS1496, _M0L6_2atmpS3632);
      moonbit_decref(_M0L6_2atmpS3632);
      #line 427 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
      _M0L6_2atmpS3630
      = _M0FPC15debug17comma__seq__lines(_M0L5beginS1501, _M0L3endS1502, _M0L6_2atmpS3631);
      moonbit_decref(_M0L6_2atmpS3631);
      _block_4358
      = (struct _M0TPC15debug7Content*)moonbit_malloc(sizeof(struct _M0TPC15debug7Content));
      Moonbit_object_header(_block_4358)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 56, 0);
      _block_4358->$0 = _M0L4sizeS1498;
      _block_4358->$1 = _M0L6_2atmpS3630;
      _block_4358->$2 = 0;
      return _block_4358;
    }
    break;
  }
}

struct _M0TPB5ArrayGsE* _M0FPC15debug10comma__seqC3633l427(
  struct _M0TWRPC15debug13ContentParensERPB5ArrayGsE* _M0L6_2aenvS3634,
  struct _M0TPC15debug13ContentParens* _M0L1cS1503
) {
  struct _M0TPB5ArrayGsE* _M0L8_2afieldS4032;
  #line 427 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _M0L8_2afieldS4032 = _M0L1cS1503->$1;
  moonbit_incref(_M0L8_2afieldS4032);
  return _M0L8_2afieldS4032;
}

struct _M0TPB5ArrayGsE* _M0FPC15debug17comma__seq__lines(
  moonbit_string_t _M0L5beginS1453,
  moonbit_string_t _M0L3endS1454,
  struct _M0TPB5ArrayGRPB5ArrayGsEE* _M0L8contentsS1455
) {
  int32_t _if__result_4359;
  #line 332 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  #line 338 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  if (
    _M0L5beginS1453 == (moonbit_string_t)moonbit_string_literal_25.data
    || Moonbit_array_length(_M0L5beginS1453)
       == Moonbit_array_length((moonbit_string_t)moonbit_string_literal_25.data)
       && 0
          == memcmp(_M0L5beginS1453, (moonbit_string_t)moonbit_string_literal_25.data, Moonbit_array_length(_M0L5beginS1453) * 2)
  ) {
    #line 338 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
    _if__result_4359
    = _M0L3endS1454 == (moonbit_string_t)moonbit_string_literal_26.data
      || Moonbit_array_length(_M0L3endS1454)
         == Moonbit_array_length((moonbit_string_t)moonbit_string_literal_26.data)
         && 0
            == memcmp(_M0L3endS1454, (moonbit_string_t)moonbit_string_literal_26.data, Moonbit_array_length(_M0L3endS1454) * 2);
  } else {
    _if__result_4359 = 0;
  }
  if (_if__result_4359) {
    #line 339 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
    return _M0FPC15debug19bracket__seq__lines((moonbit_string_t)moonbit_string_literal_25.data, (moonbit_string_t)moonbit_string_literal_26.data, 2, _M0L8contentsS1455);
  } else {
    int32_t _if__result_4360;
    #line 340 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
    if (
      _M0L5beginS1453 == (moonbit_string_t)moonbit_string_literal_27.data
      || Moonbit_array_length(_M0L5beginS1453)
         == Moonbit_array_length((moonbit_string_t)moonbit_string_literal_27.data)
         && 0
            == memcmp(_M0L5beginS1453, (moonbit_string_t)moonbit_string_literal_27.data, Moonbit_array_length(_M0L5beginS1453) * 2)
    ) {
      #line 340 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
      _if__result_4360
      = _M0L3endS1454 == (moonbit_string_t)moonbit_string_literal_11.data
        || Moonbit_array_length(_M0L3endS1454)
           == Moonbit_array_length((moonbit_string_t)moonbit_string_literal_11.data)
           && 0
              == memcmp(_M0L3endS1454, (moonbit_string_t)moonbit_string_literal_11.data, Moonbit_array_length(_M0L3endS1454) * 2);
    } else {
      _if__result_4360 = 0;
    }
    if (_if__result_4360) {
      #line 341 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
      return _M0FPC15debug19bracket__seq__lines((moonbit_string_t)moonbit_string_literal_27.data, (moonbit_string_t)moonbit_string_literal_11.data, 2, _M0L8contentsS1455);
    } else {
      int32_t _if__result_4361;
      #line 342 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
      if (
        _M0L5beginS1453 == (moonbit_string_t)moonbit_string_literal_1.data
        || Moonbit_array_length(_M0L5beginS1453)
           == Moonbit_array_length((moonbit_string_t)moonbit_string_literal_1.data)
           && 0
              == memcmp(_M0L5beginS1453, (moonbit_string_t)moonbit_string_literal_1.data, Moonbit_array_length(_M0L5beginS1453) * 2)
      ) {
        #line 342 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
        _if__result_4361
        = _M0L3endS1454 == (moonbit_string_t)moonbit_string_literal_1.data
          || Moonbit_array_length(_M0L3endS1454)
             == Moonbit_array_length((moonbit_string_t)moonbit_string_literal_1.data)
             && 0
                == memcmp(_M0L3endS1454, (moonbit_string_t)moonbit_string_literal_1.data, Moonbit_array_length(_M0L3endS1454) * 2);
      } else {
        _if__result_4361 = 0;
      }
      if (_if__result_4361) {
        int32_t _M0L3lenS3544 = _M0L8contentsS1455->$1;
        struct _M0TPB5ArrayGsE* _M0L5linesS1456;
        struct _M0TWsEb* _M0L6_2atmpS3541;
        struct _M0TPB5ArrayGsE* _result_4363;
        if (_M0L3lenS3544 == 0) {
          moonbit_string_t _M0L6_2atmpS3546;
          moonbit_string_t* _M0L6_2atmpS3545;
          #line 350 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _M0L6_2atmpS3546
          = moonbit_add_string(_M0L5beginS1453, _M0L3endS1454);
          _M0L6_2atmpS3545 = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
          _M0L6_2atmpS3545[0] = _M0L6_2atmpS3546;
          _M0L5linesS1456
          = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
          Moonbit_object_header(_M0L5linesS1456)->meta
          = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
          _M0L5linesS1456->$0 = _M0L6_2atmpS3545;
          _M0L5linesS1456->$1 = 1;
        } else {
          int32_t _M0L3lenS3547 = _M0L8contentsS1455->$1;
          if (_M0L3lenS3547 == 1) {
            struct _M0TPB5ArrayGsE** _M0L3bufS3548 = _M0L8contentsS1455->$0;
            struct _M0TPB5ArrayGsE* _M0L7_2aitemS1457 =
              (struct _M0TPB5ArrayGsE*)_M0L3bufS3548[0];
            moonbit_incref(_M0L7_2aitemS1457);
            #line 351 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _M0L5linesS1456
            = _M0FPC15debug15surround__lines(_M0L5beginS1453, _M0L3endS1454, _M0L7_2aitemS1457);
            moonbit_decref(_M0L7_2aitemS1457);
          } else {
            struct _M0TPB5ArrayGsE** _M0L3bufS3566 = _M0L8contentsS1455->$0;
            struct _M0TPB5ArrayGsE* _M0L8_2afirstS1458 =
              (struct _M0TPB5ArrayGsE*)_M0L3bufS3566[0];
            struct _M0TPB5ArrayGsE** _M0L3bufS3563 = _M0L8contentsS1455->$0;
            int32_t _M0L3lenS3565 = _M0L8contentsS1455->$1;
            int32_t _M0L6_2atmpS3564 = _M0L3lenS3565 - 1;
            struct _M0TPB5ArrayGsE* _M0L7_2alastS1459 =
              (struct _M0TPB5ArrayGsE*)_M0L3bufS3563[_M0L6_2atmpS3564];
            struct _M0TPB5ArrayGsE** _M0L9_2ax__bufS1460 =
              _M0L8contentsS1455->$0;
            int32_t _M0L3lenS3562 = _M0L8contentsS1455->$1;
            int32_t _M0L9_2ax__endS1461 = _M0L3lenS3562 - 1;
            int32_t _M0L6_2atmpS3561 = Moonbit_array_length(_M0L5beginS1453);
            moonbit_string_t _M0L5spaceS1462;
            moonbit_string_t* _M0L6_2atmpS3560;
            struct _M0TPB5ArrayGsE* _M0L13middle__linesS1463;
            int32_t _M0L7_2abindS1464;
            int32_t _M0L2__S1465;
            moonbit_string_t* _M0L6_2atmpS3559;
            struct _M0TPB5ArrayGsE* _M0L7_2aselfS1469;
            struct _M0TPB5ArrayGsE* _M0L6_2atmpS3555;
            struct _M0TPB4IterGsE* _M0L6_2atmpS3554;
            struct _M0TPB4IterGsE* _M0L6_2atmpS3556;
            struct _M0TPB5ArrayGsE* _M0L6_2atmpS3558;
            struct _M0TPB4IterGsE* _M0L6_2atmpS3557;
            moonbit_incref(_M0L9_2ax__bufS1460);
            moonbit_incref(_M0L7_2alastS1459);
            moonbit_incref(_M0L8_2afirstS1458);
            #line 346 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _M0L5spaceS1462
            = _M0MPC16string6String6repeat((moonbit_string_t)moonbit_string_literal_2.data, _M0L6_2atmpS3561);
            _M0L6_2atmpS3560 = (moonbit_string_t*)moonbit_empty_ref_array;
            _M0L13middle__linesS1463
            = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
            Moonbit_object_header(_M0L13middle__linesS1463)->meta
            = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
            _M0L13middle__linesS1463->$0 = _M0L6_2atmpS3560;
            _M0L13middle__linesS1463->$1 = 0;
            _M0L7_2abindS1464 = _M0L9_2ax__endS1461 - 1;
            _M0L2__S1465 = 0;
            while (1) {
              if (_M0L2__S1465 < _M0L7_2abindS1464) {
                int32_t _M0L6_2atmpS3553 = 1 + _M0L2__S1465;
                struct _M0TPB5ArrayGsE* _M0L4itemS1466 =
                  (struct _M0TPB5ArrayGsE*)_M0L9_2ax__bufS1460[
                    _M0L6_2atmpS3553
                  ];
                struct _M0TPB5ArrayGsE* _M0L7_2abindS1467;
                moonbit_string_t* _M0L3bufS3550;
                int32_t _M0L3lenS3551;
                int32_t _M0L6_2acntS4222;
                struct _M0TPB9ArrayViewGsE _M0L6_2atmpS3549;
                int32_t _M0L6_2atmpS3552;
                moonbit_incref(_M0L4itemS1466);
                #line 356 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                _M0L7_2abindS1467
                = _M0FPC15debug15surround__lines(_M0L5spaceS1462, (moonbit_string_t)moonbit_string_literal_3.data, _M0L4itemS1466);
                moonbit_decref(_M0L4itemS1466);
                _M0L3bufS3550 = _M0L7_2abindS1467->$0;
                _M0L3lenS3551 = _M0L7_2abindS1467->$1;
                _M0L6_2acntS4222
                = Moonbit_rc_count(Moonbit_object_header(_M0L7_2abindS1467));
                if (_M0L6_2acntS4222 > 1) {
                  int32_t _M0L11_2anew__cntS4223 = _M0L6_2acntS4222 - 1;
                  Moonbit_set_rc_count(Moonbit_object_header(_M0L7_2abindS1467), _M0L11_2anew__cntS4223);
                  moonbit_incref(_M0L3bufS3550);
                } else if (_M0L6_2acntS4222 == 1) {
                  #line 356 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                  moonbit_free(_M0L7_2abindS1467);
                }
                _M0L6_2atmpS3549
                = (struct _M0TPB9ArrayViewGsE){
                  .$0 = _M0L3bufS3550, .$1 = 0, .$2 = _M0L3lenS3551
                };
                #line 356 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                _M0MPC15array5Array6appendGsE(_M0L13middle__linesS1463, _M0L6_2atmpS3549);
                moonbit_decref(_M0L6_2atmpS3549.$0);
                _M0L6_2atmpS3552 = _M0L2__S1465 + 1;
                _M0L2__S1465 = _M0L6_2atmpS3552;
                continue;
              } else {
                moonbit_decref(_M0L9_2ax__bufS1460);
              }
              break;
            }
            _M0L6_2atmpS3559 = (moonbit_string_t*)moonbit_empty_ref_array;
            _M0L7_2aselfS1469
            = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
            Moonbit_object_header(_M0L7_2aselfS1469)->meta
            = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
            _M0L7_2aselfS1469->$0 = _M0L6_2atmpS3559;
            _M0L7_2aselfS1469->$1 = 0;
            #line 359 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _M0L6_2atmpS3555
            = _M0FPC15debug15surround__lines(_M0L5beginS1453, (moonbit_string_t)moonbit_string_literal_3.data, _M0L8_2afirstS1458);
            moonbit_decref(_M0L8_2afirstS1458);
            #line 359 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _M0L6_2atmpS3554 = _M0MPC15array5Array4iterGsE(_M0L6_2atmpS3555);
            moonbit_decref(_M0L6_2atmpS3555);
            #line 358 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _M0MPC15array5Array10push__iterGsE(_M0L7_2aselfS1469, _M0L6_2atmpS3554);
            moonbit_decref(_M0L6_2atmpS3554);
            #line 360 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _M0L6_2atmpS3556
            = _M0MPC15array5Array4iterGsE(_M0L13middle__linesS1463);
            moonbit_decref(_M0L13middle__linesS1463);
            #line 358 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _M0MPC15array5Array10push__iterGsE(_M0L7_2aselfS1469, _M0L6_2atmpS3556);
            moonbit_decref(_M0L6_2atmpS3556);
            #line 361 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _M0L6_2atmpS3558
            = _M0FPC15debug15surround__lines(_M0L5spaceS1462, _M0L3endS1454, _M0L7_2alastS1459);
            moonbit_decref(_M0L5spaceS1462);
            moonbit_decref(_M0L7_2alastS1459);
            #line 361 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _M0L6_2atmpS3557 = _M0MPC15array5Array4iterGsE(_M0L6_2atmpS3558);
            moonbit_decref(_M0L6_2atmpS3558);
            #line 358 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _M0MPC15array5Array10push__iterGsE(_M0L7_2aselfS1469, _M0L6_2atmpS3557);
            moonbit_decref(_M0L6_2atmpS3557);
            _M0L5linesS1456 = _M0L7_2aselfS1469;
          }
        }
        _M0L6_2atmpS3541
        = (struct _M0TWsEb*)&_M0FPC15debug17comma__seq__linesC3542l365$closure.data;
        #line 365 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
        _result_4363
        = _M0MPC15array5Array6filterGsE(_M0L5linesS1456, _M0L6_2atmpS3541);
        moonbit_decref(_M0L5linesS1456);
        moonbit_decref(_M0L6_2atmpS3541);
        return _result_4363;
      } else {
        int32_t _M0L3lenS3567 = _M0L8contentsS1455->$1;
        if (_M0L3lenS3567 == 0) {
          moonbit_string_t _M0L6_2atmpS3569;
          moonbit_string_t* _M0L6_2atmpS3568;
          struct _M0TPB5ArrayGsE* _block_4364;
          #line 377 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _M0L6_2atmpS3569
          = moonbit_add_string(_M0L5beginS1453, _M0L3endS1454);
          _M0L6_2atmpS3568 = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
          _M0L6_2atmpS3568[0] = _M0L6_2atmpS3569;
          _block_4364
          = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
          Moonbit_object_header(_block_4364)->meta
          = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
          _block_4364->$0 = _M0L6_2atmpS3568;
          _block_4364->$1 = 1;
          return _block_4364;
        } else {
          int32_t _M0L3lenS3570 = _M0L8contentsS1455->$1;
          if (_M0L3lenS3570 == 1) {
            struct _M0TPB5ArrayGsE** _M0L3bufS3599 = _M0L8contentsS1455->$0;
            struct _M0TPB5ArrayGsE* _M0L7_2aitemS1471 =
              (struct _M0TPB5ArrayGsE*)_M0L3bufS3599[0];
            struct _M0TWsEb* _M0L6_2atmpS3596 =
              (struct _M0TWsEb*)&_M0FPC15debug17comma__seq__linesC3597l379$closure.data;
            struct _M0TPB5ArrayGsE* _M0L11item__linesS1472;
            int32_t _M0L3lenS3571;
            moonbit_incref(_M0L7_2aitemS1471);
            #line 379 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _M0L11item__linesS1472
            = _M0MPC15array5Array6filterGsE(_M0L7_2aitemS1471, _M0L6_2atmpS3596);
            moonbit_decref(_M0L7_2aitemS1471);
            moonbit_decref(_M0L6_2atmpS3596);
            _M0L3lenS3571 = _M0L11item__linesS1472->$1;
            if (_M0L3lenS3571 == 0) {
              moonbit_string_t _M0L6_2atmpS3573;
              moonbit_string_t* _M0L6_2atmpS3572;
              struct _M0TPB5ArrayGsE* _block_4365;
              moonbit_decref(_M0L11item__linesS1472);
              #line 381 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              _M0L6_2atmpS3573
              = moonbit_add_string(_M0L5beginS1453, _M0L3endS1454);
              _M0L6_2atmpS3572
              = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
              _M0L6_2atmpS3572[0] = _M0L6_2atmpS3573;
              _block_4365
              = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
              Moonbit_object_header(_block_4365)->meta
              = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
              _block_4365->$0 = _M0L6_2atmpS3572;
              _block_4365->$1 = 1;
              return _block_4365;
            } else {
              int32_t _M0L3lenS3574 = _M0L11item__linesS1472->$1;
              if (_M0L3lenS3574 == 1) {
                moonbit_string_t* _M0L3bufS3578 = _M0L11item__linesS1472->$0;
                int32_t _M0L6_2acntS4224 =
                  Moonbit_rc_count(Moonbit_object_header(_M0L11item__linesS1472));
                moonbit_string_t _M0L6_2atmpS4037;
                moonbit_string_t _M0L4_2axS1474;
                moonbit_string_t _M0L6_2atmpS3577;
                moonbit_string_t _M0L6_2atmpS3576;
                moonbit_string_t* _M0L6_2atmpS3575;
                struct _M0TPB5ArrayGsE* _block_4366;
                if (_M0L6_2acntS4224 > 1) {
                  int32_t _M0L11_2anew__cntS4225 = _M0L6_2acntS4224 - 1;
                  Moonbit_set_rc_count(Moonbit_object_header(_M0L11item__linesS1472), _M0L11_2anew__cntS4225);
                  moonbit_incref(_M0L3bufS3578);
                } else if (_M0L6_2acntS4224 == 1) {
                  #line 379 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                  moonbit_free(_M0L11item__linesS1472);
                }
                _M0L6_2atmpS4037 = (moonbit_string_t)_M0L3bufS3578[0];
                moonbit_incref(_M0L6_2atmpS4037);
                moonbit_decref(_M0L3bufS3578);
                _M0L4_2axS1474 = _M0L6_2atmpS4037;
                #line 382 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                _M0L6_2atmpS3577
                = moonbit_add_string(_M0L5beginS1453, _M0L4_2axS1474);
                moonbit_decref(_M0L4_2axS1474);
                #line 382 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                _M0L6_2atmpS3576
                = moonbit_add_string(_M0L6_2atmpS3577, _M0L3endS1454);
                moonbit_decref(_M0L6_2atmpS3577);
                _M0L6_2atmpS3575
                = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
                _M0L6_2atmpS3575[0] = _M0L6_2atmpS3576;
                _block_4366
                = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
                Moonbit_object_header(_block_4366)->meta
                = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
                _block_4366->$0 = _M0L6_2atmpS3575;
                _block_4366->$1 = 1;
                return _block_4366;
              } else {
                moonbit_string_t* _M0L3bufS3593 = _M0L11item__linesS1472->$0;
                int32_t _M0L3lenS3595 = _M0L11item__linesS1472->$1;
                int32_t _M0L6_2atmpS3594 = _M0L3lenS3595 - 1;
                moonbit_string_t _M0L13_2alast__lineS1475 =
                  (moonbit_string_t)_M0L3bufS3593[_M0L6_2atmpS3594];
                moonbit_string_t* _M0L3bufS3590 = _M0L11item__linesS1472->$0;
                int32_t _M0L3lenS3592 = _M0L11item__linesS1472->$1;
                int32_t _M0L6_2acntS4226;
                int32_t _M0L6_2atmpS3591;
                struct _M0TPB9ArrayViewGsE _M0L4_2axS1476;
                moonbit_string_t* _M0L6_2atmpS3589;
                struct _M0TPB5ArrayGsE* _M0L7_2aselfS1477;
                struct _M0TPB4IterGsE* _M0L6_2atmpS3581;
                struct _M0TWsEs* _M0L6_2atmpS3582;
                struct _M0TPB4IterGsE* _M0L6_2atmpS3580;
                struct _M0TPB4IterGsE* _M0L6_2atmpS3579;
                moonbit_string_t _M0L6_2atmpS3588;
                moonbit_string_t _M0L6_2atmpS3587;
                moonbit_string_t _M0L6_2atmpS3586;
                moonbit_incref(_M0L13_2alast__lineS1475);
                _M0L6_2acntS4226
                = Moonbit_rc_count(Moonbit_object_header(_M0L11item__linesS1472));
                if (_M0L6_2acntS4226 > 1) {
                  int32_t _M0L11_2anew__cntS4227 = _M0L6_2acntS4226 - 1;
                  Moonbit_set_rc_count(Moonbit_object_header(_M0L11item__linesS1472), _M0L11_2anew__cntS4227);
                  moonbit_incref(_M0L3bufS3590);
                } else if (_M0L6_2acntS4226 == 1) {
                  #line 379 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                  moonbit_free(_M0L11item__linesS1472);
                }
                _M0L6_2atmpS3591 = _M0L3lenS3592 - 1;
                _M0L4_2axS1476
                = (struct _M0TPB9ArrayViewGsE){
                  .$0 = _M0L3bufS3590, .$1 = 0, .$2 = _M0L6_2atmpS3591
                };
                _M0L6_2atmpS3589 = (moonbit_string_t*)moonbit_empty_ref_array;
                _M0L7_2aselfS1477
                = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
                Moonbit_object_header(_M0L7_2aselfS1477)->meta
                = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
                _M0L7_2aselfS1477->$0 = _M0L6_2atmpS3589;
                _M0L7_2aselfS1477->$1 = 0;
                moonbit_incref(_M0L5beginS1453);
                #line 384 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                _M0MPC15array5Array4pushGsE(_M0L7_2aselfS1477, _M0L5beginS1453);
                #line 386 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                _M0L6_2atmpS3581
                = _M0MPC15array9ArrayView4iterGsE(_M0L4_2axS1476);
                moonbit_decref(_M0L4_2axS1476.$0);
                _M0L6_2atmpS3582
                = (struct _M0TWsEs*)&_M0FPC15debug17comma__seq__linesC3583l386$closure.data;
                #line 386 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                _M0L6_2atmpS3580
                = _M0MPB4Iter3mapGssE(_M0L6_2atmpS3581, _M0L6_2atmpS3582);
                moonbit_decref(_M0L6_2atmpS3581);
                moonbit_decref(_M0L6_2atmpS3582);
                #line 386 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                _M0L6_2atmpS3579 = _M0MPB4Iter4iterGsE(_M0L6_2atmpS3580);
                moonbit_decref(_M0L6_2atmpS3580);
                #line 384 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                _M0MPC15array5Array10push__iterGsE(_M0L7_2aselfS1477, _M0L6_2atmpS3579);
                moonbit_decref(_M0L6_2atmpS3579);
                #line 387 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                _M0L6_2atmpS3588
                = _M0MPC16string6String6repeat((moonbit_string_t)moonbit_string_literal_2.data, 2);
                #line 387 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                _M0L6_2atmpS3587
                = moonbit_add_string(_M0L6_2atmpS3588, _M0L13_2alast__lineS1475);
                moonbit_decref(_M0L13_2alast__lineS1475);
                moonbit_decref(_M0L6_2atmpS3588);
                #line 387 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                _M0L6_2atmpS3586
                = moonbit_add_string(_M0L6_2atmpS3587, (moonbit_string_t)moonbit_string_literal_3.data);
                moonbit_decref(_M0L6_2atmpS3587);
                #line 384 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                _M0MPC15array5Array4pushGsE(_M0L7_2aselfS1477, _M0L6_2atmpS3586);
                moonbit_incref(_M0L3endS1454);
                #line 384 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                _M0MPC15array5Array4pushGsE(_M0L7_2aselfS1477, _M0L3endS1454);
                return _M0L7_2aselfS1477;
              }
            }
          } else {
            moonbit_string_t* _M0L6_2atmpS3625;
            struct _M0TPB5ArrayGsE* _M0L3outS1479;
            int32_t _M0L7_2abindS1480;
            int32_t _M0L2__S1481;
            moonbit_incref(_M0L5beginS1453);
            _M0L6_2atmpS3625
            = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
            _M0L6_2atmpS3625[0] = _M0L5beginS1453;
            _M0L3outS1479
            = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
            Moonbit_object_header(_M0L3outS1479)->meta
            = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
            _M0L3outS1479->$0 = _M0L6_2atmpS3625;
            _M0L3outS1479->$1 = 1;
            _M0L7_2abindS1480 = _M0L8contentsS1455->$1;
            _M0L2__S1481 = 0;
            while (1) {
              if (_M0L2__S1481 < _M0L7_2abindS1480) {
                struct _M0TPB5ArrayGsE** _M0L3bufS3624 =
                  _M0L8contentsS1455->$0;
                struct _M0TPB5ArrayGsE* _M0L4itemS1482 =
                  (struct _M0TPB5ArrayGsE*)_M0L3bufS3624[_M0L2__S1481];
                struct _M0TWsEb* _M0L6_2atmpS3620 =
                  (struct _M0TWsEb*)&_M0FPC15debug17comma__seq__linesC3621l395$closure.data;
                struct _M0TPB5ArrayGsE* _M0L11item__linesS1483;
                int32_t _M0L3lenS3600;
                int32_t _M0L6_2atmpS3623;
                moonbit_incref(_M0L4itemS1482);
                #line 395 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                _M0L11item__linesS1483
                = _M0MPC15array5Array6filterGsE(_M0L4itemS1482, _M0L6_2atmpS3620);
                moonbit_decref(_M0L4itemS1482);
                moonbit_decref(_M0L6_2atmpS3620);
                _M0L3lenS3600 = _M0L11item__linesS1483->$1;
                if (_M0L3lenS3600 == 0) {
                  moonbit_decref(_M0L11item__linesS1483);
                } else {
                  int32_t _M0L3lenS3601 = _M0L11item__linesS1483->$1;
                  if (_M0L3lenS3601 == 1) {
                    moonbit_string_t* _M0L3bufS3605 =
                      _M0L11item__linesS1483->$0;
                    int32_t _M0L6_2acntS4228 =
                      Moonbit_rc_count(Moonbit_object_header(_M0L11item__linesS1483));
                    moonbit_string_t _M0L6_2atmpS4040;
                    moonbit_string_t _M0L4_2axS1485;
                    moonbit_string_t _M0L6_2atmpS3604;
                    moonbit_string_t _M0L6_2atmpS3603;
                    moonbit_string_t _M0L6_2atmpS3602;
                    if (_M0L6_2acntS4228 > 1) {
                      int32_t _M0L11_2anew__cntS4229 = _M0L6_2acntS4228 - 1;
                      Moonbit_set_rc_count(Moonbit_object_header(_M0L11item__linesS1483), _M0L11_2anew__cntS4229);
                      moonbit_incref(_M0L3bufS3605);
                    } else if (_M0L6_2acntS4228 == 1) {
                      #line 395 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                      moonbit_free(_M0L11item__linesS1483);
                    }
                    _M0L6_2atmpS4040 = (moonbit_string_t)_M0L3bufS3605[0];
                    moonbit_incref(_M0L6_2atmpS4040);
                    moonbit_decref(_M0L3bufS3605);
                    _M0L4_2axS1485 = _M0L6_2atmpS4040;
                    #line 398 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                    _M0L6_2atmpS3604
                    = _M0MPC16string6String6repeat((moonbit_string_t)moonbit_string_literal_2.data, 2);
                    #line 398 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                    _M0L6_2atmpS3603
                    = moonbit_add_string(_M0L6_2atmpS3604, _M0L4_2axS1485);
                    moonbit_decref(_M0L4_2axS1485);
                    moonbit_decref(_M0L6_2atmpS3604);
                    #line 398 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                    _M0L6_2atmpS3602
                    = moonbit_add_string(_M0L6_2atmpS3603, (moonbit_string_t)moonbit_string_literal_3.data);
                    moonbit_decref(_M0L6_2atmpS3603);
                    #line 398 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                    _M0MPC15array5Array4pushGsE(_M0L3outS1479, _M0L6_2atmpS3602);
                  } else {
                    moonbit_string_t* _M0L3bufS3619 =
                      _M0L11item__linesS1483->$0;
                    moonbit_string_t _M0L8_2afirstS1486 =
                      (moonbit_string_t)_M0L3bufS3619[0];
                    moonbit_string_t* _M0L3bufS3616 =
                      _M0L11item__linesS1483->$0;
                    int32_t _M0L3lenS3618 = _M0L11item__linesS1483->$1;
                    int32_t _M0L6_2atmpS3617 = _M0L3lenS3618 - 1;
                    moonbit_string_t _M0L7_2alastS1487 =
                      (moonbit_string_t)_M0L3bufS3616[_M0L6_2atmpS3617];
                    moonbit_string_t* _M0L9_2ax__bufS1488 =
                      _M0L11item__linesS1483->$0;
                    int32_t _M0L3lenS3615 = _M0L11item__linesS1483->$1;
                    int32_t _M0L6_2acntS4230;
                    int32_t _M0L9_2ax__endS1489;
                    moonbit_string_t _M0L6_2atmpS3607;
                    moonbit_string_t _M0L6_2atmpS3606;
                    int32_t _M0L7_2abindS1490;
                    int32_t _M0L2__S1491;
                    moonbit_string_t _M0L6_2atmpS3614;
                    moonbit_string_t _M0L6_2atmpS3613;
                    moonbit_string_t _M0L6_2atmpS3612;
                    moonbit_incref(_M0L7_2alastS1487);
                    moonbit_incref(_M0L8_2afirstS1486);
                    _M0L6_2acntS4230
                    = Moonbit_rc_count(Moonbit_object_header(_M0L11item__linesS1483));
                    if (_M0L6_2acntS4230 > 1) {
                      int32_t _M0L11_2anew__cntS4231 = _M0L6_2acntS4230 - 1;
                      Moonbit_set_rc_count(Moonbit_object_header(_M0L11item__linesS1483), _M0L11_2anew__cntS4231);
                      moonbit_incref(_M0L9_2ax__bufS1488);
                    } else if (_M0L6_2acntS4230 == 1) {
                      #line 395 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                      moonbit_free(_M0L11item__linesS1483);
                    }
                    _M0L9_2ax__endS1489 = _M0L3lenS3615 - 1;
                    #line 400 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                    _M0L6_2atmpS3607
                    = _M0MPC16string6String6repeat((moonbit_string_t)moonbit_string_literal_2.data, 2);
                    #line 400 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                    _M0L6_2atmpS3606
                    = moonbit_add_string(_M0L6_2atmpS3607, _M0L8_2afirstS1486);
                    moonbit_decref(_M0L8_2afirstS1486);
                    moonbit_decref(_M0L6_2atmpS3607);
                    #line 400 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                    _M0MPC15array5Array4pushGsE(_M0L3outS1479, _M0L6_2atmpS3606);
                    _M0L7_2abindS1490 = _M0L9_2ax__endS1489 - 1;
                    _M0L2__S1491 = 0;
                    while (1) {
                      if (_M0L2__S1491 < _M0L7_2abindS1490) {
                        int32_t _M0L6_2atmpS3611 = 1 + _M0L2__S1491;
                        moonbit_string_t _M0L3midS1492 =
                          (moonbit_string_t)_M0L9_2ax__bufS1488[
                            _M0L6_2atmpS3611
                          ];
                        moonbit_string_t _M0L6_2atmpS3609;
                        moonbit_string_t _M0L6_2atmpS3608;
                        int32_t _M0L6_2atmpS3610;
                        moonbit_incref(_M0L3midS1492);
                        #line 402 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                        _M0L6_2atmpS3609
                        = _M0MPC16string6String6repeat((moonbit_string_t)moonbit_string_literal_2.data, 2);
                        #line 402 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                        _M0L6_2atmpS3608
                        = moonbit_add_string(_M0L6_2atmpS3609, _M0L3midS1492);
                        moonbit_decref(_M0L3midS1492);
                        moonbit_decref(_M0L6_2atmpS3609);
                        #line 402 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                        _M0MPC15array5Array4pushGsE(_M0L3outS1479, _M0L6_2atmpS3608);
                        _M0L6_2atmpS3610 = _M0L2__S1491 + 1;
                        _M0L2__S1491 = _M0L6_2atmpS3610;
                        continue;
                      } else {
                        moonbit_decref(_M0L9_2ax__bufS1488);
                      }
                      break;
                    }
                    #line 404 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                    _M0L6_2atmpS3614
                    = _M0MPC16string6String6repeat((moonbit_string_t)moonbit_string_literal_2.data, 2);
                    #line 404 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                    _M0L6_2atmpS3613
                    = moonbit_add_string(_M0L6_2atmpS3614, _M0L7_2alastS1487);
                    moonbit_decref(_M0L7_2alastS1487);
                    moonbit_decref(_M0L6_2atmpS3614);
                    #line 404 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                    _M0L6_2atmpS3612
                    = moonbit_add_string(_M0L6_2atmpS3613, (moonbit_string_t)moonbit_string_literal_3.data);
                    moonbit_decref(_M0L6_2atmpS3613);
                    #line 404 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                    _M0MPC15array5Array4pushGsE(_M0L3outS1479, _M0L6_2atmpS3612);
                  }
                }
                _M0L6_2atmpS3623 = _M0L2__S1481 + 1;
                _M0L2__S1481 = _M0L6_2atmpS3623;
                continue;
              }
              break;
            }
            moonbit_incref(_M0L3endS1454);
            #line 408 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _M0MPC15array5Array4pushGsE(_M0L3outS1479, _M0L3endS1454);
            return _M0L3outS1479;
          }
        }
      }
    }
  }
}

int32_t _M0FPC15debug17comma__seq__linesC3621l395(
  struct _M0TWsEb* _M0L6_2aenvS3622,
  moonbit_string_t _M0L4lineS1484
) {
  #line 395 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  #line 395 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  return _M0IP016_24default__implPB2Eq10not__equalGsE(_M0L4lineS1484, (moonbit_string_t)moonbit_string_literal_1.data);
}

int32_t _M0FPC15debug17comma__seq__linesC3597l379(
  struct _M0TWsEb* _M0L6_2aenvS3598,
  moonbit_string_t _M0L4lineS1473
) {
  #line 379 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  #line 379 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  return _M0IP016_24default__implPB2Eq10not__equalGsE(_M0L4lineS1473, (moonbit_string_t)moonbit_string_literal_1.data);
}

moonbit_string_t _M0FPC15debug17comma__seq__linesC3583l386(
  struct _M0TWsEs* _M0L6_2aenvS3584,
  moonbit_string_t _M0L4lineS1478
) {
  moonbit_string_t _M0L6_2atmpS3585;
  moonbit_string_t _result_4369;
  #line 386 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  #line 386 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _M0L6_2atmpS3585
  = _M0MPC16string6String6repeat((moonbit_string_t)moonbit_string_literal_2.data, 2);
  #line 386 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _result_4369 = moonbit_add_string(_M0L6_2atmpS3585, _M0L4lineS1478);
  moonbit_decref(_M0L6_2atmpS3585);
  return _result_4369;
}

int32_t _M0FPC15debug17comma__seq__linesC3542l365(
  struct _M0TWsEb* _M0L6_2aenvS3543,
  moonbit_string_t _M0L4lineS1470
) {
  #line 365 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  #line 365 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  return _M0IP016_24default__implPB2Eq10not__equalGsE(_M0L4lineS1470, (moonbit_string_t)moonbit_string_literal_1.data);
}

struct _M0TPB5ArrayGsE* _M0FPC15debug19bracket__seq__lines(
  moonbit_string_t _M0L4openS1424,
  moonbit_string_t _M0L5closeS1425,
  int32_t _M0L10indent__byS1428,
  struct _M0TPB5ArrayGRPB5ArrayGsEE* _M0L8contentsS1423
) {
  int32_t _M0L3lenS3479;
  #line 262 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _M0L3lenS3479 = _M0L8contentsS1423->$1;
  if (_M0L3lenS3479 == 0) {
    moonbit_string_t _M0L6_2atmpS3481;
    moonbit_string_t* _M0L6_2atmpS3480;
    struct _M0TPB5ArrayGsE* _block_4370;
    #line 269 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
    _M0L6_2atmpS3481 = moonbit_add_string(_M0L4openS1424, _M0L5closeS1425);
    _M0L6_2atmpS3480 = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
    _M0L6_2atmpS3480[0] = _M0L6_2atmpS3481;
    _block_4370
    = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
    Moonbit_object_header(_block_4370)->meta
    = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
    _block_4370->$0 = _M0L6_2atmpS3480;
    _block_4370->$1 = 1;
    return _block_4370;
  } else {
    int32_t _M0L3lenS3482 = _M0L8contentsS1423->$1;
    if (_M0L3lenS3482 == 1) {
      struct _M0TPB5ArrayGsE** _M0L3bufS3514 = _M0L8contentsS1423->$0;
      struct _M0TPB5ArrayGsE* _M0L7_2aitemS1426 =
        (struct _M0TPB5ArrayGsE*)_M0L3bufS3514[0];
      int32_t _M0L3lenS3483 = _M0L7_2aitemS1426->$1;
      if (_M0L3lenS3483 > 1) {
        struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3494;
        struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3493;
        struct _M0TPB5ArrayGsE* _M0L8_2afieldS4047;
        int32_t _M0L6_2acntS4232;
        struct _M0TPB5ArrayGsE* _M0L5linesS1427;
        int32_t _M0L6_2atmpS3484;
        moonbit_string_t* _M0L6_2atmpS3492;
        struct _M0TPB5ArrayGsE* _M0L7_2aselfS1431;
        struct _M0TPB4IterGsE* _M0L6_2atmpS3491;
        moonbit_incref(_M0L7_2aitemS1426);
        _M0L6_2atmpS3494
        = (struct _M0TPC15debug13ContentParens*)moonbit_malloc(sizeof(struct _M0TPC15debug13ContentParens));
        Moonbit_object_header(_M0L6_2atmpS3494)->meta
        = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 59, 0);
        _M0L6_2atmpS3494->$0 = 0;
        _M0L6_2atmpS3494->$1 = _M0L7_2aitemS1426;
        #line 275 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
        _M0L6_2atmpS3493
        = _M0FPC15debug14indent__spaces(_M0L10indent__byS1428, _M0L6_2atmpS3494);
        moonbit_decref(_M0L6_2atmpS3494);
        _M0L8_2afieldS4047 = _M0L6_2atmpS3493->$1;
        _M0L6_2acntS4232
        = Moonbit_rc_count(Moonbit_object_header(_M0L6_2atmpS3493));
        if (_M0L6_2acntS4232 > 1) {
          int32_t _M0L11_2anew__cntS4233 = _M0L6_2acntS4232 - 1;
          Moonbit_set_rc_count(Moonbit_object_header(_M0L6_2atmpS3493), _M0L11_2anew__cntS4233);
          moonbit_incref(_M0L8_2afieldS4047);
        } else if (_M0L6_2acntS4232 == 1) {
          #line 275 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          moonbit_free(_M0L6_2atmpS3493);
        }
        _M0L5linesS1427 = _M0L8_2afieldS4047;
        #line 276 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
        _M0L6_2atmpS3484 = _M0MPC15array5Array9is__emptyGsE(_M0L5linesS1427);
        if (!_M0L6_2atmpS3484) {
          int32_t _M0L3lenS3490 = _M0L5linesS1427->$1;
          int32_t _M0L7last__iS1429 = _M0L3lenS3490 - 1;
          int32_t _if__result_4371;
          moonbit_string_t* _M0L3bufS3489;
          moonbit_string_t _M0L6_2atmpS3487;
          moonbit_string_t _M0L7_2abindS1430;
          int32_t _if__result_4372;
          moonbit_string_t* _M0L3bufS3486;
          moonbit_string_t _M0L6_2aoldS4045;
          if (_M0L7last__iS1429 < 0) {
            _if__result_4371 = 1;
          } else {
            int32_t _M0L3lenS3488 = _M0L5linesS1427->$1;
            _if__result_4371 = _M0L7last__iS1429 >= _M0L3lenS3488;
          }
          if (_if__result_4371) {
            #line 278 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            moonbit_panic();
          }
          _M0L3bufS3489 = _M0L5linesS1427->$0;
          _M0L6_2atmpS3487
          = (moonbit_string_t)_M0L3bufS3489[_M0L7last__iS1429];
          #line 278 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _M0L7_2abindS1430
          = moonbit_add_string(_M0L6_2atmpS3487, (moonbit_string_t)moonbit_string_literal_3.data);
          if (_M0L7last__iS1429 < 0) {
            _if__result_4372 = 1;
          } else {
            int32_t _M0L3lenS3485 = _M0L5linesS1427->$1;
            _if__result_4372 = _M0L7last__iS1429 >= _M0L3lenS3485;
          }
          if (_if__result_4372) {
            #line 278 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            moonbit_panic();
          }
          _M0L3bufS3486 = _M0L5linesS1427->$0;
          _M0L6_2aoldS4045
          = (moonbit_string_t)_M0L3bufS3486[_M0L7last__iS1429];
          moonbit_decref(_M0L6_2aoldS4045);
          _M0L3bufS3486[_M0L7last__iS1429] = _M0L7_2abindS1430;
        }
        _M0L6_2atmpS3492 = (moonbit_string_t*)moonbit_empty_ref_array;
        _M0L7_2aselfS1431
        = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
        Moonbit_object_header(_M0L7_2aselfS1431)->meta
        = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
        _M0L7_2aselfS1431->$0 = _M0L6_2atmpS3492;
        _M0L7_2aselfS1431->$1 = 0;
        moonbit_incref(_M0L4openS1424);
        #line 280 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
        _M0MPC15array5Array4pushGsE(_M0L7_2aselfS1431, _M0L4openS1424);
        #line 280 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
        _M0L6_2atmpS3491 = _M0MPC15array5Array4iterGsE(_M0L5linesS1427);
        moonbit_decref(_M0L5linesS1427);
        #line 280 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
        _M0MPC15array5Array10push__iterGsE(_M0L7_2aselfS1431, _M0L6_2atmpS3491);
        moonbit_decref(_M0L6_2atmpS3491);
        moonbit_incref(_M0L5closeS1425);
        #line 280 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
        _M0MPC15array5Array4pushGsE(_M0L7_2aselfS1431, _M0L5closeS1425);
        return _M0L7_2aselfS1431;
      } else {
        struct _M0TPB5ArrayGsE* _M0L5innerS1432;
        int32_t _M0L3lenS3495;
        moonbit_incref(_M0L7_2aitemS1426);
        #line 283 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
        _M0L5innerS1432 = _M0FPC15debug14compact__lines(_M0L7_2aitemS1426);
        _M0L3lenS3495 = _M0L5innerS1432->$1;
        if (_M0L3lenS3495 == 0) {
          moonbit_string_t _M0L6_2atmpS3497;
          moonbit_string_t* _M0L6_2atmpS3496;
          struct _M0TPB5ArrayGsE* _block_4373;
          moonbit_decref(_M0L5innerS1432);
          moonbit_decref(_M0L7_2aitemS1426);
          #line 285 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _M0L6_2atmpS3497
          = moonbit_add_string(_M0L4openS1424, _M0L5closeS1425);
          _M0L6_2atmpS3496 = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
          _M0L6_2atmpS3496[0] = _M0L6_2atmpS3497;
          _block_4373
          = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
          Moonbit_object_header(_block_4373)->meta
          = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
          _block_4373->$0 = _M0L6_2atmpS3496;
          _block_4373->$1 = 1;
          return _block_4373;
        } else {
          int32_t _M0L3lenS3498 = _M0L5innerS1432->$1;
          if (_M0L3lenS3498 == 1) {
            moonbit_string_t* _M0L3bufS3508;
            int32_t _M0L6_2acntS4234;
            moonbit_string_t _M0L6_2atmpS4048;
            moonbit_string_t _M0L4_2axS1433;
            int32_t _if__result_4374;
            moonbit_decref(_M0L7_2aitemS1426);
            _M0L3bufS3508 = _M0L5innerS1432->$0;
            _M0L6_2acntS4234
            = Moonbit_rc_count(Moonbit_object_header(_M0L5innerS1432));
            if (_M0L6_2acntS4234 > 1) {
              int32_t _M0L11_2anew__cntS4235 = _M0L6_2acntS4234 - 1;
              Moonbit_set_rc_count(Moonbit_object_header(_M0L5innerS1432), _M0L11_2anew__cntS4235);
              moonbit_incref(_M0L3bufS3508);
            } else if (_M0L6_2acntS4234 == 1) {
              #line 283 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              moonbit_free(_M0L5innerS1432);
            }
            _M0L6_2atmpS4048 = (moonbit_string_t)_M0L3bufS3508[0];
            moonbit_incref(_M0L6_2atmpS4048);
            moonbit_decref(_M0L3bufS3508);
            _M0L4_2axS1433 = _M0L6_2atmpS4048;
            #line 287 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            if (
              _M0L4openS1424
              == (moonbit_string_t)moonbit_string_literal_27.data
              || Moonbit_array_length(_M0L4openS1424)
                 == Moonbit_array_length((moonbit_string_t)moonbit_string_literal_27.data)
                 && 0
                    == memcmp(_M0L4openS1424, (moonbit_string_t)moonbit_string_literal_27.data, Moonbit_array_length(_M0L4openS1424) * 2)
            ) {
              #line 287 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              _if__result_4374
              = _M0L5closeS1425
                == (moonbit_string_t)moonbit_string_literal_11.data
                || Moonbit_array_length(_M0L5closeS1425)
                   == Moonbit_array_length((moonbit_string_t)moonbit_string_literal_11.data)
                   && 0
                      == memcmp(_M0L5closeS1425, (moonbit_string_t)moonbit_string_literal_11.data, Moonbit_array_length(_M0L5closeS1425) * 2);
            } else {
              _if__result_4374 = 0;
            }
            if (_if__result_4374) {
              void* _M0L4NoneS3504 =
                (struct moonbit_object*)&moonbit_constant_constructor_0 + 1;
              struct _M0TPC16string10StringView _M0L5innerS1434;
              int32_t _M0L6_2atmpS3500;
              struct _M0TPC16string10StringView _M0L6_2atmpS3499;
              int32_t _result_4375;
              #line 288 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              _M0L5innerS1434
              = _M0MPC16string6String4trim(_M0L4_2axS1433, _M0L4NoneS3504);
              moonbit_decref(_M0L4_2axS1433);
              moonbit_decref(_M0L4NoneS3504);
              _M0L6_2atmpS3500
              = Moonbit_array_length(_M0FPC15debug19bracket__seq__linesN7_2abindS1229);
              moonbit_incref(_M0FPC15debug19bracket__seq__linesN7_2abindS1229);
              _M0L6_2atmpS3499
              = (struct _M0TPC16string10StringView){
                .$0 = _M0FPC15debug19bracket__seq__linesN7_2abindS1229,
                  .$1 = 0,
                  .$2 = _M0L6_2atmpS3500
              };
              #line 289 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              _result_4375
              = _M0IPC16string10StringViewPB2Eq5equal(_M0L5innerS1434, _M0L6_2atmpS3499);
              moonbit_decref(_M0L6_2atmpS3499.$0);
              if (_result_4375) {
                moonbit_string_t* _M0L6_2atmpS3501;
                struct _M0TPB5ArrayGsE* _block_4376;
                moonbit_decref(_M0L5innerS1434.$0);
                _M0L6_2atmpS3501
                = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
                _M0L6_2atmpS3501[0]
                = (moonbit_string_t)moonbit_string_literal_35.data;
                _block_4376
                = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
                Moonbit_object_header(_block_4376)->meta
                = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
                _block_4376->$0 = _M0L6_2atmpS3501;
                _block_4376->$1 = 1;
                return _block_4376;
              } else {
                struct _M0TPB13StringBuilder* _M0L18_2astring__builderS1435;
                moonbit_string_t _M0L6_2atmpS3503;
                moonbit_string_t* _M0L6_2atmpS3502;
                struct _M0TPB5ArrayGsE* _block_4377;
                #line 292 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                _M0L18_2astring__builderS1435
                = _M0MPB13StringBuilder21StringBuilder_2einner(4);
                #line 292 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS1435, (moonbit_string_t)moonbit_string_literal_36.data);
                #line 292 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                _M0MPB13StringBuilder13write__objectGRPC16string10StringViewE(_M0L18_2astring__builderS1435, _M0L5innerS1434);
                moonbit_decref(_M0L5innerS1434.$0);
                #line 292 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS1435, (moonbit_string_t)moonbit_string_literal_37.data);
                #line 292 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                _M0L6_2atmpS3503
                = _M0MPB13StringBuilder10to__string(_M0L18_2astring__builderS1435);
                moonbit_decref(_M0L18_2astring__builderS1435);
                _M0L6_2atmpS3502
                = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
                _M0L6_2atmpS3502[0] = _M0L6_2atmpS3503;
                _block_4377
                = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
                Moonbit_object_header(_block_4377)->meta
                = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
                _block_4377->$0 = _M0L6_2atmpS3502;
                _block_4377->$1 = 1;
                return _block_4377;
              }
            } else {
              moonbit_string_t _M0L6_2atmpS3507;
              moonbit_string_t _M0L6_2atmpS3506;
              moonbit_string_t* _M0L6_2atmpS3505;
              struct _M0TPB5ArrayGsE* _block_4378;
              #line 295 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              _M0L6_2atmpS3507
              = moonbit_add_string(_M0L4openS1424, _M0L4_2axS1433);
              moonbit_decref(_M0L4_2axS1433);
              #line 295 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              _M0L6_2atmpS3506
              = moonbit_add_string(_M0L6_2atmpS3507, _M0L5closeS1425);
              moonbit_decref(_M0L6_2atmpS3507);
              _M0L6_2atmpS3505
              = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
              _M0L6_2atmpS3505[0] = _M0L6_2atmpS3506;
              _block_4378
              = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
              Moonbit_object_header(_block_4378)->meta
              = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
              _block_4378->$0 = _M0L6_2atmpS3505;
              _block_4378->$1 = 1;
              return _block_4378;
            }
          } else {
            moonbit_string_t* _M0L6_2atmpS3513;
            struct _M0TPB5ArrayGsE* _M0L7_2aselfS1436;
            struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3512;
            struct _M0TPC15debug13ContentParens* _M0L6_2atmpS3511;
            struct _M0TPB5ArrayGsE* _M0L8_2afieldS4049;
            int32_t _M0L6_2acntS4236;
            struct _M0TPB5ArrayGsE* _M0L5linesS3510;
            struct _M0TPB4IterGsE* _M0L6_2atmpS3509;
            moonbit_decref(_M0L5innerS1432);
            _M0L6_2atmpS3513 = (moonbit_string_t*)moonbit_empty_ref_array;
            _M0L7_2aselfS1436
            = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
            Moonbit_object_header(_M0L7_2aselfS1436)->meta
            = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
            _M0L7_2aselfS1436->$0 = _M0L6_2atmpS3513;
            _M0L7_2aselfS1436->$1 = 0;
            moonbit_incref(_M0L4openS1424);
            #line 298 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _M0MPC15array5Array4pushGsE(_M0L7_2aselfS1436, _M0L4openS1424);
            _M0L6_2atmpS3512
            = (struct _M0TPC15debug13ContentParens*)moonbit_malloc(sizeof(struct _M0TPC15debug13ContentParens));
            Moonbit_object_header(_M0L6_2atmpS3512)->meta
            = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 59, 0);
            _M0L6_2atmpS3512->$0 = 0;
            _M0L6_2atmpS3512->$1 = _M0L7_2aitemS1426;
            #line 300 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _M0L6_2atmpS3511
            = _M0FPC15debug14indent__spaces(_M0L10indent__byS1428, _M0L6_2atmpS3512);
            moonbit_decref(_M0L6_2atmpS3512);
            _M0L8_2afieldS4049 = _M0L6_2atmpS3511->$1;
            _M0L6_2acntS4236
            = Moonbit_rc_count(Moonbit_object_header(_M0L6_2atmpS3511));
            if (_M0L6_2acntS4236 > 1) {
              int32_t _M0L11_2anew__cntS4237 = _M0L6_2acntS4236 - 1;
              Moonbit_set_rc_count(Moonbit_object_header(_M0L6_2atmpS3511), _M0L11_2anew__cntS4237);
              moonbit_incref(_M0L8_2afieldS4049);
            } else if (_M0L6_2acntS4236 == 1) {
              #line 300 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              moonbit_free(_M0L6_2atmpS3511);
            }
            _M0L5linesS3510 = _M0L8_2afieldS4049;
            #line 300 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _M0L6_2atmpS3509 = _M0MPC15array5Array4iterGsE(_M0L5linesS3510);
            moonbit_decref(_M0L5linesS3510);
            #line 298 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _M0MPC15array5Array10push__iterGsE(_M0L7_2aselfS1436, _M0L6_2atmpS3509);
            moonbit_decref(_M0L6_2atmpS3509);
            moonbit_incref(_M0L5closeS1425);
            #line 298 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _M0MPC15array5Array4pushGsE(_M0L7_2aselfS1436, _M0L5closeS1425);
            return _M0L7_2aselfS1436;
          }
        }
      }
    } else {
      moonbit_string_t* _M0L6_2atmpS3540;
      struct _M0TPB5ArrayGsE* _M0L3outS1437;
      int32_t _M0L7_2abindS1438;
      int32_t _M0L2__S1439;
      moonbit_incref(_M0L4openS1424);
      _M0L6_2atmpS3540 = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
      _M0L6_2atmpS3540[0] = _M0L4openS1424;
      _M0L3outS1437
      = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
      Moonbit_object_header(_M0L3outS1437)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
      _M0L3outS1437->$0 = _M0L6_2atmpS3540;
      _M0L3outS1437->$1 = 1;
      _M0L7_2abindS1438 = _M0L8contentsS1423->$1;
      _M0L2__S1439 = 0;
      while (1) {
        if (_M0L2__S1439 < _M0L7_2abindS1438) {
          struct _M0TPB5ArrayGsE** _M0L3bufS3539 = _M0L8contentsS1423->$0;
          struct _M0TPB5ArrayGsE* _M0L4itemS1440 =
            (struct _M0TPB5ArrayGsE*)_M0L3bufS3539[_M0L2__S1439];
          struct _M0TWsEb* _M0L6_2atmpS3535 =
            (struct _M0TWsEb*)&_M0FPC15debug19bracket__seq__linesC3536l309$closure.data;
          struct _M0TPB5ArrayGsE* _M0L11item__linesS1441;
          int32_t _M0L3lenS3515;
          int32_t _M0L6_2atmpS3538;
          moonbit_incref(_M0L4itemS1440);
          #line 309 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _M0L11item__linesS1441
          = _M0MPC15array5Array6filterGsE(_M0L4itemS1440, _M0L6_2atmpS3535);
          moonbit_decref(_M0L4itemS1440);
          moonbit_decref(_M0L6_2atmpS3535);
          _M0L3lenS3515 = _M0L11item__linesS1441->$1;
          if (_M0L3lenS3515 == 0) {
            moonbit_decref(_M0L11item__linesS1441);
          } else {
            int32_t _M0L3lenS3516 = _M0L11item__linesS1441->$1;
            if (_M0L3lenS3516 == 1) {
              moonbit_string_t* _M0L3bufS3520 = _M0L11item__linesS1441->$0;
              int32_t _M0L6_2acntS4238 =
                Moonbit_rc_count(Moonbit_object_header(_M0L11item__linesS1441));
              moonbit_string_t _M0L6_2atmpS4051;
              moonbit_string_t _M0L4_2axS1443;
              moonbit_string_t _M0L6_2atmpS3519;
              moonbit_string_t _M0L6_2atmpS3518;
              moonbit_string_t _M0L6_2atmpS3517;
              if (_M0L6_2acntS4238 > 1) {
                int32_t _M0L11_2anew__cntS4239 = _M0L6_2acntS4238 - 1;
                Moonbit_set_rc_count(Moonbit_object_header(_M0L11item__linesS1441), _M0L11_2anew__cntS4239);
                moonbit_incref(_M0L3bufS3520);
              } else if (_M0L6_2acntS4238 == 1) {
                #line 309 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                moonbit_free(_M0L11item__linesS1441);
              }
              _M0L6_2atmpS4051 = (moonbit_string_t)_M0L3bufS3520[0];
              moonbit_incref(_M0L6_2atmpS4051);
              moonbit_decref(_M0L3bufS3520);
              _M0L4_2axS1443 = _M0L6_2atmpS4051;
              #line 312 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              _M0L6_2atmpS3519
              = _M0MPC16string6String6repeat((moonbit_string_t)moonbit_string_literal_2.data, _M0L10indent__byS1428);
              #line 312 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              _M0L6_2atmpS3518
              = moonbit_add_string(_M0L6_2atmpS3519, _M0L4_2axS1443);
              moonbit_decref(_M0L4_2axS1443);
              moonbit_decref(_M0L6_2atmpS3519);
              #line 312 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              _M0L6_2atmpS3517
              = moonbit_add_string(_M0L6_2atmpS3518, (moonbit_string_t)moonbit_string_literal_3.data);
              moonbit_decref(_M0L6_2atmpS3518);
              #line 312 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              _M0MPC15array5Array4pushGsE(_M0L3outS1437, _M0L6_2atmpS3517);
            } else {
              moonbit_string_t* _M0L3bufS3534 = _M0L11item__linesS1441->$0;
              moonbit_string_t _M0L8_2afirstS1444 =
                (moonbit_string_t)_M0L3bufS3534[0];
              moonbit_string_t* _M0L3bufS3531 = _M0L11item__linesS1441->$0;
              int32_t _M0L3lenS3533 = _M0L11item__linesS1441->$1;
              int32_t _M0L6_2atmpS3532 = _M0L3lenS3533 - 1;
              moonbit_string_t _M0L7_2alastS1445 =
                (moonbit_string_t)_M0L3bufS3531[_M0L6_2atmpS3532];
              moonbit_string_t* _M0L9_2ax__bufS1446 =
                _M0L11item__linesS1441->$0;
              int32_t _M0L3lenS3530 = _M0L11item__linesS1441->$1;
              int32_t _M0L6_2acntS4240;
              int32_t _M0L9_2ax__endS1447;
              moonbit_string_t _M0L6_2atmpS3522;
              moonbit_string_t _M0L6_2atmpS3521;
              int32_t _M0L7_2abindS1448;
              int32_t _M0L2__S1449;
              moonbit_string_t _M0L6_2atmpS3529;
              moonbit_string_t _M0L6_2atmpS3528;
              moonbit_string_t _M0L6_2atmpS3527;
              moonbit_incref(_M0L7_2alastS1445);
              moonbit_incref(_M0L8_2afirstS1444);
              _M0L6_2acntS4240
              = Moonbit_rc_count(Moonbit_object_header(_M0L11item__linesS1441));
              if (_M0L6_2acntS4240 > 1) {
                int32_t _M0L11_2anew__cntS4241 = _M0L6_2acntS4240 - 1;
                Moonbit_set_rc_count(Moonbit_object_header(_M0L11item__linesS1441), _M0L11_2anew__cntS4241);
                moonbit_incref(_M0L9_2ax__bufS1446);
              } else if (_M0L6_2acntS4240 == 1) {
                #line 309 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                moonbit_free(_M0L11item__linesS1441);
              }
              _M0L9_2ax__endS1447 = _M0L3lenS3530 - 1;
              #line 314 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              _M0L6_2atmpS3522
              = _M0MPC16string6String6repeat((moonbit_string_t)moonbit_string_literal_2.data, _M0L10indent__byS1428);
              #line 314 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              _M0L6_2atmpS3521
              = moonbit_add_string(_M0L6_2atmpS3522, _M0L8_2afirstS1444);
              moonbit_decref(_M0L8_2afirstS1444);
              moonbit_decref(_M0L6_2atmpS3522);
              #line 314 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              _M0MPC15array5Array4pushGsE(_M0L3outS1437, _M0L6_2atmpS3521);
              _M0L7_2abindS1448 = _M0L9_2ax__endS1447 - 1;
              _M0L2__S1449 = 0;
              while (1) {
                if (_M0L2__S1449 < _M0L7_2abindS1448) {
                  int32_t _M0L6_2atmpS3526 = 1 + _M0L2__S1449;
                  moonbit_string_t _M0L3midS1450 =
                    (moonbit_string_t)_M0L9_2ax__bufS1446[_M0L6_2atmpS3526];
                  moonbit_string_t _M0L6_2atmpS3524;
                  moonbit_string_t _M0L6_2atmpS3523;
                  int32_t _M0L6_2atmpS3525;
                  moonbit_incref(_M0L3midS1450);
                  #line 316 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                  _M0L6_2atmpS3524
                  = _M0MPC16string6String6repeat((moonbit_string_t)moonbit_string_literal_2.data, _M0L10indent__byS1428);
                  #line 316 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                  _M0L6_2atmpS3523
                  = moonbit_add_string(_M0L6_2atmpS3524, _M0L3midS1450);
                  moonbit_decref(_M0L3midS1450);
                  moonbit_decref(_M0L6_2atmpS3524);
                  #line 316 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                  _M0MPC15array5Array4pushGsE(_M0L3outS1437, _M0L6_2atmpS3523);
                  _M0L6_2atmpS3525 = _M0L2__S1449 + 1;
                  _M0L2__S1449 = _M0L6_2atmpS3525;
                  continue;
                } else {
                  moonbit_decref(_M0L9_2ax__bufS1446);
                }
                break;
              }
              #line 318 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              _M0L6_2atmpS3529
              = _M0MPC16string6String6repeat((moonbit_string_t)moonbit_string_literal_2.data, _M0L10indent__byS1428);
              #line 318 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              _M0L6_2atmpS3528
              = moonbit_add_string(_M0L6_2atmpS3529, _M0L7_2alastS1445);
              moonbit_decref(_M0L7_2alastS1445);
              moonbit_decref(_M0L6_2atmpS3529);
              #line 318 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              _M0L6_2atmpS3527
              = moonbit_add_string(_M0L6_2atmpS3528, (moonbit_string_t)moonbit_string_literal_3.data);
              moonbit_decref(_M0L6_2atmpS3528);
              #line 318 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              _M0MPC15array5Array4pushGsE(_M0L3outS1437, _M0L6_2atmpS3527);
            }
          }
          _M0L6_2atmpS3538 = _M0L2__S1439 + 1;
          _M0L2__S1439 = _M0L6_2atmpS3538;
          continue;
        }
        break;
      }
      moonbit_incref(_M0L5closeS1425);
      #line 322 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
      _M0MPC15array5Array4pushGsE(_M0L3outS1437, _M0L5closeS1425);
      return _M0L3outS1437;
    }
  }
}

int32_t _M0FPC15debug19bracket__seq__linesC3536l309(
  struct _M0TWsEb* _M0L6_2aenvS3537,
  moonbit_string_t _M0L4lineS1442
) {
  #line 309 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  #line 309 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  return _M0IP016_24default__implPB2Eq10not__equalGsE(_M0L4lineS1442, (moonbit_string_t)moonbit_string_literal_1.data);
}

struct _M0TPC15debug13ContentParens* _M0FPC15debug14indent__spaces(
  int32_t _M0L1nS1421,
  struct _M0TPC15debug13ContentParens* _M0L1rS1422
) {
  moonbit_string_t _M0L6_2atmpS3478;
  struct _M0TPC15debug13ContentParens* _result_4381;
  #line 241 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  #line 242 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _M0L6_2atmpS3478
  = _M0MPC16string6String6repeat((moonbit_string_t)moonbit_string_literal_2.data, _M0L1nS1421);
  #line 242 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _result_4381 = _M0FPC15debug6indent(_M0L6_2atmpS3478, _M0L1rS1422);
  moonbit_decref(_M0L6_2atmpS3478);
  return _result_4381;
}

struct _M0TPC15debug13ContentParens* _M0FPC15debug6indent(
  moonbit_string_t _M0L6prefixS1420,
  struct _M0TPC15debug13ContentParens* _M0L1rS1417
) {
  struct _M0R60_24moonbitlang_2fcore_2fdebug_2eindent_2eanon__u3471__l236__* _closure_4382;
  struct _M0TWRPB5ArrayGsEERPB5ArrayGsE* _M0L6_2atmpS3470;
  struct _M0TPC15debug13ContentParens* _result_4383;
  #line 235 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  moonbit_incref(_M0L6prefixS1420);
  _closure_4382
  = (struct _M0R60_24moonbitlang_2fcore_2fdebug_2eindent_2eanon__u3471__l236__*)moonbit_malloc(sizeof(struct _M0R60_24moonbitlang_2fcore_2fdebug_2eindent_2eanon__u3471__l236__));
  Moonbit_object_header(_closure_4382)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 62, 0);
  _closure_4382->code = &_M0FPC15debug6indentC3471l236;
  _closure_4382->$0 = _M0L6prefixS1420;
  _M0L6_2atmpS3470 = (struct _M0TWRPB5ArrayGsEERPB5ArrayGsE*)_closure_4382;
  #line 236 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _result_4383 = _M0FPC15debug11with__lines(_M0L1rS1417, _M0L6_2atmpS3470);
  moonbit_decref(_M0L6_2atmpS3470);
  return _result_4383;
}

struct _M0TPB5ArrayGsE* _M0FPC15debug6indentC3471l236(
  struct _M0TWRPB5ArrayGsEERPB5ArrayGsE* _M0L6_2aenvS3472,
  struct _M0TPB5ArrayGsE* _M0L5linesS1418
) {
  struct _M0R60_24moonbitlang_2fcore_2fdebug_2eindent_2eanon__u3471__l236__* _M0L14_2acasted__envS3473;
  moonbit_string_t _M0L6prefixS1420;
  struct _M0R60_24moonbitlang_2fcore_2fdebug_2eindent_2eanon__u3475__l236__* _closure_4384;
  struct _M0TWsEs* _M0L6_2atmpS3474;
  struct _M0TPB5ArrayGsE* _result_4385;
  #line 236 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _M0L14_2acasted__envS3473
  = (struct _M0R60_24moonbitlang_2fcore_2fdebug_2eindent_2eanon__u3471__l236__*)_M0L6_2aenvS3472;
  _M0L6prefixS1420 = _M0L14_2acasted__envS3473->$0;
  moonbit_incref(_M0L6prefixS1420);
  _closure_4384
  = (struct _M0R60_24moonbitlang_2fcore_2fdebug_2eindent_2eanon__u3475__l236__*)moonbit_malloc(sizeof(struct _M0R60_24moonbitlang_2fcore_2fdebug_2eindent_2eanon__u3475__l236__));
  Moonbit_object_header(_closure_4384)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 65, 0);
  _closure_4384->code = &_M0FPC15debug6indentC3475l236;
  _closure_4384->$0 = _M0L6prefixS1420;
  _M0L6_2atmpS3474 = (struct _M0TWsEs*)_closure_4384;
  #line 236 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _result_4385
  = _M0MPC15array5Array3mapGssE(_M0L5linesS1418, _M0L6_2atmpS3474);
  moonbit_decref(_M0L6_2atmpS3474);
  return _result_4385;
}

moonbit_string_t _M0FPC15debug6indentC3475l236(
  struct _M0TWsEs* _M0L6_2aenvS3476,
  moonbit_string_t _M0L4lineS1419
) {
  struct _M0R60_24moonbitlang_2fcore_2fdebug_2eindent_2eanon__u3475__l236__* _M0L14_2acasted__envS3477;
  moonbit_string_t _M0L6prefixS1420;
  #line 236 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _M0L14_2acasted__envS3477
  = (struct _M0R60_24moonbitlang_2fcore_2fdebug_2eindent_2eanon__u3475__l236__*)_M0L6_2aenvS3476;
  _M0L6prefixS1420 = _M0L14_2acasted__envS3477->$0;
  #line 236 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  return moonbit_add_string(_M0L6prefixS1420, _M0L4lineS1419);
}

struct _M0TPC15debug7Content* _M0MPC15debug7Content7compact(
  struct _M0TPC15debug7Content* _M0L1rS1416
) {
  #line 229 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  #line 230 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  return _M0MPC15debug7Content20with__lines__content(_M0L1rS1416, _M0FPC15debug20compact__lines_2eclo);
}

struct _M0TPB5ArrayGsE* _M0FPC15debug14compact__lines(
  struct _M0TPB5ArrayGsE* _M0L5linesS1376
) {
  int32_t _M0L3lenS3410;
  #line 147 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _M0L3lenS3410 = _M0L5linesS1376->$1;
  if (_M0L3lenS3410 == 0) {
    moonbit_string_t* _M0L6_2atmpS3411 =
      (moonbit_string_t*)moonbit_empty_ref_array;
    struct _M0TPB5ArrayGsE* _block_4386 =
      (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
    Moonbit_object_header(_block_4386)->meta
    = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
    _block_4386->$0 = _M0L6_2atmpS3411;
    _block_4386->$1 = 0;
    return _block_4386;
  } else {
    int32_t _M0L3lenS3412 = _M0L5linesS1376->$1;
    if (_M0L3lenS3412 == 1) {
      moonbit_string_t* _M0L3bufS3414 = _M0L5linesS1376->$0;
      moonbit_string_t _M0L4_2axS1377 = (moonbit_string_t)_M0L3bufS3414[0];
      moonbit_string_t* _M0L6_2atmpS3413;
      struct _M0TPB5ArrayGsE* _block_4387;
      moonbit_incref(_M0L4_2axS1377);
      _M0L6_2atmpS3413 = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
      _M0L6_2atmpS3413[0] = _M0L4_2axS1377;
      _block_4387
      = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
      Moonbit_object_header(_block_4387)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
      _block_4387->$0 = _M0L6_2atmpS3413;
      _block_4387->$1 = 1;
      return _block_4387;
    } else {
      moonbit_string_t* _M0L3bufS3469 = _M0L5linesS1376->$0;
      moonbit_string_t _M0L8_2afirstS1378 =
        (moonbit_string_t)_M0L3bufS3469[0];
      moonbit_string_t* _M0L3bufS3466 = _M0L5linesS1376->$0;
      int32_t _M0L3lenS3468 = _M0L5linesS1376->$1;
      int32_t _M0L6_2atmpS3467 = _M0L3lenS3468 - 1;
      moonbit_string_t _M0L7_2alastS1379 =
        (moonbit_string_t)_M0L3bufS3466[_M0L6_2atmpS3467];
      moonbit_string_t* _M0L9_2ax__bufS1380 = _M0L5linesS1376->$0;
      int32_t _M0L3lenS3465 = _M0L5linesS1376->$1;
      int32_t _M0L9_2ax__endS1381 = _M0L3lenS3465 - 1;
      int32_t _if__result_4388;
      int32_t _if__result_4389;
      #line 154 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
      if (
        _M0L8_2afirstS1378
        == (moonbit_string_t)moonbit_string_literal_25.data
        || Moonbit_array_length(_M0L8_2afirstS1378)
           == Moonbit_array_length((moonbit_string_t)moonbit_string_literal_25.data)
           && 0
              == memcmp(_M0L8_2afirstS1378, (moonbit_string_t)moonbit_string_literal_25.data, Moonbit_array_length(_M0L8_2afirstS1378) * 2)
      ) {
        #line 154 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
        _if__result_4388
        = _M0L7_2alastS1379
          == (moonbit_string_t)moonbit_string_literal_26.data
          || Moonbit_array_length(_M0L7_2alastS1379)
             == Moonbit_array_length((moonbit_string_t)moonbit_string_literal_26.data)
             && 0
                == memcmp(_M0L7_2alastS1379, (moonbit_string_t)moonbit_string_literal_26.data, Moonbit_array_length(_M0L7_2alastS1379) * 2);
      } else {
        _if__result_4388 = 0;
      }
      if (_if__result_4388) {
        _if__result_4389 = 1;
      } else {
        #line 154 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
        if (
          _M0L8_2afirstS1378
          == (moonbit_string_t)moonbit_string_literal_27.data
          || Moonbit_array_length(_M0L8_2afirstS1378)
             == Moonbit_array_length((moonbit_string_t)moonbit_string_literal_27.data)
             && 0
                == memcmp(_M0L8_2afirstS1378, (moonbit_string_t)moonbit_string_literal_27.data, Moonbit_array_length(_M0L8_2afirstS1378) * 2)
        ) {
          #line 154 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _if__result_4389
          = _M0L7_2alastS1379
            == (moonbit_string_t)moonbit_string_literal_11.data
            || Moonbit_array_length(_M0L7_2alastS1379)
               == Moonbit_array_length((moonbit_string_t)moonbit_string_literal_11.data)
               && 0
                  == memcmp(_M0L7_2alastS1379, (moonbit_string_t)moonbit_string_literal_11.data, Moonbit_array_length(_M0L7_2alastS1379) * 2);
        } else {
          _if__result_4389 = 0;
        }
      }
      if (_if__result_4389) {
        struct _M0TPC16string10StringView* _M0L6_2atmpS3436 =
          (struct _M0TPC16string10StringView*)moonbit_empty_ref_valtype_array;
        struct _M0TPB5ArrayGRPC16string10StringViewE* _M0L5partsS1382 =
          (struct _M0TPB5ArrayGRPC16string10StringViewE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGRPC16string10StringViewE));
        int32_t _M0L7_2abindS1383;
        int32_t _M0L2__S1384;
        int32_t _M0L6_2atmpS3435;
        struct _M0TPC16string10StringView _M0L6_2atmpS3434;
        moonbit_string_t _M0L7joined0S1388;
        int32_t _M0L6_2atmpS3433;
        struct _M0TPC16string10StringView _M0L6_2atmpS3432;
        void* _M0L7_2abindS1389;
        struct _M0TPC16string10StringView _M0L6joinedS1390;
        int32_t _result_4392;
        Moonbit_object_header(_M0L5partsS1382)->meta
        = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 68, 0);
        _M0L5partsS1382->$0 = _M0L6_2atmpS3436;
        _M0L5partsS1382->$1 = 0;
        _M0L7_2abindS1383 = _M0L9_2ax__endS1381 - 1;
        moonbit_incref(_M0L9_2ax__bufS1380);
        moonbit_incref(_M0L8_2afirstS1378);
        _M0L2__S1384 = 0;
        while (1) {
          if (_M0L2__S1384 < _M0L7_2abindS1383) {
            int32_t _M0L6_2atmpS3419 = 1 + _M0L2__S1384;
            moonbit_string_t _M0L1mS1385 =
              (moonbit_string_t)_M0L9_2ax__bufS1380[_M0L6_2atmpS3419];
            void* _M0L4NoneS3417 =
              (struct moonbit_object*)&moonbit_constant_constructor_0 + 1;
            struct _M0TPC16string10StringView _M0L1tS1386;
            int32_t _M0L6_2atmpS3416;
            struct _M0TPC16string10StringView _M0L6_2atmpS3415;
            int32_t _result_4391;
            int32_t _M0L6_2atmpS3418;
            moonbit_incref(_M0L1mS1385);
            #line 157 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _M0L1tS1386
            = _M0MPC16string6String4trim(_M0L1mS1385, _M0L4NoneS3417);
            moonbit_decref(_M0L1mS1385);
            moonbit_decref(_M0L4NoneS3417);
            _M0L6_2atmpS3416
            = Moonbit_array_length(_M0FPC15debug14compact__linesN7_2abindS1177);
            moonbit_incref(_M0FPC15debug14compact__linesN7_2abindS1177);
            _M0L6_2atmpS3415
            = (struct _M0TPC16string10StringView){
              .$0 = _M0FPC15debug14compact__linesN7_2abindS1177,
                .$1 = 0,
                .$2 = _M0L6_2atmpS3416
            };
            #line 158 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _result_4391
            = _M0IP016_24default__implPB2Eq10not__equalGRPC16string10StringViewE(_M0L1tS1386, _M0L6_2atmpS3415);
            moonbit_decref(_M0L6_2atmpS3415.$0);
            if (_result_4391) {
              #line 159 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              _M0MPC15array5Array4pushGRPC16string10StringViewE(_M0L5partsS1382, _M0L1tS1386);
            } else {
              moonbit_decref(_M0L1tS1386.$0);
            }
            _M0L6_2atmpS3418 = _M0L2__S1384 + 1;
            _M0L2__S1384 = _M0L6_2atmpS3418;
            continue;
          } else {
            moonbit_decref(_M0L9_2ax__bufS1380);
          }
          break;
        }
        _M0L6_2atmpS3435
        = Moonbit_array_length(_M0FPC15debug14compact__linesN7_2abindS1200);
        moonbit_incref(_M0FPC15debug14compact__linesN7_2abindS1200);
        _M0L6_2atmpS3434
        = (struct _M0TPC16string10StringView){
          .$0 = _M0FPC15debug14compact__linesN7_2abindS1200,
            .$1 = 0,
            .$2 = _M0L6_2atmpS3435
        };
        #line 162 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
        _M0L7joined0S1388
        = _M0MPC15array5Array4joinGRPC16string10StringViewE(_M0L5partsS1382, _M0L6_2atmpS3434);
        moonbit_decref(_M0L5partsS1382);
        moonbit_decref(_M0L6_2atmpS3434.$0);
        _M0L6_2atmpS3433
        = Moonbit_array_length(_M0FPC15debug14compact__linesN7_2abindS1194);
        moonbit_incref(_M0FPC15debug14compact__linesN7_2abindS1194);
        _M0L6_2atmpS3432
        = (struct _M0TPC16string10StringView){
          .$0 = _M0FPC15debug14compact__linesN7_2abindS1194,
            .$1 = 0,
            .$2 = _M0L6_2atmpS3433
        };
        #line 163 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
        _M0L7_2abindS1389
        = _M0MPC16string6String13strip__suffix(_M0L7joined0S1388, _M0L6_2atmpS3432);
        moonbit_decref(_M0L6_2atmpS3432.$0);
        switch (Moonbit_object_tag(_M0L7_2abindS1389)) {
          case 1: {
            struct _M0DTPC16option6OptionGRPC16string10StringViewE4Some* _M0L7_2aSomeS1391;
            struct _M0TPC16string10StringView _M0L8_2afieldS4059;
            int32_t _M0L6_2acntS4242;
            moonbit_decref(_M0L7joined0S1388);
            _M0L7_2aSomeS1391
            = (struct _M0DTPC16option6OptionGRPC16string10StringViewE4Some*)_M0L7_2abindS1389;
            _M0L8_2afieldS4059 = _M0L7_2aSomeS1391->$0;
            _M0L6_2acntS4242
            = Moonbit_rc_count(Moonbit_object_header(_M0L7_2aSomeS1391));
            if (_M0L6_2acntS4242 > 1) {
              int32_t _M0L11_2anew__cntS4243 = _M0L6_2acntS4242 - 1;
              Moonbit_set_rc_count(Moonbit_object_header(_M0L7_2aSomeS1391), _M0L11_2anew__cntS4243);
              moonbit_incref(_M0L8_2afieldS4059.$0);
            } else if (_M0L6_2acntS4242 == 1) {
              #line 163 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              moonbit_free(_M0L7_2aSomeS1391);
            }
            _M0L6joinedS1390 = _M0L8_2afieldS4059;
            break;
          }
          default: {
            int32_t _M0L6_2atmpS3431;
            moonbit_decref(_M0L7_2abindS1389);
            _M0L6_2atmpS3431 = Moonbit_array_length(_M0L7joined0S1388);
            _M0L6joinedS1390
            = (struct _M0TPC16string10StringView){
              .$0 = _M0L7joined0S1388, .$1 = 0, .$2 = _M0L6_2atmpS3431
            };
            break;
          }
        }
        #line 171 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
        _result_4392
        = _M0L8_2afirstS1378
          == (moonbit_string_t)moonbit_string_literal_27.data
          || Moonbit_array_length(_M0L8_2afirstS1378)
             == Moonbit_array_length((moonbit_string_t)moonbit_string_literal_27.data)
             && 0
                == memcmp(_M0L8_2afirstS1378, (moonbit_string_t)moonbit_string_literal_27.data, Moonbit_array_length(_M0L8_2afirstS1378) * 2);
        moonbit_decref(_M0L8_2afirstS1378);
        if (_result_4392) {
          int32_t _M0L6_2atmpS3428 =
            Moonbit_array_length(_M0FPC15debug14compact__linesN7_2abindS1187);
          struct _M0TPC16string10StringView _M0L6_2atmpS3427;
          void* _M0L7_2abindS1392;
          struct _M0TPC16string10StringView _M0L2s1S1393;
          int32_t _M0L6_2atmpS3426;
          struct _M0TPC16string10StringView _M0L6_2atmpS3425;
          void* _M0L7_2abindS1395;
          struct _M0TPC16string10StringView _M0L5innerS1396;
          int32_t _M0L6_2atmpS3421;
          struct _M0TPC16string10StringView _M0L6_2atmpS3420;
          int32_t _result_4393;
          moonbit_incref(_M0FPC15debug14compact__linesN7_2abindS1187);
          _M0L6_2atmpS3427
          = (struct _M0TPC16string10StringView){
            .$0 = _M0FPC15debug14compact__linesN7_2abindS1187,
              .$1 = 0,
              .$2 = _M0L6_2atmpS3428
          };
          #line 172 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _M0L7_2abindS1392
          = _M0MPC16string10StringView13strip__prefix(_M0L6joinedS1390, _M0L6_2atmpS3427);
          moonbit_decref(_M0L6_2atmpS3427.$0);
          switch (Moonbit_object_tag(_M0L7_2abindS1392)) {
            case 1: {
              struct _M0DTPC16option6OptionGRPC16string10StringViewE4Some* _M0L7_2aSomeS1394;
              struct _M0TPC16string10StringView _M0L8_2afieldS4058;
              int32_t _M0L6_2acntS4244;
              moonbit_decref(_M0L6joinedS1390.$0);
              _M0L7_2aSomeS1394
              = (struct _M0DTPC16option6OptionGRPC16string10StringViewE4Some*)_M0L7_2abindS1392;
              _M0L8_2afieldS4058 = _M0L7_2aSomeS1394->$0;
              _M0L6_2acntS4244
              = Moonbit_rc_count(Moonbit_object_header(_M0L7_2aSomeS1394));
              if (_M0L6_2acntS4244 > 1) {
                int32_t _M0L11_2anew__cntS4245 = _M0L6_2acntS4244 - 1;
                Moonbit_set_rc_count(Moonbit_object_header(_M0L7_2aSomeS1394), _M0L11_2anew__cntS4245);
                moonbit_incref(_M0L8_2afieldS4058.$0);
              } else if (_M0L6_2acntS4244 == 1) {
                #line 172 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                moonbit_free(_M0L7_2aSomeS1394);
              }
              _M0L2s1S1393 = _M0L8_2afieldS4058;
              break;
            }
            default: {
              moonbit_decref(_M0L7_2abindS1392);
              _M0L2s1S1393 = _M0L6joinedS1390;
              break;
            }
          }
          _M0L6_2atmpS3426
          = Moonbit_array_length(_M0FPC15debug14compact__linesN7_2abindS1181);
          moonbit_incref(_M0FPC15debug14compact__linesN7_2abindS1181);
          _M0L6_2atmpS3425
          = (struct _M0TPC16string10StringView){
            .$0 = _M0FPC15debug14compact__linesN7_2abindS1181,
              .$1 = 0,
              .$2 = _M0L6_2atmpS3426
          };
          #line 176 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _M0L7_2abindS1395
          = _M0MPC16string10StringView13strip__suffix(_M0L2s1S1393, _M0L6_2atmpS3425);
          moonbit_decref(_M0L6_2atmpS3425.$0);
          switch (Moonbit_object_tag(_M0L7_2abindS1395)) {
            case 1: {
              struct _M0DTPC16option6OptionGRPC16string10StringViewE4Some* _M0L7_2aSomeS1397;
              struct _M0TPC16string10StringView _M0L8_2afieldS4057;
              int32_t _M0L6_2acntS4246;
              moonbit_decref(_M0L2s1S1393.$0);
              _M0L7_2aSomeS1397
              = (struct _M0DTPC16option6OptionGRPC16string10StringViewE4Some*)_M0L7_2abindS1395;
              _M0L8_2afieldS4057 = _M0L7_2aSomeS1397->$0;
              _M0L6_2acntS4246
              = Moonbit_rc_count(Moonbit_object_header(_M0L7_2aSomeS1397));
              if (_M0L6_2acntS4246 > 1) {
                int32_t _M0L11_2anew__cntS4247 = _M0L6_2acntS4246 - 1;
                Moonbit_set_rc_count(Moonbit_object_header(_M0L7_2aSomeS1397), _M0L11_2anew__cntS4247);
                moonbit_incref(_M0L8_2afieldS4057.$0);
              } else if (_M0L6_2acntS4246 == 1) {
                #line 176 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                moonbit_free(_M0L7_2aSomeS1397);
              }
              _M0L5innerS1396 = _M0L8_2afieldS4057;
              break;
            }
            default: {
              moonbit_decref(_M0L7_2abindS1395);
              _M0L5innerS1396 = _M0L2s1S1393;
              break;
            }
          }
          _M0L6_2atmpS3421
          = Moonbit_array_length(_M0FPC15debug14compact__linesN7_2abindS1179);
          moonbit_incref(_M0FPC15debug14compact__linesN7_2abindS1179);
          _M0L6_2atmpS3420
          = (struct _M0TPC16string10StringView){
            .$0 = _M0FPC15debug14compact__linesN7_2abindS1179,
              .$1 = 0,
              .$2 = _M0L6_2atmpS3421
          };
          #line 180 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _result_4393
          = _M0IPC16string10StringViewPB2Eq5equal(_M0L5innerS1396, _M0L6_2atmpS3420);
          moonbit_decref(_M0L6_2atmpS3420.$0);
          if (_result_4393) {
            moonbit_string_t* _M0L6_2atmpS3422;
            struct _M0TPB5ArrayGsE* _block_4394;
            moonbit_decref(_M0L5innerS1396.$0);
            _M0L6_2atmpS3422
            = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
            _M0L6_2atmpS3422[0]
            = (moonbit_string_t)moonbit_string_literal_35.data;
            _block_4394
            = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
            Moonbit_object_header(_block_4394)->meta
            = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
            _block_4394->$0 = _M0L6_2atmpS3422;
            _block_4394->$1 = 1;
            return _block_4394;
          } else {
            struct _M0TPB13StringBuilder* _M0L18_2astring__builderS1398;
            moonbit_string_t _M0L6_2atmpS3424;
            moonbit_string_t* _M0L6_2atmpS3423;
            struct _M0TPB5ArrayGsE* _block_4395;
            #line 183 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _M0L18_2astring__builderS1398
            = _M0MPB13StringBuilder21StringBuilder_2einner(4);
            #line 183 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS1398, (moonbit_string_t)moonbit_string_literal_36.data);
            #line 183 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _M0MPB13StringBuilder13write__objectGRPC16string10StringViewE(_M0L18_2astring__builderS1398, _M0L5innerS1396);
            moonbit_decref(_M0L5innerS1396.$0);
            #line 183 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS1398, (moonbit_string_t)moonbit_string_literal_37.data);
            #line 183 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
            _M0L6_2atmpS3424
            = _M0MPB13StringBuilder10to__string(_M0L18_2astring__builderS1398);
            moonbit_decref(_M0L18_2astring__builderS1398);
            _M0L6_2atmpS3423
            = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
            _M0L6_2atmpS3423[0] = _M0L6_2atmpS3424;
            _block_4395
            = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
            Moonbit_object_header(_block_4395)->meta
            = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
            _block_4395->$0 = _M0L6_2atmpS3423;
            _block_4395->$1 = 1;
            return _block_4395;
          }
        } else {
          struct _M0TPB13StringBuilder* _M0L18_2astring__builderS1399;
          moonbit_string_t _M0L6_2atmpS3430;
          moonbit_string_t* _M0L6_2atmpS3429;
          struct _M0TPB5ArrayGsE* _block_4396;
          #line 186 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _M0L18_2astring__builderS1399
          = _M0MPB13StringBuilder21StringBuilder_2einner(2);
          #line 186 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS1399, (moonbit_string_t)moonbit_string_literal_25.data);
          #line 186 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _M0MPB13StringBuilder13write__objectGRPC16string10StringViewE(_M0L18_2astring__builderS1399, _M0L6joinedS1390);
          moonbit_decref(_M0L6joinedS1390.$0);
          #line 186 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS1399, (moonbit_string_t)moonbit_string_literal_26.data);
          #line 186 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _M0L6_2atmpS3430
          = _M0MPB13StringBuilder10to__string(_M0L18_2astring__builderS1399);
          moonbit_decref(_M0L18_2astring__builderS1399);
          _M0L6_2atmpS3429 = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
          _M0L6_2atmpS3429[0] = _M0L6_2atmpS3430;
          _block_4396
          = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
          Moonbit_object_header(_block_4396)->meta
          = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
          _block_4396->$0 = _M0L6_2atmpS3429;
          _block_4396->$1 = 1;
          return _block_4396;
        }
      } else {
        int32_t _M0L6_2atmpS3438 =
          Moonbit_array_length(_M0FPC15debug14compact__linesN7_2abindS1201);
        struct _M0TPC16string10StringView _M0L6_2atmpS3437;
        int32_t _result_4397;
        int32_t _if__result_4398;
        moonbit_incref(_M0FPC15debug14compact__linesN7_2abindS1201);
        _M0L6_2atmpS3437
        = (struct _M0TPC16string10StringView){
          .$0 = _M0FPC15debug14compact__linesN7_2abindS1201,
            .$1 = 0,
            .$2 = _M0L6_2atmpS3438
        };
        moonbit_incref(_M0L9_2ax__bufS1380);
        moonbit_incref(_M0L7_2alastS1379);
        moonbit_incref(_M0L8_2afirstS1378);
        #line 202 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
        _result_4397
        = _M0MPC16string6String11has__suffix(_M0L8_2afirstS1378, _M0L6_2atmpS3437);
        moonbit_decref(_M0L6_2atmpS3437.$0);
        if (_result_4397) {
          #line 202 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _if__result_4398
          = _M0L7_2alastS1379
            == (moonbit_string_t)moonbit_string_literal_23.data
            || Moonbit_array_length(_M0L7_2alastS1379)
               == Moonbit_array_length((moonbit_string_t)moonbit_string_literal_23.data)
               && 0
                  == memcmp(_M0L7_2alastS1379, (moonbit_string_t)moonbit_string_literal_23.data, Moonbit_array_length(_M0L7_2alastS1379) * 2);
        } else {
          _if__result_4398 = 0;
        }
        if (_if__result_4398) {
          struct _M0TPC16string10StringView* _M0L6_2atmpS3451 =
            (struct _M0TPC16string10StringView*)moonbit_empty_ref_valtype_array;
          struct _M0TPB5ArrayGRPC16string10StringViewE* _M0L5partsS1400 =
            (struct _M0TPB5ArrayGRPC16string10StringViewE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGRPC16string10StringViewE));
          int32_t _M0L7_2abindS1401;
          int32_t _M0L2__S1402;
          int32_t _M0L6_2atmpS3450;
          struct _M0TPC16string10StringView _M0L6_2atmpS3449;
          moonbit_string_t _M0L7joined0S1406;
          int32_t _M0L6_2atmpS3448;
          struct _M0TPC16string10StringView _M0L6_2atmpS3447;
          void* _M0L7_2abindS1407;
          struct _M0TPC16string10StringView _M0L6joinedS1408;
          struct _M0TPB13StringBuilder* _M0L18_2astring__builderS1410;
          moonbit_string_t _M0L6_2atmpS3445;
          moonbit_string_t* _M0L6_2atmpS3444;
          struct _M0TPB5ArrayGsE* _block_4401;
          Moonbit_object_header(_M0L5partsS1400)->meta
          = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 68, 0);
          _M0L5partsS1400->$0 = _M0L6_2atmpS3451;
          _M0L5partsS1400->$1 = 0;
          _M0L7_2abindS1401 = _M0L9_2ax__endS1381 - 1;
          _M0L2__S1402 = 0;
          while (1) {
            if (_M0L2__S1402 < _M0L7_2abindS1401) {
              int32_t _M0L6_2atmpS3443 = 1 + _M0L2__S1402;
              moonbit_string_t _M0L1mS1403 =
                (moonbit_string_t)_M0L9_2ax__bufS1380[_M0L6_2atmpS3443];
              void* _M0L4NoneS3441 =
                (struct moonbit_object*)&moonbit_constant_constructor_0 + 1;
              struct _M0TPC16string10StringView _M0L1tS1404;
              int32_t _M0L6_2atmpS3440;
              struct _M0TPC16string10StringView _M0L6_2atmpS3439;
              int32_t _result_4400;
              int32_t _M0L6_2atmpS3442;
              moonbit_incref(_M0L1mS1403);
              #line 205 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              _M0L1tS1404
              = _M0MPC16string6String4trim(_M0L1mS1403, _M0L4NoneS3441);
              moonbit_decref(_M0L1mS1403);
              moonbit_decref(_M0L4NoneS3441);
              _M0L6_2atmpS3440
              = Moonbit_array_length(_M0FPC15debug14compact__linesN7_2abindS1205);
              moonbit_incref(_M0FPC15debug14compact__linesN7_2abindS1205);
              _M0L6_2atmpS3439
              = (struct _M0TPC16string10StringView){
                .$0 = _M0FPC15debug14compact__linesN7_2abindS1205,
                  .$1 = 0,
                  .$2 = _M0L6_2atmpS3440
              };
              #line 206 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              _result_4400
              = _M0IP016_24default__implPB2Eq10not__equalGRPC16string10StringViewE(_M0L1tS1404, _M0L6_2atmpS3439);
              moonbit_decref(_M0L6_2atmpS3439.$0);
              if (_result_4400) {
                #line 207 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                _M0MPC15array5Array4pushGRPC16string10StringViewE(_M0L5partsS1400, _M0L1tS1404);
              } else {
                moonbit_decref(_M0L1tS1404.$0);
              }
              _M0L6_2atmpS3442 = _M0L2__S1402 + 1;
              _M0L2__S1402 = _M0L6_2atmpS3442;
              continue;
            } else {
              moonbit_decref(_M0L9_2ax__bufS1380);
            }
            break;
          }
          _M0L6_2atmpS3450
          = Moonbit_array_length(_M0FPC15debug14compact__linesN7_2abindS1214);
          moonbit_incref(_M0FPC15debug14compact__linesN7_2abindS1214);
          _M0L6_2atmpS3449
          = (struct _M0TPC16string10StringView){
            .$0 = _M0FPC15debug14compact__linesN7_2abindS1214,
              .$1 = 0,
              .$2 = _M0L6_2atmpS3450
          };
          #line 210 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _M0L7joined0S1406
          = _M0MPC15array5Array4joinGRPC16string10StringViewE(_M0L5partsS1400, _M0L6_2atmpS3449);
          moonbit_decref(_M0L5partsS1400);
          moonbit_decref(_M0L6_2atmpS3449.$0);
          _M0L6_2atmpS3448
          = Moonbit_array_length(_M0FPC15debug14compact__linesN7_2abindS1208);
          moonbit_incref(_M0FPC15debug14compact__linesN7_2abindS1208);
          _M0L6_2atmpS3447
          = (struct _M0TPC16string10StringView){
            .$0 = _M0FPC15debug14compact__linesN7_2abindS1208,
              .$1 = 0,
              .$2 = _M0L6_2atmpS3448
          };
          #line 211 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _M0L7_2abindS1407
          = _M0MPC16string6String13strip__suffix(_M0L7joined0S1406, _M0L6_2atmpS3447);
          moonbit_decref(_M0L6_2atmpS3447.$0);
          switch (Moonbit_object_tag(_M0L7_2abindS1407)) {
            case 1: {
              struct _M0DTPC16option6OptionGRPC16string10StringViewE4Some* _M0L7_2aSomeS1409;
              struct _M0TPC16string10StringView _M0L8_2afieldS4061;
              int32_t _M0L6_2acntS4248;
              moonbit_decref(_M0L7joined0S1406);
              _M0L7_2aSomeS1409
              = (struct _M0DTPC16option6OptionGRPC16string10StringViewE4Some*)_M0L7_2abindS1407;
              _M0L8_2afieldS4061 = _M0L7_2aSomeS1409->$0;
              _M0L6_2acntS4248
              = Moonbit_rc_count(Moonbit_object_header(_M0L7_2aSomeS1409));
              if (_M0L6_2acntS4248 > 1) {
                int32_t _M0L11_2anew__cntS4249 = _M0L6_2acntS4248 - 1;
                Moonbit_set_rc_count(Moonbit_object_header(_M0L7_2aSomeS1409), _M0L11_2anew__cntS4249);
                moonbit_incref(_M0L8_2afieldS4061.$0);
              } else if (_M0L6_2acntS4248 == 1) {
                #line 211 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
                moonbit_free(_M0L7_2aSomeS1409);
              }
              _M0L6joinedS1408 = _M0L8_2afieldS4061;
              break;
            }
            default: {
              int32_t _M0L6_2atmpS3446;
              moonbit_decref(_M0L7_2abindS1407);
              _M0L6_2atmpS3446 = Moonbit_array_length(_M0L7joined0S1406);
              _M0L6joinedS1408
              = (struct _M0TPC16string10StringView){
                .$0 = _M0L7joined0S1406, .$1 = 0, .$2 = _M0L6_2atmpS3446
              };
              break;
            }
          }
          #line 215 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _M0L18_2astring__builderS1410
          = _M0MPB13StringBuilder21StringBuilder_2einner(0);
          #line 215 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _M0MPB13StringBuilder13write__objectGsE(_M0L18_2astring__builderS1410, _M0L8_2afirstS1378);
          moonbit_decref(_M0L8_2afirstS1378);
          #line 215 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _M0MPB13StringBuilder13write__objectGRPC16string10StringViewE(_M0L18_2astring__builderS1410, _M0L6joinedS1408);
          moonbit_decref(_M0L6joinedS1408.$0);
          #line 215 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _M0MPB13StringBuilder13write__objectGsE(_M0L18_2astring__builderS1410, _M0L7_2alastS1379);
          moonbit_decref(_M0L7_2alastS1379);
          #line 215 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _M0L6_2atmpS3445
          = _M0MPB13StringBuilder10to__string(_M0L18_2astring__builderS1410);
          moonbit_decref(_M0L18_2astring__builderS1410);
          _M0L6_2atmpS3444 = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
          _M0L6_2atmpS3444[0] = _M0L6_2atmpS3445;
          _block_4401
          = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
          Moonbit_object_header(_block_4401)->meta
          = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
          _block_4401->$0 = _M0L6_2atmpS3444;
          _block_4401->$1 = 1;
          return _block_4401;
        } else {
          int32_t _M0L6_2atmpS3464 = Moonbit_array_length(_M0L8_2afirstS1378);
          struct _M0TPC16string10StringView _M0L6_2atmpS3463 =
            (struct _M0TPC16string10StringView){.$0 = _M0L8_2afirstS1378,
                                                  .$1 = 0,
                                                  .$2 = _M0L6_2atmpS3464};
          struct _M0TPC16string10StringView* _M0L6_2atmpS3462 =
            (struct _M0TPC16string10StringView*)moonbit_make_ref_valtype_array_raw(1, sizeof(struct _M0TPC16string10StringView), Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 71, 0));
          struct _M0TPB5ArrayGRPC16string10StringViewE* _M0L5partsS1411;
          int32_t _M0L7_2abindS1412;
          int32_t _M0L2__S1413;
          void* _M0L4NoneS3457;
          struct _M0TPC16string10StringView _M0L6_2atmpS3456;
          int32_t _M0L6_2atmpS3461;
          struct _M0TPC16string10StringView _M0L6_2atmpS3460;
          moonbit_string_t _M0L6_2atmpS3459;
          moonbit_string_t* _M0L6_2atmpS3458;
          struct _M0TPB5ArrayGsE* _block_4403;
          _M0L6_2atmpS3462[0] = _M0L6_2atmpS3463;
          _M0L5partsS1411
          = (struct _M0TPB5ArrayGRPC16string10StringViewE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGRPC16string10StringViewE));
          Moonbit_object_header(_M0L5partsS1411)->meta
          = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 68, 0);
          _M0L5partsS1411->$0 = _M0L6_2atmpS3462;
          _M0L5partsS1411->$1 = 1;
          _M0L7_2abindS1412 = _M0L9_2ax__endS1381 - 1;
          _M0L2__S1413 = 0;
          while (1) {
            if (_M0L2__S1413 < _M0L7_2abindS1412) {
              int32_t _M0L6_2atmpS3455 = 1 + _M0L2__S1413;
              moonbit_string_t _M0L1mS1414 =
                (moonbit_string_t)_M0L9_2ax__bufS1380[_M0L6_2atmpS3455];
              void* _M0L4NoneS3453 =
                (struct moonbit_object*)&moonbit_constant_constructor_0 + 1;
              struct _M0TPC16string10StringView _M0L6_2atmpS3452;
              int32_t _M0L6_2atmpS3454;
              moonbit_incref(_M0L1mS1414);
              #line 219 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              _M0L6_2atmpS3452
              = _M0MPC16string6String4trim(_M0L1mS1414, _M0L4NoneS3453);
              moonbit_decref(_M0L1mS1414);
              moonbit_decref(_M0L4NoneS3453);
              #line 219 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
              _M0MPC15array5Array4pushGRPC16string10StringViewE(_M0L5partsS1411, _M0L6_2atmpS3452);
              _M0L6_2atmpS3454 = _M0L2__S1413 + 1;
              _M0L2__S1413 = _M0L6_2atmpS3454;
              continue;
            } else {
              moonbit_decref(_M0L9_2ax__bufS1380);
            }
            break;
          }
          _M0L4NoneS3457
          = (struct moonbit_object*)&moonbit_constant_constructor_0 + 1;
          #line 221 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _M0L6_2atmpS3456
          = _M0MPC16string6String4trim(_M0L7_2alastS1379, _M0L4NoneS3457);
          moonbit_decref(_M0L7_2alastS1379);
          moonbit_decref(_M0L4NoneS3457);
          #line 221 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _M0MPC15array5Array4pushGRPC16string10StringViewE(_M0L5partsS1411, _M0L6_2atmpS3456);
          _M0L6_2atmpS3461
          = Moonbit_array_length(_M0FPC15debug14compact__linesN7_2abindS1219);
          moonbit_incref(_M0FPC15debug14compact__linesN7_2abindS1219);
          _M0L6_2atmpS3460
          = (struct _M0TPC16string10StringView){
            .$0 = _M0FPC15debug14compact__linesN7_2abindS1219,
              .$1 = 0,
              .$2 = _M0L6_2atmpS3461
          };
          #line 222 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
          _M0L6_2atmpS3459
          = _M0MPC15array5Array4joinGRPC16string10StringViewE(_M0L5partsS1411, _M0L6_2atmpS3460);
          moonbit_decref(_M0L5partsS1411);
          moonbit_decref(_M0L6_2atmpS3460.$0);
          _M0L6_2atmpS3458 = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
          _M0L6_2atmpS3458[0] = _M0L6_2atmpS3459;
          _block_4403
          = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
          Moonbit_object_header(_block_4403)->meta
          = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
          _block_4403->$0 = _M0L6_2atmpS3458;
          _block_4403->$1 = 1;
          return _block_4403;
        }
      }
    }
  }
}

struct _M0TPC15debug7Content* _M0FPC15debug10no__parens(
  struct _M0TPC15debug13ContentParens* _M0L1rS1375
) {
  int32_t _M0L4sizeS3408;
  struct _M0TPB5ArrayGsE* _M0L5linesS3409;
  struct _M0TPC15debug7Content* _block_4404;
  #line 125 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _M0L4sizeS3408 = _M0L1rS1375->$0;
  _M0L5linesS3409 = _M0L1rS1375->$1;
  moonbit_incref(_M0L5linesS3409);
  _block_4404
  = (struct _M0TPC15debug7Content*)moonbit_malloc(sizeof(struct _M0TPC15debug7Content));
  Moonbit_object_header(_block_4404)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 56, 0);
  _block_4404->$0 = _M0L4sizeS3408;
  _block_4404->$1 = _M0L5linesS3409;
  _block_4404->$2 = 0;
  return _block_4404;
}

struct _M0TPC15debug7Content* _M0FPC15debug6parens(
  struct _M0TPC15debug13ContentParens* _M0L1rS1374
) {
  int32_t _M0L4sizeS3406;
  struct _M0TPB5ArrayGsE* _M0L5linesS3407;
  struct _M0TPC15debug7Content* _block_4405;
  #line 119 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _M0L4sizeS3406 = _M0L1rS1374->$0;
  _M0L5linesS3407 = _M0L1rS1374->$1;
  moonbit_incref(_M0L5linesS3407);
  _block_4405
  = (struct _M0TPC15debug7Content*)moonbit_malloc(sizeof(struct _M0TPC15debug7Content));
  Moonbit_object_header(_block_4405)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 56, 0);
  _block_4405->$0 = _M0L4sizeS3406;
  _block_4405->$1 = _M0L5linesS3407;
  _block_4405->$2 = 1;
  return _block_4405;
}

struct _M0TPC15debug13ContentParens* _M0MPC15debug7Content8no__wrap(
  struct _M0TPC15debug7Content* _M0L1cS1373
) {
  int32_t _M0L4sizeS3404;
  struct _M0TPB5ArrayGsE* _M0L5linesS3405;
  struct _M0TPC15debug13ContentParens* _block_4406;
  #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _M0L4sizeS3404 = _M0L1cS1373->$0;
  _M0L5linesS3405 = _M0L1cS1373->$1;
  moonbit_incref(_M0L5linesS3405);
  _block_4406
  = (struct _M0TPC15debug13ContentParens*)moonbit_malloc(sizeof(struct _M0TPC15debug13ContentParens));
  Moonbit_object_header(_block_4406)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 59, 0);
  _block_4406->$0 = _M0L4sizeS3404;
  _block_4406->$1 = _M0L5linesS3405;
  return _block_4406;
}

struct _M0TPC15debug13ContentParens* _M0FPC15debug8surround(
  moonbit_string_t _M0L5startS1371,
  moonbit_string_t _M0L6finishS1372,
  struct _M0TPC15debug13ContentParens* _M0L1rS1369
) {
  struct _M0R62_24moonbitlang_2fcore_2fdebug_2esurround_2eanon__u3401__l108__* _closure_4407;
  struct _M0TWRPB5ArrayGsEERPB5ArrayGsE* _M0L6_2atmpS3400;
  struct _M0TPC15debug13ContentParens* _result_4408;
  #line 103 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  moonbit_incref(_M0L6finishS1372);
  moonbit_incref(_M0L5startS1371);
  _closure_4407
  = (struct _M0R62_24moonbitlang_2fcore_2fdebug_2esurround_2eanon__u3401__l108__*)moonbit_malloc(sizeof(struct _M0R62_24moonbitlang_2fcore_2fdebug_2esurround_2eanon__u3401__l108__));
  Moonbit_object_header(_closure_4407)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 74, 0);
  _closure_4407->code = &_M0FPC15debug8surroundC3401l108;
  _closure_4407->$0 = _M0L6finishS1372;
  _closure_4407->$1 = _M0L5startS1371;
  _M0L6_2atmpS3400 = (struct _M0TWRPB5ArrayGsEERPB5ArrayGsE*)_closure_4407;
  #line 108 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _result_4408 = _M0FPC15debug11with__lines(_M0L1rS1369, _M0L6_2atmpS3400);
  moonbit_decref(_M0L6_2atmpS3400);
  return _result_4408;
}

struct _M0TPB5ArrayGsE* _M0FPC15debug8surroundC3401l108(
  struct _M0TWRPB5ArrayGsEERPB5ArrayGsE* _M0L6_2aenvS3402,
  struct _M0TPB5ArrayGsE* _M0L5linesS1370
) {
  struct _M0R62_24moonbitlang_2fcore_2fdebug_2esurround_2eanon__u3401__l108__* _M0L14_2acasted__envS3403;
  moonbit_string_t _M0L5startS1371;
  moonbit_string_t _M0L6finishS1372;
  #line 108 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _M0L14_2acasted__envS3403
  = (struct _M0R62_24moonbitlang_2fcore_2fdebug_2esurround_2eanon__u3401__l108__*)_M0L6_2aenvS3402;
  _M0L5startS1371 = _M0L14_2acasted__envS3403->$1;
  _M0L6finishS1372 = _M0L14_2acasted__envS3403->$0;
  #line 108 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  return _M0FPC15debug15surround__lines(_M0L5startS1371, _M0L6finishS1372, _M0L5linesS1370);
}

struct _M0TPB5ArrayGsE* _M0FPC15debug15surround__lines(
  moonbit_string_t _M0L5startS1362,
  moonbit_string_t _M0L6finishS1363,
  struct _M0TPB5ArrayGsE* _M0L5linesS1361
) {
  int32_t _M0L3lenS3381;
  #line 89 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _M0L3lenS3381 = _M0L5linesS1361->$1;
  if (_M0L3lenS3381 == 0) {
    moonbit_string_t _M0L6_2atmpS3383;
    moonbit_string_t* _M0L6_2atmpS3382;
    struct _M0TPB5ArrayGsE* _block_4409;
    #line 95 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
    _M0L6_2atmpS3383 = moonbit_add_string(_M0L5startS1362, _M0L6finishS1363);
    _M0L6_2atmpS3382 = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
    _M0L6_2atmpS3382[0] = _M0L6_2atmpS3383;
    _block_4409
    = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
    Moonbit_object_header(_block_4409)->meta
    = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
    _block_4409->$0 = _M0L6_2atmpS3382;
    _block_4409->$1 = 1;
    return _block_4409;
  } else {
    int32_t _M0L3lenS3384 = _M0L5linesS1361->$1;
    if (_M0L3lenS3384 == 1) {
      moonbit_string_t* _M0L3bufS3388 = _M0L5linesS1361->$0;
      moonbit_string_t _M0L7_2aitemS1364 = (moonbit_string_t)_M0L3bufS3388[0];
      moonbit_string_t _M0L6_2atmpS3387;
      moonbit_string_t _M0L6_2atmpS3386;
      moonbit_string_t* _M0L6_2atmpS3385;
      struct _M0TPB5ArrayGsE* _block_4410;
      #line 96 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
      _M0L6_2atmpS3387
      = moonbit_add_string(_M0L5startS1362, _M0L7_2aitemS1364);
      #line 96 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
      _M0L6_2atmpS3386
      = moonbit_add_string(_M0L6_2atmpS3387, _M0L6finishS1363);
      moonbit_decref(_M0L6_2atmpS3387);
      _M0L6_2atmpS3385 = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
      _M0L6_2atmpS3385[0] = _M0L6_2atmpS3386;
      _block_4410
      = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
      Moonbit_object_header(_block_4410)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
      _block_4410->$0 = _M0L6_2atmpS3385;
      _block_4410->$1 = 1;
      return _block_4410;
    } else {
      moonbit_string_t* _M0L3bufS3399 = _M0L5linesS1361->$0;
      moonbit_string_t _M0L8_2afirstS1365 =
        (moonbit_string_t)_M0L3bufS3399[0];
      moonbit_string_t* _M0L3bufS3396 = _M0L5linesS1361->$0;
      int32_t _M0L3lenS3398 = _M0L5linesS1361->$1;
      int32_t _M0L6_2atmpS3397 = _M0L3lenS3398 - 1;
      moonbit_string_t _M0L7_2alastS1366 =
        (moonbit_string_t)_M0L3bufS3396[_M0L6_2atmpS3397];
      moonbit_string_t* _M0L3bufS3393 = _M0L5linesS1361->$0;
      int32_t _M0L3lenS3395 = _M0L5linesS1361->$1;
      int32_t _M0L6_2atmpS3394 = _M0L3lenS3395 - 1;
      struct _M0TPB9ArrayViewGsE _M0L4_2axS1367;
      moonbit_string_t* _M0L6_2atmpS3392;
      struct _M0TPB5ArrayGsE* _M0L7_2aselfS1368;
      moonbit_string_t _M0L6_2atmpS3389;
      struct _M0TPB4IterGsE* _M0L6_2atmpS3390;
      moonbit_string_t _M0L6_2atmpS3391;
      moonbit_incref(_M0L3bufS3393);
      _M0L4_2axS1367
      = (struct _M0TPB9ArrayViewGsE){
        .$0 = _M0L3bufS3393, .$1 = 1, .$2 = _M0L6_2atmpS3394
      };
      _M0L6_2atmpS3392 = (moonbit_string_t*)moonbit_empty_ref_array;
      _M0L7_2aselfS1368
      = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
      Moonbit_object_header(_M0L7_2aselfS1368)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
      _M0L7_2aselfS1368->$0 = _M0L6_2atmpS3392;
      _M0L7_2aselfS1368->$1 = 0;
      #line 97 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
      _M0L6_2atmpS3389
      = moonbit_add_string(_M0L5startS1362, _M0L8_2afirstS1365);
      moonbit_incref(_M0L7_2alastS1366);
      #line 97 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
      _M0MPC15array5Array4pushGsE(_M0L7_2aselfS1368, _M0L6_2atmpS3389);
      #line 97 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
      _M0L6_2atmpS3390 = _M0MPC15array9ArrayView4iterGsE(_M0L4_2axS1367);
      moonbit_decref(_M0L4_2axS1367.$0);
      #line 97 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
      _M0MPC15array5Array10push__iterGsE(_M0L7_2aselfS1368, _M0L6_2atmpS3390);
      moonbit_decref(_M0L6_2atmpS3390);
      #line 97 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
      _M0L6_2atmpS3391
      = moonbit_add_string(_M0L7_2alastS1366, _M0L6finishS1363);
      moonbit_decref(_M0L7_2alastS1366);
      #line 97 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
      _M0MPC15array5Array4pushGsE(_M0L7_2aselfS1368, _M0L6_2atmpS3391);
      return _M0L7_2aselfS1368;
    }
  }
}

struct _M0TPC15debug7Content* _M0MPC15debug7Content20with__lines__content(
  struct _M0TPC15debug7Content* _M0L1rS1359,
  struct _M0TWRPB5ArrayGsEERPB5ArrayGsE* _M0L1fS1360
) {
  int32_t _M0L4sizeS3377;
  struct _M0TPB5ArrayGsE* _M0L5linesS3380;
  struct _M0TPB5ArrayGsE* _M0L6_2atmpS3378;
  int32_t _M0L13needs__parensS3379;
  struct _M0TPC15debug7Content* _block_4411;
  #line 80 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _M0L4sizeS3377 = _M0L1rS1359->$0;
  _M0L5linesS3380 = _M0L1rS1359->$1;
  moonbit_incref(_M0L5linesS3380);
  #line 84 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _M0L6_2atmpS3378 = _M0L1fS1360->code(_M0L1fS1360, _M0L5linesS3380);
  moonbit_decref(_M0L5linesS3380);
  _M0L13needs__parensS3379 = _M0L1rS1359->$2;
  _block_4411
  = (struct _M0TPC15debug7Content*)moonbit_malloc(sizeof(struct _M0TPC15debug7Content));
  Moonbit_object_header(_block_4411)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 56, 0);
  _block_4411->$0 = _M0L4sizeS3377;
  _block_4411->$1 = _M0L6_2atmpS3378;
  _block_4411->$2 = _M0L13needs__parensS3379;
  return _block_4411;
}

struct _M0TPC15debug13ContentParens* _M0FPC15debug11with__lines(
  struct _M0TPC15debug13ContentParens* _M0L1rS1357,
  struct _M0TWRPB5ArrayGsEERPB5ArrayGsE* _M0L1fS1358
) {
  int32_t _M0L4sizeS3374;
  struct _M0TPB5ArrayGsE* _M0L5linesS3376;
  struct _M0TPB5ArrayGsE* _M0L6_2atmpS3375;
  struct _M0TPC15debug13ContentParens* _block_4412;
  #line 71 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _M0L4sizeS3374 = _M0L1rS1357->$0;
  _M0L5linesS3376 = _M0L1rS1357->$1;
  moonbit_incref(_M0L5linesS3376);
  #line 75 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _M0L6_2atmpS3375 = _M0L1fS1358->code(_M0L1fS1358, _M0L5linesS3376);
  moonbit_decref(_M0L5linesS3376);
  _block_4412
  = (struct _M0TPC15debug13ContentParens*)moonbit_malloc(sizeof(struct _M0TPC15debug13ContentParens));
  Moonbit_object_header(_block_4412)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 59, 0);
  _block_4412->$0 = _M0L4sizeS3374;
  _block_4412->$1 = _M0L6_2atmpS3375;
  return _block_4412;
}

struct _M0TPC15debug7Content* _M0FPC15debug12leaf_2einner(
  moonbit_string_t _M0L1xS1355,
  int32_t _M0L13needs__parensS1356
) {
  moonbit_string_t* _M0L6_2atmpS3373;
  struct _M0TPB5ArrayGsE* _M0L6_2atmpS3372;
  struct _M0TPC15debug7Content* _block_4413;
  #line 62 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  moonbit_incref(_M0L1xS1355);
  _M0L6_2atmpS3373 = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
  _M0L6_2atmpS3373[0] = _M0L1xS1355;
  _M0L6_2atmpS3372
  = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
  Moonbit_object_header(_M0L6_2atmpS3372)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
  _M0L6_2atmpS3372->$0 = _M0L6_2atmpS3373;
  _M0L6_2atmpS3372->$1 = 1;
  _block_4413
  = (struct _M0TPC15debug7Content*)moonbit_malloc(sizeof(struct _M0TPC15debug7Content));
  Moonbit_object_header(_block_4413)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 56, 0);
  _block_4413->$0 = 1;
  _block_4413->$1 = _M0L6_2atmpS3372;
  _block_4413->$2 = _M0L13needs__parensS1356;
  return _block_4413;
}

struct _M0TPC15debug13ContentParens* _M0FPC15debug15content__parens(
  int32_t _M0L4sizeS1353,
  struct _M0TPB5ArrayGsE* _M0L5linesS1354
) {
  struct _M0TPC15debug13ContentParens* _block_4414;
  #line 56 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  moonbit_incref(_M0L5linesS1354);
  _block_4414
  = (struct _M0TPC15debug13ContentParens*)moonbit_malloc(sizeof(struct _M0TPC15debug13ContentParens));
  Moonbit_object_header(_block_4414)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 59, 0);
  _block_4414->$0 = _M0L4sizeS1353;
  _block_4414->$1 = _M0L5linesS1354;
  return _block_4414;
}

struct _M0TPC15debug13ContentParens* _M0FPC15debug8verbatim(
  moonbit_string_t _M0L1xS1352
) {
  moonbit_string_t* _M0L6_2atmpS3371;
  struct _M0TPB5ArrayGsE* _M0L6_2atmpS3370;
  struct _M0TPC15debug13ContentParens* _block_4415;
  #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  moonbit_incref(_M0L1xS1352);
  _M0L6_2atmpS3371 = (moonbit_string_t*)moonbit_make_ref_array_raw(1);
  _M0L6_2atmpS3371[0] = _M0L1xS1352;
  _M0L6_2atmpS3370
  = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
  Moonbit_object_header(_M0L6_2atmpS3370)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
  _M0L6_2atmpS3370->$0 = _M0L6_2atmpS3371;
  _M0L6_2atmpS3370->$1 = 1;
  _block_4415
  = (struct _M0TPC15debug13ContentParens*)moonbit_malloc(sizeof(struct _M0TPC15debug13ContentParens));
  Moonbit_object_header(_block_4415)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 59, 0);
  _block_4415->$0 = 1;
  _block_4415->$1 = _M0L6_2atmpS3370;
  return _block_4415;
}

struct _M0TPC15debug7Content* _M0FPC15debug14empty__content() {
  moonbit_string_t* _M0L6_2atmpS3369;
  struct _M0TPB5ArrayGsE* _M0L6_2atmpS3368;
  struct _M0TPC15debug7Content* _block_4416;
  #line 44 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _M0L6_2atmpS3369 = (moonbit_string_t*)moonbit_empty_ref_array;
  _M0L6_2atmpS3368
  = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
  Moonbit_object_header(_M0L6_2atmpS3368)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
  _M0L6_2atmpS3368->$0 = _M0L6_2atmpS3369;
  _M0L6_2atmpS3368->$1 = 0;
  _block_4416
  = (struct _M0TPC15debug7Content*)moonbit_malloc(sizeof(struct _M0TPC15debug7Content));
  Moonbit_object_header(_block_4416)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 56, 0);
  _block_4416->$0 = 0;
  _block_4416->$1 = _M0L6_2atmpS3368;
  _block_4416->$2 = 0;
  return _block_4416;
}

struct _M0TPC15debug13ContentParens* _M0IPC15debug13ContentParensPB3Add3add(
  struct _M0TPC15debug13ContentParens* _M0L4selfS1350,
  struct _M0TPC15debug13ContentParens* _M0L5otherS1351
) {
  int32_t _M0L4sizeS3366;
  int32_t _M0L4sizeS3367;
  int32_t _M0L6_2atmpS3362;
  struct _M0TPB5ArrayGsE* _M0L5linesS3364;
  struct _M0TPB5ArrayGsE* _M0L5linesS3365;
  struct _M0TPB5ArrayGsE* _M0L6_2atmpS3363;
  struct _M0TPC15debug13ContentParens* _block_4417;
  #line 38 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _M0L4sizeS3366 = _M0L4selfS1350->$0;
  _M0L4sizeS3367 = _M0L5otherS1351->$0;
  _M0L6_2atmpS3362 = _M0L4sizeS3366 + _M0L4sizeS3367;
  _M0L5linesS3364 = _M0L4selfS1350->$1;
  _M0L5linesS3365 = _M0L5otherS1351->$1;
  moonbit_incref(_M0L5linesS3365);
  moonbit_incref(_M0L5linesS3364);
  #line 39 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\printer.mbt"
  _M0L6_2atmpS3363
  = _M0IPC15array5ArrayPB3Add3addGsE(_M0L5linesS3364, _M0L5linesS3365);
  moonbit_decref(_M0L5linesS3364);
  moonbit_decref(_M0L5linesS3365);
  _block_4417
  = (struct _M0TPC15debug13ContentParens*)moonbit_malloc(sizeof(struct _M0TPC15debug13ContentParens));
  Moonbit_object_header(_block_4417)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 59, 0);
  _block_4417->$0 = _M0L6_2atmpS3362;
  _block_4417->$1 = _M0L6_2atmpS3363;
  return _block_4417;
}

void* _M0MPC15debug4Repr7shallow(void* _M0L4selfS1341) {
  #line 317 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\repr.mbt"
  switch (Moonbit_object_tag(_M0L4selfS1341)) {
    case 0: {
      goto join_1340;
      break;
    }
    
    case 1: {
      goto join_1340;
      break;
    }
    
    case 2: {
      goto join_1340;
      break;
    }
    
    case 3: {
      goto join_1340;
      break;
    }
    
    case 4: {
      goto join_1340;
      break;
    }
    
    case 5: {
      goto join_1340;
      break;
    }
    
    case 6: {
      goto join_1340;
      break;
    }
    
    case 15: {
      goto join_1340;
      break;
    }
    
    case 17: {
      goto join_1340;
      break;
    }
    
    case 7: {
      void** _M0L6_2atmpS3361 = (void**)moonbit_empty_ref_array;
      struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L6_2atmpS3360 =
        (struct _M0TPB5ArrayGRPC15debug4ReprE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGRPC15debug4ReprE));
      void* _block_4419;
      Moonbit_object_header(_M0L6_2atmpS3360)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 78, 0);
      set_cycle_capable(_M0L6_2atmpS3360);
      _M0L6_2atmpS3360->$0 = _M0L6_2atmpS3361;
      _M0L6_2atmpS3360->$1 = 0;
      _block_4419
      = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug4Repr5Tuple));
      Moonbit_object_header(_block_4419)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 81, 7);
      set_cycle_capable(_block_4419);
      ((struct _M0DTPC15debug4Repr5Tuple*)_block_4419)->$0 = _M0L6_2atmpS3360;
      return _block_4419;
      break;
    }
    
    case 8: {
      void** _M0L6_2atmpS3359 = (void**)moonbit_empty_ref_array;
      struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L6_2atmpS3358 =
        (struct _M0TPB5ArrayGRPC15debug4ReprE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGRPC15debug4ReprE));
      void* _block_4420;
      Moonbit_object_header(_M0L6_2atmpS3358)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 78, 0);
      set_cycle_capable(_M0L6_2atmpS3358);
      _M0L6_2atmpS3358->$0 = _M0L6_2atmpS3359;
      _M0L6_2atmpS3358->$1 = 0;
      _block_4420
      = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug4Repr5Array));
      Moonbit_object_header(_block_4420)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 84, 8);
      set_cycle_capable(_block_4420);
      ((struct _M0DTPC15debug4Repr5Array*)_block_4420)->$0 = _M0L6_2atmpS3358;
      return _block_4420;
      break;
    }
    
    case 9: {
      void** _M0L6_2atmpS3357 = (void**)moonbit_empty_ref_array;
      struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L6_2atmpS3356 =
        (struct _M0TPB5ArrayGRPC15debug4ReprE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGRPC15debug4ReprE));
      void* _block_4421;
      Moonbit_object_header(_M0L6_2atmpS3356)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 78, 0);
      set_cycle_capable(_M0L6_2atmpS3356);
      _M0L6_2atmpS3356->$0 = _M0L6_2atmpS3357;
      _M0L6_2atmpS3356->$1 = 0;
      _block_4421
      = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug4Repr6Record));
      Moonbit_object_header(_block_4421)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 87, 9);
      set_cycle_capable(_block_4421);
      ((struct _M0DTPC15debug4Repr6Record*)_block_4421)->$0
      = _M0L6_2atmpS3356;
      return _block_4421;
      break;
    }
    
    case 10: {
      struct _M0DTPC15debug4Repr4Enum* _M0L7_2aEnumS1342 =
        (struct _M0DTPC15debug4Repr4Enum*)_M0L4selfS1341;
      moonbit_string_t _M0L7_2anameS1343 = _M0L7_2aEnumS1342->$0;
      void** _M0L6_2atmpS3355 = (void**)moonbit_empty_ref_array;
      struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L6_2atmpS3354 =
        (struct _M0TPB5ArrayGRPC15debug4ReprE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGRPC15debug4ReprE));
      void* _block_4422;
      Moonbit_object_header(_M0L6_2atmpS3354)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 78, 0);
      set_cycle_capable(_M0L6_2atmpS3354);
      _M0L6_2atmpS3354->$0 = _M0L6_2atmpS3355;
      _M0L6_2atmpS3354->$1 = 0;
      moonbit_incref(_M0L7_2anameS1343);
      _block_4422
      = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug4Repr4Enum));
      Moonbit_object_header(_block_4422)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 90, 10);
      set_cycle_capable(_block_4422);
      ((struct _M0DTPC15debug4Repr4Enum*)_block_4422)->$0 = _M0L7_2anameS1343;
      ((struct _M0DTPC15debug4Repr4Enum*)_block_4422)->$1 = _M0L6_2atmpS3354;
      return _block_4422;
      break;
    }
    
    case 14: {
      struct _M0DTPC15debug4Repr6Opaque* _M0L9_2aOpaqueS1344 =
        (struct _M0DTPC15debug4Repr6Opaque*)_M0L4selfS1341;
      moonbit_string_t _M0L7_2anameS1345 = _M0L9_2aOpaqueS1344->$0;
      void* _M0L7OmittedS3353 =
        (struct moonbit_object*)&moonbit_constant_constructor_17 + 1;
      void* _block_4423;
      moonbit_incref(_M0L7_2anameS1345);
      _block_4423
      = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug4Repr6Opaque));
      Moonbit_object_header(_block_4423)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 94, 14);
      set_cycle_capable(_block_4423);
      ((struct _M0DTPC15debug4Repr6Opaque*)_block_4423)->$0
      = _M0L7_2anameS1345;
      ((struct _M0DTPC15debug4Repr6Opaque*)_block_4423)->$1
      = _M0L7OmittedS3353;
      return _block_4423;
      break;
    }
    
    case 11: {
      void** _M0L6_2atmpS3352 = (void**)moonbit_empty_ref_array;
      struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L6_2atmpS3351 =
        (struct _M0TPB5ArrayGRPC15debug4ReprE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGRPC15debug4ReprE));
      void* _block_4424;
      Moonbit_object_header(_M0L6_2atmpS3351)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 78, 0);
      set_cycle_capable(_M0L6_2atmpS3351);
      _M0L6_2atmpS3351->$0 = _M0L6_2atmpS3352;
      _M0L6_2atmpS3351->$1 = 0;
      _block_4424
      = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug4Repr3Map));
      Moonbit_object_header(_block_4424)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 98, 11);
      set_cycle_capable(_block_4424);
      ((struct _M0DTPC15debug4Repr3Map*)_block_4424)->$0 = _M0L6_2atmpS3351;
      return _block_4424;
      break;
    }
    
    case 12: {
      struct _M0DTPC15debug4Repr11RecordField* _M0L14_2aRecordFieldS1346 =
        (struct _M0DTPC15debug4Repr11RecordField*)_M0L4selfS1341;
      moonbit_string_t _M0L7_2anameS1347 = _M0L14_2aRecordFieldS1346->$0;
      void* _M0L7OmittedS3350 =
        (struct moonbit_object*)&moonbit_constant_constructor_17 + 1;
      void* _block_4425;
      moonbit_incref(_M0L7_2anameS1347);
      _block_4425
      = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug4Repr11RecordField));
      Moonbit_object_header(_block_4425)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 101, 12);
      set_cycle_capable(_block_4425);
      ((struct _M0DTPC15debug4Repr11RecordField*)_block_4425)->$0
      = _M0L7_2anameS1347;
      ((struct _M0DTPC15debug4Repr11RecordField*)_block_4425)->$1
      = _M0L7OmittedS3350;
      return _block_4425;
      break;
    }
    
    case 13: {
      struct _M0DTPC15debug4Repr14EnumLabeledArg* _M0L17_2aEnumLabeledArgS1348 =
        (struct _M0DTPC15debug4Repr14EnumLabeledArg*)_M0L4selfS1341;
      moonbit_string_t _M0L8_2alabelS1349 = _M0L17_2aEnumLabeledArgS1348->$0;
      void* _M0L7OmittedS3349 =
        (struct moonbit_object*)&moonbit_constant_constructor_17 + 1;
      void* _block_4426;
      moonbit_incref(_M0L8_2alabelS1349);
      _block_4426
      = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug4Repr14EnumLabeledArg));
      Moonbit_object_header(_block_4426)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 105, 13);
      set_cycle_capable(_block_4426);
      ((struct _M0DTPC15debug4Repr14EnumLabeledArg*)_block_4426)->$0
      = _M0L8_2alabelS1349;
      ((struct _M0DTPC15debug4Repr14EnumLabeledArg*)_block_4426)->$1
      = _M0L7OmittedS3349;
      return _block_4426;
      break;
    }
    default: {
      void* _M0L7OmittedS3347 =
        (struct moonbit_object*)&moonbit_constant_constructor_17 + 1;
      void* _M0L7OmittedS3348 =
        (struct moonbit_object*)&moonbit_constant_constructor_17 + 1;
      void* _block_4427 =
        (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug4Repr8MapEntry));
      Moonbit_object_header(_block_4427)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 109, 16);
      set_cycle_capable(_block_4427);
      ((struct _M0DTPC15debug4Repr8MapEntry*)_block_4427)->$0
      = _M0L7OmittedS3347;
      ((struct _M0DTPC15debug4Repr8MapEntry*)_block_4427)->$1
      = _M0L7OmittedS3348;
      return _block_4427;
      break;
    }
  }
  join_1340:;
  moonbit_incref(_M0L4selfS1341);
  return _M0L4selfS1341;
}

void* _M0MPC15debug4Repr7omitted() {
  #line 282 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\repr.mbt"
  return (struct moonbit_object*)&moonbit_constant_constructor_17 + 1;
}

void* _M0MPC15debug4Repr7integer(moonbit_string_t _M0L1xS1339) {
  void* _block_4428;
  #line 190 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\repr.mbt"
  moonbit_incref(_M0L1xS1339);
  _block_4428
  = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug4Repr7Integer));
  Moonbit_object_header(_block_4428)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 113, 1);
  ((struct _M0DTPC15debug4Repr7Integer*)_block_4428)->$0 = _M0L1xS1339;
  return _block_4428;
}

void* _M0MPC15debug4Repr14with__children(
  void* _M0L4selfS1324,
  struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L8childrenS1325
) {
  #line 108 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\repr.mbt"
  switch (Moonbit_object_tag(_M0L4selfS1324)) {
    case 0: {
      goto join_1323;
      break;
    }
    
    case 1: {
      goto join_1323;
      break;
    }
    
    case 2: {
      goto join_1323;
      break;
    }
    
    case 3: {
      goto join_1323;
      break;
    }
    
    case 4: {
      goto join_1323;
      break;
    }
    
    case 5: {
      goto join_1323;
      break;
    }
    
    case 6: {
      goto join_1323;
      break;
    }
    
    case 15: {
      goto join_1323;
      break;
    }
    
    case 17: {
      goto join_1323;
      break;
    }
    
    case 7: {
      void* _block_4430;
      moonbit_incref(_M0L8childrenS1325);
      _block_4430
      = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug4Repr5Tuple));
      Moonbit_object_header(_block_4430)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 81, 7);
      set_cycle_capable(_block_4430);
      ((struct _M0DTPC15debug4Repr5Tuple*)_block_4430)->$0
      = _M0L8childrenS1325;
      return _block_4430;
      break;
    }
    
    case 8: {
      void* _block_4431;
      moonbit_incref(_M0L8childrenS1325);
      _block_4431
      = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug4Repr5Array));
      Moonbit_object_header(_block_4431)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 84, 8);
      set_cycle_capable(_block_4431);
      ((struct _M0DTPC15debug4Repr5Array*)_block_4431)->$0
      = _M0L8childrenS1325;
      return _block_4431;
      break;
    }
    
    case 9: {
      void* _block_4432;
      moonbit_incref(_M0L8childrenS1325);
      _block_4432
      = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug4Repr6Record));
      Moonbit_object_header(_block_4432)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 87, 9);
      set_cycle_capable(_block_4432);
      ((struct _M0DTPC15debug4Repr6Record*)_block_4432)->$0
      = _M0L8childrenS1325;
      return _block_4432;
      break;
    }
    
    case 10: {
      struct _M0DTPC15debug4Repr4Enum* _M0L7_2aEnumS1326 =
        (struct _M0DTPC15debug4Repr4Enum*)_M0L4selfS1324;
      moonbit_string_t _M0L7_2anameS1327 = _M0L7_2aEnumS1326->$0;
      void* _block_4433;
      moonbit_incref(_M0L7_2anameS1327);
      moonbit_incref(_M0L8childrenS1325);
      _block_4433
      = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug4Repr4Enum));
      Moonbit_object_header(_block_4433)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 90, 10);
      set_cycle_capable(_block_4433);
      ((struct _M0DTPC15debug4Repr4Enum*)_block_4433)->$0 = _M0L7_2anameS1327;
      ((struct _M0DTPC15debug4Repr4Enum*)_block_4433)->$1
      = _M0L8childrenS1325;
      return _block_4433;
      break;
    }
    
    case 11: {
      void* _block_4434;
      moonbit_incref(_M0L8childrenS1325);
      _block_4434
      = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug4Repr3Map));
      Moonbit_object_header(_block_4434)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 98, 11);
      set_cycle_capable(_block_4434);
      ((struct _M0DTPC15debug4Repr3Map*)_block_4434)->$0 = _M0L8childrenS1325;
      return _block_4434;
      break;
    }
    
    case 12: {
      struct _M0DTPC15debug4Repr11RecordField* _M0L14_2aRecordFieldS1328 =
        (struct _M0DTPC15debug4Repr11RecordField*)_M0L4selfS1324;
      moonbit_string_t _M0L7_2anameS1329 = _M0L14_2aRecordFieldS1328->$0;
      int32_t _M0L3lenS3344 = _M0L8childrenS1325->$1;
      if (_M0L3lenS3344 == 1) {
        void** _M0L3bufS3345 = _M0L8childrenS1325->$0;
        void* _M0L8_2avalueS1330 = (void*)_M0L3bufS3345[0];
        void* _block_4435;
        moonbit_incref(_M0L7_2anameS1329);
        moonbit_incref(_M0L8_2avalueS1330);
        _block_4435
        = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug4Repr11RecordField));
        Moonbit_object_header(_block_4435)->meta
        = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 101, 12);
        set_cycle_capable(_block_4435);
        ((struct _M0DTPC15debug4Repr11RecordField*)_block_4435)->$0
        = _M0L7_2anameS1329;
        ((struct _M0DTPC15debug4Repr11RecordField*)_block_4435)->$1
        = _M0L8_2avalueS1330;
        return _block_4435;
      } else {
        void* _M0L7OmittedS3346 =
          (struct moonbit_object*)&moonbit_constant_constructor_17 + 1;
        void* _block_4436;
        moonbit_incref(_M0L7_2anameS1329);
        _block_4436
        = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug4Repr11RecordField));
        Moonbit_object_header(_block_4436)->meta
        = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 101, 12);
        set_cycle_capable(_block_4436);
        ((struct _M0DTPC15debug4Repr11RecordField*)_block_4436)->$0
        = _M0L7_2anameS1329;
        ((struct _M0DTPC15debug4Repr11RecordField*)_block_4436)->$1
        = _M0L7OmittedS3346;
        return _block_4436;
      }
      break;
    }
    
    case 13: {
      struct _M0DTPC15debug4Repr14EnumLabeledArg* _M0L17_2aEnumLabeledArgS1331 =
        (struct _M0DTPC15debug4Repr14EnumLabeledArg*)_M0L4selfS1324;
      moonbit_string_t _M0L8_2alabelS1332 = _M0L17_2aEnumLabeledArgS1331->$0;
      int32_t _M0L3lenS3341 = _M0L8childrenS1325->$1;
      if (_M0L3lenS3341 == 1) {
        void** _M0L3bufS3342 = _M0L8childrenS1325->$0;
        void* _M0L8_2avalueS1333 = (void*)_M0L3bufS3342[0];
        void* _block_4437;
        moonbit_incref(_M0L8_2alabelS1332);
        moonbit_incref(_M0L8_2avalueS1333);
        _block_4437
        = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug4Repr14EnumLabeledArg));
        Moonbit_object_header(_block_4437)->meta
        = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 105, 13);
        set_cycle_capable(_block_4437);
        ((struct _M0DTPC15debug4Repr14EnumLabeledArg*)_block_4437)->$0
        = _M0L8_2alabelS1332;
        ((struct _M0DTPC15debug4Repr14EnumLabeledArg*)_block_4437)->$1
        = _M0L8_2avalueS1333;
        return _block_4437;
      } else {
        void* _M0L7OmittedS3343 =
          (struct moonbit_object*)&moonbit_constant_constructor_17 + 1;
        void* _block_4438;
        moonbit_incref(_M0L8_2alabelS1332);
        _block_4438
        = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug4Repr14EnumLabeledArg));
        Moonbit_object_header(_block_4438)->meta
        = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 105, 13);
        set_cycle_capable(_block_4438);
        ((struct _M0DTPC15debug4Repr14EnumLabeledArg*)_block_4438)->$0
        = _M0L8_2alabelS1332;
        ((struct _M0DTPC15debug4Repr14EnumLabeledArg*)_block_4438)->$1
        = _M0L7OmittedS3343;
        return _block_4438;
      }
      break;
    }
    
    case 16: {
      int32_t _M0L3lenS3336 = _M0L8childrenS1325->$1;
      if (_M0L3lenS3336 == 2) {
        void** _M0L3bufS3338 = _M0L8childrenS1325->$0;
        void* _M0L6_2akeyS1334 = (void*)_M0L3bufS3338[0];
        void** _M0L3bufS3337 = _M0L8childrenS1325->$0;
        void* _M0L8_2avalueS1335 = (void*)_M0L3bufS3337[1];
        void* _block_4439;
        moonbit_incref(_M0L6_2akeyS1334);
        moonbit_incref(_M0L8_2avalueS1335);
        _block_4439
        = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug4Repr8MapEntry));
        Moonbit_object_header(_block_4439)->meta
        = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 109, 16);
        set_cycle_capable(_block_4439);
        ((struct _M0DTPC15debug4Repr8MapEntry*)_block_4439)->$0
        = _M0L6_2akeyS1334;
        ((struct _M0DTPC15debug4Repr8MapEntry*)_block_4439)->$1
        = _M0L8_2avalueS1335;
        return _block_4439;
      } else {
        void* _M0L7OmittedS3339 =
          (struct moonbit_object*)&moonbit_constant_constructor_17 + 1;
        void* _M0L7OmittedS3340 =
          (struct moonbit_object*)&moonbit_constant_constructor_17 + 1;
        void* _block_4440 =
          (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug4Repr8MapEntry));
        Moonbit_object_header(_block_4440)->meta
        = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 109, 16);
        set_cycle_capable(_block_4440);
        ((struct _M0DTPC15debug4Repr8MapEntry*)_block_4440)->$0
        = _M0L7OmittedS3339;
        ((struct _M0DTPC15debug4Repr8MapEntry*)_block_4440)->$1
        = _M0L7OmittedS3340;
        return _block_4440;
      }
      break;
    }
    default: {
      struct _M0DTPC15debug4Repr6Opaque* _M0L9_2aOpaqueS1336 =
        (struct _M0DTPC15debug4Repr6Opaque*)_M0L4selfS1324;
      moonbit_string_t _M0L7_2anameS1337 = _M0L9_2aOpaqueS1336->$0;
      int32_t _M0L3lenS3333 = _M0L8childrenS1325->$1;
      if (_M0L3lenS3333 == 1) {
        void** _M0L3bufS3334 = _M0L8childrenS1325->$0;
        void* _M0L8_2avalueS1338 = (void*)_M0L3bufS3334[0];
        void* _block_4441;
        moonbit_incref(_M0L7_2anameS1337);
        moonbit_incref(_M0L8_2avalueS1338);
        _block_4441
        = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug4Repr6Opaque));
        Moonbit_object_header(_block_4441)->meta
        = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 94, 14);
        set_cycle_capable(_block_4441);
        ((struct _M0DTPC15debug4Repr6Opaque*)_block_4441)->$0
        = _M0L7_2anameS1337;
        ((struct _M0DTPC15debug4Repr6Opaque*)_block_4441)->$1
        = _M0L8_2avalueS1338;
        return _block_4441;
      } else {
        void* _M0L7OmittedS3335 =
          (struct moonbit_object*)&moonbit_constant_constructor_17 + 1;
        void* _block_4442;
        moonbit_incref(_M0L7_2anameS1337);
        _block_4442
        = (void*)moonbit_malloc(sizeof(struct _M0DTPC15debug4Repr6Opaque));
        Moonbit_object_header(_block_4442)->meta
        = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 94, 14);
        set_cycle_capable(_block_4442);
        ((struct _M0DTPC15debug4Repr6Opaque*)_block_4442)->$0
        = _M0L7_2anameS1337;
        ((struct _M0DTPC15debug4Repr6Opaque*)_block_4442)->$1
        = _M0L7OmittedS3335;
        return _block_4442;
      }
      break;
    }
  }
  join_1323:;
  moonbit_incref(_M0L4selfS1324);
  return _M0L4selfS1324;
}

struct _M0TPB5ArrayGRPC15debug4ReprE* _M0MPC15debug4Repr8children(
  void* _M0L4selfS1303
) {
  void* _M0L5valueS1299;
  struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L2xsS1301;
  void** _M0L6_2atmpS3331;
  struct _M0TPB5ArrayGRPC15debug4ReprE* _block_4447;
  void** _M0L6_2atmpS3330;
  struct _M0TPB5ArrayGRPC15debug4ReprE* _block_4448;
  #line 80 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\repr.mbt"
  switch (Moonbit_object_tag(_M0L4selfS1303)) {
    case 0: {
      goto join_1302;
      break;
    }
    
    case 1: {
      goto join_1302;
      break;
    }
    
    case 2: {
      goto join_1302;
      break;
    }
    
    case 3: {
      goto join_1302;
      break;
    }
    
    case 4: {
      goto join_1302;
      break;
    }
    
    case 5: {
      goto join_1302;
      break;
    }
    
    case 6: {
      goto join_1302;
      break;
    }
    
    case 15: {
      goto join_1302;
      break;
    }
    
    case 17: {
      goto join_1302;
      break;
    }
    
    case 7: {
      struct _M0DTPC15debug4Repr5Tuple* _M0L8_2aTupleS1304 =
        (struct _M0DTPC15debug4Repr5Tuple*)_M0L4selfS1303;
      struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L5_2axsS1305 =
        _M0L8_2aTupleS1304->$0;
      moonbit_incref(_M0L5_2axsS1305);
      _M0L2xsS1301 = _M0L5_2axsS1305;
      goto join_1300;
      break;
    }
    
    case 8: {
      struct _M0DTPC15debug4Repr5Array* _M0L8_2aArrayS1306 =
        (struct _M0DTPC15debug4Repr5Array*)_M0L4selfS1303;
      struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L5_2axsS1307 =
        _M0L8_2aArrayS1306->$0;
      moonbit_incref(_M0L5_2axsS1307);
      _M0L2xsS1301 = _M0L5_2axsS1307;
      goto join_1300;
      break;
    }
    
    case 9: {
      struct _M0DTPC15debug4Repr6Record* _M0L9_2aRecordS1308 =
        (struct _M0DTPC15debug4Repr6Record*)_M0L4selfS1303;
      struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L5_2axsS1309 =
        _M0L9_2aRecordS1308->$0;
      moonbit_incref(_M0L5_2axsS1309);
      _M0L2xsS1301 = _M0L5_2axsS1309;
      goto join_1300;
      break;
    }
    
    case 10: {
      struct _M0DTPC15debug4Repr4Enum* _M0L7_2aEnumS1310 =
        (struct _M0DTPC15debug4Repr4Enum*)_M0L4selfS1303;
      struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L5_2axsS1311 =
        _M0L7_2aEnumS1310->$1;
      moonbit_incref(_M0L5_2axsS1311);
      _M0L2xsS1301 = _M0L5_2axsS1311;
      goto join_1300;
      break;
    }
    
    case 11: {
      struct _M0DTPC15debug4Repr3Map* _M0L6_2aMapS1312 =
        (struct _M0DTPC15debug4Repr3Map*)_M0L4selfS1303;
      struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L5_2axsS1313 =
        _M0L6_2aMapS1312->$0;
      moonbit_incref(_M0L5_2axsS1313);
      _M0L2xsS1301 = _M0L5_2axsS1313;
      goto join_1300;
      break;
    }
    
    case 14: {
      struct _M0DTPC15debug4Repr6Opaque* _M0L9_2aOpaqueS1314 =
        (struct _M0DTPC15debug4Repr6Opaque*)_M0L4selfS1303;
      void* _M0L8_2avalueS1315 = _M0L9_2aOpaqueS1314->$1;
      moonbit_incref(_M0L8_2avalueS1315);
      _M0L5valueS1299 = _M0L8_2avalueS1315;
      goto join_1298;
      break;
    }
    
    case 12: {
      struct _M0DTPC15debug4Repr11RecordField* _M0L14_2aRecordFieldS1316 =
        (struct _M0DTPC15debug4Repr11RecordField*)_M0L4selfS1303;
      void* _M0L8_2avalueS1317 = _M0L14_2aRecordFieldS1316->$1;
      moonbit_incref(_M0L8_2avalueS1317);
      _M0L5valueS1299 = _M0L8_2avalueS1317;
      goto join_1298;
      break;
    }
    
    case 13: {
      struct _M0DTPC15debug4Repr14EnumLabeledArg* _M0L17_2aEnumLabeledArgS1318 =
        (struct _M0DTPC15debug4Repr14EnumLabeledArg*)_M0L4selfS1303;
      void* _M0L8_2avalueS1319 = _M0L17_2aEnumLabeledArgS1318->$1;
      moonbit_incref(_M0L8_2avalueS1319);
      _M0L5valueS1299 = _M0L8_2avalueS1319;
      goto join_1298;
      break;
    }
    default: {
      struct _M0DTPC15debug4Repr8MapEntry* _M0L11_2aMapEntryS1320 =
        (struct _M0DTPC15debug4Repr8MapEntry*)_M0L4selfS1303;
      void* _M0L6_2akeyS1321 = _M0L11_2aMapEntryS1320->$0;
      void* _M0L8_2avalueS1322 = _M0L11_2aMapEntryS1320->$1;
      void** _M0L6_2atmpS3332;
      struct _M0TPB5ArrayGRPC15debug4ReprE* _block_4446;
      moonbit_incref(_M0L6_2akeyS1321);
      moonbit_incref(_M0L8_2avalueS1322);
      _M0L6_2atmpS3332 = (void**)moonbit_make_ref_array_raw(2);
      set_cycle_capable(_M0L6_2atmpS3332);
      _M0L6_2atmpS3332[0] = _M0L6_2akeyS1321;
      _M0L6_2atmpS3332[1] = _M0L8_2avalueS1322;
      _block_4446
      = (struct _M0TPB5ArrayGRPC15debug4ReprE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGRPC15debug4ReprE));
      Moonbit_object_header(_block_4446)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 78, 0);
      set_cycle_capable(_block_4446);
      _block_4446->$0 = _M0L6_2atmpS3332;
      _block_4446->$1 = 2;
      return _block_4446;
      break;
    }
  }
  join_1302:;
  _M0L6_2atmpS3331 = (void**)moonbit_empty_ref_array;
  _block_4447
  = (struct _M0TPB5ArrayGRPC15debug4ReprE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGRPC15debug4ReprE));
  Moonbit_object_header(_block_4447)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 78, 0);
  set_cycle_capable(_block_4447);
  _block_4447->$0 = _M0L6_2atmpS3331;
  _block_4447->$1 = 0;
  return _block_4447;
  join_1300:;
  return _M0L2xsS1301;
  join_1298:;
  _M0L6_2atmpS3330 = (void**)moonbit_make_ref_array_raw(1);
  set_cycle_capable(_M0L6_2atmpS3330);
  _M0L6_2atmpS3330[0] = _M0L5valueS1299;
  _block_4448
  = (struct _M0TPB5ArrayGRPC15debug4ReprE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGRPC15debug4ReprE));
  Moonbit_object_header(_block_4448)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 78, 0);
  set_cycle_capable(_block_4448);
  _block_4448->$0 = _M0L6_2atmpS3330;
  _block_4448->$1 = 1;
  return _block_4448;
}

void* _M0MPC15debug4Repr4ReprGiE(int32_t _M0L5valueS1297) {
  #line 184 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\repr.mbt"
  #line 185 "C:\\Users\\Administrator\\.moon\\lib\\core\\debug\\repr.mbt"
  return _M0IPC13int3IntPC15debug5Debug8to__repr(_M0L5valueS1297);
}

moonbit_string_t _M0IPC15float5FloatPB4Show10to__string(float _M0L4selfS1296) {
  double _M0L6_2atmpS3329;
  #line 16 "C:\\Users\\Administrator\\.moon\\lib\\core\\float\\methods.mbt"
  _M0L6_2atmpS3329 = (double)_M0L4selfS1296;
  #line 17 "C:\\Users\\Administrator\\.moon\\lib\\core\\float\\methods.mbt"
  return _M0MPC16double6Double10to__string(_M0L6_2atmpS3329);
}

moonbit_string_t _M0MPC15array5Array4joinGsE(
  struct _M0TPB5ArrayGsE* _M0L4selfS1292,
  struct _M0TPC16string10StringView _M0L9separatorS1293
) {
  moonbit_string_t* _M0L3bufS3324;
  int32_t _M0L3lenS3325;
  struct _M0TPB9ArrayViewGsE _M0L6_2atmpS3323;
  moonbit_string_t _result_4449;
  #line 2182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L3bufS3324 = _M0L4selfS1292->$0;
  _M0L3lenS3325 = _M0L4selfS1292->$1;
  moonbit_incref(_M0L3bufS3324);
  _M0L6_2atmpS3323
  = (struct _M0TPB9ArrayViewGsE){
    .$0 = _M0L3bufS3324, .$1 = 0, .$2 = _M0L3lenS3325
  };
  #line 2186 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _result_4449
  = _M0MPC15array9ArrayView4joinGsE(_M0L6_2atmpS3323, _M0L9separatorS1293);
  moonbit_decref(_M0L6_2atmpS3323.$0);
  return _result_4449;
}

moonbit_string_t _M0MPC15array5Array4joinGRPC16string10StringViewE(
  struct _M0TPB5ArrayGRPC16string10StringViewE* _M0L4selfS1294,
  struct _M0TPC16string10StringView _M0L9separatorS1295
) {
  struct _M0TPC16string10StringView* _M0L3bufS3327;
  int32_t _M0L3lenS3328;
  struct _M0TPB9ArrayViewGRPC16string10StringViewE _M0L6_2atmpS3326;
  moonbit_string_t _result_4450;
  #line 2182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L3bufS3327 = _M0L4selfS1294->$0;
  _M0L3lenS3328 = _M0L4selfS1294->$1;
  moonbit_incref(_M0L3bufS3327);
  _M0L6_2atmpS3326
  = (struct _M0TPB9ArrayViewGRPC16string10StringViewE){
    .$0 = _M0L3bufS3327, .$1 = 0, .$2 = _M0L3lenS3328
  };
  #line 2186 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _result_4450
  = _M0MPC15array9ArrayView4joinGRPC16string10StringViewE(_M0L6_2atmpS3326, _M0L9separatorS1295);
  moonbit_decref(_M0L6_2atmpS3326.$0);
  return _result_4450;
}

int32_t _M0MPC15array5Array10push__iterGsE(
  struct _M0TPB5ArrayGsE* _M0L4selfS1287,
  struct _M0TPB4IterGsE* _M0L4iterS1284
) {
  int64_t _M0L7_2abindS1283;
  #line 1952 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  #line 1955 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L7_2abindS1283 = _M0MPB4Iter10size__hintGsE(_M0L4iterS1284);
  if (_M0L7_2abindS1283 == 4294967296ll) {
    
  } else {
    int64_t _M0L7_2aSomeS1285 = _M0L7_2abindS1283;
    int32_t _M0L4_2anS1286 = (int32_t)_M0L7_2aSomeS1285;
    int32_t _M0L3lenS3322 = _M0L4selfS1287->$1;
    int32_t _M0L6_2atmpS3321 = _M0L3lenS3322 + _M0L4_2anS1286;
    #line 1956 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
    _M0MPC15array5Array17reserve__capacityGsE(_M0L4selfS1287, _M0L6_2atmpS3321);
  }
  while (1) {
    moonbit_string_t _M0L7_2abindS1288;
    #line 1958 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
    _M0L7_2abindS1288 = _M0MPB4Iter4nextGsE(_M0L4iterS1284);
    if (_M0L7_2abindS1288 == 0) {
      if (_M0L7_2abindS1288) {
        moonbit_decref(_M0L7_2abindS1288);
      }
    } else {
      moonbit_string_t _M0L7_2aSomeS1289 = _M0L7_2abindS1288;
      moonbit_string_t _M0L4_2axS1290 = _M0L7_2aSomeS1289;
      #line 1959 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
      _M0MPC15array5Array4pushGsE(_M0L4selfS1287, _M0L4_2axS1290);
      continue;
    }
    break;
  }
  return 0;
}

struct _M0TPB5ArrayGsE* _M0MPC15array5Array6filterGsE(
  struct _M0TPB5ArrayGsE* _M0L4selfS1278,
  struct _M0TWsEb* _M0L1fS1281
) {
  moonbit_string_t* _M0L6_2atmpS3320;
  struct _M0TPB5ArrayGsE* _M0L3arrS1276;
  int32_t _M0L7_2abindS1277;
  int32_t _M0L2__S1279;
  #line 689 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L6_2atmpS3320 = (moonbit_string_t*)moonbit_empty_ref_array;
  _M0L3arrS1276
  = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
  Moonbit_object_header(_M0L3arrS1276)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
  _M0L3arrS1276->$0 = _M0L6_2atmpS3320;
  _M0L3arrS1276->$1 = 0;
  _M0L7_2abindS1277 = _M0L4selfS1278->$1;
  _M0L2__S1279 = 0;
  while (1) {
    if (_M0L2__S1279 < _M0L7_2abindS1277) {
      moonbit_string_t* _M0L3bufS3319 = _M0L4selfS1278->$0;
      moonbit_string_t _M0L1vS1280 =
        (moonbit_string_t)_M0L3bufS3319[_M0L2__S1279];
      int32_t _M0L6_2atmpS3318;
      moonbit_incref(_M0L1vS1280);
      #line 696 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
      if (_M0L1fS1281->code(_M0L1fS1281, _M0L1vS1280)) {
        #line 697 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
        _M0MPC15array5Array4pushGsE(_M0L3arrS1276, _M0L1vS1280);
      } else {
        moonbit_decref(_M0L1vS1280);
      }
      _M0L6_2atmpS3318 = _M0L2__S1279 + 1;
      _M0L2__S1279 = _M0L6_2atmpS3318;
      continue;
    }
    break;
  }
  return _M0L3arrS1276;
}

int32_t _M0MPC15array5Array9is__emptyGRPC15debug7ContentE(
  struct _M0TPB5ArrayGRPC15debug7ContentE* _M0L4selfS1272
) {
  int32_t _M0L3lenS3314;
  #line 722 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L3lenS3314 = _M0L4selfS1272->$1;
  return _M0L3lenS3314 == 0;
}

int32_t _M0MPC15array5Array9is__emptyGRPC15debug9ReprDeltaE(
  struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* _M0L4selfS1273
) {
  int32_t _M0L3lenS3315;
  #line 722 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L3lenS3315 = _M0L4selfS1273->$1;
  return _M0L3lenS3315 == 0;
}

int32_t _M0MPC15array5Array9is__emptyGRPC15debug4ReprE(
  struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L4selfS1274
) {
  int32_t _M0L3lenS3316;
  #line 722 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L3lenS3316 = _M0L4selfS1274->$1;
  return _M0L3lenS3316 == 0;
}

int32_t _M0MPC15array5Array9is__emptyGsE(
  struct _M0TPB5ArrayGsE* _M0L4selfS1275
) {
  int32_t _M0L3lenS3317;
  #line 722 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L3lenS3317 = _M0L4selfS1275->$1;
  return _M0L3lenS3317 == 0;
}

int32_t _M0MPC15array5Array3allGsE(
  struct _M0TPB5ArrayGsE* _M0L4selfS1261,
  struct _M0TWsEb* _M0L1fS1264
) {
  int32_t _M0L7_2abindS1260;
  int32_t _M0L2__S1262;
  #line 520 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L7_2abindS1260 = _M0L4selfS1261->$1;
  _M0L2__S1262 = 0;
  while (1) {
    if (_M0L2__S1262 < _M0L7_2abindS1260) {
      moonbit_string_t* _M0L3bufS3310 = _M0L4selfS1261->$0;
      moonbit_string_t _M0L1vS1263 =
        (moonbit_string_t)_M0L3bufS3310[_M0L2__S1262];
      int32_t _M0L6_2atmpS3308;
      int32_t _M0L6_2atmpS3309;
      moonbit_incref(_M0L1vS1263);
      #line 525 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
      _M0L6_2atmpS3308 = _M0L1fS1264->code(_M0L1fS1264, _M0L1vS1263);
      moonbit_decref(_M0L1vS1263);
      if (!_M0L6_2atmpS3308) {
        return 0;
      }
      _M0L6_2atmpS3309 = _M0L2__S1262 + 1;
      _M0L2__S1262 = _M0L6_2atmpS3309;
      continue;
    }
    break;
  }
  return 1;
}

int32_t _M0MPC15array5Array3allGRPC15debug9ReprDeltaE(
  struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* _M0L4selfS1267,
  struct _M0TWRPC15debug9ReprDeltaEb* _M0L1fS1270
) {
  int32_t _M0L7_2abindS1266;
  int32_t _M0L2__S1268;
  #line 520 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L7_2abindS1266 = _M0L4selfS1267->$1;
  _M0L2__S1268 = 0;
  while (1) {
    if (_M0L2__S1268 < _M0L7_2abindS1266) {
      void** _M0L3bufS3313 = _M0L4selfS1267->$0;
      void* _M0L1vS1269 = (void*)_M0L3bufS3313[_M0L2__S1268];
      int32_t _M0L6_2atmpS3311;
      int32_t _M0L6_2atmpS3312;
      moonbit_incref(_M0L1vS1269);
      #line 525 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
      _M0L6_2atmpS3311 = _M0L1fS1270->code(_M0L1fS1270, _M0L1vS1269);
      moonbit_decref(_M0L1vS1269);
      if (!_M0L6_2atmpS3311) {
        return 0;
      }
      _M0L6_2atmpS3312 = _M0L2__S1268 + 1;
      _M0L2__S1268 = _M0L6_2atmpS3312;
      continue;
    }
    break;
  }
  return 1;
}

struct _M0TPB5ArrayGsE* _M0IPC15array5ArrayPB3Add3addGsE(
  struct _M0TPB5ArrayGsE* _M0L4selfS1256,
  struct _M0TPB5ArrayGsE* _M0L5otherS1258
) {
  int32_t _M0L9len__selfS1255;
  int32_t _M0L10len__otherS1257;
  #line 375 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L9len__selfS1255 = _M0L4selfS1256->$1;
  _M0L10len__otherS1257 = _M0L5otherS1258->$1;
  if (_M0L9len__selfS1255 == 0) {
    moonbit_string_t* _M0L6_2atmpS3303;
    #line 380 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
    _M0L6_2atmpS3303 = _M0MPC15array5Array6bufferGsE(_M0L5otherS1258);
    #line 379 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
    return _M0MPC15array5Array31unsafe__make__and__blit_2einnerGsE(_M0L6_2atmpS3303, _M0L10len__otherS1257, _M0L10len__otherS1257, 0, 0);
  } else {
    moonbit_string_t* _M0L6_2atmpS3306;
    int32_t _M0L6_2atmpS3307;
    struct _M0TPB5ArrayGsE* _M0L6resultS1259;
    moonbit_string_t* _M0L6_2atmpS3304;
    moonbit_string_t* _M0L6_2atmpS3305;
    #line 386 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
    _M0L6_2atmpS3306 = _M0MPC15array5Array6bufferGsE(_M0L4selfS1256);
    _M0L6_2atmpS3307 = _M0L9len__selfS1255 + _M0L10len__otherS1257;
    #line 385 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
    _M0L6resultS1259
    = _M0MPC15array5Array31unsafe__make__and__blit_2einnerGsE(_M0L6_2atmpS3306, _M0L6_2atmpS3307, _M0L9len__selfS1255, 0, 0);
    #line 391 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
    _M0L6_2atmpS3304 = _M0MPC15array5Array6bufferGsE(_M0L6resultS1259);
    #line 393 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
    _M0L6_2atmpS3305 = _M0MPC15array5Array6bufferGsE(_M0L5otherS1258);
    #line 390 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
    _M0MPB18UninitializedArray12unsafe__blitGsE(_M0L6_2atmpS3304, _M0L9len__selfS1255, _M0L6_2atmpS3305, 0, _M0L10len__otherS1257);
    moonbit_decref(_M0L6_2atmpS3304);
    moonbit_decref(_M0L6_2atmpS3305);
    return _M0L6resultS1259;
  }
}

int32_t _M0MPC15array5Array6appendGsE(
  struct _M0TPB5ArrayGsE* _M0L4selfS1253,
  struct _M0TPB9ArrayViewGsE _M0L5otherS1249
) {
  moonbit_string_t* _M0L3srcS1248;
  int32_t _M0L11src__offsetS1250;
  int32_t _M0L3endS3301;
  int32_t _M0L5startS3302;
  int32_t _M0L11append__lenS1251;
  int32_t _M0L8old__lenS1252;
  int32_t _M0L8new__lenS1254;
  #line 388 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L3srcS1248 = _M0L5otherS1249.$0;
  _M0L11src__offsetS1250 = _M0L5otherS1249.$1;
  _M0L3endS3301 = _M0L5otherS1249.$2;
  _M0L5startS3302 = _M0L5otherS1249.$1;
  _M0L11append__lenS1251 = _M0L3endS3301 - _M0L5startS3302;
  _M0L8old__lenS1252 = _M0L4selfS1253->$1;
  _M0L8new__lenS1254 = _M0L8old__lenS1252 + _M0L11append__lenS1251;
  if (_M0L8new__lenS1254 >= _M0L8old__lenS1252) {
    moonbit_string_t* _M0L3bufS3299 = _M0L4selfS1253->$0;
    int32_t _M0L6_2atmpS3298 = Moonbit_array_length(_M0L3bufS3299);
    moonbit_string_t* _M0L3bufS3300;
    if (_M0L8new__lenS1254 > _M0L6_2atmpS3298) {
      moonbit_incref(_M0L3srcS1248);
      #line 396 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
      _M0MPC15array5Array7reallocGsE(_M0L4selfS1253, _M0L8new__lenS1254);
    } else {
      moonbit_incref(_M0L3srcS1248);
    }
    _M0L4selfS1253->$1 = _M0L8new__lenS1254;
    _M0L3bufS3300 = _M0L4selfS1253->$0;
    moonbit_incref(_M0L3bufS3300);
    #line 399 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
    _M0MPB18UninitializedArray12unsafe__blitGsE(_M0L3bufS3300, _M0L8old__lenS1252, _M0L3srcS1248, _M0L11src__offsetS1250, _M0L11append__lenS1251);
    moonbit_decref(_M0L3bufS3300);
    moonbit_decref(_M0L3srcS1248);
  } else {
    #line 394 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
    moonbit_panic();
  }
  return 0;
}

int32_t _M0MPC15array5Array17reserve__capacityGsE(
  struct _M0TPB5ArrayGsE* _M0L4selfS1246,
  int32_t _M0L8capacityS1247
) {
  int32_t _M0L6_2atmpS3297;
  #line 314 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  #line 315 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L6_2atmpS3297 = _M0MPC15array5Array8capacityGsE(_M0L4selfS1246);
  if (_M0L6_2atmpS3297 >= _M0L8capacityS1247) {
    return 0;
  }
  #line 318 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0MPC15array5Array14resize__bufferGsE(_M0L4selfS1246, _M0L8capacityS1247);
  return 0;
}

moonbit_string_t _M0MPC15array5Array2atGsE(
  struct _M0TPB5ArrayGsE* _M0L4selfS1244,
  int32_t _M0L5indexS1245
) {
  int32_t _M0L3lenS1243;
  int32_t _if__result_4455;
  #line 183 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L3lenS1243 = _M0L4selfS1244->$1;
  if (_M0L5indexS1245 >= 0) {
    _if__result_4455 = _M0L5indexS1245 < _M0L3lenS1243;
  } else {
    _if__result_4455 = 0;
  }
  if (_if__result_4455) {
    moonbit_string_t* _M0L6_2atmpS3296;
    moonbit_string_t _M0L6_2atmpS4086;
    #line 188 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
    _M0L6_2atmpS3296 = _M0MPC15array5Array6bufferGsE(_M0L4selfS1244);
    _M0L6_2atmpS4086 = (moonbit_string_t)_M0L6_2atmpS3296[_M0L5indexS1245];
    moonbit_incref(_M0L6_2atmpS4086);
    moonbit_decref(_M0L6_2atmpS3296);
    return _M0L6_2atmpS4086;
  } else {
    #line 187 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
    moonbit_panic();
  }
}

struct _M0TPB9ArrayViewGRPC15debug4ReprE _M0MPC15array5Array12view_2einnerGRPC15debug4ReprE(
  struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L4selfS1233,
  int32_t _M0L5startS1240,
  int64_t _M0L3endS1237
) {
  int32_t _M0L3lenS1232;
  int32_t _M0L3endS1236;
  int32_t _M0L3endS1234;
  int32_t _if__result_4457;
  #line 252 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
  _M0L3lenS1232 = _M0L4selfS1233->$1;
  if (_M0L3endS1237 == 4294967296ll) {
    _M0L3endS1236 = _M0L3lenS1232;
    goto join_1235;
  } else {
    int64_t _M0L7_2aSomeS1238 = _M0L3endS1237;
    int32_t _M0L6_2aendS1239 = (int32_t)_M0L7_2aSomeS1238;
    _M0L3endS1236 = _M0L6_2aendS1239;
    goto join_1235;
  }
  goto joinlet_4456;
  join_1235:;
  _M0L3endS1234 = _M0L3endS1236;
  joinlet_4456:;
  if (_M0L5startS1240 >= 0) {
    if (_M0L5startS1240 <= _M0L3endS1234) {
      _if__result_4457 = _M0L3endS1234 <= _M0L3lenS1232;
    } else {
      _if__result_4457 = 0;
    }
  } else {
    _if__result_4457 = 0;
  }
  if (_if__result_4457) {
    void** _M0L7_2abindS1241;
    int32_t _M0L7_2abindS1242;
    int32_t _M0L6_2atmpS3295;
    #line 266 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
    _M0L7_2abindS1241
    = _M0MPC15array5Array6bufferGRPC15debug4ReprE(_M0L4selfS1233);
    _M0L7_2abindS1242 = _M0L3endS1234 - _M0L5startS1240;
    _M0L6_2atmpS3295 = _M0L5startS1240 + _M0L7_2abindS1242;
    return (struct _M0TPB9ArrayViewGRPC15debug4ReprE){.$0 = _M0L7_2abindS1241,
                                                        .$1 = _M0L5startS1240,
                                                        .$2 = _M0L6_2atmpS3295};
  } else {
    #line 264 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
    return _M0FPC15abort5abortGRPB9ArrayViewGRPC15debug4ReprEE((moonbit_string_t)moonbit_string_literal_38.data);
  }
}

int32_t _M0IPB9SourceLocPB4Show6output(
  moonbit_string_t _M0L4selfS1231,
  struct _M0TPB6Logger _M0L6loggerS1230
) {
  moonbit_string_t _M0L6_2atmpS3294;
  #line 43 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\autoloc.mbt"
  moonbit_incref(_M0L4selfS1231);
  _M0L6_2atmpS3294 = _M0L4selfS1231;
  #line 44 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\autoloc.mbt"
  _M0L6loggerS1230.$0->$method_0(_M0L6loggerS1230.$1, _M0L6_2atmpS3294);
  moonbit_decref(_M0L6_2atmpS3294);
  return 0;
}

moonbit_string_t _M0MPC14char4Char14escape_2einner(
  int32_t _M0L4selfS1228,
  int32_t _M0L5quoteS1229
) {
  struct _M0TPB13StringBuilder* _M0L3bufS1227;
  struct _M0TPB6Logger _M0L6_2atmpS3293;
  moonbit_string_t _result_4458;
  #line 478 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
  #line 479 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
  _M0L3bufS1227 = _M0MPB13StringBuilder21StringBuilder_2einner(0);
  moonbit_incref(_M0L3bufS1227);
  _M0L6_2atmpS3293
  = (struct _M0TPB6Logger){
    _M0FP0119moonbitlang_2fcore_2fbuiltin_2fStringBuilder_2eas___40moonbitlang_2fcore_2fbuiltin_2eLogger_2estatic__method__table__id,
      _M0L3bufS1227
  };
  #line 480 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
  _M0MPC14char4Char18escape__to_2einner(_M0L4selfS1228, _M0L6_2atmpS3293, _M0L5quoteS1229);
  if (_M0L6_2atmpS3293.$1) {
    moonbit_decref(_M0L6_2atmpS3293.$1);
  }
  #line 481 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
  _result_4458 = _M0MPB13StringBuilder10to__string(_M0L3bufS1227);
  moonbit_decref(_M0L3bufS1227);
  return _result_4458;
}

int32_t _M0MPC14char4Char18escape__to_2einner(
  int32_t _M0L4selfS1226,
  struct _M0TPB6Logger _M0L6loggerS1224,
  int32_t _M0L5quoteS1223
) {
  #line 485 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
  if (_M0L5quoteS1223) {
    #line 487 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
    _M0L6loggerS1224.$0->$method_3(_M0L6loggerS1224.$1, 39);
  }
  if (_M0L4selfS1226 == 39) {
    goto join_1225;
  } else if (_M0L4selfS1226 == 92) {
    goto join_1225;
  } else if (_M0L4selfS1226 == 10) {
    #line 494 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
    _M0L6loggerS1224.$0->$method_0(_M0L6loggerS1224.$1, (moonbit_string_t)moonbit_string_literal_39.data);
  } else if (_M0L4selfS1226 == 13) {
    #line 495 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
    _M0L6loggerS1224.$0->$method_0(_M0L6loggerS1224.$1, (moonbit_string_t)moonbit_string_literal_40.data);
  } else if (_M0L4selfS1226 == 8) {
    #line 496 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
    _M0L6loggerS1224.$0->$method_0(_M0L6loggerS1224.$1, (moonbit_string_t)moonbit_string_literal_41.data);
  } else if (_M0L4selfS1226 == 9) {
    #line 497 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
    _M0L6loggerS1224.$0->$method_0(_M0L6loggerS1224.$1, (moonbit_string_t)moonbit_string_literal_42.data);
  } else if (_M0L4selfS1226 >= 32 && _M0L4selfS1226 <= 126) {
    #line 498 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
    _M0L6loggerS1224.$0->$method_3(_M0L6loggerS1224.$1, _M0L4selfS1226);
  } else {
    int32_t _M0L6_2atmpS3291;
    #line 500 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
    _M0L6_2atmpS3291 = _M0MPC14char4Char13is__printable(_M0L4selfS1226);
    if (!_M0L6_2atmpS3291) {
      moonbit_string_t _M0L6_2atmpS3292;
      #line 501 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
      _M0L6loggerS1224.$0->$method_0(_M0L6loggerS1224.$1, (moonbit_string_t)moonbit_string_literal_43.data);
      #line 502 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
      _M0L6_2atmpS3292 = _M0MPC14char4Char7to__hex(_M0L4selfS1226);
      #line 502 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
      _M0L6loggerS1224.$0->$method_0(_M0L6loggerS1224.$1, _M0L6_2atmpS3292);
      moonbit_decref(_M0L6_2atmpS3292);
      #line 503 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
      _M0L6loggerS1224.$0->$method_3(_M0L6loggerS1224.$1, 125);
    } else {
      #line 505 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
      _M0L6loggerS1224.$0->$method_3(_M0L6loggerS1224.$1, _M0L4selfS1226);
    }
  }
  goto joinlet_4459;
  join_1225:;
  #line 491 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
  _M0L6loggerS1224.$0->$method_3(_M0L6loggerS1224.$1, 92);
  #line 492 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
  _M0L6loggerS1224.$0->$method_3(_M0L6loggerS1224.$1, _M0L4selfS1226);
  joinlet_4459:;
  if (_M0L5quoteS1223) {
    #line 509 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
    _M0L6loggerS1224.$0->$method_3(_M0L6loggerS1224.$1, 39);
  }
  return 0;
}

int32_t _M0MPC14char4Char13is__printable(int32_t _M0L4selfS1218) {
  int32_t _M0L4selfS1219;
  int32_t _if__result_4462;
  #line 347 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
  #line 349 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
  if (_M0MPC14char4Char11is__control(_M0L4selfS1218)) {
    return 0;
  }
  _M0L4selfS1219 = _M0L4selfS1218;
  if (_M0L4selfS1219 >= 57344 && _M0L4selfS1219 <= 63743) {
    goto join_1220;
  } else if (_M0L4selfS1219 >= 983040 && _M0L4selfS1219 <= 1048573) {
    goto join_1220;
  } else if (_M0L4selfS1219 >= 1048576 && _M0L4selfS1219 <= 1114109) {
    goto join_1220;
  }
  goto joinlet_4460;
  join_1220:;
  return 0;
  joinlet_4460:;
  if (_M0L4selfS1219 == 173) {
    goto join_1221;
  } else if (_M0L4selfS1219 >= 1536 && _M0L4selfS1219 <= 1541) {
    goto join_1221;
  } else if (_M0L4selfS1219 == 1564) {
    goto join_1221;
  } else if (_M0L4selfS1219 == 1757) {
    goto join_1221;
  } else if (_M0L4selfS1219 == 1807) {
    goto join_1221;
  } else if (_M0L4selfS1219 >= 2192 && _M0L4selfS1219 <= 2193) {
    goto join_1221;
  } else if (_M0L4selfS1219 == 2274) {
    goto join_1221;
  } else if (_M0L4selfS1219 == 6158) {
    goto join_1221;
  } else if (_M0L4selfS1219 >= 8203 && _M0L4selfS1219 <= 8207) {
    goto join_1221;
  } else if (_M0L4selfS1219 >= 8234 && _M0L4selfS1219 <= 8238) {
    goto join_1221;
  } else if (_M0L4selfS1219 >= 8288 && _M0L4selfS1219 <= 8292) {
    goto join_1221;
  } else if (_M0L4selfS1219 >= 8294 && _M0L4selfS1219 <= 8303) {
    goto join_1221;
  } else if (_M0L4selfS1219 == 65279) {
    goto join_1221;
  } else if (_M0L4selfS1219 >= 65529 && _M0L4selfS1219 <= 65531) {
    goto join_1221;
  } else if (_M0L4selfS1219 == 69821) {
    goto join_1221;
  } else if (_M0L4selfS1219 == 69837) {
    goto join_1221;
  } else if (_M0L4selfS1219 >= 78896 && _M0L4selfS1219 <= 78911) {
    goto join_1221;
  } else if (_M0L4selfS1219 >= 113824 && _M0L4selfS1219 <= 113827) {
    goto join_1221;
  } else if (_M0L4selfS1219 >= 119155 && _M0L4selfS1219 <= 119162) {
    goto join_1221;
  } else if (_M0L4selfS1219 == 917505) {
    goto join_1221;
  } else if (_M0L4selfS1219 >= 917536 && _M0L4selfS1219 <= 917631) {
    goto join_1221;
  }
  goto joinlet_4461;
  join_1221:;
  return 0;
  joinlet_4461:;
  #line 385 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
  if (_M0MPC13int3Int13is__surrogate(_M0L4selfS1219)) {
    return 0;
  }
  if (_M0L4selfS1219 == 8232) {
    _if__result_4462 = 1;
  } else {
    _if__result_4462 = _M0L4selfS1219 == 8233;
  }
  if (_if__result_4462) {
    return 0;
  }
  if (_M0L4selfS1219 >= 64976 && _M0L4selfS1219 <= 65007) {
    goto join_1222;
  } else if (_M0L4selfS1219 >= 65534 && _M0L4selfS1219 <= 65535) {
    goto join_1222;
  } else if (_M0L4selfS1219 >= 131070 && _M0L4selfS1219 <= 131071) {
    goto join_1222;
  } else if (_M0L4selfS1219 >= 196606 && _M0L4selfS1219 <= 196607) {
    goto join_1222;
  } else if (_M0L4selfS1219 >= 262142 && _M0L4selfS1219 <= 262143) {
    goto join_1222;
  } else if (_M0L4selfS1219 >= 327678 && _M0L4selfS1219 <= 327679) {
    goto join_1222;
  } else if (_M0L4selfS1219 >= 393214 && _M0L4selfS1219 <= 393215) {
    goto join_1222;
  } else if (_M0L4selfS1219 >= 458750 && _M0L4selfS1219 <= 458751) {
    goto join_1222;
  } else if (_M0L4selfS1219 >= 524286 && _M0L4selfS1219 <= 524287) {
    goto join_1222;
  } else if (_M0L4selfS1219 >= 589822 && _M0L4selfS1219 <= 589823) {
    goto join_1222;
  } else if (_M0L4selfS1219 >= 655358 && _M0L4selfS1219 <= 655359) {
    goto join_1222;
  } else if (_M0L4selfS1219 >= 720894 && _M0L4selfS1219 <= 720895) {
    goto join_1222;
  } else if (_M0L4selfS1219 >= 786430 && _M0L4selfS1219 <= 786431) {
    goto join_1222;
  } else if (_M0L4selfS1219 >= 851966 && _M0L4selfS1219 <= 851967) {
    goto join_1222;
  } else if (_M0L4selfS1219 >= 917502 && _M0L4selfS1219 <= 917503) {
    goto join_1222;
  } else if (_M0L4selfS1219 >= 983038 && _M0L4selfS1219 <= 983039) {
    goto join_1222;
  } else if (_M0L4selfS1219 >= 1048574 && _M0L4selfS1219 <= 1048575) {
    goto join_1222;
  } else if (_M0L4selfS1219 >= 1114110 && _M0L4selfS1219 <= 1114111) {
    goto join_1222;
  }
  goto joinlet_4463;
  join_1222:;
  return 0;
  joinlet_4463:;
  return 1;
}

int32_t _M0MPC14char4Char11is__control(int32_t _M0L4selfS1217) {
  #line 144 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
  return _M0L4selfS1217 >= 0 && _M0L4selfS1217 <= 31
         || _M0L4selfS1217 >= 127 && _M0L4selfS1217 <= 159
         || 0;
}

moonbit_string_t _M0MPC14char4Char7to__hex(int32_t _M0L4charS1216) {
  int32_t _M0L4codeS1215;
  #line 16 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
  _M0L4codeS1215 = _M0L4charS1216;
  if (_M0L4codeS1215 >= 0 && _M0L4codeS1215 <= 255) {
    int32_t _M0L6_2atmpS3290 = _M0L4codeS1215 & 0xff;
    #line 19 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
    return _M0MPC14byte4Byte7to__hex(_M0L6_2atmpS3290);
  } else if (_M0L4codeS1215 <= 65535) {
    int32_t _M0L6_2atmpS3289 = _M0L4codeS1215 >> 8;
    int32_t _M0L6_2atmpS3288 = _M0L6_2atmpS3289 & 0xff;
    moonbit_string_t _M0L6_2atmpS3285;
    int32_t _M0L6_2atmpS3287;
    moonbit_string_t _M0L6_2atmpS3286;
    moonbit_string_t _result_4464;
    #line 20 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
    _M0L6_2atmpS3285 = _M0MPC14byte4Byte7to__hex(_M0L6_2atmpS3288);
    _M0L6_2atmpS3287 = _M0L4codeS1215 & 0xff;
    #line 20 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
    _M0L6_2atmpS3286 = _M0MPC14byte4Byte7to__hex(_M0L6_2atmpS3287);
    #line 20 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
    _result_4464 = moonbit_add_string(_M0L6_2atmpS3285, _M0L6_2atmpS3286);
    moonbit_decref(_M0L6_2atmpS3286);
    moonbit_decref(_M0L6_2atmpS3285);
    return _result_4464;
  } else {
    int32_t _M0L6_2atmpS3284 = _M0L4codeS1215 >> 16;
    int32_t _M0L6_2atmpS3283 = _M0L6_2atmpS3284 & 0xff;
    moonbit_string_t _M0L6_2atmpS3279;
    int32_t _M0L6_2atmpS3282;
    int32_t _M0L6_2atmpS3281;
    moonbit_string_t _M0L6_2atmpS3280;
    moonbit_string_t _M0L6_2atmpS3276;
    int32_t _M0L6_2atmpS3278;
    moonbit_string_t _M0L6_2atmpS3277;
    moonbit_string_t _result_4465;
    #line 22 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
    _M0L6_2atmpS3279 = _M0MPC14byte4Byte7to__hex(_M0L6_2atmpS3283);
    _M0L6_2atmpS3282 = _M0L4codeS1215 >> 8;
    _M0L6_2atmpS3281 = _M0L6_2atmpS3282 & 0xff;
    #line 23 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
    _M0L6_2atmpS3280 = _M0MPC14byte4Byte7to__hex(_M0L6_2atmpS3281);
    #line 22 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
    _M0L6_2atmpS3276 = moonbit_add_string(_M0L6_2atmpS3279, _M0L6_2atmpS3280);
    moonbit_decref(_M0L6_2atmpS3280);
    moonbit_decref(_M0L6_2atmpS3279);
    _M0L6_2atmpS3278 = _M0L4codeS1215 & 0xff;
    #line 24 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
    _M0L6_2atmpS3277 = _M0MPC14byte4Byte7to__hex(_M0L6_2atmpS3278);
    #line 22 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\char.mbt"
    _result_4465 = moonbit_add_string(_M0L6_2atmpS3276, _M0L6_2atmpS3277);
    moonbit_decref(_M0L6_2atmpS3277);
    moonbit_decref(_M0L6_2atmpS3276);
    return _result_4465;
  }
}

int32_t _M0FPB7printlnGsE(moonbit_string_t _M0L5inputS1214) {
  moonbit_string_t _M0L6_2atmpS3275;
  #line 36 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\console.mbt"
  #line 37 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\console.mbt"
  _M0L6_2atmpS3275
  = _M0IPC16string6StringPB4Show10to__string(_M0L5inputS1214);
  #line 37 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\console.mbt"
  moonbit_println(_M0L6_2atmpS3275);
  moonbit_decref(_M0L6_2atmpS3275);
  return 0;
}

moonbit_string_t _M0MPC16double6Double10to__string(double _M0L4selfS1213) {
  #line 295 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double.mbt"
  #line 297 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double.mbt"
  return _M0FPB15ryu__to__string(_M0L4selfS1213);
}

moonbit_string_t _M0FPB15ryu__to__string(double _M0L3valS1200) {
  uint64_t _M0L4bitsS1201;
  uint64_t _M0L6_2atmpS3274;
  uint64_t _M0L6_2atmpS3273;
  int32_t _M0L8ieeeSignS1202;
  uint64_t _M0L12ieeeMantissaS1203;
  uint64_t _M0L6_2atmpS3272;
  uint64_t _M0L6_2atmpS3271;
  int32_t _M0L12ieeeExponentS1204;
  int32_t _if__result_4466;
  struct _M0TPB17FloatingDecimal64* _M0L7_2abindS1205;
  struct _M0TPB17FloatingDecimal64* _M0L1vS1206;
  moonbit_string_t _result_4468;
  #line 659 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  if (_M0L3valS1200 == 0x0p+0) {
    return (moonbit_string_t)moonbit_string_literal_44.data;
  }
  _M0L4bitsS1201 = *(int64_t*)&_M0L3valS1200;
  _M0L6_2atmpS3274 = _M0L4bitsS1201 >> 63;
  _M0L6_2atmpS3273 = _M0L6_2atmpS3274 & 1ull;
  _M0L8ieeeSignS1202 = _M0L6_2atmpS3273 != 0ull;
  _M0L12ieeeMantissaS1203 = _M0L4bitsS1201 & 4503599627370495ull;
  _M0L6_2atmpS3272 = _M0L4bitsS1201 >> 52;
  _M0L6_2atmpS3271 = _M0L6_2atmpS3272 & 2047ull;
  _M0L12ieeeExponentS1204 = (int32_t)_M0L6_2atmpS3271;
  if (_M0L12ieeeExponentS1204 == 2047) {
    _if__result_4466 = 1;
  } else if (_M0L12ieeeExponentS1204 == 0) {
    _if__result_4466 = _M0L12ieeeMantissaS1203 == 0ull;
  } else {
    _if__result_4466 = 0;
  }
  if (_if__result_4466) {
    int32_t _M0L6_2atmpS3262 = _M0L12ieeeExponentS1204 != 0;
    int32_t _M0L6_2atmpS3263 = _M0L12ieeeMantissaS1203 != 0ull;
    #line 676 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
    return _M0FPB18copy__special__str(_M0L8ieeeSignS1202, _M0L6_2atmpS3262, _M0L6_2atmpS3263);
  }
  #line 678 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L7_2abindS1205
  = _M0FPB15d2d__small__int(_M0L12ieeeMantissaS1203, _M0L12ieeeExponentS1204);
  if (_M0L7_2abindS1205 == 0) {
    uint32_t _M0L6_2atmpS3264;
    if (_M0L7_2abindS1205) {
      moonbit_decref(_M0L7_2abindS1205);
    }
    _M0L6_2atmpS3264 = *(uint32_t*)&_M0L12ieeeExponentS1204;
    #line 688 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
    _M0L1vS1206 = _M0FPB3d2d(_M0L12ieeeMantissaS1203, _M0L6_2atmpS3264);
  } else {
    struct _M0TPB17FloatingDecimal64* _M0L7_2aSomeS1207 = _M0L7_2abindS1205;
    struct _M0TPB17FloatingDecimal64* _M0L4_2afS1208 = _M0L7_2aSomeS1207;
    struct _M0TPB17FloatingDecimal64* _M0L1xS1209 = _M0L4_2afS1208;
    while (1) {
      uint64_t _M0L8mantissaS3270 = _M0L1xS1209->$0;
      uint64_t _M0L1qS1210 = _M0L8mantissaS3270 / 10ull;
      uint64_t _M0L8mantissaS3268 = _M0L1xS1209->$0;
      uint64_t _M0L6_2atmpS3269 = 10ull * _M0L1qS1210;
      uint64_t _M0L1rS1211 = _M0L8mantissaS3268 - _M0L6_2atmpS3269;
      int32_t _M0L8exponentS3267;
      int32_t _M0L6_2atmpS3266;
      struct _M0TPB17FloatingDecimal64* _M0L6_2atmpS3265;
      if (_M0L1rS1211 != 0ull) {
        _M0L1vS1206 = _M0L1xS1209;
        break;
      }
      _M0L8exponentS3267 = _M0L1xS1209->$1;
      moonbit_decref(_M0L1xS1209);
      _M0L6_2atmpS3266 = _M0L8exponentS3267 + 1;
      _M0L6_2atmpS3265
      = (struct _M0TPB17FloatingDecimal64*)moonbit_malloc(sizeof(struct _M0TPB17FloatingDecimal64));
      Moonbit_object_header(_M0L6_2atmpS3265)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0);
      _M0L6_2atmpS3265->$0 = _M0L1qS1210;
      _M0L6_2atmpS3265->$1 = _M0L6_2atmpS3266;
      _M0L1xS1209 = _M0L6_2atmpS3265;
      continue;
      break;
    }
  }
  #line 690 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _result_4468 = _M0FPB9to__chars(_M0L1vS1206, _M0L8ieeeSignS1202);
  moonbit_decref(_M0L1vS1206);
  return _result_4468;
}

struct _M0TPB17FloatingDecimal64* _M0FPB15d2d__small__int(
  uint64_t _M0L12ieeeMantissaS1195,
  int32_t _M0L12ieeeExponentS1197
) {
  uint64_t _M0L2m2S1194;
  int32_t _M0L6_2atmpS3261;
  int32_t _M0L2e2S1196;
  int32_t _M0L6_2atmpS3260;
  uint64_t _M0L6_2atmpS3259;
  uint64_t _M0L4maskS1198;
  uint64_t _M0L8fractionS1199;
  int32_t _M0L6_2atmpS3258;
  uint64_t _M0L6_2atmpS3257;
  struct _M0TPB17FloatingDecimal64* _M0L6_2atmpS3256;
  #line 637 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L2m2S1194 = 4503599627370496ull | _M0L12ieeeMantissaS1195;
  _M0L6_2atmpS3261 = _M0L12ieeeExponentS1197 - 1023;
  _M0L2e2S1196 = _M0L6_2atmpS3261 - 52;
  if (_M0L2e2S1196 > 0) {
    return 0;
  }
  if (_M0L2e2S1196 < -52) {
    return 0;
  }
  _M0L6_2atmpS3260 = -_M0L2e2S1196;
  _M0L6_2atmpS3259 = 1ull << (_M0L6_2atmpS3260 & 63);
  _M0L4maskS1198 = _M0L6_2atmpS3259 - 1ull;
  _M0L8fractionS1199 = _M0L2m2S1194 & _M0L4maskS1198;
  if (_M0L8fractionS1199 != 0ull) {
    return 0;
  }
  _M0L6_2atmpS3258 = -_M0L2e2S1196;
  _M0L6_2atmpS3257 = _M0L2m2S1194 >> (_M0L6_2atmpS3258 & 63);
  _M0L6_2atmpS3256
  = (struct _M0TPB17FloatingDecimal64*)moonbit_malloc(sizeof(struct _M0TPB17FloatingDecimal64));
  Moonbit_object_header(_M0L6_2atmpS3256)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0);
  _M0L6_2atmpS3256->$0 = _M0L6_2atmpS3257;
  _M0L6_2atmpS3256->$1 = 0;
  return _M0L6_2atmpS3256;
}

moonbit_string_t _M0FPB9to__chars(
  struct _M0TPB17FloatingDecimal64* _M0L1vS1162,
  int32_t _M0L4signS1160
) {
  moonbit_bytes_t _M0L6resultS1158;
  int32_t _M0Lm5indexS1159;
  uint64_t _M0L6outputS1161;
  int32_t _M0L7olengthS1163;
  int32_t _M0L8exponentS3255;
  int32_t _M0L6_2atmpS3254;
  int32_t _M0Lm3expS1164;
  int32_t _M0L6_2atmpS3253;
  int32_t _M0L6_2atmpS3251;
  int32_t _M0L18scientificNotationS1165;
  #line 530 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L6resultS1158 = (moonbit_bytes_t)moonbit_make_bytes(25, 0);
  _M0Lm5indexS1159 = 0;
  if (_M0L4signS1160) {
    int32_t _M0L6_2atmpS3125 = _M0Lm5indexS1159;
    int32_t _M0L6_2atmpS3126;
    if (
      _M0L6_2atmpS3125 < 0
      || _M0L6_2atmpS3125 >= Moonbit_array_length(_M0L6resultS1158)
    ) {
      #line 535 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
      moonbit_panic();
    }
    _M0L6resultS1158[_M0L6_2atmpS3125] = 45;
    _M0L6_2atmpS3126 = _M0Lm5indexS1159;
    _M0Lm5indexS1159 = _M0L6_2atmpS3126 + 1;
  }
  _M0L6outputS1161 = _M0L1vS1162->$0;
  #line 539 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L7olengthS1163 = _M0FPB17decimal__length17(_M0L6outputS1161);
  _M0L8exponentS3255 = _M0L1vS1162->$1;
  _M0L6_2atmpS3254 = _M0L8exponentS3255 + _M0L7olengthS1163;
  _M0Lm3expS1164 = _M0L6_2atmpS3254 - 1;
  _M0L6_2atmpS3253 = _M0Lm3expS1164;
  if (_M0L6_2atmpS3253 >= -6) {
    int32_t _M0L6_2atmpS3252 = _M0Lm3expS1164;
    _M0L6_2atmpS3251 = _M0L6_2atmpS3252 < 21;
  } else {
    _M0L6_2atmpS3251 = 0;
  }
  _M0L18scientificNotationS1165 = !_M0L6_2atmpS3251;
  if (_M0L18scientificNotationS1165) {
    int32_t _M0L7_2abindS1166 = _M0L7olengthS1163 - 1;
    uint64_t _M0L6outputS1167;
    int32_t _M0L1iS1168 = 0;
    uint64_t _M0L6outputS1169 = _M0L6outputS1161;
    int32_t _M0L6_2atmpS3127;
    int32_t _M0L6_2atmpS3131;
    int32_t _M0L6_2atmpS3130;
    int32_t _M0L6_2atmpS3129;
    int32_t _M0L6_2atmpS3128;
    int32_t _M0L6_2atmpS3135;
    int32_t _M0L6_2atmpS3136;
    int32_t _M0L6_2atmpS3137;
    int32_t _M0L6_2atmpS3138;
    int32_t _M0L6_2atmpS3139;
    int32_t _M0L6_2atmpS3145;
    int32_t _M0L6_2atmpS3178;
    moonbit_string_t _result_4470;
    while (1) {
      if (_M0L1iS1168 < _M0L7_2abindS1166) {
        uint64_t _M0L1cS1170 = _M0L6outputS1169 % 10ull;
        int32_t _M0L6_2atmpS3184 = _M0Lm5indexS1159;
        int32_t _M0L6_2atmpS3183 = _M0L6_2atmpS3184 + _M0L7olengthS1163;
        int32_t _M0L6_2atmpS3179 = _M0L6_2atmpS3183 - _M0L1iS1168;
        int32_t _M0L6_2atmpS3182 = (int32_t)_M0L1cS1170;
        int32_t _M0L6_2atmpS3181 = 48 + _M0L6_2atmpS3182;
        int32_t _M0L6_2atmpS3180 = _M0L6_2atmpS3181 & 0xff;
        int32_t _M0L6_2atmpS3185;
        uint64_t _M0L6_2atmpS3186;
        if (
          _M0L6_2atmpS3179 < 0
          || _M0L6_2atmpS3179 >= Moonbit_array_length(_M0L6resultS1158)
        ) {
          #line 547 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
          moonbit_panic();
        }
        _M0L6resultS1158[_M0L6_2atmpS3179] = _M0L6_2atmpS3180;
        _M0L6_2atmpS3185 = _M0L1iS1168 + 1;
        _M0L6_2atmpS3186 = _M0L6outputS1169 / 10ull;
        _M0L1iS1168 = _M0L6_2atmpS3185;
        _M0L6outputS1169 = _M0L6_2atmpS3186;
        continue;
      } else {
        _M0L6outputS1167 = _M0L6outputS1169;
      }
      break;
    }
    _M0L6_2atmpS3127 = _M0Lm5indexS1159;
    _M0L6_2atmpS3131 = (int32_t)_M0L6outputS1167;
    _M0L6_2atmpS3130 = _M0L6_2atmpS3131 % 10;
    _M0L6_2atmpS3129 = 48 + _M0L6_2atmpS3130;
    _M0L6_2atmpS3128 = _M0L6_2atmpS3129 & 0xff;
    if (
      _M0L6_2atmpS3127 < 0
      || _M0L6_2atmpS3127 >= Moonbit_array_length(_M0L6resultS1158)
    ) {
      #line 552 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
      moonbit_panic();
    }
    _M0L6resultS1158[_M0L6_2atmpS3127] = _M0L6_2atmpS3128;
    if (_M0L7olengthS1163 > 1) {
      int32_t _M0L6_2atmpS3133 = _M0Lm5indexS1159;
      int32_t _M0L6_2atmpS3132 = _M0L6_2atmpS3133 + 1;
      if (
        _M0L6_2atmpS3132 < 0
        || _M0L6_2atmpS3132 >= Moonbit_array_length(_M0L6resultS1158)
      ) {
        #line 554 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
        moonbit_panic();
      }
      _M0L6resultS1158[_M0L6_2atmpS3132] = 46;
    } else {
      int32_t _M0L6_2atmpS3134 = _M0Lm5indexS1159;
      _M0Lm5indexS1159 = _M0L6_2atmpS3134 - 1;
    }
    _M0L6_2atmpS3135 = _M0Lm5indexS1159;
    _M0L6_2atmpS3136 = _M0L7olengthS1163 + 1;
    _M0Lm5indexS1159 = _M0L6_2atmpS3135 + _M0L6_2atmpS3136;
    _M0L6_2atmpS3137 = _M0Lm5indexS1159;
    if (
      _M0L6_2atmpS3137 < 0
      || _M0L6_2atmpS3137 >= Moonbit_array_length(_M0L6resultS1158)
    ) {
      #line 562 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
      moonbit_panic();
    }
    _M0L6resultS1158[_M0L6_2atmpS3137] = 101;
    _M0L6_2atmpS3138 = _M0Lm5indexS1159;
    _M0Lm5indexS1159 = _M0L6_2atmpS3138 + 1;
    _M0L6_2atmpS3139 = _M0Lm3expS1164;
    if (_M0L6_2atmpS3139 < 0) {
      int32_t _M0L6_2atmpS3140 = _M0Lm5indexS1159;
      int32_t _M0L6_2atmpS3141;
      int32_t _M0L6_2atmpS3142;
      if (
        _M0L6_2atmpS3140 < 0
        || _M0L6_2atmpS3140 >= Moonbit_array_length(_M0L6resultS1158)
      ) {
        #line 565 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
        moonbit_panic();
      }
      _M0L6resultS1158[_M0L6_2atmpS3140] = 45;
      _M0L6_2atmpS3141 = _M0Lm5indexS1159;
      _M0Lm5indexS1159 = _M0L6_2atmpS3141 + 1;
      _M0L6_2atmpS3142 = _M0Lm3expS1164;
      _M0Lm3expS1164 = -_M0L6_2atmpS3142;
    } else {
      int32_t _M0L6_2atmpS3143 = _M0Lm5indexS1159;
      int32_t _M0L6_2atmpS3144;
      if (
        _M0L6_2atmpS3143 < 0
        || _M0L6_2atmpS3143 >= Moonbit_array_length(_M0L6resultS1158)
      ) {
        #line 569 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
        moonbit_panic();
      }
      _M0L6resultS1158[_M0L6_2atmpS3143] = 43;
      _M0L6_2atmpS3144 = _M0Lm5indexS1159;
      _M0Lm5indexS1159 = _M0L6_2atmpS3144 + 1;
    }
    _M0L6_2atmpS3145 = _M0Lm3expS1164;
    if (_M0L6_2atmpS3145 >= 100) {
      int32_t _M0L6_2atmpS3161 = _M0Lm3expS1164;
      int32_t _M0L1aS1172 = _M0L6_2atmpS3161 / 100;
      int32_t _M0L6_2atmpS3160 = _M0Lm3expS1164;
      int32_t _M0L6_2atmpS3159 = _M0L6_2atmpS3160 / 10;
      int32_t _M0L1bS1173 = _M0L6_2atmpS3159 % 10;
      int32_t _M0L6_2atmpS3158 = _M0Lm3expS1164;
      int32_t _M0L1cS1174 = _M0L6_2atmpS3158 % 10;
      int32_t _M0L6_2atmpS3146 = _M0Lm5indexS1159;
      int32_t _M0L6_2atmpS3148 = 48 + _M0L1aS1172;
      int32_t _M0L6_2atmpS3147 = _M0L6_2atmpS3148 & 0xff;
      int32_t _M0L6_2atmpS3152;
      int32_t _M0L6_2atmpS3149;
      int32_t _M0L6_2atmpS3151;
      int32_t _M0L6_2atmpS3150;
      int32_t _M0L6_2atmpS3156;
      int32_t _M0L6_2atmpS3153;
      int32_t _M0L6_2atmpS3155;
      int32_t _M0L6_2atmpS3154;
      int32_t _M0L6_2atmpS3157;
      if (
        _M0L6_2atmpS3146 < 0
        || _M0L6_2atmpS3146 >= Moonbit_array_length(_M0L6resultS1158)
      ) {
        #line 576 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
        moonbit_panic();
      }
      _M0L6resultS1158[_M0L6_2atmpS3146] = _M0L6_2atmpS3147;
      _M0L6_2atmpS3152 = _M0Lm5indexS1159;
      _M0L6_2atmpS3149 = _M0L6_2atmpS3152 + 1;
      _M0L6_2atmpS3151 = 48 + _M0L1bS1173;
      _M0L6_2atmpS3150 = _M0L6_2atmpS3151 & 0xff;
      if (
        _M0L6_2atmpS3149 < 0
        || _M0L6_2atmpS3149 >= Moonbit_array_length(_M0L6resultS1158)
      ) {
        #line 577 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
        moonbit_panic();
      }
      _M0L6resultS1158[_M0L6_2atmpS3149] = _M0L6_2atmpS3150;
      _M0L6_2atmpS3156 = _M0Lm5indexS1159;
      _M0L6_2atmpS3153 = _M0L6_2atmpS3156 + 2;
      _M0L6_2atmpS3155 = 48 + _M0L1cS1174;
      _M0L6_2atmpS3154 = _M0L6_2atmpS3155 & 0xff;
      if (
        _M0L6_2atmpS3153 < 0
        || _M0L6_2atmpS3153 >= Moonbit_array_length(_M0L6resultS1158)
      ) {
        #line 578 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
        moonbit_panic();
      }
      _M0L6resultS1158[_M0L6_2atmpS3153] = _M0L6_2atmpS3154;
      _M0L6_2atmpS3157 = _M0Lm5indexS1159;
      _M0Lm5indexS1159 = _M0L6_2atmpS3157 + 3;
    } else {
      int32_t _M0L6_2atmpS3162 = _M0Lm3expS1164;
      if (_M0L6_2atmpS3162 >= 10) {
        int32_t _M0L6_2atmpS3172 = _M0Lm3expS1164;
        int32_t _M0L1aS1175 = _M0L6_2atmpS3172 / 10;
        int32_t _M0L6_2atmpS3171 = _M0Lm3expS1164;
        int32_t _M0L1bS1176 = _M0L6_2atmpS3171 % 10;
        int32_t _M0L6_2atmpS3163 = _M0Lm5indexS1159;
        int32_t _M0L6_2atmpS3165 = 48 + _M0L1aS1175;
        int32_t _M0L6_2atmpS3164 = _M0L6_2atmpS3165 & 0xff;
        int32_t _M0L6_2atmpS3169;
        int32_t _M0L6_2atmpS3166;
        int32_t _M0L6_2atmpS3168;
        int32_t _M0L6_2atmpS3167;
        int32_t _M0L6_2atmpS3170;
        if (
          _M0L6_2atmpS3163 < 0
          || _M0L6_2atmpS3163 >= Moonbit_array_length(_M0L6resultS1158)
        ) {
          #line 583 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
          moonbit_panic();
        }
        _M0L6resultS1158[_M0L6_2atmpS3163] = _M0L6_2atmpS3164;
        _M0L6_2atmpS3169 = _M0Lm5indexS1159;
        _M0L6_2atmpS3166 = _M0L6_2atmpS3169 + 1;
        _M0L6_2atmpS3168 = 48 + _M0L1bS1176;
        _M0L6_2atmpS3167 = _M0L6_2atmpS3168 & 0xff;
        if (
          _M0L6_2atmpS3166 < 0
          || _M0L6_2atmpS3166 >= Moonbit_array_length(_M0L6resultS1158)
        ) {
          #line 584 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
          moonbit_panic();
        }
        _M0L6resultS1158[_M0L6_2atmpS3166] = _M0L6_2atmpS3167;
        _M0L6_2atmpS3170 = _M0Lm5indexS1159;
        _M0Lm5indexS1159 = _M0L6_2atmpS3170 + 2;
      } else {
        int32_t _M0L6_2atmpS3173 = _M0Lm5indexS1159;
        int32_t _M0L6_2atmpS3176 = _M0Lm3expS1164;
        int32_t _M0L6_2atmpS3175 = 48 + _M0L6_2atmpS3176;
        int32_t _M0L6_2atmpS3174 = _M0L6_2atmpS3175 & 0xff;
        int32_t _M0L6_2atmpS3177;
        if (
          _M0L6_2atmpS3173 < 0
          || _M0L6_2atmpS3173 >= Moonbit_array_length(_M0L6resultS1158)
        ) {
          #line 587 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
          moonbit_panic();
        }
        _M0L6resultS1158[_M0L6_2atmpS3173] = _M0L6_2atmpS3174;
        _M0L6_2atmpS3177 = _M0Lm5indexS1159;
        _M0Lm5indexS1159 = _M0L6_2atmpS3177 + 1;
      }
    }
    _M0L6_2atmpS3178 = _M0Lm5indexS1159;
    #line 590 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
    _result_4470
    = _M0FPB19string__from__bytes(_M0L6resultS1158, 0, _M0L6_2atmpS3178);
    moonbit_decref(_M0L6resultS1158);
    return _result_4470;
  } else {
    int32_t _M0L6_2atmpS3187 = _M0Lm3expS1164;
    int32_t _M0L6_2atmpS3250;
    moonbit_string_t _result_4476;
    if (_M0L6_2atmpS3187 < 0) {
      int32_t _M0L6_2atmpS3188 = _M0Lm5indexS1159;
      int32_t _M0L6_2atmpS3190;
      int32_t _M0L6_2atmpS3189;
      int32_t _M0L6_2atmpS3191;
      int32_t _M0L1iS1177;
      int32_t _M0L6_2atmpS3206;
      int32_t _M0L6_2atmpS3208;
      int32_t _M0L6_2atmpS3207;
      int32_t _M0L7currentS1179;
      int32_t _M0L1iS1180;
      uint64_t _M0L6outputS1181;
      if (
        _M0L6_2atmpS3188 < 0
        || _M0L6_2atmpS3188 >= Moonbit_array_length(_M0L6resultS1158)
      ) {
        #line 595 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
        moonbit_panic();
      }
      _M0L6resultS1158[_M0L6_2atmpS3188] = 48;
      _M0L6_2atmpS3190 = _M0Lm5indexS1159;
      _M0L6_2atmpS3189 = _M0L6_2atmpS3190 + 1;
      if (
        _M0L6_2atmpS3189 < 0
        || _M0L6_2atmpS3189 >= Moonbit_array_length(_M0L6resultS1158)
      ) {
        #line 596 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
        moonbit_panic();
      }
      _M0L6resultS1158[_M0L6_2atmpS3189] = 46;
      _M0L6_2atmpS3191 = _M0Lm5indexS1159;
      _M0Lm5indexS1159 = _M0L6_2atmpS3191 + 2;
      _M0L1iS1177 = -1;
      while (1) {
        int32_t _M0L6_2atmpS3192 = _M0Lm3expS1164;
        if (_M0L1iS1177 > _M0L6_2atmpS3192) {
          int32_t _M0L6_2atmpS3195 = _M0Lm5indexS1159;
          int32_t _M0L6_2atmpS3194 = _M0L6_2atmpS3195 - _M0L1iS1177;
          int32_t _M0L6_2atmpS3193 = _M0L6_2atmpS3194 - 1;
          int32_t _M0L6_2atmpS3196;
          if (
            _M0L6_2atmpS3193 < 0
            || _M0L6_2atmpS3193 >= Moonbit_array_length(_M0L6resultS1158)
          ) {
            #line 599 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
            moonbit_panic();
          }
          _M0L6resultS1158[_M0L6_2atmpS3193] = 48;
          _M0L6_2atmpS3196 = _M0L1iS1177 - 1;
          _M0L1iS1177 = _M0L6_2atmpS3196;
          continue;
        }
        break;
      }
      _M0L6_2atmpS3206 = _M0Lm5indexS1159;
      _M0L6_2atmpS3208 = _M0Lm3expS1164;
      _M0L6_2atmpS3207 = -1 - _M0L6_2atmpS3208;
      _M0L7currentS1179 = _M0L6_2atmpS3206 + _M0L6_2atmpS3207;
      _M0L1iS1180 = 0;
      _M0L6outputS1181 = _M0L6outputS1161;
      while (1) {
        if (_M0L1iS1180 < _M0L7olengthS1163) {
          int32_t _M0L6_2atmpS3203 = _M0L7currentS1179 + _M0L7olengthS1163;
          int32_t _M0L6_2atmpS3202 = _M0L6_2atmpS3203 - _M0L1iS1180;
          int32_t _M0L6_2atmpS3197 = _M0L6_2atmpS3202 - 1;
          uint64_t _M0L6_2atmpS3201 = _M0L6outputS1181 % 10ull;
          int32_t _M0L6_2atmpS3200 = (int32_t)_M0L6_2atmpS3201;
          int32_t _M0L6_2atmpS3199 = 48 + _M0L6_2atmpS3200;
          int32_t _M0L6_2atmpS3198 = _M0L6_2atmpS3199 & 0xff;
          int32_t _M0L6_2atmpS3204;
          uint64_t _M0L6_2atmpS3205;
          if (
            _M0L6_2atmpS3197 < 0
            || _M0L6_2atmpS3197 >= Moonbit_array_length(_M0L6resultS1158)
          ) {
            #line 603 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
            moonbit_panic();
          }
          _M0L6resultS1158[_M0L6_2atmpS3197] = _M0L6_2atmpS3198;
          _M0L6_2atmpS3204 = _M0L1iS1180 + 1;
          _M0L6_2atmpS3205 = _M0L6outputS1181 / 10ull;
          _M0L1iS1180 = _M0L6_2atmpS3204;
          _M0L6outputS1181 = _M0L6_2atmpS3205;
          continue;
        }
        break;
      }
      _M0Lm5indexS1159 = _M0L7currentS1179 + _M0L7olengthS1163;
    } else {
      int32_t _M0L6_2atmpS3210 = _M0Lm3expS1164;
      int32_t _M0L6_2atmpS3209 = _M0L6_2atmpS3210 + 1;
      if (_M0L6_2atmpS3209 >= _M0L7olengthS1163) {
        int32_t _M0L1iS1183 = 0;
        uint64_t _M0L6outputS1184 = _M0L6outputS1161;
        int32_t _M0L6_2atmpS3221;
        int32_t _M0L6_2atmpS3226;
        int32_t _M0L7_2abindS1186;
        int32_t _M0L1iS1187;
        int32_t _M0L6_2atmpS3227;
        int32_t _M0L6_2atmpS3230;
        int32_t _M0L6_2atmpS3229;
        int32_t _M0L6_2atmpS3228;
        while (1) {
          if (_M0L1iS1183 < _M0L7olengthS1163) {
            int32_t _M0L6_2atmpS3218 = _M0Lm5indexS1159;
            int32_t _M0L6_2atmpS3217 = _M0L6_2atmpS3218 + _M0L7olengthS1163;
            int32_t _M0L6_2atmpS3216 = _M0L6_2atmpS3217 - _M0L1iS1183;
            int32_t _M0L6_2atmpS3211 = _M0L6_2atmpS3216 - 1;
            uint64_t _M0L6_2atmpS3215 = _M0L6outputS1184 % 10ull;
            int32_t _M0L6_2atmpS3214 = (int32_t)_M0L6_2atmpS3215;
            int32_t _M0L6_2atmpS3213 = 48 + _M0L6_2atmpS3214;
            int32_t _M0L6_2atmpS3212 = _M0L6_2atmpS3213 & 0xff;
            int32_t _M0L6_2atmpS3219;
            uint64_t _M0L6_2atmpS3220;
            if (
              _M0L6_2atmpS3211 < 0
              || _M0L6_2atmpS3211 >= Moonbit_array_length(_M0L6resultS1158)
            ) {
              #line 610 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
              moonbit_panic();
            }
            _M0L6resultS1158[_M0L6_2atmpS3211] = _M0L6_2atmpS3212;
            _M0L6_2atmpS3219 = _M0L1iS1183 + 1;
            _M0L6_2atmpS3220 = _M0L6outputS1184 / 10ull;
            _M0L1iS1183 = _M0L6_2atmpS3219;
            _M0L6outputS1184 = _M0L6_2atmpS3220;
            continue;
          }
          break;
        }
        _M0L6_2atmpS3221 = _M0Lm5indexS1159;
        _M0Lm5indexS1159 = _M0L6_2atmpS3221 + _M0L7olengthS1163;
        _M0L6_2atmpS3226 = _M0Lm3expS1164;
        _M0L7_2abindS1186 = _M0L6_2atmpS3226 + 1;
        _M0L1iS1187 = _M0L7olengthS1163;
        while (1) {
          if (_M0L1iS1187 < _M0L7_2abindS1186) {
            int32_t _M0L6_2atmpS3224 = _M0Lm5indexS1159;
            int32_t _M0L6_2atmpS3223 = _M0L6_2atmpS3224 + _M0L1iS1187;
            int32_t _M0L6_2atmpS3222 = _M0L6_2atmpS3223 - _M0L7olengthS1163;
            int32_t _M0L6_2atmpS3225;
            if (
              _M0L6_2atmpS3222 < 0
              || _M0L6_2atmpS3222 >= Moonbit_array_length(_M0L6resultS1158)
            ) {
              #line 615 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
              moonbit_panic();
            }
            _M0L6resultS1158[_M0L6_2atmpS3222] = 48;
            _M0L6_2atmpS3225 = _M0L1iS1187 + 1;
            _M0L1iS1187 = _M0L6_2atmpS3225;
            continue;
          }
          break;
        }
        _M0L6_2atmpS3227 = _M0Lm5indexS1159;
        _M0L6_2atmpS3230 = _M0Lm3expS1164;
        _M0L6_2atmpS3229 = _M0L6_2atmpS3230 + 1;
        _M0L6_2atmpS3228 = _M0L6_2atmpS3229 - _M0L7olengthS1163;
        _M0Lm5indexS1159 = _M0L6_2atmpS3227 + _M0L6_2atmpS3228;
      } else {
        int32_t _M0L6_2atmpS3247 = _M0Lm5indexS1159;
        int32_t _M0L6_2atmpS3246 = _M0L6_2atmpS3247 + 1;
        int32_t _M0L1iS1189 = 0;
        int32_t _M0L7currentS1190 = _M0L6_2atmpS3246;
        uint64_t _M0L6outputS1191 = _M0L6outputS1161;
        int32_t _M0L6_2atmpS3248;
        int32_t _M0L6_2atmpS3249;
        while (1) {
          if (_M0L1iS1189 < _M0L7olengthS1163) {
            int32_t _M0L6_2atmpS3242 = _M0L7olengthS1163 - _M0L1iS1189;
            int32_t _M0L6_2atmpS3240 = _M0L6_2atmpS3242 - 1;
            int32_t _M0L6_2atmpS3241 = _M0Lm3expS1164;
            int32_t _M0L7currentS1192;
            int32_t _M0L6_2atmpS3237;
            int32_t _M0L6_2atmpS3236;
            int32_t _M0L6_2atmpS3231;
            uint64_t _M0L6_2atmpS3235;
            int32_t _M0L6_2atmpS3234;
            int32_t _M0L6_2atmpS3233;
            int32_t _M0L6_2atmpS3232;
            int32_t _M0L6_2atmpS3238;
            uint64_t _M0L6_2atmpS3239;
            if (_M0L6_2atmpS3240 == _M0L6_2atmpS3241) {
              int32_t _M0L6_2atmpS3245 =
                _M0L7currentS1190 + _M0L7olengthS1163;
              int32_t _M0L6_2atmpS3244 = _M0L6_2atmpS3245 - _M0L1iS1189;
              int32_t _M0L6_2atmpS3243 = _M0L6_2atmpS3244 - 1;
              if (
                _M0L6_2atmpS3243 < 0
                || _M0L6_2atmpS3243 >= Moonbit_array_length(_M0L6resultS1158)
              ) {
                #line 622 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
                moonbit_panic();
              }
              _M0L6resultS1158[_M0L6_2atmpS3243] = 46;
              _M0L7currentS1192 = _M0L7currentS1190 - 1;
            } else {
              _M0L7currentS1192 = _M0L7currentS1190;
            }
            _M0L6_2atmpS3237 = _M0L7currentS1192 + _M0L7olengthS1163;
            _M0L6_2atmpS3236 = _M0L6_2atmpS3237 - _M0L1iS1189;
            _M0L6_2atmpS3231 = _M0L6_2atmpS3236 - 1;
            _M0L6_2atmpS3235 = _M0L6outputS1191 % 10ull;
            _M0L6_2atmpS3234 = (int32_t)_M0L6_2atmpS3235;
            _M0L6_2atmpS3233 = 48 + _M0L6_2atmpS3234;
            _M0L6_2atmpS3232 = _M0L6_2atmpS3233 & 0xff;
            if (
              _M0L6_2atmpS3231 < 0
              || _M0L6_2atmpS3231 >= Moonbit_array_length(_M0L6resultS1158)
            ) {
              #line 627 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
              moonbit_panic();
            }
            _M0L6resultS1158[_M0L6_2atmpS3231] = _M0L6_2atmpS3232;
            _M0L6_2atmpS3238 = _M0L1iS1189 + 1;
            _M0L6_2atmpS3239 = _M0L6outputS1191 / 10ull;
            _M0L1iS1189 = _M0L6_2atmpS3238;
            _M0L7currentS1190 = _M0L7currentS1192;
            _M0L6outputS1191 = _M0L6_2atmpS3239;
            continue;
          }
          break;
        }
        _M0L6_2atmpS3248 = _M0Lm5indexS1159;
        _M0L6_2atmpS3249 = _M0L7olengthS1163 + 1;
        _M0Lm5indexS1159 = _M0L6_2atmpS3248 + _M0L6_2atmpS3249;
      }
    }
    _M0L6_2atmpS3250 = _M0Lm5indexS1159;
    #line 632 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
    _result_4476
    = _M0FPB19string__from__bytes(_M0L6resultS1158, 0, _M0L6_2atmpS3250);
    moonbit_decref(_M0L6resultS1158);
    return _result_4476;
  }
}

struct _M0TPB17FloatingDecimal64* _M0FPB3d2d(
  uint64_t _M0L12ieeeMantissaS1104,
  uint32_t _M0L12ieeeExponentS1103
) {
  int32_t _M0Lm2e2S1101;
  uint64_t _M0Lm2m2S1102;
  uint64_t _M0L6_2atmpS3124;
  uint64_t _M0L6_2atmpS3123;
  int32_t _M0L4evenS1105;
  uint64_t _M0L6_2atmpS3122;
  uint64_t _M0L2mvS1106;
  int32_t _M0L7mmShiftS1107;
  uint64_t _M0Lm2vrS1108;
  uint64_t _M0Lm2vpS1109;
  uint64_t _M0Lm2vmS1110;
  int32_t _M0Lm3e10S1111;
  int32_t _M0Lm17vmIsTrailingZerosS1112;
  int32_t _M0Lm17vrIsTrailingZerosS1113;
  int32_t _M0L6_2atmpS3024;
  int32_t _M0Lm7removedS1132;
  int32_t _M0Lm16lastRemovedDigitS1133;
  uint64_t _M0Lm6outputS1134;
  int32_t _M0L6_2atmpS3120;
  int32_t _M0L6_2atmpS3121;
  int32_t _M0L3expS1157;
  uint64_t _M0L6_2atmpS3119;
  struct _M0TPB17FloatingDecimal64* _block_4482;
  #line 347 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0Lm2e2S1101 = 0;
  _M0Lm2m2S1102 = 0ull;
  if (_M0L12ieeeExponentS1103 == 0u) {
    _M0Lm2e2S1101 = -1076;
    _M0Lm2m2S1102 = _M0L12ieeeMantissaS1104;
  } else {
    int32_t _M0L6_2atmpS3023 = *(int32_t*)&_M0L12ieeeExponentS1103;
    int32_t _M0L6_2atmpS3022 = _M0L6_2atmpS3023 - 1023;
    int32_t _M0L6_2atmpS3021 = _M0L6_2atmpS3022 - 52;
    _M0Lm2e2S1101 = _M0L6_2atmpS3021 - 2;
    _M0Lm2m2S1102 = 4503599627370496ull | _M0L12ieeeMantissaS1104;
  }
  _M0L6_2atmpS3124 = _M0Lm2m2S1102;
  _M0L6_2atmpS3123 = _M0L6_2atmpS3124 & 1ull;
  _M0L4evenS1105 = _M0L6_2atmpS3123 == 0ull;
  _M0L6_2atmpS3122 = _M0Lm2m2S1102;
  _M0L2mvS1106 = 4ull * _M0L6_2atmpS3122;
  if (_M0L12ieeeMantissaS1104 != 0ull) {
    _M0L7mmShiftS1107 = 1;
  } else {
    _M0L7mmShiftS1107 = _M0L12ieeeExponentS1103 <= 1u;
  }
  _M0Lm2vrS1108 = 0ull;
  _M0Lm2vpS1109 = 0ull;
  _M0Lm2vmS1110 = 0ull;
  _M0Lm3e10S1111 = 0;
  _M0Lm17vmIsTrailingZerosS1112 = 0;
  _M0Lm17vrIsTrailingZerosS1113 = 0;
  _M0L6_2atmpS3024 = _M0Lm2e2S1101;
  if (_M0L6_2atmpS3024 >= 0) {
    int32_t _M0L6_2atmpS3046 = _M0Lm2e2S1101;
    int32_t _M0L6_2atmpS3042;
    int32_t _M0L6_2atmpS3045;
    int32_t _M0L6_2atmpS3044;
    int32_t _M0L6_2atmpS3043;
    int32_t _M0L1qS1114;
    int32_t _M0L6_2atmpS3041;
    int32_t _M0L6_2atmpS3040;
    int32_t _M0L1kS1115;
    int32_t _M0L6_2atmpS3039;
    int32_t _M0L6_2atmpS3038;
    int32_t _M0L6_2atmpS3037;
    int32_t _M0L1iS1116;
    struct _M0TPB8Pow5Pair _M0L4pow5S1117;
    uint64_t _M0L6_2atmpS3036;
    struct _M0TPB19MulShiftAll64Result _M0L7_2abindS1118;
    uint64_t _M0L8_2avrOutS1119;
    uint64_t _M0L8_2avpOutS1120;
    uint64_t _M0L8_2avmOutS1121;
    #line 383 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
    _M0L6_2atmpS3042 = _M0FPB9log10Pow2(_M0L6_2atmpS3046);
    _M0L6_2atmpS3045 = _M0Lm2e2S1101;
    _M0L6_2atmpS3044 = _M0L6_2atmpS3045 > 3;
    #line 383 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
    _M0L6_2atmpS3043 = _M0MPC14bool4Bool7to__int(_M0L6_2atmpS3044);
    _M0L1qS1114 = _M0L6_2atmpS3042 - _M0L6_2atmpS3043;
    _M0Lm3e10S1111 = _M0L1qS1114;
    #line 385 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
    _M0L6_2atmpS3041 = _M0FPB8pow5bits(_M0L1qS1114);
    _M0L6_2atmpS3040 = 125 + _M0L6_2atmpS3041;
    _M0L1kS1115 = _M0L6_2atmpS3040 - 1;
    _M0L6_2atmpS3039 = _M0Lm2e2S1101;
    _M0L6_2atmpS3038 = -_M0L6_2atmpS3039;
    _M0L6_2atmpS3037 = _M0L6_2atmpS3038 + _M0L1qS1114;
    _M0L1iS1116 = _M0L6_2atmpS3037 + _M0L1kS1115;
    #line 387 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
    _M0L4pow5S1117 = _M0FPB22double__computeInvPow5(_M0L1qS1114);
    _M0L6_2atmpS3036 = _M0Lm2m2S1102;
    #line 388 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
    _M0L7_2abindS1118
    = _M0FPB13mulShiftAll64(_M0L6_2atmpS3036, _M0L4pow5S1117, _M0L1iS1116, _M0L7mmShiftS1107);
    _M0L8_2avrOutS1119 = _M0L7_2abindS1118.$0;
    _M0L8_2avpOutS1120 = _M0L7_2abindS1118.$1;
    _M0L8_2avmOutS1121 = _M0L7_2abindS1118.$2;
    _M0Lm2vrS1108 = _M0L8_2avrOutS1119;
    _M0Lm2vpS1109 = _M0L8_2avpOutS1120;
    _M0Lm2vmS1110 = _M0L8_2avmOutS1121;
    if (_M0L1qS1114 <= 21) {
      int32_t _M0L6_2atmpS3032 = (int32_t)_M0L2mvS1106;
      uint64_t _M0L6_2atmpS3035 = _M0L2mvS1106 / 5ull;
      int32_t _M0L6_2atmpS3034 = (int32_t)_M0L6_2atmpS3035;
      int32_t _M0L6_2atmpS3033 = 5 * _M0L6_2atmpS3034;
      int32_t _M0L6mvMod5S1122 = _M0L6_2atmpS3032 - _M0L6_2atmpS3033;
      if (_M0L6mvMod5S1122 == 0) {
        #line 400 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
        _M0Lm17vrIsTrailingZerosS1113
        = _M0FPB18multipleOfPowerOf5(_M0L2mvS1106, _M0L1qS1114);
      } else if (_M0L4evenS1105) {
        uint64_t _M0L6_2atmpS3026 = _M0L2mvS1106 - 1ull;
        uint64_t _M0L6_2atmpS3027;
        uint64_t _M0L6_2atmpS3025;
        #line 406 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
        _M0L6_2atmpS3027 = _M0MPC14bool4Bool10to__uint64(_M0L7mmShiftS1107);
        _M0L6_2atmpS3025 = _M0L6_2atmpS3026 - _M0L6_2atmpS3027;
        #line 405 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
        _M0Lm17vmIsTrailingZerosS1112
        = _M0FPB18multipleOfPowerOf5(_M0L6_2atmpS3025, _M0L1qS1114);
      } else {
        uint64_t _M0L6_2atmpS3028 = _M0Lm2vpS1109;
        uint64_t _M0L6_2atmpS3031 = _M0L2mvS1106 + 2ull;
        int32_t _M0L6_2atmpS3030;
        uint64_t _M0L6_2atmpS3029;
        #line 410 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
        _M0L6_2atmpS3030
        = _M0FPB18multipleOfPowerOf5(_M0L6_2atmpS3031, _M0L1qS1114);
        #line 410 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
        _M0L6_2atmpS3029 = _M0MPC14bool4Bool10to__uint64(_M0L6_2atmpS3030);
        _M0Lm2vpS1109 = _M0L6_2atmpS3028 - _M0L6_2atmpS3029;
      }
    }
  } else {
    int32_t _M0L6_2atmpS3060 = _M0Lm2e2S1101;
    int32_t _M0L6_2atmpS3059 = -_M0L6_2atmpS3060;
    int32_t _M0L6_2atmpS3054;
    int32_t _M0L6_2atmpS3058;
    int32_t _M0L6_2atmpS3057;
    int32_t _M0L6_2atmpS3056;
    int32_t _M0L6_2atmpS3055;
    int32_t _M0L1qS1123;
    int32_t _M0L6_2atmpS3047;
    int32_t _M0L6_2atmpS3053;
    int32_t _M0L6_2atmpS3052;
    int32_t _M0L1iS1124;
    int32_t _M0L6_2atmpS3051;
    int32_t _M0L1kS1125;
    int32_t _M0L1jS1126;
    struct _M0TPB8Pow5Pair _M0L4pow5S1127;
    uint64_t _M0L6_2atmpS3050;
    struct _M0TPB19MulShiftAll64Result _M0L7_2abindS1128;
    uint64_t _M0L8_2avrOutS1129;
    uint64_t _M0L8_2avpOutS1130;
    uint64_t _M0L8_2avmOutS1131;
    #line 415 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
    _M0L6_2atmpS3054 = _M0FPB9log10Pow5(_M0L6_2atmpS3059);
    _M0L6_2atmpS3058 = _M0Lm2e2S1101;
    _M0L6_2atmpS3057 = -_M0L6_2atmpS3058;
    _M0L6_2atmpS3056 = _M0L6_2atmpS3057 > 1;
    #line 415 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
    _M0L6_2atmpS3055 = _M0MPC14bool4Bool7to__int(_M0L6_2atmpS3056);
    _M0L1qS1123 = _M0L6_2atmpS3054 - _M0L6_2atmpS3055;
    _M0L6_2atmpS3047 = _M0Lm2e2S1101;
    _M0Lm3e10S1111 = _M0L1qS1123 + _M0L6_2atmpS3047;
    _M0L6_2atmpS3053 = _M0Lm2e2S1101;
    _M0L6_2atmpS3052 = -_M0L6_2atmpS3053;
    _M0L1iS1124 = _M0L6_2atmpS3052 - _M0L1qS1123;
    #line 418 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
    _M0L6_2atmpS3051 = _M0FPB8pow5bits(_M0L1iS1124);
    _M0L1kS1125 = _M0L6_2atmpS3051 - 125;
    _M0L1jS1126 = _M0L1qS1123 - _M0L1kS1125;
    #line 420 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
    _M0L4pow5S1127 = _M0FPB19double__computePow5(_M0L1iS1124);
    _M0L6_2atmpS3050 = _M0Lm2m2S1102;
    #line 421 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
    _M0L7_2abindS1128
    = _M0FPB13mulShiftAll64(_M0L6_2atmpS3050, _M0L4pow5S1127, _M0L1jS1126, _M0L7mmShiftS1107);
    _M0L8_2avrOutS1129 = _M0L7_2abindS1128.$0;
    _M0L8_2avpOutS1130 = _M0L7_2abindS1128.$1;
    _M0L8_2avmOutS1131 = _M0L7_2abindS1128.$2;
    _M0Lm2vrS1108 = _M0L8_2avrOutS1129;
    _M0Lm2vpS1109 = _M0L8_2avpOutS1130;
    _M0Lm2vmS1110 = _M0L8_2avmOutS1131;
    if (_M0L1qS1123 <= 1) {
      _M0Lm17vrIsTrailingZerosS1113 = 1;
      if (_M0L4evenS1105) {
        int32_t _M0L6_2atmpS3048;
        #line 432 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
        _M0L6_2atmpS3048 = _M0MPC14bool4Bool7to__int(_M0L7mmShiftS1107);
        _M0Lm17vmIsTrailingZerosS1112 = _M0L6_2atmpS3048 == 1;
      } else {
        uint64_t _M0L6_2atmpS3049 = _M0Lm2vpS1109;
        _M0Lm2vpS1109 = _M0L6_2atmpS3049 - 1ull;
      }
    } else if (_M0L1qS1123 < 63) {
      #line 437 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
      _M0Lm17vrIsTrailingZerosS1113
      = _M0FPB18multipleOfPowerOf2(_M0L2mvS1106, _M0L1qS1123);
    }
  }
  _M0Lm7removedS1132 = 0;
  _M0Lm16lastRemovedDigitS1133 = 0;
  _M0Lm6outputS1134 = 0ull;
  if (_M0Lm17vmIsTrailingZerosS1112 || _M0Lm17vrIsTrailingZerosS1113) {
    int32_t _if__result_4479;
    uint64_t _M0L6_2atmpS3090;
    uint64_t _M0L6_2atmpS3096;
    uint64_t _M0L6_2atmpS3097;
    int32_t _if__result_4480;
    int32_t _M0L6_2atmpS3093;
    int64_t _M0L6_2atmpS3092;
    uint64_t _M0L6_2atmpS3091;
    while (1) {
      uint64_t _M0L6_2atmpS3073 = _M0Lm2vpS1109;
      uint64_t _M0L7vpDiv10S1135 = _M0L6_2atmpS3073 / 10ull;
      uint64_t _M0L6_2atmpS3072 = _M0Lm2vmS1110;
      uint64_t _M0L7vmDiv10S1136 = _M0L6_2atmpS3072 / 10ull;
      uint64_t _M0L6_2atmpS3071;
      int32_t _M0L6_2atmpS3068;
      int32_t _M0L6_2atmpS3070;
      int32_t _M0L6_2atmpS3069;
      int32_t _M0L7vmMod10S1138;
      uint64_t _M0L6_2atmpS3067;
      uint64_t _M0L7vrDiv10S1139;
      uint64_t _M0L6_2atmpS3066;
      int32_t _M0L6_2atmpS3063;
      int32_t _M0L6_2atmpS3065;
      int32_t _M0L6_2atmpS3064;
      int32_t _M0L7vrMod10S1140;
      int32_t _M0L6_2atmpS3062;
      if (_M0L7vpDiv10S1135 <= _M0L7vmDiv10S1136) {
        break;
      }
      _M0L6_2atmpS3071 = _M0Lm2vmS1110;
      _M0L6_2atmpS3068 = (int32_t)_M0L6_2atmpS3071;
      _M0L6_2atmpS3070 = (int32_t)_M0L7vmDiv10S1136;
      _M0L6_2atmpS3069 = 10 * _M0L6_2atmpS3070;
      _M0L7vmMod10S1138 = _M0L6_2atmpS3068 - _M0L6_2atmpS3069;
      _M0L6_2atmpS3067 = _M0Lm2vrS1108;
      _M0L7vrDiv10S1139 = _M0L6_2atmpS3067 / 10ull;
      _M0L6_2atmpS3066 = _M0Lm2vrS1108;
      _M0L6_2atmpS3063 = (int32_t)_M0L6_2atmpS3066;
      _M0L6_2atmpS3065 = (int32_t)_M0L7vrDiv10S1139;
      _M0L6_2atmpS3064 = 10 * _M0L6_2atmpS3065;
      _M0L7vrMod10S1140 = _M0L6_2atmpS3063 - _M0L6_2atmpS3064;
      if (_M0Lm17vmIsTrailingZerosS1112) {
        _M0Lm17vmIsTrailingZerosS1112 = _M0L7vmMod10S1138 == 0;
      } else {
        _M0Lm17vmIsTrailingZerosS1112 = 0;
      }
      if (_M0Lm17vrIsTrailingZerosS1113) {
        int32_t _M0L6_2atmpS3061 = _M0Lm16lastRemovedDigitS1133;
        _M0Lm17vrIsTrailingZerosS1113 = _M0L6_2atmpS3061 == 0;
      } else {
        _M0Lm17vrIsTrailingZerosS1113 = 0;
      }
      _M0Lm16lastRemovedDigitS1133 = _M0L7vrMod10S1140;
      _M0Lm2vrS1108 = _M0L7vrDiv10S1139;
      _M0Lm2vpS1109 = _M0L7vpDiv10S1135;
      _M0Lm2vmS1110 = _M0L7vmDiv10S1136;
      _M0L6_2atmpS3062 = _M0Lm7removedS1132;
      _M0Lm7removedS1132 = _M0L6_2atmpS3062 + 1;
      continue;
      break;
    }
    if (_M0Lm17vmIsTrailingZerosS1112) {
      while (1) {
        uint64_t _M0L6_2atmpS3086 = _M0Lm2vmS1110;
        uint64_t _M0L7vmDiv10S1141 = _M0L6_2atmpS3086 / 10ull;
        uint64_t _M0L6_2atmpS3085 = _M0Lm2vmS1110;
        int32_t _M0L6_2atmpS3082 = (int32_t)_M0L6_2atmpS3085;
        int32_t _M0L6_2atmpS3084 = (int32_t)_M0L7vmDiv10S1141;
        int32_t _M0L6_2atmpS3083 = 10 * _M0L6_2atmpS3084;
        int32_t _M0L7vmMod10S1142 = _M0L6_2atmpS3082 - _M0L6_2atmpS3083;
        uint64_t _M0L6_2atmpS3081;
        uint64_t _M0L7vpDiv10S1144;
        uint64_t _M0L6_2atmpS3080;
        uint64_t _M0L7vrDiv10S1145;
        uint64_t _M0L6_2atmpS3079;
        int32_t _M0L6_2atmpS3076;
        int32_t _M0L6_2atmpS3078;
        int32_t _M0L6_2atmpS3077;
        int32_t _M0L7vrMod10S1146;
        int32_t _M0L6_2atmpS3075;
        if (_M0L7vmMod10S1142 != 0) {
          break;
        }
        _M0L6_2atmpS3081 = _M0Lm2vpS1109;
        _M0L7vpDiv10S1144 = _M0L6_2atmpS3081 / 10ull;
        _M0L6_2atmpS3080 = _M0Lm2vrS1108;
        _M0L7vrDiv10S1145 = _M0L6_2atmpS3080 / 10ull;
        _M0L6_2atmpS3079 = _M0Lm2vrS1108;
        _M0L6_2atmpS3076 = (int32_t)_M0L6_2atmpS3079;
        _M0L6_2atmpS3078 = (int32_t)_M0L7vrDiv10S1145;
        _M0L6_2atmpS3077 = 10 * _M0L6_2atmpS3078;
        _M0L7vrMod10S1146 = _M0L6_2atmpS3076 - _M0L6_2atmpS3077;
        if (_M0Lm17vrIsTrailingZerosS1113) {
          int32_t _M0L6_2atmpS3074 = _M0Lm16lastRemovedDigitS1133;
          _M0Lm17vrIsTrailingZerosS1113 = _M0L6_2atmpS3074 == 0;
        } else {
          _M0Lm17vrIsTrailingZerosS1113 = 0;
        }
        _M0Lm16lastRemovedDigitS1133 = _M0L7vrMod10S1146;
        _M0Lm2vrS1108 = _M0L7vrDiv10S1145;
        _M0Lm2vpS1109 = _M0L7vpDiv10S1144;
        _M0Lm2vmS1110 = _M0L7vmDiv10S1141;
        _M0L6_2atmpS3075 = _M0Lm7removedS1132;
        _M0Lm7removedS1132 = _M0L6_2atmpS3075 + 1;
        continue;
        break;
      }
    }
    if (_M0Lm17vrIsTrailingZerosS1113) {
      int32_t _M0L6_2atmpS3089 = _M0Lm16lastRemovedDigitS1133;
      if (_M0L6_2atmpS3089 == 5) {
        uint64_t _M0L6_2atmpS3088 = _M0Lm2vrS1108;
        uint64_t _M0L6_2atmpS3087 = _M0L6_2atmpS3088 % 2ull;
        _if__result_4479 = _M0L6_2atmpS3087 == 0ull;
      } else {
        _if__result_4479 = 0;
      }
    } else {
      _if__result_4479 = 0;
    }
    if (_if__result_4479) {
      _M0Lm16lastRemovedDigitS1133 = 4;
    }
    _M0L6_2atmpS3090 = _M0Lm2vrS1108;
    _M0L6_2atmpS3096 = _M0Lm2vrS1108;
    _M0L6_2atmpS3097 = _M0Lm2vmS1110;
    if (_M0L6_2atmpS3096 == _M0L6_2atmpS3097) {
      if (!_M0L4evenS1105) {
        _if__result_4480 = 1;
      } else {
        int32_t _M0L6_2atmpS3095 = _M0Lm17vmIsTrailingZerosS1112;
        _if__result_4480 = !_M0L6_2atmpS3095;
      }
    } else {
      _if__result_4480 = 0;
    }
    if (_if__result_4480) {
      _M0L6_2atmpS3093 = 1;
    } else {
      int32_t _M0L6_2atmpS3094 = _M0Lm16lastRemovedDigitS1133;
      _M0L6_2atmpS3093 = _M0L6_2atmpS3094 >= 5;
    }
    #line 487 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
    _M0L6_2atmpS3092 = _M0MPC14bool4Bool9to__int64(_M0L6_2atmpS3093);
    _M0L6_2atmpS3091 = *(uint64_t*)&_M0L6_2atmpS3092;
    _M0Lm6outputS1134 = _M0L6_2atmpS3090 + _M0L6_2atmpS3091;
  } else {
    int32_t _M0Lm7roundUpS1147 = 0;
    uint64_t _M0L6_2atmpS3118 = _M0Lm2vpS1109;
    uint64_t _M0L8vpDiv100S1148 = _M0L6_2atmpS3118 / 100ull;
    uint64_t _M0L6_2atmpS3117 = _M0Lm2vmS1110;
    uint64_t _M0L8vmDiv100S1149 = _M0L6_2atmpS3117 / 100ull;
    uint64_t _M0L6_2atmpS3112;
    uint64_t _M0L6_2atmpS3115;
    uint64_t _M0L6_2atmpS3116;
    int32_t _M0L6_2atmpS3114;
    uint64_t _M0L6_2atmpS3113;
    if (_M0L8vpDiv100S1148 > _M0L8vmDiv100S1149) {
      uint64_t _M0L6_2atmpS3103 = _M0Lm2vrS1108;
      uint64_t _M0L8vrDiv100S1150 = _M0L6_2atmpS3103 / 100ull;
      uint64_t _M0L6_2atmpS3102 = _M0Lm2vrS1108;
      int32_t _M0L6_2atmpS3099 = (int32_t)_M0L6_2atmpS3102;
      int32_t _M0L6_2atmpS3101 = (int32_t)_M0L8vrDiv100S1150;
      int32_t _M0L6_2atmpS3100 = 100 * _M0L6_2atmpS3101;
      int32_t _M0L8vrMod100S1151 = _M0L6_2atmpS3099 - _M0L6_2atmpS3100;
      int32_t _M0L6_2atmpS3098;
      _M0Lm7roundUpS1147 = _M0L8vrMod100S1151 >= 50;
      _M0Lm2vrS1108 = _M0L8vrDiv100S1150;
      _M0Lm2vpS1109 = _M0L8vpDiv100S1148;
      _M0Lm2vmS1110 = _M0L8vmDiv100S1149;
      _M0L6_2atmpS3098 = _M0Lm7removedS1132;
      _M0Lm7removedS1132 = _M0L6_2atmpS3098 + 2;
    }
    while (1) {
      uint64_t _M0L6_2atmpS3111 = _M0Lm2vpS1109;
      uint64_t _M0L7vpDiv10S1152 = _M0L6_2atmpS3111 / 10ull;
      uint64_t _M0L6_2atmpS3110 = _M0Lm2vmS1110;
      uint64_t _M0L7vmDiv10S1153 = _M0L6_2atmpS3110 / 10ull;
      uint64_t _M0L6_2atmpS3109;
      uint64_t _M0L7vrDiv10S1155;
      uint64_t _M0L6_2atmpS3108;
      int32_t _M0L6_2atmpS3105;
      int32_t _M0L6_2atmpS3107;
      int32_t _M0L6_2atmpS3106;
      int32_t _M0L7vrMod10S1156;
      int32_t _M0L6_2atmpS3104;
      if (_M0L7vpDiv10S1152 <= _M0L7vmDiv10S1153) {
        break;
      }
      _M0L6_2atmpS3109 = _M0Lm2vrS1108;
      _M0L7vrDiv10S1155 = _M0L6_2atmpS3109 / 10ull;
      _M0L6_2atmpS3108 = _M0Lm2vrS1108;
      _M0L6_2atmpS3105 = (int32_t)_M0L6_2atmpS3108;
      _M0L6_2atmpS3107 = (int32_t)_M0L7vrDiv10S1155;
      _M0L6_2atmpS3106 = 10 * _M0L6_2atmpS3107;
      _M0L7vrMod10S1156 = _M0L6_2atmpS3105 - _M0L6_2atmpS3106;
      _M0Lm7roundUpS1147 = _M0L7vrMod10S1156 >= 5;
      _M0Lm2vrS1108 = _M0L7vrDiv10S1155;
      _M0Lm2vpS1109 = _M0L7vpDiv10S1152;
      _M0Lm2vmS1110 = _M0L7vmDiv10S1153;
      _M0L6_2atmpS3104 = _M0Lm7removedS1132;
      _M0Lm7removedS1132 = _M0L6_2atmpS3104 + 1;
      continue;
      break;
    }
    _M0L6_2atmpS3112 = _M0Lm2vrS1108;
    _M0L6_2atmpS3115 = _M0Lm2vrS1108;
    _M0L6_2atmpS3116 = _M0Lm2vmS1110;
    _M0L6_2atmpS3114
    = _M0L6_2atmpS3115 == _M0L6_2atmpS3116 || _M0Lm7roundUpS1147;
    #line 522 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
    _M0L6_2atmpS3113 = _M0MPC14bool4Bool10to__uint64(_M0L6_2atmpS3114);
    _M0Lm6outputS1134 = _M0L6_2atmpS3112 + _M0L6_2atmpS3113;
  }
  _M0L6_2atmpS3120 = _M0Lm3e10S1111;
  _M0L6_2atmpS3121 = _M0Lm7removedS1132;
  _M0L3expS1157 = _M0L6_2atmpS3120 + _M0L6_2atmpS3121;
  _M0L6_2atmpS3119 = _M0Lm6outputS1134;
  _block_4482
  = (struct _M0TPB17FloatingDecimal64*)moonbit_malloc(sizeof(struct _M0TPB17FloatingDecimal64));
  Moonbit_object_header(_block_4482)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0);
  _block_4482->$0 = _M0L6_2atmpS3119;
  _block_4482->$1 = _M0L3expS1157;
  return _block_4482;
}

uint64_t _M0MPC14bool4Bool10to__uint64(int32_t _M0L4selfS1100) {
  #line 110 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\bool.mbt"
  if (_M0L4selfS1100) {
    return 1ull;
  } else {
    return 0ull;
  }
}

int64_t _M0MPC14bool4Bool9to__int64(int32_t _M0L4selfS1099) {
  #line 58 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\bool.mbt"
  if (_M0L4selfS1099) {
    return 1ll;
  } else {
    return 0ll;
  }
}

int32_t _M0MPC14bool4Bool7to__int(int32_t _M0L4selfS1098) {
  #line 32 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\bool.mbt"
  if (_M0L4selfS1098) {
    return 1;
  } else {
    return 0;
  }
}

int32_t _M0FPB17decimal__length17(uint64_t _M0L1vS1097) {
  #line 280 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  if (_M0L1vS1097 >= 10000000000000000ull) {
    return 17;
  }
  if (_M0L1vS1097 >= 1000000000000000ull) {
    return 16;
  }
  if (_M0L1vS1097 >= 100000000000000ull) {
    return 15;
  }
  if (_M0L1vS1097 >= 10000000000000ull) {
    return 14;
  }
  if (_M0L1vS1097 >= 1000000000000ull) {
    return 13;
  }
  if (_M0L1vS1097 >= 100000000000ull) {
    return 12;
  }
  if (_M0L1vS1097 >= 10000000000ull) {
    return 11;
  }
  if (_M0L1vS1097 >= 1000000000ull) {
    return 10;
  }
  if (_M0L1vS1097 >= 100000000ull) {
    return 9;
  }
  if (_M0L1vS1097 >= 10000000ull) {
    return 8;
  }
  if (_M0L1vS1097 >= 1000000ull) {
    return 7;
  }
  if (_M0L1vS1097 >= 100000ull) {
    return 6;
  }
  if (_M0L1vS1097 >= 10000ull) {
    return 5;
  }
  if (_M0L1vS1097 >= 1000ull) {
    return 4;
  }
  if (_M0L1vS1097 >= 100ull) {
    return 3;
  }
  if (_M0L1vS1097 >= 10ull) {
    return 2;
  }
  return 1;
}

struct _M0TPB8Pow5Pair _M0FPB22double__computeInvPow5(int32_t _M0L1iS1080) {
  int32_t _M0L6_2atmpS3020;
  int32_t _M0L6_2atmpS3019;
  int32_t _M0L4baseS1079;
  int32_t _M0L5base2S1081;
  int32_t _M0L6offsetS1082;
  int32_t _M0L6_2atmpS3018;
  uint64_t _M0L4mul0S1083;
  int32_t _M0L6_2atmpS3017;
  int32_t _M0L6_2atmpS3016;
  uint64_t _M0L4mul1S1084;
  uint64_t _M0L1mS1085;
  struct _M0TPB7Umul128 _M0L7_2abindS1086;
  uint64_t _M0L7_2alow1S1087;
  uint64_t _M0L8_2ahigh1S1088;
  struct _M0TPB7Umul128 _M0L7_2abindS1089;
  uint64_t _M0L7_2alow0S1090;
  uint64_t _M0L8_2ahigh0S1091;
  uint64_t _M0L3sumS1092;
  uint64_t _M0Lm5high1S1093;
  int32_t _M0L6_2atmpS3014;
  int32_t _M0L6_2atmpS3015;
  int32_t _M0L5deltaS1094;
  uint64_t _M0L6_2atmpS3013;
  uint64_t _M0L6_2atmpS3005;
  int32_t _M0L6_2atmpS3012;
  uint32_t _M0L6_2atmpS3009;
  int32_t _M0L6_2atmpS3011;
  int32_t _M0L6_2atmpS3010;
  uint32_t _M0L6_2atmpS3008;
  uint32_t _M0L6_2atmpS3007;
  uint64_t _M0L6_2atmpS3006;
  uint64_t _M0L1aS1095;
  uint64_t _M0L6_2atmpS3004;
  uint64_t _M0L1bS1096;
  #line 239 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L6_2atmpS3020 = _M0L1iS1080 + 26;
  _M0L6_2atmpS3019 = _M0L6_2atmpS3020 - 1;
  _M0L4baseS1079 = _M0L6_2atmpS3019 / 26;
  _M0L5base2S1081 = _M0L4baseS1079 * 26;
  _M0L6offsetS1082 = _M0L5base2S1081 - _M0L1iS1080;
  _M0L6_2atmpS3018 = _M0L4baseS1079 * 2;
  #line 243 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L4mul0S1083
  = _M0MPC15array13ReadOnlyArray2atGmE(_M0FPB26gDOUBLE__POW5__INV__SPLIT2, _M0L6_2atmpS3018);
  _M0L6_2atmpS3017 = _M0L4baseS1079 * 2;
  _M0L6_2atmpS3016 = _M0L6_2atmpS3017 + 1;
  #line 244 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L4mul1S1084
  = _M0MPC15array13ReadOnlyArray2atGmE(_M0FPB26gDOUBLE__POW5__INV__SPLIT2, _M0L6_2atmpS3016);
  if (_M0L6offsetS1082 == 0) {
    return (struct _M0TPB8Pow5Pair){.$0 = _M0L4mul0S1083,
                                      .$1 = _M0L4mul1S1084};
  }
  #line 248 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L1mS1085
  = _M0MPC15array13ReadOnlyArray2atGmE(_M0FPB20gDOUBLE__POW5__TABLE, _M0L6offsetS1082);
  #line 249 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L7_2abindS1086 = _M0FPB7umul128(_M0L1mS1085, _M0L4mul1S1084);
  _M0L7_2alow1S1087 = _M0L7_2abindS1086.$0;
  _M0L8_2ahigh1S1088 = _M0L7_2abindS1086.$1;
  #line 250 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L7_2abindS1089 = _M0FPB7umul128(_M0L1mS1085, _M0L4mul0S1083);
  _M0L7_2alow0S1090 = _M0L7_2abindS1089.$0;
  _M0L8_2ahigh0S1091 = _M0L7_2abindS1089.$1;
  _M0L3sumS1092 = _M0L8_2ahigh0S1091 + _M0L7_2alow1S1087;
  _M0Lm5high1S1093 = _M0L8_2ahigh1S1088;
  if (_M0L3sumS1092 < _M0L8_2ahigh0S1091) {
    uint64_t _M0L6_2atmpS3003 = _M0Lm5high1S1093;
    _M0Lm5high1S1093 = _M0L6_2atmpS3003 + 1ull;
  }
  #line 256 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L6_2atmpS3014 = _M0FPB8pow5bits(_M0L5base2S1081);
  #line 256 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L6_2atmpS3015 = _M0FPB8pow5bits(_M0L1iS1080);
  _M0L5deltaS1094 = _M0L6_2atmpS3014 - _M0L6_2atmpS3015;
  #line 257 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L6_2atmpS3013
  = _M0FPB13shiftright128(_M0L7_2alow0S1090, _M0L3sumS1092, _M0L5deltaS1094);
  _M0L6_2atmpS3005 = _M0L6_2atmpS3013 + 1ull;
  _M0L6_2atmpS3012 = _M0L1iS1080 / 16;
  #line 259 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L6_2atmpS3009
  = _M0MPC15array13ReadOnlyArray2atGjE(_M0FPB19gPOW5__INV__OFFSETS, _M0L6_2atmpS3012);
  _M0L6_2atmpS3011 = _M0L1iS1080 % 16;
  _M0L6_2atmpS3010 = _M0L6_2atmpS3011 << 1;
  _M0L6_2atmpS3008 = _M0L6_2atmpS3009 >> (_M0L6_2atmpS3010 & 31);
  _M0L6_2atmpS3007 = _M0L6_2atmpS3008 & 3u;
  #line 259 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L6_2atmpS3006 = _M0MPC14uint4UInt10to__uint64(_M0L6_2atmpS3007);
  _M0L1aS1095 = _M0L6_2atmpS3005 + _M0L6_2atmpS3006;
  _M0L6_2atmpS3004 = _M0Lm5high1S1093;
  #line 260 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L1bS1096
  = _M0FPB13shiftright128(_M0L3sumS1092, _M0L6_2atmpS3004, _M0L5deltaS1094);
  return (struct _M0TPB8Pow5Pair){.$0 = _M0L1aS1095, .$1 = _M0L1bS1096};
}

struct _M0TPB8Pow5Pair _M0FPB19double__computePow5(int32_t _M0L1iS1062) {
  int32_t _M0L4baseS1061;
  int32_t _M0L5base2S1063;
  int32_t _M0L6offsetS1064;
  int32_t _M0L6_2atmpS3002;
  uint64_t _M0L4mul0S1065;
  int32_t _M0L6_2atmpS3001;
  int32_t _M0L6_2atmpS3000;
  uint64_t _M0L4mul1S1066;
  uint64_t _M0L1mS1067;
  struct _M0TPB7Umul128 _M0L7_2abindS1068;
  uint64_t _M0L7_2alow1S1069;
  uint64_t _M0L8_2ahigh1S1070;
  struct _M0TPB7Umul128 _M0L7_2abindS1071;
  uint64_t _M0L7_2alow0S1072;
  uint64_t _M0L8_2ahigh0S1073;
  uint64_t _M0L3sumS1074;
  uint64_t _M0Lm5high1S1075;
  int32_t _M0L6_2atmpS2998;
  int32_t _M0L6_2atmpS2999;
  int32_t _M0L5deltaS1076;
  uint64_t _M0L6_2atmpS2990;
  int32_t _M0L6_2atmpS2997;
  uint32_t _M0L6_2atmpS2994;
  int32_t _M0L6_2atmpS2996;
  int32_t _M0L6_2atmpS2995;
  uint32_t _M0L6_2atmpS2993;
  uint32_t _M0L6_2atmpS2992;
  uint64_t _M0L6_2atmpS2991;
  uint64_t _M0L1aS1077;
  uint64_t _M0L6_2atmpS2989;
  uint64_t _M0L1bS1078;
  #line 213 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L4baseS1061 = _M0L1iS1062 / 26;
  _M0L5base2S1063 = _M0L4baseS1061 * 26;
  _M0L6offsetS1064 = _M0L1iS1062 - _M0L5base2S1063;
  _M0L6_2atmpS3002 = _M0L4baseS1061 * 2;
  #line 217 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L4mul0S1065
  = _M0MPC15array13ReadOnlyArray2atGmE(_M0FPB21gDOUBLE__POW5__SPLIT2, _M0L6_2atmpS3002);
  _M0L6_2atmpS3001 = _M0L4baseS1061 * 2;
  _M0L6_2atmpS3000 = _M0L6_2atmpS3001 + 1;
  #line 218 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L4mul1S1066
  = _M0MPC15array13ReadOnlyArray2atGmE(_M0FPB21gDOUBLE__POW5__SPLIT2, _M0L6_2atmpS3000);
  if (_M0L6offsetS1064 == 0) {
    return (struct _M0TPB8Pow5Pair){.$0 = _M0L4mul0S1065,
                                      .$1 = _M0L4mul1S1066};
  }
  #line 222 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L1mS1067
  = _M0MPC15array13ReadOnlyArray2atGmE(_M0FPB20gDOUBLE__POW5__TABLE, _M0L6offsetS1064);
  #line 223 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L7_2abindS1068 = _M0FPB7umul128(_M0L1mS1067, _M0L4mul1S1066);
  _M0L7_2alow1S1069 = _M0L7_2abindS1068.$0;
  _M0L8_2ahigh1S1070 = _M0L7_2abindS1068.$1;
  #line 224 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L7_2abindS1071 = _M0FPB7umul128(_M0L1mS1067, _M0L4mul0S1065);
  _M0L7_2alow0S1072 = _M0L7_2abindS1071.$0;
  _M0L8_2ahigh0S1073 = _M0L7_2abindS1071.$1;
  _M0L3sumS1074 = _M0L8_2ahigh0S1073 + _M0L7_2alow1S1069;
  _M0Lm5high1S1075 = _M0L8_2ahigh1S1070;
  if (_M0L3sumS1074 < _M0L8_2ahigh0S1073) {
    uint64_t _M0L6_2atmpS2988 = _M0Lm5high1S1075;
    _M0Lm5high1S1075 = _M0L6_2atmpS2988 + 1ull;
  }
  #line 230 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L6_2atmpS2998 = _M0FPB8pow5bits(_M0L1iS1062);
  #line 230 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L6_2atmpS2999 = _M0FPB8pow5bits(_M0L5base2S1063);
  _M0L5deltaS1076 = _M0L6_2atmpS2998 - _M0L6_2atmpS2999;
  #line 231 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L6_2atmpS2990
  = _M0FPB13shiftright128(_M0L7_2alow0S1072, _M0L3sumS1074, _M0L5deltaS1076);
  _M0L6_2atmpS2997 = _M0L1iS1062 / 16;
  #line 232 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L6_2atmpS2994
  = _M0MPC15array13ReadOnlyArray2atGjE(_M0FPB14gPOW5__OFFSETS, _M0L6_2atmpS2997);
  _M0L6_2atmpS2996 = _M0L1iS1062 % 16;
  _M0L6_2atmpS2995 = _M0L6_2atmpS2996 << 1;
  _M0L6_2atmpS2993 = _M0L6_2atmpS2994 >> (_M0L6_2atmpS2995 & 31);
  _M0L6_2atmpS2992 = _M0L6_2atmpS2993 & 3u;
  #line 232 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L6_2atmpS2991 = _M0MPC14uint4UInt10to__uint64(_M0L6_2atmpS2992);
  _M0L1aS1077 = _M0L6_2atmpS2990 + _M0L6_2atmpS2991;
  _M0L6_2atmpS2989 = _M0Lm5high1S1075;
  #line 233 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L1bS1078
  = _M0FPB13shiftright128(_M0L3sumS1074, _M0L6_2atmpS2989, _M0L5deltaS1076);
  return (struct _M0TPB8Pow5Pair){.$0 = _M0L1aS1077, .$1 = _M0L1bS1078};
}

struct _M0TPB19MulShiftAll64Result _M0FPB13mulShiftAll64(
  uint64_t _M0L1mS1035,
  struct _M0TPB8Pow5Pair _M0L3mulS1032,
  int32_t _M0L1jS1048,
  int32_t _M0L7mmShiftS1050
) {
  uint64_t _M0L7_2amul0S1031;
  uint64_t _M0L7_2amul1S1033;
  uint64_t _M0L1mS1034;
  struct _M0TPB7Umul128 _M0L7_2abindS1036;
  uint64_t _M0L5_2aloS1037;
  uint64_t _M0L6_2atmpS1038;
  struct _M0TPB7Umul128 _M0L7_2abindS1039;
  uint64_t _M0L6_2alo2S1040;
  uint64_t _M0L6_2ahi2S1041;
  uint64_t _M0L3midS1042;
  uint64_t _M0L6_2atmpS2987;
  uint64_t _M0L2hiS1043;
  uint64_t _M0L3lo2S1044;
  uint64_t _M0L6_2atmpS2985;
  uint64_t _M0L6_2atmpS2986;
  uint64_t _M0L4mid2S1045;
  uint64_t _M0L6_2atmpS2984;
  uint64_t _M0L3hi2S1046;
  int32_t _M0L6_2atmpS2983;
  int32_t _M0L6_2atmpS2982;
  uint64_t _M0L2vpS1047;
  uint64_t _M0Lm2vmS1049;
  int32_t _M0L6_2atmpS2981;
  int32_t _M0L6_2atmpS2980;
  uint64_t _M0L2vrS1060;
  uint64_t _M0L6_2atmpS2979;
  #line 129 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L7_2amul0S1031 = _M0L3mulS1032.$0;
  _M0L7_2amul1S1033 = _M0L3mulS1032.$1;
  _M0L1mS1034 = _M0L1mS1035 << 1;
  #line 137 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L7_2abindS1036 = _M0FPB7umul128(_M0L1mS1034, _M0L7_2amul0S1031);
  _M0L5_2aloS1037 = _M0L7_2abindS1036.$0;
  _M0L6_2atmpS1038 = _M0L7_2abindS1036.$1;
  #line 138 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L7_2abindS1039 = _M0FPB7umul128(_M0L1mS1034, _M0L7_2amul1S1033);
  _M0L6_2alo2S1040 = _M0L7_2abindS1039.$0;
  _M0L6_2ahi2S1041 = _M0L7_2abindS1039.$1;
  _M0L3midS1042 = _M0L6_2atmpS1038 + _M0L6_2alo2S1040;
  if (_M0L3midS1042 < _M0L6_2atmpS1038) {
    _M0L6_2atmpS2987 = 1ull;
  } else {
    _M0L6_2atmpS2987 = 0ull;
  }
  _M0L2hiS1043 = _M0L6_2ahi2S1041 + _M0L6_2atmpS2987;
  _M0L3lo2S1044 = _M0L5_2aloS1037 + _M0L7_2amul0S1031;
  _M0L6_2atmpS2985 = _M0L3midS1042 + _M0L7_2amul1S1033;
  if (_M0L3lo2S1044 < _M0L5_2aloS1037) {
    _M0L6_2atmpS2986 = 1ull;
  } else {
    _M0L6_2atmpS2986 = 0ull;
  }
  _M0L4mid2S1045 = _M0L6_2atmpS2985 + _M0L6_2atmpS2986;
  if (_M0L4mid2S1045 < _M0L3midS1042) {
    _M0L6_2atmpS2984 = 1ull;
  } else {
    _M0L6_2atmpS2984 = 0ull;
  }
  _M0L3hi2S1046 = _M0L2hiS1043 + _M0L6_2atmpS2984;
  _M0L6_2atmpS2983 = _M0L1jS1048 - 64;
  _M0L6_2atmpS2982 = _M0L6_2atmpS2983 - 1;
  #line 144 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L2vpS1047
  = _M0FPB13shiftright128(_M0L4mid2S1045, _M0L3hi2S1046, _M0L6_2atmpS2982);
  _M0Lm2vmS1049 = 0ull;
  if (_M0L7mmShiftS1050) {
    uint64_t _M0L3lo3S1051 = _M0L5_2aloS1037 - _M0L7_2amul0S1031;
    uint64_t _M0L6_2atmpS2969 = _M0L3midS1042 - _M0L7_2amul1S1033;
    uint64_t _M0L6_2atmpS2970;
    uint64_t _M0L4mid3S1052;
    uint64_t _M0L6_2atmpS2968;
    uint64_t _M0L3hi3S1053;
    int32_t _M0L6_2atmpS2967;
    int32_t _M0L6_2atmpS2966;
    if (_M0L5_2aloS1037 < _M0L3lo3S1051) {
      _M0L6_2atmpS2970 = 1ull;
    } else {
      _M0L6_2atmpS2970 = 0ull;
    }
    _M0L4mid3S1052 = _M0L6_2atmpS2969 - _M0L6_2atmpS2970;
    if (_M0L3midS1042 < _M0L4mid3S1052) {
      _M0L6_2atmpS2968 = 1ull;
    } else {
      _M0L6_2atmpS2968 = 0ull;
    }
    _M0L3hi3S1053 = _M0L2hiS1043 - _M0L6_2atmpS2968;
    _M0L6_2atmpS2967 = _M0L1jS1048 - 64;
    _M0L6_2atmpS2966 = _M0L6_2atmpS2967 - 1;
    #line 150 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
    _M0Lm2vmS1049
    = _M0FPB13shiftright128(_M0L4mid3S1052, _M0L3hi3S1053, _M0L6_2atmpS2966);
  } else {
    uint64_t _M0L3lo3S1054 = _M0L5_2aloS1037 + _M0L5_2aloS1037;
    uint64_t _M0L6_2atmpS2977 = _M0L3midS1042 + _M0L3midS1042;
    uint64_t _M0L6_2atmpS2978;
    uint64_t _M0L4mid3S1055;
    uint64_t _M0L6_2atmpS2975;
    uint64_t _M0L6_2atmpS2976;
    uint64_t _M0L3hi3S1056;
    uint64_t _M0L3lo4S1057;
    uint64_t _M0L6_2atmpS2973;
    uint64_t _M0L6_2atmpS2974;
    uint64_t _M0L4mid4S1058;
    uint64_t _M0L6_2atmpS2972;
    uint64_t _M0L3hi4S1059;
    int32_t _M0L6_2atmpS2971;
    if (_M0L3lo3S1054 < _M0L5_2aloS1037) {
      _M0L6_2atmpS2978 = 1ull;
    } else {
      _M0L6_2atmpS2978 = 0ull;
    }
    _M0L4mid3S1055 = _M0L6_2atmpS2977 + _M0L6_2atmpS2978;
    _M0L6_2atmpS2975 = _M0L2hiS1043 + _M0L2hiS1043;
    if (_M0L4mid3S1055 < _M0L3midS1042) {
      _M0L6_2atmpS2976 = 1ull;
    } else {
      _M0L6_2atmpS2976 = 0ull;
    }
    _M0L3hi3S1056 = _M0L6_2atmpS2975 + _M0L6_2atmpS2976;
    _M0L3lo4S1057 = _M0L3lo3S1054 - _M0L7_2amul0S1031;
    _M0L6_2atmpS2973 = _M0L4mid3S1055 - _M0L7_2amul1S1033;
    if (_M0L3lo3S1054 < _M0L3lo4S1057) {
      _M0L6_2atmpS2974 = 1ull;
    } else {
      _M0L6_2atmpS2974 = 0ull;
    }
    _M0L4mid4S1058 = _M0L6_2atmpS2973 - _M0L6_2atmpS2974;
    if (_M0L4mid3S1055 < _M0L4mid4S1058) {
      _M0L6_2atmpS2972 = 1ull;
    } else {
      _M0L6_2atmpS2972 = 0ull;
    }
    _M0L3hi4S1059 = _M0L3hi3S1056 - _M0L6_2atmpS2972;
    _M0L6_2atmpS2971 = _M0L1jS1048 - 64;
    #line 158 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
    _M0Lm2vmS1049
    = _M0FPB13shiftright128(_M0L4mid4S1058, _M0L3hi4S1059, _M0L6_2atmpS2971);
  }
  _M0L6_2atmpS2981 = _M0L1jS1048 - 64;
  _M0L6_2atmpS2980 = _M0L6_2atmpS2981 - 1;
  #line 160 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L2vrS1060
  = _M0FPB13shiftright128(_M0L3midS1042, _M0L2hiS1043, _M0L6_2atmpS2980);
  _M0L6_2atmpS2979 = _M0Lm2vmS1049;
  return (struct _M0TPB19MulShiftAll64Result){.$0 = _M0L2vrS1060,
                                                .$1 = _M0L2vpS1047,
                                                .$2 = _M0L6_2atmpS2979};
}

int32_t _M0FPB18multipleOfPowerOf2(
  uint64_t _M0L5valueS1029,
  int32_t _M0L1pS1030
) {
  uint64_t _M0L6_2atmpS2965;
  uint64_t _M0L6_2atmpS2964;
  uint64_t _M0L6_2atmpS2963;
  #line 124 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L6_2atmpS2965 = 1ull << (_M0L1pS1030 & 63);
  _M0L6_2atmpS2964 = _M0L6_2atmpS2965 - 1ull;
  _M0L6_2atmpS2963 = _M0L5valueS1029 & _M0L6_2atmpS2964;
  return _M0L6_2atmpS2963 == 0ull;
}

int32_t _M0FPB18multipleOfPowerOf5(
  uint64_t _M0L5valueS1027,
  int32_t _M0L1pS1028
) {
  int32_t _M0L6_2atmpS2962;
  #line 119 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  #line 120 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L6_2atmpS2962 = _M0FPB10pow5Factor(_M0L5valueS1027);
  return _M0L6_2atmpS2962 >= _M0L1pS1028;
}

int32_t _M0FPB10pow5Factor(uint64_t _M0L5valueS1022) {
  uint64_t _M0L6_2atmpS2953;
  uint64_t _M0L6_2atmpS2954;
  uint64_t _M0L6_2atmpS2955;
  uint64_t _M0L6_2atmpS2956;
  uint64_t _M0L6_2atmpS2961;
  int32_t _M0L5countS1023;
  uint64_t _M0L1vS1024;
  #line 94 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L6_2atmpS2953 = _M0L5valueS1022 % 5ull;
  if (_M0L6_2atmpS2953 != 0ull) {
    return 0;
  }
  _M0L6_2atmpS2954 = _M0L5valueS1022 % 25ull;
  if (_M0L6_2atmpS2954 != 0ull) {
    return 1;
  }
  _M0L6_2atmpS2955 = _M0L5valueS1022 % 125ull;
  if (_M0L6_2atmpS2955 != 0ull) {
    return 2;
  }
  _M0L6_2atmpS2956 = _M0L5valueS1022 % 625ull;
  if (_M0L6_2atmpS2956 != 0ull) {
    return 3;
  }
  _M0L6_2atmpS2961 = _M0L5valueS1022 / 625ull;
  _M0L5countS1023 = 4;
  _M0L1vS1024 = _M0L6_2atmpS2961;
  while (1) {
    if (_M0L1vS1024 > 0ull) {
      uint64_t _M0L6_2atmpS2957 = _M0L1vS1024 % 5ull;
      int32_t _M0L6_2atmpS2958;
      uint64_t _M0L6_2atmpS2959;
      if (_M0L6_2atmpS2957 != 0ull) {
        return _M0L5countS1023;
      }
      _M0L6_2atmpS2958 = _M0L5countS1023 + 1;
      _M0L6_2atmpS2959 = _M0L1vS1024 / 5ull;
      _M0L5countS1023 = _M0L6_2atmpS2958;
      _M0L1vS1024 = _M0L6_2atmpS2959;
      continue;
    } else {
      struct _M0TPB13StringBuilder* _M0L18_2astring__builderS1026;
      moonbit_string_t _M0L6_2atmpS2960;
      int32_t _result_4484;
      #line 114 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
      _M0L18_2astring__builderS1026
      = _M0MPB13StringBuilder21StringBuilder_2einner(25);
      #line 114 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
      _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS1026, (moonbit_string_t)moonbit_string_literal_45.data);
      #line 114 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
      _M0MPB13StringBuilder13write__objectGmE(_M0L18_2astring__builderS1026, _M0L5valueS1022);
      #line 114 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
      _M0L6_2atmpS2960
      = _M0MPB13StringBuilder10to__string(_M0L18_2astring__builderS1026);
      moonbit_decref(_M0L18_2astring__builderS1026);
      #line 114 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
      _result_4484 = _M0FPC15abort5abortGiE(_M0L6_2atmpS2960);
      moonbit_decref(_M0L6_2atmpS2960);
      return _result_4484;
    }
    break;
  }
}

uint64_t _M0FPB13shiftright128(
  uint64_t _M0L2loS1021,
  uint64_t _M0L2hiS1019,
  int32_t _M0L4distS1020
) {
  int32_t _M0L6_2atmpS2952;
  uint64_t _M0L6_2atmpS2950;
  uint64_t _M0L6_2atmpS2951;
  #line 89 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L6_2atmpS2952 = 64 - _M0L4distS1020;
  _M0L6_2atmpS2950 = _M0L2hiS1019 << (_M0L6_2atmpS2952 & 63);
  _M0L6_2atmpS2951 = _M0L2loS1021 >> (_M0L4distS1020 & 63);
  return _M0L6_2atmpS2950 | _M0L6_2atmpS2951;
}

struct _M0TPB7Umul128 _M0FPB7umul128(
  uint64_t _M0L1aS1009,
  uint64_t _M0L1bS1012
) {
  uint64_t _M0L3aLoS1008;
  uint64_t _M0L3aHiS1010;
  uint64_t _M0L3bLoS1011;
  uint64_t _M0L3bHiS1013;
  uint64_t _M0L1xS1014;
  uint64_t _M0L6_2atmpS2948;
  uint64_t _M0L6_2atmpS2949;
  uint64_t _M0L1yS1015;
  uint64_t _M0L6_2atmpS2946;
  uint64_t _M0L6_2atmpS2947;
  uint64_t _M0L1zS1016;
  uint64_t _M0L6_2atmpS2944;
  uint64_t _M0L6_2atmpS2945;
  uint64_t _M0L6_2atmpS2942;
  uint64_t _M0L6_2atmpS2943;
  uint64_t _M0L1wS1017;
  uint64_t _M0L2loS1018;
  #line 74 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L3aLoS1008 = _M0L1aS1009 & 4294967295ull;
  _M0L3aHiS1010 = _M0L1aS1009 >> 32;
  _M0L3bLoS1011 = _M0L1bS1012 & 4294967295ull;
  _M0L3bHiS1013 = _M0L1bS1012 >> 32;
  _M0L1xS1014 = _M0L3aLoS1008 * _M0L3bLoS1011;
  _M0L6_2atmpS2948 = _M0L3aHiS1010 * _M0L3bLoS1011;
  _M0L6_2atmpS2949 = _M0L1xS1014 >> 32;
  _M0L1yS1015 = _M0L6_2atmpS2948 + _M0L6_2atmpS2949;
  _M0L6_2atmpS2946 = _M0L3aLoS1008 * _M0L3bHiS1013;
  _M0L6_2atmpS2947 = _M0L1yS1015 & 4294967295ull;
  _M0L1zS1016 = _M0L6_2atmpS2946 + _M0L6_2atmpS2947;
  _M0L6_2atmpS2944 = _M0L3aHiS1010 * _M0L3bHiS1013;
  _M0L6_2atmpS2945 = _M0L1yS1015 >> 32;
  _M0L6_2atmpS2942 = _M0L6_2atmpS2944 + _M0L6_2atmpS2945;
  _M0L6_2atmpS2943 = _M0L1zS1016 >> 32;
  _M0L1wS1017 = _M0L6_2atmpS2942 + _M0L6_2atmpS2943;
  _M0L2loS1018 = _M0L1aS1009 * _M0L1bS1012;
  return (struct _M0TPB7Umul128){.$0 = _M0L2loS1018, .$1 = _M0L1wS1017};
}

moonbit_string_t _M0FPB19string__from__bytes(
  moonbit_bytes_t _M0L5bytesS1006,
  int32_t _M0L4fromS1003,
  int32_t _M0L2toS1002
) {
  int32_t _M0L3lenS1001;
  int32_t _M0L6_2atmpS2941;
  uint16_t* _M0L6bufferS1004;
  int32_t _M0L1iS1005;
  #line 52 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L3lenS1001 = _M0L2toS1002 - _M0L4fromS1003;
  #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L6_2atmpS2941 = _M0IPC16uint166UInt16PB7Default7default();
  _M0L6bufferS1004
  = (uint16_t*)moonbit_make_string(_M0L3lenS1001, _M0L6_2atmpS2941);
  _M0L1iS1005 = 0;
  while (1) {
    if (_M0L1iS1005 < _M0L3lenS1001) {
      int32_t _M0L6_2atmpS2939 = _M0L4fromS1003 + _M0L1iS1005;
      int32_t _M0L6_2atmpS2938;
      int32_t _M0L6_2atmpS2937;
      int32_t _M0L6_2atmpS2940;
      if (
        _M0L6_2atmpS2939 < 0
        || _M0L6_2atmpS2939 >= Moonbit_array_length(_M0L5bytesS1006)
      ) {
        #line 56 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
        moonbit_panic();
      }
      _M0L6_2atmpS2938 = (int32_t)_M0L5bytesS1006[_M0L6_2atmpS2939];
      _M0L6_2atmpS2937 = (uint16_t)_M0L6_2atmpS2938;
      if (
        _M0L1iS1005 < 0
        || _M0L1iS1005 >= Moonbit_array_length(_M0L6bufferS1004)
      ) {
        #line 56 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
        moonbit_panic();
      }
      _M0L6bufferS1004[_M0L1iS1005] = _M0L6_2atmpS2937;
      _M0L6_2atmpS2940 = _M0L1iS1005 + 1;
      _M0L1iS1005 = _M0L6_2atmpS2940;
      continue;
    }
    break;
  }
  return _M0L6bufferS1004;
}

int32_t _M0FPB9log10Pow2(int32_t _M0L1eS1000) {
  int32_t _M0L6_2atmpS2936;
  uint32_t _M0L6_2atmpS2935;
  uint32_t _M0L6_2atmpS2934;
  #line 44 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L6_2atmpS2936 = _M0L1eS1000 * 78913;
  _M0L6_2atmpS2935 = *(uint32_t*)&_M0L6_2atmpS2936;
  _M0L6_2atmpS2934 = _M0L6_2atmpS2935 >> 18;
  return *(int32_t*)&_M0L6_2atmpS2934;
}

int32_t _M0FPB9log10Pow5(int32_t _M0L1eS999) {
  int32_t _M0L6_2atmpS2933;
  uint32_t _M0L6_2atmpS2932;
  uint32_t _M0L6_2atmpS2931;
  #line 37 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L6_2atmpS2933 = _M0L1eS999 * 732923;
  _M0L6_2atmpS2932 = *(uint32_t*)&_M0L6_2atmpS2933;
  _M0L6_2atmpS2931 = _M0L6_2atmpS2932 >> 20;
  return *(int32_t*)&_M0L6_2atmpS2931;
}

moonbit_string_t _M0FPB18copy__special__str(
  int32_t _M0L4signS997,
  int32_t _M0L8exponentS998,
  int32_t _M0L8mantissaS995
) {
  moonbit_string_t _M0L1sS996;
  moonbit_string_t _result_4487;
  #line 23 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  if (_M0L8mantissaS995) {
    return (moonbit_string_t)moonbit_string_literal_46.data;
  }
  if (_M0L4signS997) {
    _M0L1sS996 = (moonbit_string_t)moonbit_string_literal_20.data;
  } else {
    _M0L1sS996 = (moonbit_string_t)moonbit_string_literal_1.data;
  }
  if (_M0L8exponentS998) {
    moonbit_string_t _result_4486;
    #line 29 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
    _result_4486
    = moonbit_add_string(_M0L1sS996, (moonbit_string_t)moonbit_string_literal_47.data);
    moonbit_decref(_M0L1sS996);
    return _result_4486;
  }
  #line 31 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _result_4487
  = moonbit_add_string(_M0L1sS996, (moonbit_string_t)moonbit_string_literal_48.data);
  moonbit_decref(_M0L1sS996);
  return _result_4487;
}

int32_t _M0FPB8pow5bits(int32_t _M0L1eS994) {
  int32_t _M0L6_2atmpS2930;
  uint32_t _M0L6_2atmpS2929;
  uint32_t _M0L6_2atmpS2928;
  int32_t _M0L6_2atmpS2927;
  #line 18 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\double_ryu_nonjs.mbt"
  _M0L6_2atmpS2930 = _M0L1eS994 * 1217359;
  _M0L6_2atmpS2929 = *(uint32_t*)&_M0L6_2atmpS2930;
  _M0L6_2atmpS2928 = _M0L6_2atmpS2929 >> 19;
  _M0L6_2atmpS2927 = *(int32_t*)&_M0L6_2atmpS2928;
  return _M0L6_2atmpS2927 + 1;
}

int32_t _M0IPC13int3IntPB4Hash4hash(int32_t _M0L4selfS993) {
  int32_t _tmp_4488;
  uint32_t _M0L6_2atmpS2926;
  uint32_t _M0L6_2atmpS2925;
  uint32_t _M0L3accS992;
  uint32_t _M0L6_2atmpS2924;
  uint32_t _M0L6_2atmpS2923;
  #line 585 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\hasher.mbt"
  _tmp_4488 = 0;
  _M0L6_2atmpS2926 = *(uint32_t*)&_tmp_4488;
  _M0L6_2atmpS2925 = _M0L6_2atmpS2926 + 374761393u;
  _M0L3accS992 = _M0L6_2atmpS2925 + 4u;
  _M0L6_2atmpS2924 = *(uint32_t*)&_M0L4selfS993;
  #line 587 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\hasher.mbt"
  _M0L6_2atmpS2923 = _M0FPB13consume4__acc(_M0L3accS992, _M0L6_2atmpS2924);
  #line 587 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\hasher.mbt"
  return _M0FPB13finalize__acc(_M0L6_2atmpS2923);
}

int32_t _M0IPC16string6StringPB4Hash4hash(moonbit_string_t _M0L4selfS988) {
  int32_t _tmp_4489;
  uint32_t _M0L6_2atmpS2922;
  uint32_t _M0Lm3accS986;
  int32_t _M0L7_2abindS987;
  int32_t _M0L1iS989;
  uint32_t _M0L6_2atmpS2921;
  #line 519 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\hasher.mbt"
  _tmp_4489 = 0;
  _M0L6_2atmpS2922 = *(uint32_t*)&_tmp_4489;
  _M0Lm3accS986 = _M0L6_2atmpS2922 + 374761393u;
  _M0L7_2abindS987 = Moonbit_array_length(_M0L4selfS988);
  _M0L1iS989 = 0;
  while (1) {
    if (_M0L1iS989 < _M0L7_2abindS987) {
      uint32_t _M0L6_2atmpS2916 = _M0Lm3accS986;
      int32_t _M0L6_2atmpS2919;
      int32_t _M0L6_2atmpS2918;
      uint32_t _M0L1vS990;
      uint32_t _M0L6_2atmpS2917;
      int32_t _M0L6_2atmpS2920;
      _M0Lm3accS986 = _M0L6_2atmpS2916 + 4u;
      _M0L6_2atmpS2919 = _M0L4selfS988[_M0L1iS989];
      _M0L6_2atmpS2918 = (int32_t)_M0L6_2atmpS2919;
      _M0L1vS990 = *(uint32_t*)&_M0L6_2atmpS2918;
      _M0L6_2atmpS2917 = _M0Lm3accS986;
      #line 524 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\hasher.mbt"
      _M0Lm3accS986 = _M0FPB13consume4__acc(_M0L6_2atmpS2917, _M0L1vS990);
      _M0L6_2atmpS2920 = _M0L1iS989 + 1;
      _M0L1iS989 = _M0L6_2atmpS2920;
      continue;
    }
    break;
  }
  _M0L6_2atmpS2921 = _M0Lm3accS986;
  #line 526 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\hasher.mbt"
  return _M0FPB13finalize__acc(_M0L6_2atmpS2921);
}

int32_t _M0MPC13int3Int13is__surrogate(int32_t _M0L4selfS985) {
  #line 167 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\int.mbt"
  if (55296 <= _M0L4selfS985) {
    return _M0L4selfS985 <= 57343;
  } else {
    return 0;
  }
}

struct _M0TPB4IterGsE* _M0MPB4Iter4iterGsE(
  struct _M0TPB4IterGsE* _M0L4selfS984
) {
  #line 828 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\iterator.mbt"
  moonbit_incref(_M0L4selfS984);
  return _M0L4selfS984;
}

int64_t _M0MPB4Iter10size__hintGsE(struct _M0TPB4IterGsE* _M0L4selfS983) {
  #line 56 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\iterator.mbt"
  return _M0L4selfS983->$1;
}

struct _M0TPB5ArrayGRPC15debug7ContentE* _M0MPC15array5Array3mapGRPC15debug4ReprRPC15debug7ContentE(
  struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L4selfS935,
  struct _M0TWRPC15debug4ReprERPC15debug7Content* _M0L1fS939
) {
  int32_t _M0L3lenS2885;
  struct _M0TPB5ArrayGRPC15debug7ContentE* _M0L3arrS934;
  int32_t _M0L7_2abindS936;
  int32_t _M0L1iS937;
  #line 585 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L3lenS2885 = _M0L4selfS935->$1;
  #line 590 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L3arrS934
  = _M0MPC15array5Array12make__uninitGRPC15debug7ContentE(_M0L3lenS2885);
  _M0L7_2abindS936 = _M0L4selfS935->$1;
  _M0L1iS937 = 0;
  while (1) {
    if (_M0L1iS937 < _M0L7_2abindS936) {
      void** _M0L3bufS2884 = _M0L4selfS935->$0;
      void* _M0L1vS938 = (void*)_M0L3bufS2884[_M0L1iS937];
      struct _M0TPC15debug7Content** _M0L3bufS2881 = _M0L3arrS934->$0;
      struct _M0TPC15debug7Content* _M0L6_2atmpS2882;
      struct _M0TPC15debug7Content* _M0L6_2aoldS4087;
      int32_t _M0L6_2atmpS2883;
      moonbit_incref(_M0L3bufS2881);
      moonbit_incref(_M0L1vS938);
      #line 592 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
      _M0L6_2atmpS2882 = _M0L1fS939->code(_M0L1fS939, _M0L1vS938);
      moonbit_decref(_M0L1vS938);
      _M0L6_2aoldS4087
      = (struct _M0TPC15debug7Content*)_M0L3bufS2881[_M0L1iS937];
      if (_M0L6_2aoldS4087) {
        moonbit_decref(_M0L6_2aoldS4087);
      }
      _M0L3bufS2881[_M0L1iS937] = _M0L6_2atmpS2882;
      moonbit_decref(_M0L3bufS2881);
      _M0L6_2atmpS2883 = _M0L1iS937 + 1;
      _M0L1iS937 = _M0L6_2atmpS2883;
      continue;
    }
    break;
  }
  return _M0L3arrS934;
}

struct _M0TPB5ArrayGRPC15debug7ContentE* _M0MPC15array5Array3mapGRPC15debug9ReprDeltaRPC15debug7ContentE(
  struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* _M0L4selfS942,
  struct _M0TWRPC15debug9ReprDeltaERPC15debug7Content* _M0L1fS946
) {
  int32_t _M0L3lenS2890;
  struct _M0TPB5ArrayGRPC15debug7ContentE* _M0L3arrS941;
  int32_t _M0L7_2abindS943;
  int32_t _M0L1iS944;
  #line 585 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L3lenS2890 = _M0L4selfS942->$1;
  #line 590 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L3arrS941
  = _M0MPC15array5Array12make__uninitGRPC15debug7ContentE(_M0L3lenS2890);
  _M0L7_2abindS943 = _M0L4selfS942->$1;
  _M0L1iS944 = 0;
  while (1) {
    if (_M0L1iS944 < _M0L7_2abindS943) {
      void** _M0L3bufS2889 = _M0L4selfS942->$0;
      void* _M0L1vS945 = (void*)_M0L3bufS2889[_M0L1iS944];
      struct _M0TPC15debug7Content** _M0L3bufS2886 = _M0L3arrS941->$0;
      struct _M0TPC15debug7Content* _M0L6_2atmpS2887;
      struct _M0TPC15debug7Content* _M0L6_2aoldS4089;
      int32_t _M0L6_2atmpS2888;
      moonbit_incref(_M0L3bufS2886);
      moonbit_incref(_M0L1vS945);
      #line 592 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
      _M0L6_2atmpS2887 = _M0L1fS946->code(_M0L1fS946, _M0L1vS945);
      moonbit_decref(_M0L1vS945);
      _M0L6_2aoldS4089
      = (struct _M0TPC15debug7Content*)_M0L3bufS2886[_M0L1iS944];
      if (_M0L6_2aoldS4089) {
        moonbit_decref(_M0L6_2aoldS4089);
      }
      _M0L3bufS2886[_M0L1iS944] = _M0L6_2atmpS2887;
      moonbit_decref(_M0L3bufS2886);
      _M0L6_2atmpS2888 = _M0L1iS944 + 1;
      _M0L1iS944 = _M0L6_2atmpS2888;
      continue;
    }
    break;
  }
  return _M0L3arrS941;
}

struct _M0TPB5ArrayGRPC15debug13ContentParensE* _M0MPC15array5Array3mapGRPC15debug7ContentRPC15debug13ContentParensE(
  struct _M0TPB5ArrayGRPC15debug7ContentE* _M0L4selfS949,
  struct _M0TWRPC15debug7ContentERPC15debug13ContentParens* _M0L1fS953
) {
  int32_t _M0L3lenS2895;
  struct _M0TPB5ArrayGRPC15debug13ContentParensE* _M0L3arrS948;
  int32_t _M0L7_2abindS950;
  int32_t _M0L1iS951;
  #line 585 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L3lenS2895 = _M0L4selfS949->$1;
  #line 590 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L3arrS948
  = _M0MPC15array5Array12make__uninitGRPC15debug13ContentParensE(_M0L3lenS2895);
  _M0L7_2abindS950 = _M0L4selfS949->$1;
  _M0L1iS951 = 0;
  while (1) {
    if (_M0L1iS951 < _M0L7_2abindS950) {
      struct _M0TPC15debug7Content** _M0L3bufS2894 = _M0L4selfS949->$0;
      struct _M0TPC15debug7Content* _M0L1vS952 =
        (struct _M0TPC15debug7Content*)_M0L3bufS2894[_M0L1iS951];
      struct _M0TPC15debug13ContentParens** _M0L3bufS2891 = _M0L3arrS948->$0;
      struct _M0TPC15debug13ContentParens* _M0L6_2atmpS2892;
      struct _M0TPC15debug13ContentParens* _M0L6_2aoldS4091;
      int32_t _M0L6_2atmpS2893;
      moonbit_incref(_M0L3bufS2891);
      moonbit_incref(_M0L1vS952);
      #line 592 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
      _M0L6_2atmpS2892 = _M0L1fS953->code(_M0L1fS953, _M0L1vS952);
      moonbit_decref(_M0L1vS952);
      _M0L6_2aoldS4091
      = (struct _M0TPC15debug13ContentParens*)_M0L3bufS2891[_M0L1iS951];
      if (_M0L6_2aoldS4091) {
        moonbit_decref(_M0L6_2aoldS4091);
      }
      _M0L3bufS2891[_M0L1iS951] = _M0L6_2atmpS2892;
      moonbit_decref(_M0L3bufS2891);
      _M0L6_2atmpS2893 = _M0L1iS951 + 1;
      _M0L1iS951 = _M0L6_2atmpS2893;
      continue;
    }
    break;
  }
  return _M0L3arrS948;
}

struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* _M0MPC15array5Array3mapGRPC15debug9ReprDeltaRPC15debug9ReprDeltaE(
  struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* _M0L4selfS956,
  struct _M0TWRPC15debug9ReprDeltaERPC15debug9ReprDelta* _M0L1fS960
) {
  int32_t _M0L3lenS2900;
  struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* _M0L3arrS955;
  int32_t _M0L7_2abindS957;
  int32_t _M0L1iS958;
  #line 585 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L3lenS2900 = _M0L4selfS956->$1;
  #line 590 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L3arrS955
  = _M0MPC15array5Array12make__uninitGRPC15debug9ReprDeltaE(_M0L3lenS2900);
  _M0L7_2abindS957 = _M0L4selfS956->$1;
  _M0L1iS958 = 0;
  while (1) {
    if (_M0L1iS958 < _M0L7_2abindS957) {
      void** _M0L3bufS2899 = _M0L4selfS956->$0;
      void* _M0L1vS959 = (void*)_M0L3bufS2899[_M0L1iS958];
      void** _M0L3bufS2896 = _M0L3arrS955->$0;
      void* _M0L6_2atmpS2897;
      void* _M0L6_2aoldS4093;
      int32_t _M0L6_2atmpS2898;
      moonbit_incref(_M0L3bufS2896);
      moonbit_incref(_M0L1vS959);
      #line 592 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
      _M0L6_2atmpS2897 = _M0L1fS960->code(_M0L1fS960, _M0L1vS959);
      moonbit_decref(_M0L1vS959);
      _M0L6_2aoldS4093 = (void*)_M0L3bufS2896[_M0L1iS958];
      moonbit_decref(_M0L6_2aoldS4093);
      _M0L3bufS2896[_M0L1iS958] = _M0L6_2atmpS2897;
      moonbit_decref(_M0L3bufS2896);
      _M0L6_2atmpS2898 = _M0L1iS958 + 1;
      _M0L1iS958 = _M0L6_2atmpS2898;
      continue;
    }
    break;
  }
  return _M0L3arrS955;
}

struct _M0TPB5ArrayGRPC15debug4ReprE* _M0MPC15array5Array3mapGRPC15debug4ReprRPC15debug4ReprE(
  struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L4selfS963,
  struct _M0TWRPC15debug4ReprERPC15debug4Repr* _M0L1fS967
) {
  int32_t _M0L3lenS2905;
  struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L3arrS962;
  int32_t _M0L7_2abindS964;
  int32_t _M0L1iS965;
  #line 585 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L3lenS2905 = _M0L4selfS963->$1;
  #line 590 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L3arrS962
  = _M0MPC15array5Array12make__uninitGRPC15debug4ReprE(_M0L3lenS2905);
  _M0L7_2abindS964 = _M0L4selfS963->$1;
  _M0L1iS965 = 0;
  while (1) {
    if (_M0L1iS965 < _M0L7_2abindS964) {
      void** _M0L3bufS2904 = _M0L4selfS963->$0;
      void* _M0L1vS966 = (void*)_M0L3bufS2904[_M0L1iS965];
      void** _M0L3bufS2901 = _M0L3arrS962->$0;
      void* _M0L6_2atmpS2902;
      void* _M0L6_2aoldS4095;
      int32_t _M0L6_2atmpS2903;
      moonbit_incref(_M0L3bufS2901);
      moonbit_incref(_M0L1vS966);
      #line 592 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
      _M0L6_2atmpS2902 = _M0L1fS967->code(_M0L1fS967, _M0L1vS966);
      moonbit_decref(_M0L1vS966);
      _M0L6_2aoldS4095 = (void*)_M0L3bufS2901[_M0L1iS965];
      moonbit_decref(_M0L6_2aoldS4095);
      _M0L3bufS2901[_M0L1iS965] = _M0L6_2atmpS2902;
      moonbit_decref(_M0L3bufS2901);
      _M0L6_2atmpS2903 = _M0L1iS965 + 1;
      _M0L1iS965 = _M0L6_2atmpS2903;
      continue;
    }
    break;
  }
  return _M0L3arrS962;
}

struct _M0TPB5ArrayGRPB5ArrayGsEE* _M0MPC15array5Array3mapGRPC15debug13ContentParensRPB5ArrayGsEE(
  struct _M0TPB5ArrayGRPC15debug13ContentParensE* _M0L4selfS970,
  struct _M0TWRPC15debug13ContentParensERPB5ArrayGsE* _M0L1fS974
) {
  int32_t _M0L3lenS2910;
  struct _M0TPB5ArrayGRPB5ArrayGsEE* _M0L3arrS969;
  int32_t _M0L7_2abindS971;
  int32_t _M0L1iS972;
  #line 585 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L3lenS2910 = _M0L4selfS970->$1;
  #line 590 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L3arrS969
  = _M0MPC15array5Array12make__uninitGRPB5ArrayGsEE(_M0L3lenS2910);
  _M0L7_2abindS971 = _M0L4selfS970->$1;
  _M0L1iS972 = 0;
  while (1) {
    if (_M0L1iS972 < _M0L7_2abindS971) {
      struct _M0TPC15debug13ContentParens** _M0L3bufS2909 = _M0L4selfS970->$0;
      struct _M0TPC15debug13ContentParens* _M0L1vS973 =
        (struct _M0TPC15debug13ContentParens*)_M0L3bufS2909[_M0L1iS972];
      struct _M0TPB5ArrayGsE** _M0L3bufS2906 = _M0L3arrS969->$0;
      struct _M0TPB5ArrayGsE* _M0L6_2atmpS2907;
      struct _M0TPB5ArrayGsE* _M0L6_2aoldS4097;
      int32_t _M0L6_2atmpS2908;
      moonbit_incref(_M0L3bufS2906);
      moonbit_incref(_M0L1vS973);
      #line 592 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
      _M0L6_2atmpS2907 = _M0L1fS974->code(_M0L1fS974, _M0L1vS973);
      moonbit_decref(_M0L1vS973);
      _M0L6_2aoldS4097 = (struct _M0TPB5ArrayGsE*)_M0L3bufS2906[_M0L1iS972];
      if (_M0L6_2aoldS4097) {
        moonbit_decref(_M0L6_2aoldS4097);
      }
      _M0L3bufS2906[_M0L1iS972] = _M0L6_2atmpS2907;
      moonbit_decref(_M0L3bufS2906);
      _M0L6_2atmpS2908 = _M0L1iS972 + 1;
      _M0L1iS972 = _M0L6_2atmpS2908;
      continue;
    }
    break;
  }
  return _M0L3arrS969;
}

struct _M0TPB5ArrayGsE* _M0MPC15array5Array3mapGssE(
  struct _M0TPB5ArrayGsE* _M0L4selfS977,
  struct _M0TWsEs* _M0L1fS981
) {
  int32_t _M0L3lenS2915;
  struct _M0TPB5ArrayGsE* _M0L3arrS976;
  int32_t _M0L7_2abindS978;
  int32_t _M0L1iS979;
  #line 585 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L3lenS2915 = _M0L4selfS977->$1;
  #line 590 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L3arrS976 = _M0MPC15array5Array12make__uninitGsE(_M0L3lenS2915);
  _M0L7_2abindS978 = _M0L4selfS977->$1;
  _M0L1iS979 = 0;
  while (1) {
    if (_M0L1iS979 < _M0L7_2abindS978) {
      moonbit_string_t* _M0L3bufS2914 = _M0L4selfS977->$0;
      moonbit_string_t _M0L1vS980 =
        (moonbit_string_t)_M0L3bufS2914[_M0L1iS979];
      moonbit_string_t* _M0L3bufS2911 = _M0L3arrS976->$0;
      moonbit_string_t _M0L6_2atmpS2912;
      moonbit_string_t _M0L6_2aoldS4099;
      int32_t _M0L6_2atmpS2913;
      moonbit_incref(_M0L3bufS2911);
      moonbit_incref(_M0L1vS980);
      #line 592 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
      _M0L6_2atmpS2912 = _M0L1fS981->code(_M0L1fS981, _M0L1vS980);
      moonbit_decref(_M0L1vS980);
      _M0L6_2aoldS4099 = (moonbit_string_t)_M0L3bufS2911[_M0L1iS979];
      moonbit_decref(_M0L6_2aoldS4099);
      _M0L3bufS2911[_M0L1iS979] = _M0L6_2atmpS2912;
      moonbit_decref(_M0L3bufS2911);
      _M0L6_2atmpS2913 = _M0L1iS979 + 1;
      _M0L1iS979 = _M0L6_2atmpS2913;
      continue;
    }
    break;
  }
  return _M0L3arrS976;
}

struct _M0TUWEuQRPC15error5ErrorNsE* _M0MPB3Map3getGiUWEuQRPC15error5ErrorNsEE(
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0L4selfS921,
  int32_t _M0L3keyS917
) {
  int32_t _M0L4hashS916;
  int32_t _M0L14capacity__maskS2866;
  int32_t _M0L6_2atmpS2865;
  int32_t _M0L1iS918;
  int32_t _M0L3idxS919;
  #line 244 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  #line 245 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L4hashS916 = _M0IPC13int3IntPB4Hash4hash(_M0L3keyS917);
  _M0L14capacity__maskS2866 = _M0L4selfS921->$3;
  _M0L6_2atmpS2865 = _M0L4hashS916 & _M0L14capacity__maskS2866;
  _M0L1iS918 = 0;
  _M0L3idxS919 = _M0L6_2atmpS2865;
  while (1) {
    struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE** _M0L7entriesS2864 =
      _M0L4selfS921->$0;
    struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L7_2abindS920;
    if (
      _M0L3idxS919 < 0
      || _M0L3idxS919 >= Moonbit_array_length(_M0L7entriesS2864)
    ) {
      #line 247 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
      moonbit_panic();
    }
    _M0L7_2abindS920
    = (struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE*)_M0L7entriesS2864[
        _M0L3idxS919
      ];
    if (_M0L7_2abindS920 == 0) {
      struct _M0TUWEuQRPC15error5ErrorNsE* _M0L6_2atmpS2853 = 0;
      return _M0L6_2atmpS2853;
    } else {
      struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L7_2aSomeS922 =
        _M0L7_2abindS920;
      struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L8_2aentryS923 =
        _M0L7_2aSomeS922;
      int32_t _M0L4hashS2855 = _M0L8_2aentryS923->$3;
      int32_t _if__result_4499;
      int32_t _M0L3pslS2858;
      int32_t _M0L6_2atmpS2860;
      int32_t _M0L6_2atmpS2862;
      int32_t _M0L14capacity__maskS2863;
      int32_t _M0L6_2atmpS2861;
      if (_M0L4hashS2855 == _M0L4hashS916) {
        int32_t _M0L3keyS2854 = _M0L8_2aentryS923->$4;
        _if__result_4499 = _M0L3keyS2854 == _M0L3keyS917;
      } else {
        _if__result_4499 = 0;
      }
      if (_if__result_4499) {
        struct _M0TUWEuQRPC15error5ErrorNsE* _M0L5valueS2857 =
          _M0L8_2aentryS923->$5;
        struct _M0TUWEuQRPC15error5ErrorNsE* _M0L6_2atmpS2856;
        moonbit_incref(_M0L5valueS2857);
        _M0L6_2atmpS2856 = _M0L5valueS2857;
        return _M0L6_2atmpS2856;
      } else {
        moonbit_incref(_M0L8_2aentryS923);
      }
      _M0L3pslS2858 = _M0L8_2aentryS923->$2;
      moonbit_decref(_M0L8_2aentryS923);
      if (_M0L1iS918 > _M0L3pslS2858) {
        struct _M0TUWEuQRPC15error5ErrorNsE* _M0L6_2atmpS2859 = 0;
        return _M0L6_2atmpS2859;
      }
      _M0L6_2atmpS2860 = _M0L1iS918 + 1;
      _M0L6_2atmpS2862 = _M0L3idxS919 + 1;
      _M0L14capacity__maskS2863 = _M0L4selfS921->$3;
      _M0L6_2atmpS2861 = _M0L6_2atmpS2862 & _M0L14capacity__maskS2863;
      _M0L1iS918 = _M0L6_2atmpS2860;
      _M0L3idxS919 = _M0L6_2atmpS2861;
      continue;
    }
    break;
  }
}

struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0MPB3Map3getGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(
  struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L4selfS930,
  moonbit_string_t _M0L3keyS926
) {
  int32_t _M0L4hashS925;
  int32_t _M0L14capacity__maskS2880;
  int32_t _M0L6_2atmpS2879;
  int32_t _M0L1iS927;
  int32_t _M0L3idxS928;
  #line 244 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  #line 245 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L4hashS925 = _M0IPC16string6StringPB4Hash4hash(_M0L3keyS926);
  _M0L14capacity__maskS2880 = _M0L4selfS930->$3;
  _M0L6_2atmpS2879 = _M0L4hashS925 & _M0L14capacity__maskS2880;
  _M0L1iS927 = 0;
  _M0L3idxS928 = _M0L6_2atmpS2879;
  while (1) {
    struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE** _M0L7entriesS2878 =
      _M0L4selfS930->$0;
    struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L7_2abindS929;
    if (
      _M0L3idxS928 < 0
      || _M0L3idxS928 >= Moonbit_array_length(_M0L7entriesS2878)
    ) {
      #line 247 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
      moonbit_panic();
    }
    _M0L7_2abindS929
    = (struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*)_M0L7entriesS2878[
        _M0L3idxS928
      ];
    if (_M0L7_2abindS929 == 0) {
      struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0L6_2atmpS2867 = 0;
      return _M0L6_2atmpS2867;
    } else {
      struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L7_2aSomeS931 =
        _M0L7_2abindS929;
      struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L8_2aentryS932 =
        _M0L7_2aSomeS931;
      int32_t _M0L4hashS2869 = _M0L8_2aentryS932->$3;
      int32_t _if__result_4501;
      int32_t _M0L3pslS2872;
      int32_t _M0L6_2atmpS2874;
      int32_t _M0L6_2atmpS2876;
      int32_t _M0L14capacity__maskS2877;
      int32_t _M0L6_2atmpS2875;
      if (_M0L4hashS2869 == _M0L4hashS925) {
        moonbit_string_t _M0L3keyS2868 = _M0L8_2aentryS932->$4;
        #line 248 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
        _if__result_4501
        = _M0L3keyS2868 == _M0L3keyS926
          || Moonbit_array_length(_M0L3keyS2868)
             == Moonbit_array_length(_M0L3keyS926)
             && 0
                == memcmp(_M0L3keyS2868, _M0L3keyS926, Moonbit_array_length(_M0L3keyS2868) * 2);
      } else {
        _if__result_4501 = 0;
      }
      if (_if__result_4501) {
        struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0L5valueS2871 =
          _M0L8_2aentryS932->$5;
        struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0L6_2atmpS2870;
        moonbit_incref(_M0L5valueS2871);
        _M0L6_2atmpS2870 = _M0L5valueS2871;
        return _M0L6_2atmpS2870;
      } else {
        moonbit_incref(_M0L8_2aentryS932);
      }
      _M0L3pslS2872 = _M0L8_2aentryS932->$2;
      moonbit_decref(_M0L8_2aentryS932);
      if (_M0L1iS927 > _M0L3pslS2872) {
        struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0L6_2atmpS2873 = 0;
        return _M0L6_2atmpS2873;
      }
      _M0L6_2atmpS2874 = _M0L1iS927 + 1;
      _M0L6_2atmpS2876 = _M0L3idxS928 + 1;
      _M0L14capacity__maskS2877 = _M0L4selfS930->$3;
      _M0L6_2atmpS2875 = _M0L6_2atmpS2876 & _M0L14capacity__maskS2877;
      _M0L1iS927 = _M0L6_2atmpS2874;
      _M0L3idxS928 = _M0L6_2atmpS2875;
      continue;
    }
    break;
  }
}

struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0MPB3Map3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(
  struct _M0TPB9ArrayViewGUsRPB3MapGiUWEuQRPC15error5ErrorNsEEEE _M0L3arrS895,
  int64_t _M0L8capacityS897
) {
  int32_t _M0L3endS2840;
  int32_t _M0L5startS2841;
  int32_t _M0L6lengthS894;
  int32_t _M0L8capacityS896;
  struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L1mS900;
  int32_t _M0L3endS2837;
  int32_t _M0L5startS2838;
  int32_t _M0L7_2abindS901;
  int32_t _M0L2__S902;
  #line 84 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L3endS2840 = _M0L3arrS895.$2;
  _M0L5startS2841 = _M0L3arrS895.$1;
  _M0L6lengthS894 = _M0L3endS2840 - _M0L5startS2841;
  if (_M0L8capacityS897 == 4294967296ll) {
    if (_M0L6lengthS894 == 0) {
      _M0L8capacityS896 = 8;
    } else {
      #line 96 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
      _M0L8capacityS896 = _M0FPB21capacity__for__length(_M0L6lengthS894);
    }
  } else {
    int64_t _M0L7_2aSomeS898 = _M0L8capacityS897;
    int32_t _M0L11_2acapacityS899 = (int32_t)_M0L7_2aSomeS898;
    int32_t _M0L6_2atmpS2839;
    #line 91 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
    _M0L6_2atmpS2839 = _M0FPB21capacity__for__length(_M0L6lengthS894);
    #line 91 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
    _M0L8capacityS896
    = _M0MPC13int3Int3max(_M0L11_2acapacityS899, _M0L6_2atmpS2839);
  }
  #line 99 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L1mS900
  = _M0FPB8new__mapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(_M0L8capacityS896);
  _M0L3endS2837 = _M0L3arrS895.$2;
  _M0L5startS2838 = _M0L3arrS895.$1;
  _M0L7_2abindS901 = _M0L3endS2837 - _M0L5startS2838;
  _M0L2__S902 = 0;
  while (1) {
    if (_M0L2__S902 < _M0L7_2abindS901) {
      struct _M0TUsRPB3MapGiUWEuQRPC15error5ErrorNsEEE** _M0L3bufS2834 =
        _M0L3arrS895.$0;
      int32_t _M0L5startS2836 = _M0L3arrS895.$1;
      int32_t _M0L6_2atmpS2835 = _M0L5startS2836 + _M0L2__S902;
      struct _M0TUsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L1eS903 =
        (struct _M0TUsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*)_M0L3bufS2834[
          _M0L6_2atmpS2835
        ];
      moonbit_string_t _M0L6_2atmpS2831 = _M0L1eS903->$0;
      struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0L6_2atmpS2832 =
        _M0L1eS903->$1;
      int32_t _M0L6_2atmpS2833;
      moonbit_incref(_M0L6_2atmpS2832);
      moonbit_incref(_M0L6_2atmpS2831);
      #line 101 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
      _M0MPB3Map3setGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(_M0L1mS900, _M0L6_2atmpS2831, _M0L6_2atmpS2832);
      moonbit_decref(_M0L6_2atmpS2831);
      _M0L6_2atmpS2833 = _M0L2__S902 + 1;
      _M0L2__S902 = _M0L6_2atmpS2833;
      continue;
    }
    break;
  }
  return _M0L1mS900;
}

struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0MPB3Map3MapGiUWEuQRPC15error5ErrorNsEE(
  struct _M0TPB9ArrayViewGUiUWEuQRPC15error5ErrorNsEEE _M0L3arrS906,
  int64_t _M0L8capacityS908
) {
  int32_t _M0L3endS2851;
  int32_t _M0L5startS2852;
  int32_t _M0L6lengthS905;
  int32_t _M0L8capacityS907;
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0L1mS911;
  int32_t _M0L3endS2848;
  int32_t _M0L5startS2849;
  int32_t _M0L7_2abindS912;
  int32_t _M0L2__S913;
  #line 84 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L3endS2851 = _M0L3arrS906.$2;
  _M0L5startS2852 = _M0L3arrS906.$1;
  _M0L6lengthS905 = _M0L3endS2851 - _M0L5startS2852;
  if (_M0L8capacityS908 == 4294967296ll) {
    if (_M0L6lengthS905 == 0) {
      _M0L8capacityS907 = 8;
    } else {
      #line 96 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
      _M0L8capacityS907 = _M0FPB21capacity__for__length(_M0L6lengthS905);
    }
  } else {
    int64_t _M0L7_2aSomeS909 = _M0L8capacityS908;
    int32_t _M0L11_2acapacityS910 = (int32_t)_M0L7_2aSomeS909;
    int32_t _M0L6_2atmpS2850;
    #line 91 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
    _M0L6_2atmpS2850 = _M0FPB21capacity__for__length(_M0L6lengthS905);
    #line 91 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
    _M0L8capacityS907
    = _M0MPC13int3Int3max(_M0L11_2acapacityS910, _M0L6_2atmpS2850);
  }
  #line 99 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L1mS911 = _M0FPB8new__mapGiUWEuQRPC15error5ErrorNsEE(_M0L8capacityS907);
  _M0L3endS2848 = _M0L3arrS906.$2;
  _M0L5startS2849 = _M0L3arrS906.$1;
  _M0L7_2abindS912 = _M0L3endS2848 - _M0L5startS2849;
  _M0L2__S913 = 0;
  while (1) {
    if (_M0L2__S913 < _M0L7_2abindS912) {
      struct _M0TUiUWEuQRPC15error5ErrorNsEE** _M0L3bufS2845 =
        _M0L3arrS906.$0;
      int32_t _M0L5startS2847 = _M0L3arrS906.$1;
      int32_t _M0L6_2atmpS2846 = _M0L5startS2847 + _M0L2__S913;
      struct _M0TUiUWEuQRPC15error5ErrorNsEE* _M0L1eS914 =
        (struct _M0TUiUWEuQRPC15error5ErrorNsEE*)_M0L3bufS2845[
          _M0L6_2atmpS2846
        ];
      int32_t _M0L6_2atmpS2842 = _M0L1eS914->$0;
      struct _M0TUWEuQRPC15error5ErrorNsE* _M0L6_2atmpS2843 = _M0L1eS914->$1;
      int32_t _M0L6_2atmpS2844;
      moonbit_incref(_M0L6_2atmpS2843);
      #line 101 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
      _M0MPB3Map3setGiUWEuQRPC15error5ErrorNsEE(_M0L1mS911, _M0L6_2atmpS2842, _M0L6_2atmpS2843);
      _M0L6_2atmpS2844 = _M0L2__S913 + 1;
      _M0L2__S913 = _M0L6_2atmpS2844;
      continue;
    }
    break;
  }
  return _M0L1mS911;
}

int32_t _M0MPB3Map3setGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(
  struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L4selfS888,
  moonbit_string_t _M0L3keyS889,
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0L5valueS890
) {
  int32_t _M0L6_2atmpS2829;
  #line 128 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  #line 131 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L6_2atmpS2829 = _M0IPC16string6StringPB4Hash4hash(_M0L3keyS889);
  #line 131 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0MPB3Map15set__with__hashGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(_M0L4selfS888, _M0L3keyS889, _M0L5valueS890, _M0L6_2atmpS2829);
  return 0;
}

int32_t _M0MPB3Map3setGiUWEuQRPC15error5ErrorNsEE(
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0L4selfS891,
  int32_t _M0L3keyS892,
  struct _M0TUWEuQRPC15error5ErrorNsE* _M0L5valueS893
) {
  int32_t _M0L6_2atmpS2830;
  #line 128 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  #line 131 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L6_2atmpS2830 = _M0IPC13int3IntPB4Hash4hash(_M0L3keyS892);
  #line 131 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0MPB3Map15set__with__hashGiUWEuQRPC15error5ErrorNsEE(_M0L4selfS891, _M0L3keyS892, _M0L5valueS893, _M0L6_2atmpS2830);
  return 0;
}

int32_t _M0MPB3Map15set__with__hashGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(
  struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L4selfS859,
  moonbit_string_t _M0L3keyS865,
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0L5valueS866,
  int32_t _M0L4hashS861
) {
  int32_t _M0L14capacity__maskS2810;
  int32_t _M0L6_2atmpS2809;
  int32_t _M0L3pslS856;
  int32_t _M0L3idxS857;
  #line 135 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L14capacity__maskS2810 = _M0L4selfS859->$3;
  _M0L6_2atmpS2809 = _M0L4hashS861 & _M0L14capacity__maskS2810;
  _M0L3pslS856 = 0;
  _M0L3idxS857 = _M0L6_2atmpS2809;
  while (1) {
    struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE** _M0L7entriesS2808 =
      _M0L4selfS859->$0;
    struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L7_2abindS858;
    if (
      _M0L3idxS857 < 0
      || _M0L3idxS857 >= Moonbit_array_length(_M0L7entriesS2808)
    ) {
      #line 144 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
      moonbit_panic();
    }
    _M0L7_2abindS858
    = (struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*)_M0L7entriesS2808[
        _M0L3idxS857
      ];
    if (_M0L7_2abindS858 == 0) {
      int32_t _M0L4sizeS2793 = _M0L4selfS859->$1;
      int32_t _M0L8grow__atS2794 = _M0L4selfS859->$4;
      int32_t _M0L7_2abindS862;
      struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L7_2abindS863;
      struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L5entryS864;
      if (_M0L4sizeS2793 >= _M0L8grow__atS2794) {
        int32_t _M0L14capacity__maskS2796;
        int32_t _M0L6_2atmpS2795;
        #line 148 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
        _M0MPB3Map4growGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(_M0L4selfS859);
        _M0L14capacity__maskS2796 = _M0L4selfS859->$3;
        _M0L6_2atmpS2795 = _M0L4hashS861 & _M0L14capacity__maskS2796;
        _M0L3pslS856 = 0;
        _M0L3idxS857 = _M0L6_2atmpS2795;
        continue;
      }
      _M0L7_2abindS862 = _M0L4selfS859->$6;
      _M0L7_2abindS863 = 0;
      moonbit_incref(_M0L3keyS865);
      _M0L5entryS864
      = (struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*)moonbit_malloc(sizeof(struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE));
      Moonbit_object_header(_M0L5entryS864)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 116, 0);
      _M0L5entryS864->$0 = _M0L7_2abindS862;
      _M0L5entryS864->$1 = _M0L7_2abindS863;
      _M0L5entryS864->$2 = _M0L3pslS856;
      _M0L5entryS864->$3 = _M0L4hashS861;
      _M0L5entryS864->$4 = _M0L3keyS865;
      _M0L5entryS864->$5 = _M0L5valueS866;
      #line 153 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
      _M0MPB3Map20add__entry__to__tailGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(_M0L4selfS859, _M0L3idxS857, _M0L5entryS864);
      return 0;
    } else {
      struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L7_2aSomeS867 =
        _M0L7_2abindS858;
      struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L14_2acurr__entryS868 =
        _M0L7_2aSomeS867;
      int32_t _M0L4hashS2798 = _M0L14_2acurr__entryS868->$3;
      int32_t _if__result_4505;
      int32_t _M0L3pslS2799;
      int32_t _M0L6_2atmpS2804;
      int32_t _M0L6_2atmpS2806;
      int32_t _M0L14capacity__maskS2807;
      int32_t _M0L6_2atmpS2805;
      if (_M0L4hashS2798 == _M0L4hashS861) {
        moonbit_string_t _M0L3keyS2797 = _M0L14_2acurr__entryS868->$4;
        #line 157 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
        _if__result_4505
        = _M0L3keyS2797 == _M0L3keyS865
          || Moonbit_array_length(_M0L3keyS2797)
             == Moonbit_array_length(_M0L3keyS865)
             && 0
                == memcmp(_M0L3keyS2797, _M0L3keyS865, Moonbit_array_length(_M0L3keyS2797) * 2);
      } else {
        _if__result_4505 = 0;
      }
      if (_if__result_4505) {
        struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0L6_2aoldS4113 =
          _M0L14_2acurr__entryS868->$5;
        moonbit_decref(_M0L6_2aoldS4113);
        _M0L14_2acurr__entryS868->$5 = _M0L5valueS866;
        return 0;
      } else {
        moonbit_incref(_M0L14_2acurr__entryS868);
      }
      _M0L3pslS2799 = _M0L14_2acurr__entryS868->$2;
      if (_M0L3pslS856 > _M0L3pslS2799) {
        int32_t _M0L4sizeS2800 = _M0L4selfS859->$1;
        int32_t _M0L8grow__atS2801 = _M0L4selfS859->$4;
        int32_t _M0L7_2abindS869;
        struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L7_2abindS870;
        struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L5entryS871;
        if (_M0L4sizeS2800 >= _M0L8grow__atS2801) {
          int32_t _M0L14capacity__maskS2803;
          int32_t _M0L6_2atmpS2802;
          moonbit_decref(_M0L14_2acurr__entryS868);
          #line 165 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
          _M0MPB3Map4growGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(_M0L4selfS859);
          _M0L14capacity__maskS2803 = _M0L4selfS859->$3;
          _M0L6_2atmpS2802 = _M0L4hashS861 & _M0L14capacity__maskS2803;
          _M0L3pslS856 = 0;
          _M0L3idxS857 = _M0L6_2atmpS2802;
          continue;
        }
        #line 169 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
        _M0MPB3Map10push__awayGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(_M0L4selfS859, _M0L3idxS857, _M0L14_2acurr__entryS868);
        _M0L7_2abindS869 = _M0L4selfS859->$6;
        _M0L7_2abindS870 = 0;
        moonbit_incref(_M0L3keyS865);
        _M0L5entryS871
        = (struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*)moonbit_malloc(sizeof(struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE));
        Moonbit_object_header(_M0L5entryS871)->meta
        = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 116, 0);
        _M0L5entryS871->$0 = _M0L7_2abindS869;
        _M0L5entryS871->$1 = _M0L7_2abindS870;
        _M0L5entryS871->$2 = _M0L3pslS856;
        _M0L5entryS871->$3 = _M0L4hashS861;
        _M0L5entryS871->$4 = _M0L3keyS865;
        _M0L5entryS871->$5 = _M0L5valueS866;
        #line 171 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
        _M0MPB3Map20add__entry__to__tailGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(_M0L4selfS859, _M0L3idxS857, _M0L5entryS871);
        return 0;
      } else {
        moonbit_decref(_M0L14_2acurr__entryS868);
      }
      _M0L6_2atmpS2804 = _M0L3pslS856 + 1;
      _M0L6_2atmpS2806 = _M0L3idxS857 + 1;
      _M0L14capacity__maskS2807 = _M0L4selfS859->$3;
      _M0L6_2atmpS2805 = _M0L6_2atmpS2806 & _M0L14capacity__maskS2807;
      _M0L3pslS856 = _M0L6_2atmpS2804;
      _M0L3idxS857 = _M0L6_2atmpS2805;
      continue;
    }
    break;
  }
  return 0;
}

int32_t _M0MPB3Map15set__with__hashGiUWEuQRPC15error5ErrorNsEE(
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0L4selfS875,
  int32_t _M0L3keyS881,
  struct _M0TUWEuQRPC15error5ErrorNsE* _M0L5valueS882,
  int32_t _M0L4hashS877
) {
  int32_t _M0L14capacity__maskS2828;
  int32_t _M0L6_2atmpS2827;
  int32_t _M0L3pslS872;
  int32_t _M0L3idxS873;
  #line 135 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L14capacity__maskS2828 = _M0L4selfS875->$3;
  _M0L6_2atmpS2827 = _M0L4hashS877 & _M0L14capacity__maskS2828;
  _M0L3pslS872 = 0;
  _M0L3idxS873 = _M0L6_2atmpS2827;
  while (1) {
    struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE** _M0L7entriesS2826 =
      _M0L4selfS875->$0;
    struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L7_2abindS874;
    if (
      _M0L3idxS873 < 0
      || _M0L3idxS873 >= Moonbit_array_length(_M0L7entriesS2826)
    ) {
      #line 144 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
      moonbit_panic();
    }
    _M0L7_2abindS874
    = (struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE*)_M0L7entriesS2826[
        _M0L3idxS873
      ];
    if (_M0L7_2abindS874 == 0) {
      int32_t _M0L4sizeS2811 = _M0L4selfS875->$1;
      int32_t _M0L8grow__atS2812 = _M0L4selfS875->$4;
      int32_t _M0L7_2abindS878;
      struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L7_2abindS879;
      struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L5entryS880;
      if (_M0L4sizeS2811 >= _M0L8grow__atS2812) {
        int32_t _M0L14capacity__maskS2814;
        int32_t _M0L6_2atmpS2813;
        #line 148 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
        _M0MPB3Map4growGiUWEuQRPC15error5ErrorNsEE(_M0L4selfS875);
        _M0L14capacity__maskS2814 = _M0L4selfS875->$3;
        _M0L6_2atmpS2813 = _M0L4hashS877 & _M0L14capacity__maskS2814;
        _M0L3pslS872 = 0;
        _M0L3idxS873 = _M0L6_2atmpS2813;
        continue;
      }
      _M0L7_2abindS878 = _M0L4selfS875->$6;
      _M0L7_2abindS879 = 0;
      _M0L5entryS880
      = (struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE*)moonbit_malloc(sizeof(struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE));
      Moonbit_object_header(_M0L5entryS880)->meta
      = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 121, 0);
      _M0L5entryS880->$0 = _M0L7_2abindS878;
      _M0L5entryS880->$1 = _M0L7_2abindS879;
      _M0L5entryS880->$2 = _M0L3pslS872;
      _M0L5entryS880->$3 = _M0L4hashS877;
      _M0L5entryS880->$4 = _M0L3keyS881;
      _M0L5entryS880->$5 = _M0L5valueS882;
      #line 153 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
      _M0MPB3Map20add__entry__to__tailGiUWEuQRPC15error5ErrorNsEE(_M0L4selfS875, _M0L3idxS873, _M0L5entryS880);
      return 0;
    } else {
      struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L7_2aSomeS883 =
        _M0L7_2abindS874;
      struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L14_2acurr__entryS884 =
        _M0L7_2aSomeS883;
      int32_t _M0L4hashS2816 = _M0L14_2acurr__entryS884->$3;
      int32_t _if__result_4507;
      int32_t _M0L3pslS2817;
      int32_t _M0L6_2atmpS2822;
      int32_t _M0L6_2atmpS2824;
      int32_t _M0L14capacity__maskS2825;
      int32_t _M0L6_2atmpS2823;
      if (_M0L4hashS2816 == _M0L4hashS877) {
        int32_t _M0L3keyS2815 = _M0L14_2acurr__entryS884->$4;
        _if__result_4507 = _M0L3keyS2815 == _M0L3keyS881;
      } else {
        _if__result_4507 = 0;
      }
      if (_if__result_4507) {
        struct _M0TUWEuQRPC15error5ErrorNsE* _M0L6_2aoldS4117 =
          _M0L14_2acurr__entryS884->$5;
        moonbit_decref(_M0L6_2aoldS4117);
        _M0L14_2acurr__entryS884->$5 = _M0L5valueS882;
        return 0;
      } else {
        moonbit_incref(_M0L14_2acurr__entryS884);
      }
      _M0L3pslS2817 = _M0L14_2acurr__entryS884->$2;
      if (_M0L3pslS872 > _M0L3pslS2817) {
        int32_t _M0L4sizeS2818 = _M0L4selfS875->$1;
        int32_t _M0L8grow__atS2819 = _M0L4selfS875->$4;
        int32_t _M0L7_2abindS885;
        struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L7_2abindS886;
        struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L5entryS887;
        if (_M0L4sizeS2818 >= _M0L8grow__atS2819) {
          int32_t _M0L14capacity__maskS2821;
          int32_t _M0L6_2atmpS2820;
          moonbit_decref(_M0L14_2acurr__entryS884);
          #line 165 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
          _M0MPB3Map4growGiUWEuQRPC15error5ErrorNsEE(_M0L4selfS875);
          _M0L14capacity__maskS2821 = _M0L4selfS875->$3;
          _M0L6_2atmpS2820 = _M0L4hashS877 & _M0L14capacity__maskS2821;
          _M0L3pslS872 = 0;
          _M0L3idxS873 = _M0L6_2atmpS2820;
          continue;
        }
        #line 169 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
        _M0MPB3Map10push__awayGiUWEuQRPC15error5ErrorNsEE(_M0L4selfS875, _M0L3idxS873, _M0L14_2acurr__entryS884);
        _M0L7_2abindS885 = _M0L4selfS875->$6;
        _M0L7_2abindS886 = 0;
        _M0L5entryS887
        = (struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE*)moonbit_malloc(sizeof(struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE));
        Moonbit_object_header(_M0L5entryS887)->meta
        = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 121, 0);
        _M0L5entryS887->$0 = _M0L7_2abindS885;
        _M0L5entryS887->$1 = _M0L7_2abindS886;
        _M0L5entryS887->$2 = _M0L3pslS872;
        _M0L5entryS887->$3 = _M0L4hashS877;
        _M0L5entryS887->$4 = _M0L3keyS881;
        _M0L5entryS887->$5 = _M0L5valueS882;
        #line 171 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
        _M0MPB3Map20add__entry__to__tailGiUWEuQRPC15error5ErrorNsEE(_M0L4selfS875, _M0L3idxS873, _M0L5entryS887);
        return 0;
      } else {
        moonbit_decref(_M0L14_2acurr__entryS884);
      }
      _M0L6_2atmpS2822 = _M0L3pslS872 + 1;
      _M0L6_2atmpS2824 = _M0L3idxS873 + 1;
      _M0L14capacity__maskS2825 = _M0L4selfS875->$3;
      _M0L6_2atmpS2823 = _M0L6_2atmpS2824 & _M0L14capacity__maskS2825;
      _M0L3pslS872 = _M0L6_2atmpS2822;
      _M0L3idxS873 = _M0L6_2atmpS2823;
      continue;
    }
    break;
  }
  return 0;
}

int32_t _M0MPB3Map4growGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(
  struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L4selfS841
) {
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L9old__headS840;
  int32_t _M0L8capacityS2784;
  int32_t _M0L13new__capacityS842;
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L6_2atmpS2778;
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE** _M0L6_2atmpS2777;
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE** _M0L6_2aoldS4123;
  int32_t _M0L6_2atmpS2779;
  int32_t _M0L8capacityS2781;
  int32_t _M0L6_2atmpS2780;
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L6_2atmpS2782;
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L6_2aoldS4122;
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L1xS843;
  #line 570 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L9old__headS840 = _M0L4selfS841->$5;
  _M0L8capacityS2784 = _M0L4selfS841->$2;
  _M0L13new__capacityS842 = _M0L8capacityS2784 << 1;
  _M0L6_2atmpS2778 = 0;
  _M0L6_2atmpS2777
  = (struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE**)moonbit_make_ref_array(_M0L13new__capacityS842, _M0L6_2atmpS2778);
  _M0L6_2aoldS4123 = _M0L4selfS841->$0;
  if (_M0L9old__headS840) {
    moonbit_incref(_M0L9old__headS840);
  }
  moonbit_decref(_M0L6_2aoldS4123);
  _M0L4selfS841->$0 = _M0L6_2atmpS2777;
  _M0L4selfS841->$2 = _M0L13new__capacityS842;
  _M0L6_2atmpS2779 = _M0L13new__capacityS842 - 1;
  _M0L4selfS841->$3 = _M0L6_2atmpS2779;
  _M0L8capacityS2781 = _M0L4selfS841->$2;
  #line 576 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L6_2atmpS2780 = _M0FPB21calc__grow__threshold(_M0L8capacityS2781);
  _M0L4selfS841->$4 = _M0L6_2atmpS2780;
  _M0L4selfS841->$1 = 0;
  _M0L6_2atmpS2782 = 0;
  _M0L6_2aoldS4122 = _M0L4selfS841->$5;
  if (_M0L6_2aoldS4122) {
    moonbit_decref(_M0L6_2aoldS4122);
  }
  _M0L4selfS841->$5 = _M0L6_2atmpS2782;
  _M0L4selfS841->$6 = -1;
  _M0L1xS843 = _M0L9old__headS840;
  while (1) {
    if (_M0L1xS843 == 0) {
      if (_M0L1xS843) {
        moonbit_decref(_M0L1xS843);
      }
      break;
    } else {
      struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L7_2aSomeS845 =
        _M0L1xS843;
      struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L4_2aeS846 =
        _M0L7_2aSomeS845;
      struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L15next__in__chainS847 =
        _M0L4_2aeS846->$1;
      struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L6_2atmpS2783 =
        0;
      struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L6_2aoldS4120 =
        _M0L4_2aeS846->$1;
      _M0L4_2aeS846->$1 = _M0L6_2atmpS2783;
      #line 586 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
      _M0MPB3Map20rehash__place__entryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(_M0L4selfS841, _M0L4_2aeS846);
      _M0L1xS843 = _M0L15next__in__chainS847;
      continue;
    }
    break;
  }
  return 0;
}

int32_t _M0MPB3Map4growGiUWEuQRPC15error5ErrorNsEE(
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0L4selfS849
) {
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L9old__headS848;
  int32_t _M0L8capacityS2792;
  int32_t _M0L13new__capacityS850;
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L6_2atmpS2786;
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE** _M0L6_2atmpS2785;
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE** _M0L6_2aoldS4128;
  int32_t _M0L6_2atmpS2787;
  int32_t _M0L8capacityS2789;
  int32_t _M0L6_2atmpS2788;
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L6_2atmpS2790;
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L6_2aoldS4127;
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L1xS851;
  #line 570 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L9old__headS848 = _M0L4selfS849->$5;
  _M0L8capacityS2792 = _M0L4selfS849->$2;
  _M0L13new__capacityS850 = _M0L8capacityS2792 << 1;
  _M0L6_2atmpS2786 = 0;
  _M0L6_2atmpS2785
  = (struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE**)moonbit_make_ref_array(_M0L13new__capacityS850, _M0L6_2atmpS2786);
  _M0L6_2aoldS4128 = _M0L4selfS849->$0;
  if (_M0L9old__headS848) {
    moonbit_incref(_M0L9old__headS848);
  }
  moonbit_decref(_M0L6_2aoldS4128);
  _M0L4selfS849->$0 = _M0L6_2atmpS2785;
  _M0L4selfS849->$2 = _M0L13new__capacityS850;
  _M0L6_2atmpS2787 = _M0L13new__capacityS850 - 1;
  _M0L4selfS849->$3 = _M0L6_2atmpS2787;
  _M0L8capacityS2789 = _M0L4selfS849->$2;
  #line 576 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L6_2atmpS2788 = _M0FPB21calc__grow__threshold(_M0L8capacityS2789);
  _M0L4selfS849->$4 = _M0L6_2atmpS2788;
  _M0L4selfS849->$1 = 0;
  _M0L6_2atmpS2790 = 0;
  _M0L6_2aoldS4127 = _M0L4selfS849->$5;
  if (_M0L6_2aoldS4127) {
    moonbit_decref(_M0L6_2aoldS4127);
  }
  _M0L4selfS849->$5 = _M0L6_2atmpS2790;
  _M0L4selfS849->$6 = -1;
  _M0L1xS851 = _M0L9old__headS848;
  while (1) {
    if (_M0L1xS851 == 0) {
      if (_M0L1xS851) {
        moonbit_decref(_M0L1xS851);
      }
      break;
    } else {
      struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L7_2aSomeS853 =
        _M0L1xS851;
      struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L4_2aeS854 =
        _M0L7_2aSomeS853;
      struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L15next__in__chainS855 =
        _M0L4_2aeS854->$1;
      struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L6_2atmpS2791 = 0;
      struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L6_2aoldS4125 =
        _M0L4_2aeS854->$1;
      _M0L4_2aeS854->$1 = _M0L6_2atmpS2791;
      #line 586 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
      _M0MPB3Map20rehash__place__entryGiUWEuQRPC15error5ErrorNsEE(_M0L4selfS849, _M0L4_2aeS854);
      _M0L1xS851 = _M0L15next__in__chainS855;
      continue;
    }
    break;
  }
  return 0;
}

int32_t _M0MPB3Map20rehash__place__entryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(
  struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L4selfS827,
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L5outerS823
) {
  int32_t _M0L4hashS822;
  int32_t _M0L14capacity__maskS2766;
  int32_t _M0L6_2atmpS2765;
  int32_t _M0L3pslS824;
  int32_t _M0L3idxS825;
  #line 594 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L4hashS822 = _M0L5outerS823->$3;
  _M0L14capacity__maskS2766 = _M0L4selfS827->$3;
  _M0L6_2atmpS2765 = _M0L4hashS822 & _M0L14capacity__maskS2766;
  _M0L3pslS824 = 0;
  _M0L3idxS825 = _M0L6_2atmpS2765;
  while (1) {
    struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE** _M0L7entriesS2764 =
      _M0L4selfS827->$0;
    struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L7_2abindS826;
    if (
      _M0L3idxS825 < 0
      || _M0L3idxS825 >= Moonbit_array_length(_M0L7entriesS2764)
    ) {
      #line 598 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
      moonbit_panic();
    }
    _M0L7_2abindS826
    = (struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*)_M0L7entriesS2764[
        _M0L3idxS825
      ];
    if (_M0L7_2abindS826 == 0) {
      int32_t _M0L4tailS2757;
      _M0L5outerS823->$2 = _M0L3pslS824;
      _M0L4tailS2757 = _M0L4selfS827->$6;
      _M0L5outerS823->$0 = _M0L4tailS2757;
      #line 602 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
      _M0MPB3Map20add__entry__to__tailGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(_M0L4selfS827, _M0L3idxS825, _M0L5outerS823);
      return 0;
    } else {
      struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L7_2aSomeS828 =
        _M0L7_2abindS826;
      struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L7_2acurrS829 =
        _M0L7_2aSomeS828;
      int32_t _M0L3pslS2758 = _M0L7_2acurrS829->$2;
      if (_M0L3pslS824 > _M0L3pslS2758) {
        int32_t _M0L4tailS2759;
        moonbit_incref(_M0L7_2acurrS829);
        #line 607 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
        _M0MPB3Map10push__awayGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(_M0L4selfS827, _M0L3idxS825, _M0L7_2acurrS829);
        _M0L5outerS823->$2 = _M0L3pslS824;
        _M0L4tailS2759 = _M0L4selfS827->$6;
        _M0L5outerS823->$0 = _M0L4tailS2759;
        #line 610 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
        _M0MPB3Map20add__entry__to__tailGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(_M0L4selfS827, _M0L3idxS825, _M0L5outerS823);
        return 0;
      } else {
        int32_t _M0L6_2atmpS2760 = _M0L3pslS824 + 1;
        int32_t _M0L6_2atmpS2762 = _M0L3idxS825 + 1;
        int32_t _M0L14capacity__maskS2763 = _M0L4selfS827->$3;
        int32_t _M0L6_2atmpS2761 =
          _M0L6_2atmpS2762 & _M0L14capacity__maskS2763;
        _M0L3pslS824 = _M0L6_2atmpS2760;
        _M0L3idxS825 = _M0L6_2atmpS2761;
        continue;
      }
    }
    break;
  }
  return 0;
}

int32_t _M0MPB3Map20rehash__place__entryGiUWEuQRPC15error5ErrorNsEE(
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0L4selfS836,
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L5outerS832
) {
  int32_t _M0L4hashS831;
  int32_t _M0L14capacity__maskS2776;
  int32_t _M0L6_2atmpS2775;
  int32_t _M0L3pslS833;
  int32_t _M0L3idxS834;
  #line 594 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L4hashS831 = _M0L5outerS832->$3;
  _M0L14capacity__maskS2776 = _M0L4selfS836->$3;
  _M0L6_2atmpS2775 = _M0L4hashS831 & _M0L14capacity__maskS2776;
  _M0L3pslS833 = 0;
  _M0L3idxS834 = _M0L6_2atmpS2775;
  while (1) {
    struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE** _M0L7entriesS2774 =
      _M0L4selfS836->$0;
    struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L7_2abindS835;
    if (
      _M0L3idxS834 < 0
      || _M0L3idxS834 >= Moonbit_array_length(_M0L7entriesS2774)
    ) {
      #line 598 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
      moonbit_panic();
    }
    _M0L7_2abindS835
    = (struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE*)_M0L7entriesS2774[
        _M0L3idxS834
      ];
    if (_M0L7_2abindS835 == 0) {
      int32_t _M0L4tailS2767;
      _M0L5outerS832->$2 = _M0L3pslS833;
      _M0L4tailS2767 = _M0L4selfS836->$6;
      _M0L5outerS832->$0 = _M0L4tailS2767;
      #line 602 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
      _M0MPB3Map20add__entry__to__tailGiUWEuQRPC15error5ErrorNsEE(_M0L4selfS836, _M0L3idxS834, _M0L5outerS832);
      return 0;
    } else {
      struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L7_2aSomeS837 =
        _M0L7_2abindS835;
      struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L7_2acurrS838 =
        _M0L7_2aSomeS837;
      int32_t _M0L3pslS2768 = _M0L7_2acurrS838->$2;
      if (_M0L3pslS833 > _M0L3pslS2768) {
        int32_t _M0L4tailS2769;
        moonbit_incref(_M0L7_2acurrS838);
        #line 607 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
        _M0MPB3Map10push__awayGiUWEuQRPC15error5ErrorNsEE(_M0L4selfS836, _M0L3idxS834, _M0L7_2acurrS838);
        _M0L5outerS832->$2 = _M0L3pslS833;
        _M0L4tailS2769 = _M0L4selfS836->$6;
        _M0L5outerS832->$0 = _M0L4tailS2769;
        #line 610 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
        _M0MPB3Map20add__entry__to__tailGiUWEuQRPC15error5ErrorNsEE(_M0L4selfS836, _M0L3idxS834, _M0L5outerS832);
        return 0;
      } else {
        int32_t _M0L6_2atmpS2770 = _M0L3pslS833 + 1;
        int32_t _M0L6_2atmpS2772 = _M0L3idxS834 + 1;
        int32_t _M0L14capacity__maskS2773 = _M0L4selfS836->$3;
        int32_t _M0L6_2atmpS2771 =
          _M0L6_2atmpS2772 & _M0L14capacity__maskS2773;
        _M0L3pslS833 = _M0L6_2atmpS2770;
        _M0L3idxS834 = _M0L6_2atmpS2771;
        continue;
      }
    }
    break;
  }
  return 0;
}

int32_t _M0MPB3Map10push__awayGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(
  struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L4selfS806,
  int32_t _M0L3idxS811,
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L5entryS810
) {
  int32_t _M0L3pslS2740;
  int32_t _M0L6_2atmpS2736;
  int32_t _M0L6_2atmpS2738;
  int32_t _M0L14capacity__maskS2739;
  int32_t _M0L6_2atmpS2737;
  int32_t _M0L3pslS802;
  int32_t _M0L3idxS803;
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L5entryS804;
  #line 181 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L3pslS2740 = _M0L5entryS810->$2;
  _M0L6_2atmpS2736 = _M0L3pslS2740 + 1;
  _M0L6_2atmpS2738 = _M0L3idxS811 + 1;
  _M0L14capacity__maskS2739 = _M0L4selfS806->$3;
  _M0L6_2atmpS2737 = _M0L6_2atmpS2738 & _M0L14capacity__maskS2739;
  _M0L3pslS802 = _M0L6_2atmpS2736;
  _M0L3idxS803 = _M0L6_2atmpS2737;
  _M0L5entryS804 = _M0L5entryS810;
  while (1) {
    struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE** _M0L7entriesS2735 =
      _M0L4selfS806->$0;
    struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L7_2abindS805;
    if (
      _M0L3idxS803 < 0
      || _M0L3idxS803 >= Moonbit_array_length(_M0L7entriesS2735)
    ) {
      #line 188 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
      moonbit_panic();
    }
    _M0L7_2abindS805
    = (struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*)_M0L7entriesS2735[
        _M0L3idxS803
      ];
    if (_M0L7_2abindS805 == 0) {
      _M0L5entryS804->$2 = _M0L3pslS802;
      #line 191 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
      _M0MPB3Map10set__entryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(_M0L4selfS806, _M0L5entryS804, _M0L3idxS803);
      break;
    } else {
      struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L7_2aSomeS808 =
        _M0L7_2abindS805;
      struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L14_2acurr__entryS809 =
        _M0L7_2aSomeS808;
      int32_t _M0L3pslS2725 = _M0L14_2acurr__entryS809->$2;
      if (_M0L3pslS802 > _M0L3pslS2725) {
        int32_t _M0L3pslS2730;
        int32_t _M0L6_2atmpS2726;
        int32_t _M0L6_2atmpS2728;
        int32_t _M0L14capacity__maskS2729;
        int32_t _M0L6_2atmpS2727;
        _M0L5entryS804->$2 = _M0L3pslS802;
        moonbit_incref(_M0L14_2acurr__entryS809);
        #line 197 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
        _M0MPB3Map10set__entryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(_M0L4selfS806, _M0L5entryS804, _M0L3idxS803);
        _M0L3pslS2730 = _M0L14_2acurr__entryS809->$2;
        _M0L6_2atmpS2726 = _M0L3pslS2730 + 1;
        _M0L6_2atmpS2728 = _M0L3idxS803 + 1;
        _M0L14capacity__maskS2729 = _M0L4selfS806->$3;
        _M0L6_2atmpS2727 = _M0L6_2atmpS2728 & _M0L14capacity__maskS2729;
        _M0L3pslS802 = _M0L6_2atmpS2726;
        _M0L3idxS803 = _M0L6_2atmpS2727;
        _M0L5entryS804 = _M0L14_2acurr__entryS809;
        continue;
      } else {
        int32_t _M0L6_2atmpS2731 = _M0L3pslS802 + 1;
        int32_t _M0L6_2atmpS2733 = _M0L3idxS803 + 1;
        int32_t _M0L14capacity__maskS2734 = _M0L4selfS806->$3;
        int32_t _M0L6_2atmpS2732 =
          _M0L6_2atmpS2733 & _M0L14capacity__maskS2734;
        struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _tmp_4513 =
          _M0L5entryS804;
        _M0L3pslS802 = _M0L6_2atmpS2731;
        _M0L3idxS803 = _M0L6_2atmpS2732;
        _M0L5entryS804 = _tmp_4513;
        continue;
      }
    }
    break;
  }
  return 0;
}

int32_t _M0MPB3Map10push__awayGiUWEuQRPC15error5ErrorNsEE(
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0L4selfS816,
  int32_t _M0L3idxS821,
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L5entryS820
) {
  int32_t _M0L3pslS2756;
  int32_t _M0L6_2atmpS2752;
  int32_t _M0L6_2atmpS2754;
  int32_t _M0L14capacity__maskS2755;
  int32_t _M0L6_2atmpS2753;
  int32_t _M0L3pslS812;
  int32_t _M0L3idxS813;
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L5entryS814;
  #line 181 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L3pslS2756 = _M0L5entryS820->$2;
  _M0L6_2atmpS2752 = _M0L3pslS2756 + 1;
  _M0L6_2atmpS2754 = _M0L3idxS821 + 1;
  _M0L14capacity__maskS2755 = _M0L4selfS816->$3;
  _M0L6_2atmpS2753 = _M0L6_2atmpS2754 & _M0L14capacity__maskS2755;
  _M0L3pslS812 = _M0L6_2atmpS2752;
  _M0L3idxS813 = _M0L6_2atmpS2753;
  _M0L5entryS814 = _M0L5entryS820;
  while (1) {
    struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE** _M0L7entriesS2751 =
      _M0L4selfS816->$0;
    struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L7_2abindS815;
    if (
      _M0L3idxS813 < 0
      || _M0L3idxS813 >= Moonbit_array_length(_M0L7entriesS2751)
    ) {
      #line 188 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
      moonbit_panic();
    }
    _M0L7_2abindS815
    = (struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE*)_M0L7entriesS2751[
        _M0L3idxS813
      ];
    if (_M0L7_2abindS815 == 0) {
      _M0L5entryS814->$2 = _M0L3pslS812;
      #line 191 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
      _M0MPB3Map10set__entryGiUWEuQRPC15error5ErrorNsEE(_M0L4selfS816, _M0L5entryS814, _M0L3idxS813);
      break;
    } else {
      struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L7_2aSomeS818 =
        _M0L7_2abindS815;
      struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L14_2acurr__entryS819 =
        _M0L7_2aSomeS818;
      int32_t _M0L3pslS2741 = _M0L14_2acurr__entryS819->$2;
      if (_M0L3pslS812 > _M0L3pslS2741) {
        int32_t _M0L3pslS2746;
        int32_t _M0L6_2atmpS2742;
        int32_t _M0L6_2atmpS2744;
        int32_t _M0L14capacity__maskS2745;
        int32_t _M0L6_2atmpS2743;
        _M0L5entryS814->$2 = _M0L3pslS812;
        moonbit_incref(_M0L14_2acurr__entryS819);
        #line 197 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
        _M0MPB3Map10set__entryGiUWEuQRPC15error5ErrorNsEE(_M0L4selfS816, _M0L5entryS814, _M0L3idxS813);
        _M0L3pslS2746 = _M0L14_2acurr__entryS819->$2;
        _M0L6_2atmpS2742 = _M0L3pslS2746 + 1;
        _M0L6_2atmpS2744 = _M0L3idxS813 + 1;
        _M0L14capacity__maskS2745 = _M0L4selfS816->$3;
        _M0L6_2atmpS2743 = _M0L6_2atmpS2744 & _M0L14capacity__maskS2745;
        _M0L3pslS812 = _M0L6_2atmpS2742;
        _M0L3idxS813 = _M0L6_2atmpS2743;
        _M0L5entryS814 = _M0L14_2acurr__entryS819;
        continue;
      } else {
        int32_t _M0L6_2atmpS2747 = _M0L3pslS812 + 1;
        int32_t _M0L6_2atmpS2749 = _M0L3idxS813 + 1;
        int32_t _M0L14capacity__maskS2750 = _M0L4selfS816->$3;
        int32_t _M0L6_2atmpS2748 =
          _M0L6_2atmpS2749 & _M0L14capacity__maskS2750;
        struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _tmp_4515 =
          _M0L5entryS814;
        _M0L3pslS812 = _M0L6_2atmpS2747;
        _M0L3idxS813 = _M0L6_2atmpS2748;
        _M0L5entryS814 = _tmp_4515;
        continue;
      }
    }
    break;
  }
  return 0;
}

int32_t _M0MPB3Map10set__entryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(
  struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L4selfS792,
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L5entryS791,
  int32_t _M0L8new__idxS793
) {
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L7_2abindS790;
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE** _M0L7entriesS2721;
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L6_2atmpS2722;
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L6_2aoldS4138;
  #line 209 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L7_2abindS790 = _M0L5entryS791->$1;
  if (_M0L7_2abindS790 == 0) {
    _M0L4selfS792->$6 = _M0L8new__idxS793;
  } else {
    struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L7_2aSomeS794 =
      _M0L7_2abindS790;
    struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L7_2anextS795 =
      _M0L7_2aSomeS794;
    _M0L7_2anextS795->$0 = _M0L8new__idxS793;
  }
  _M0L7entriesS2721 = _M0L4selfS792->$0;
  _M0L6_2atmpS2722 = _M0L5entryS791;
  if (
    _M0L8new__idxS793 < 0
    || _M0L8new__idxS793 >= Moonbit_array_length(_M0L7entriesS2721)
  ) {
    #line 222 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
    moonbit_panic();
  }
  _M0L6_2aoldS4138
  = (struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*)_M0L7entriesS2721[
      _M0L8new__idxS793
    ];
  if (_M0L6_2aoldS4138) {
    moonbit_decref(_M0L6_2aoldS4138);
  }
  _M0L7entriesS2721[_M0L8new__idxS793] = _M0L6_2atmpS2722;
  return 0;
}

int32_t _M0MPB3Map10set__entryGiUWEuQRPC15error5ErrorNsEE(
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0L4selfS798,
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L5entryS797,
  int32_t _M0L8new__idxS799
) {
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L7_2abindS796;
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE** _M0L7entriesS2723;
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L6_2atmpS2724;
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L6_2aoldS4141;
  #line 209 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L7_2abindS796 = _M0L5entryS797->$1;
  if (_M0L7_2abindS796 == 0) {
    _M0L4selfS798->$6 = _M0L8new__idxS799;
  } else {
    struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L7_2aSomeS800 =
      _M0L7_2abindS796;
    struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L7_2anextS801 =
      _M0L7_2aSomeS800;
    _M0L7_2anextS801->$0 = _M0L8new__idxS799;
  }
  _M0L7entriesS2723 = _M0L4selfS798->$0;
  _M0L6_2atmpS2724 = _M0L5entryS797;
  if (
    _M0L8new__idxS799 < 0
    || _M0L8new__idxS799 >= Moonbit_array_length(_M0L7entriesS2723)
  ) {
    #line 222 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
    moonbit_panic();
  }
  _M0L6_2aoldS4141
  = (struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE*)_M0L7entriesS2723[
      _M0L8new__idxS799
    ];
  if (_M0L6_2aoldS4141) {
    moonbit_decref(_M0L6_2aoldS4141);
  }
  _M0L7entriesS2723[_M0L8new__idxS799] = _M0L6_2atmpS2724;
  return 0;
}

int32_t _M0MPB3Map20add__entry__to__tailGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(
  struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L4selfS783,
  int32_t _M0L3idxS785,
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L5entryS784
) {
  int32_t _M0L7_2abindS782;
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE** _M0L7entriesS2708;
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L6_2atmpS2709;
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L6_2aoldS4144;
  int32_t _M0L4sizeS2711;
  int32_t _M0L6_2atmpS2710;
  #line 524 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L7_2abindS782 = _M0L4selfS783->$6;
  switch (_M0L7_2abindS782) {
    case -1: {
      struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L6_2atmpS2703;
      struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L6_2aoldS4146;
      moonbit_incref(_M0L5entryS784);
      _M0L6_2atmpS2703 = _M0L5entryS784;
      _M0L6_2aoldS4146 = _M0L4selfS783->$5;
      if (_M0L6_2aoldS4146) {
        moonbit_decref(_M0L6_2aoldS4146);
      }
      _M0L4selfS783->$5 = _M0L6_2atmpS2703;
      break;
    }
    default: {
      struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE** _M0L7entriesS2707 =
        _M0L4selfS783->$0;
      struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L6_2atmpS2706;
      struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L6_2atmpS2704;
      struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L6_2atmpS2705;
      struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L6_2aoldS4147;
      if (
        _M0L7_2abindS782 < 0
        || _M0L7_2abindS782 >= Moonbit_array_length(_M0L7entriesS2707)
      ) {
        #line 532 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
        moonbit_panic();
      }
      _M0L6_2atmpS2706
      = (struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*)_M0L7entriesS2707[
          _M0L7_2abindS782
        ];
      if (_M0L6_2atmpS2706) {
        moonbit_incref(_M0L6_2atmpS2706);
      }
      #line 532 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
      _M0L6_2atmpS2704
      = _M0MPC16option6Option6unwrapGRPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEEE(_M0L6_2atmpS2706);
      if (_M0L6_2atmpS2706) {
        moonbit_decref(_M0L6_2atmpS2706);
      }
      moonbit_incref(_M0L5entryS784);
      _M0L6_2atmpS2705 = _M0L5entryS784;
      _M0L6_2aoldS4147 = _M0L6_2atmpS2704->$1;
      if (_M0L6_2aoldS4147) {
        moonbit_decref(_M0L6_2aoldS4147);
      }
      _M0L6_2atmpS2704->$1 = _M0L6_2atmpS2705;
      moonbit_decref(_M0L6_2atmpS2704);
      break;
    }
  }
  _M0L4selfS783->$6 = _M0L3idxS785;
  _M0L7entriesS2708 = _M0L4selfS783->$0;
  _M0L6_2atmpS2709 = _M0L5entryS784;
  if (
    _M0L3idxS785 < 0
    || _M0L3idxS785 >= Moonbit_array_length(_M0L7entriesS2708)
  ) {
    #line 535 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
    moonbit_panic();
  }
  _M0L6_2aoldS4144
  = (struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*)_M0L7entriesS2708[
      _M0L3idxS785
    ];
  if (_M0L6_2aoldS4144) {
    moonbit_decref(_M0L6_2aoldS4144);
  }
  _M0L7entriesS2708[_M0L3idxS785] = _M0L6_2atmpS2709;
  _M0L4sizeS2711 = _M0L4selfS783->$1;
  _M0L6_2atmpS2710 = _M0L4sizeS2711 + 1;
  _M0L4selfS783->$1 = _M0L6_2atmpS2710;
  return 0;
}

int32_t _M0MPB3Map20add__entry__to__tailGiUWEuQRPC15error5ErrorNsEE(
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0L4selfS787,
  int32_t _M0L3idxS789,
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L5entryS788
) {
  int32_t _M0L7_2abindS786;
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE** _M0L7entriesS2717;
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L6_2atmpS2718;
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L6_2aoldS4150;
  int32_t _M0L4sizeS2720;
  int32_t _M0L6_2atmpS2719;
  #line 524 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L7_2abindS786 = _M0L4selfS787->$6;
  switch (_M0L7_2abindS786) {
    case -1: {
      struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L6_2atmpS2712;
      struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L6_2aoldS4152;
      moonbit_incref(_M0L5entryS788);
      _M0L6_2atmpS2712 = _M0L5entryS788;
      _M0L6_2aoldS4152 = _M0L4selfS787->$5;
      if (_M0L6_2aoldS4152) {
        moonbit_decref(_M0L6_2aoldS4152);
      }
      _M0L4selfS787->$5 = _M0L6_2atmpS2712;
      break;
    }
    default: {
      struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE** _M0L7entriesS2716 =
        _M0L4selfS787->$0;
      struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L6_2atmpS2715;
      struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L6_2atmpS2713;
      struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L6_2atmpS2714;
      struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L6_2aoldS4153;
      if (
        _M0L7_2abindS786 < 0
        || _M0L7_2abindS786 >= Moonbit_array_length(_M0L7entriesS2716)
      ) {
        #line 532 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
        moonbit_panic();
      }
      _M0L6_2atmpS2715
      = (struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE*)_M0L7entriesS2716[
          _M0L7_2abindS786
        ];
      if (_M0L6_2atmpS2715) {
        moonbit_incref(_M0L6_2atmpS2715);
      }
      #line 532 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
      _M0L6_2atmpS2713
      = _M0MPC16option6Option6unwrapGRPB5EntryGiUWEuQRPC15error5ErrorNsEEE(_M0L6_2atmpS2715);
      if (_M0L6_2atmpS2715) {
        moonbit_decref(_M0L6_2atmpS2715);
      }
      moonbit_incref(_M0L5entryS788);
      _M0L6_2atmpS2714 = _M0L5entryS788;
      _M0L6_2aoldS4153 = _M0L6_2atmpS2713->$1;
      if (_M0L6_2aoldS4153) {
        moonbit_decref(_M0L6_2aoldS4153);
      }
      _M0L6_2atmpS2713->$1 = _M0L6_2atmpS2714;
      moonbit_decref(_M0L6_2atmpS2713);
      break;
    }
  }
  _M0L4selfS787->$6 = _M0L3idxS789;
  _M0L7entriesS2717 = _M0L4selfS787->$0;
  _M0L6_2atmpS2718 = _M0L5entryS788;
  if (
    _M0L3idxS789 < 0
    || _M0L3idxS789 >= Moonbit_array_length(_M0L7entriesS2717)
  ) {
    #line 535 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
    moonbit_panic();
  }
  _M0L6_2aoldS4150
  = (struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE*)_M0L7entriesS2717[
      _M0L3idxS789
    ];
  if (_M0L6_2aoldS4150) {
    moonbit_decref(_M0L6_2aoldS4150);
  }
  _M0L7entriesS2717[_M0L3idxS789] = _M0L6_2atmpS2718;
  _M0L4sizeS2720 = _M0L4selfS787->$1;
  _M0L6_2atmpS2719 = _M0L4sizeS2720 + 1;
  _M0L4selfS787->$1 = _M0L6_2atmpS2719;
  return 0;
}

int32_t _M0MPC13int3Int3max(int32_t _M0L4selfS780, int32_t _M0L5otherS781) {
  #line 88 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\int.mbt"
  if (_M0L4selfS780 > _M0L5otherS781) {
    return _M0L4selfS780;
  } else {
    return _M0L5otherS781;
  }
}

int32_t _M0FPB21capacity__for__length(int32_t _M0L6lengthS779) {
  int32_t _M0Lm8capacityS778;
  int32_t _M0L6_2atmpS2701;
  int32_t _M0L6_2atmpS2700;
  #line 72 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  #line 73 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0Lm8capacityS778 = _M0MPC13int3Int20next__power__of__two(_M0L6lengthS779);
  _M0L6_2atmpS2701 = _M0Lm8capacityS778;
  #line 74 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L6_2atmpS2700 = _M0FPB21calc__grow__threshold(_M0L6_2atmpS2701);
  if (_M0L6lengthS779 > _M0L6_2atmpS2700) {
    int32_t _M0L6_2atmpS2702 = _M0Lm8capacityS778;
    _M0Lm8capacityS778 = _M0L6_2atmpS2702 * 2;
  }
  return _M0Lm8capacityS778;
}

struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0FPB8new__mapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(
  int32_t _M0L8capacityS767
) {
  int32_t _M0L8capacityS766;
  int32_t _M0L7_2abindS768;
  int32_t _M0L7_2abindS769;
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L6_2atmpS2698;
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE** _M0L7_2abindS770;
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L7_2abindS771;
  struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _block_4516;
  #line 58 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  #line 59 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L8capacityS766
  = _M0MPC13int3Int20next__power__of__two(_M0L8capacityS767);
  _M0L7_2abindS768 = _M0L8capacityS766 - 1;
  #line 64 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L7_2abindS769 = _M0FPB21calc__grow__threshold(_M0L8capacityS766);
  _M0L6_2atmpS2698 = 0;
  _M0L7_2abindS770
  = (struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE**)moonbit_make_ref_array(_M0L8capacityS766, _M0L6_2atmpS2698);
  _M0L7_2abindS771 = 0;
  _block_4516
  = (struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*)moonbit_malloc(sizeof(struct _M0TPB3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE));
  Moonbit_object_header(_block_4516)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 125, 0);
  _block_4516->$0 = _M0L7_2abindS770;
  _block_4516->$1 = 0;
  _block_4516->$2 = _M0L8capacityS766;
  _block_4516->$3 = _M0L7_2abindS768;
  _block_4516->$4 = _M0L7_2abindS769;
  _block_4516->$5 = _M0L7_2abindS771;
  _block_4516->$6 = -1;
  return _block_4516;
}

struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0FPB8new__mapGiUWEuQRPC15error5ErrorNsEE(
  int32_t _M0L8capacityS773
) {
  int32_t _M0L8capacityS772;
  int32_t _M0L7_2abindS774;
  int32_t _M0L7_2abindS775;
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L6_2atmpS2699;
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE** _M0L7_2abindS776;
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L7_2abindS777;
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _block_4517;
  #line 58 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  #line 59 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L8capacityS772
  = _M0MPC13int3Int20next__power__of__two(_M0L8capacityS773);
  _M0L7_2abindS774 = _M0L8capacityS772 - 1;
  #line 64 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L7_2abindS775 = _M0FPB21calc__grow__threshold(_M0L8capacityS772);
  _M0L6_2atmpS2699 = 0;
  _M0L7_2abindS776
  = (struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE**)moonbit_make_ref_array(_M0L8capacityS772, _M0L6_2atmpS2699);
  _M0L7_2abindS777 = 0;
  _block_4517
  = (struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE*)moonbit_malloc(sizeof(struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE));
  Moonbit_object_header(_block_4517)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 129, 0);
  _block_4517->$0 = _M0L7_2abindS776;
  _block_4517->$1 = 0;
  _block_4517->$2 = _M0L8capacityS772;
  _block_4517->$3 = _M0L7_2abindS774;
  _block_4517->$4 = _M0L7_2abindS775;
  _block_4517->$5 = _M0L7_2abindS777;
  _block_4517->$6 = -1;
  return _block_4517;
}

int32_t _M0MPC13int3Int20next__power__of__two(int32_t _M0L4selfS765) {
  #line 46 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\int.mbt"
  if (_M0L4selfS765 >= 0) {
    int32_t _M0L6_2atmpS2697;
    int32_t _M0L6_2atmpS2696;
    int32_t _M0L6_2atmpS2695;
    int32_t _M0L6_2atmpS2694;
    if (_M0L4selfS765 <= 1) {
      return 1;
    }
    if (_M0L4selfS765 > 1073741824) {
      return 1073741824;
    }
    _M0L6_2atmpS2697 = _M0L4selfS765 - 1;
    #line 57 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\int.mbt"
    _M0L6_2atmpS2696 = moonbit_clz32(_M0L6_2atmpS2697);
    _M0L6_2atmpS2695 = _M0L6_2atmpS2696 - 1;
    _M0L6_2atmpS2694 = 2147483647 >> (_M0L6_2atmpS2695 & 31);
    return _M0L6_2atmpS2694 + 1;
  } else {
    #line 47 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\int.mbt"
    moonbit_panic();
  }
}

int32_t _M0FPB21calc__grow__threshold(int32_t _M0L8capacityS764) {
  int32_t _M0L6_2atmpS2693;
  #line 620 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\linked_hash_map.mbt"
  _M0L6_2atmpS2693 = _M0L8capacityS764 * 13;
  return _M0L6_2atmpS2693 / 16;
}

struct _M0TPB5ArrayGsE* _M0MPC15array5Array31unsafe__make__and__blit_2einnerGsE(
  moonbit_string_t* _M0L3srcS759,
  int32_t _M0L13allocate__lenS760,
  int32_t _M0L3lenS761,
  int32_t _M0L11src__offsetS762,
  int32_t _M0L11dst__offsetS763
) {
  moonbit_string_t* _M0L6_2atmpS2692;
  struct _M0TPB5ArrayGsE* _block_4518;
  #line 32 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  #line 41 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L6_2atmpS2692
  = _M0MPB18UninitializedArray23make__and__blit_2einnerGsE(_M0L3srcS759, _M0L13allocate__lenS760, _M0L3lenS761, _M0L11src__offsetS762, _M0L11dst__offsetS763);
  _block_4518
  = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
  Moonbit_object_header(_block_4518)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
  _block_4518->$0 = _M0L6_2atmpS2692;
  _block_4518->$1 = _M0L13allocate__lenS760;
  return _block_4518;
}

struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0MPC16option6Option6unwrapGRPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEEE(
  struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L4selfS755
) {
  #line 38 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\option.mbt"
  if (_M0L4selfS755 == 0) {
    #line 40 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\option.mbt"
    moonbit_panic();
  } else {
    struct _M0TPB5EntryGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L7_2aSomeS756 =
      _M0L4selfS755;
    if (_M0L7_2aSomeS756) {
      moonbit_incref(_M0L7_2aSomeS756);
    }
    return _M0L7_2aSomeS756;
  }
}

struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0MPC16option6Option6unwrapGRPB5EntryGiUWEuQRPC15error5ErrorNsEEE(
  struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L4selfS757
) {
  #line 38 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\option.mbt"
  if (_M0L4selfS757 == 0) {
    #line 40 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\option.mbt"
    moonbit_panic();
  } else {
    struct _M0TPB5EntryGiUWEuQRPC15error5ErrorNsEE* _M0L7_2aSomeS758 =
      _M0L4selfS757;
    if (_M0L7_2aSomeS758) {
      moonbit_incref(_M0L7_2aSomeS758);
    }
    return _M0L7_2aSomeS758;
  }
}

moonbit_string_t _M0MPC15array9ArrayView4joinGsE(
  struct _M0TPB9ArrayViewGsE _M0L4selfS703,
  struct _M0TPC16string10StringView _M0L9separatorS716
) {
  int32_t _M0L3endS2641;
  int32_t _M0L5startS2642;
  int32_t _M0L6_2atmpS2640;
  #line 1485 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
  _M0L3endS2641 = _M0L4selfS703.$2;
  _M0L5startS2642 = _M0L4selfS703.$1;
  _M0L6_2atmpS2640 = _M0L3endS2641 - _M0L5startS2642;
  if (_M0L6_2atmpS2640 == 0) {
    return (moonbit_string_t)moonbit_string_literal_1.data;
  } else {
    moonbit_string_t* _M0L3bufS2664 = _M0L4selfS703.$0;
    int32_t _M0L5startS2665 = _M0L4selfS703.$1;
    moonbit_string_t _M0L5_2ahdS704 =
      (moonbit_string_t)_M0L3bufS2664[_M0L5startS2665];
    moonbit_string_t* _M0L9_2ax__bufS705 = _M0L4selfS703.$0;
    int32_t _M0L5startS2663 = _M0L4selfS703.$1;
    int32_t _M0L11_2ax__startS706 = 1 + _M0L5startS2663;
    int32_t _M0L9_2ax__endS707 = _M0L4selfS703.$2;
    struct _M0TPC16string10StringView _M0L2hdS708;
    int32_t _M0L7_2abindS709;
    int32_t _M0L3endS2661;
    int32_t _M0L5startS2662;
    int32_t _M0L6_2atmpS2660;
    int32_t _M0L10size__hintS710;
    int32_t _M0L2__S711;
    int32_t _M0L10size__hintS712;
    int32_t _M0L10size__hintS717;
    struct _M0TPB13StringBuilder* _M0L3bufS718;
    int32_t _M0L3endS2644;
    int32_t _M0L5startS2645;
    int32_t _M0L6_2atmpS2643;
    moonbit_string_t _result_4522;
    moonbit_incref(_M0L9_2ax__bufS705);
    moonbit_incref(_M0L5_2ahdS704);
    #line 1492 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
    _M0L2hdS708
    = _M0IPC16string6StringPB12ToStringView16to__string__view(_M0L5_2ahdS704);
    moonbit_decref(_M0L5_2ahdS704);
    _M0L7_2abindS709 = _M0L9_2ax__endS707 - _M0L11_2ax__startS706;
    _M0L3endS2661 = _M0L2hdS708.$2;
    _M0L5startS2662 = _M0L2hdS708.$1;
    _M0L6_2atmpS2660 = _M0L3endS2661 - _M0L5startS2662;
    _M0L2__S711 = 0;
    _M0L10size__hintS712 = _M0L6_2atmpS2660;
    while (1) {
      if (_M0L2__S711 < _M0L7_2abindS709) {
        int32_t _M0L6_2atmpS2659 = _M0L11_2ax__startS706 + _M0L2__S711;
        moonbit_string_t _M0L1sS713 =
          (moonbit_string_t)_M0L9_2ax__bufS705[_M0L6_2atmpS2659];
        int32_t _M0L6_2atmpS2650 = _M0L2__S711 + 1;
        struct _M0TPC16string10StringView _M0L7_2abindS715;
        int32_t _M0L3endS2657;
        int32_t _M0L5startS2658;
        int32_t _M0L6_2atmpS2656;
        int32_t _M0L6_2atmpS2652;
        int32_t _M0L3endS2654;
        int32_t _M0L5startS2655;
        int32_t _M0L6_2atmpS2653;
        int32_t _M0L6_2atmpS2651;
        moonbit_incref(_M0L1sS713);
        #line 1494 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
        _M0L7_2abindS715
        = _M0IPC16string6StringPB12ToStringView16to__string__view(_M0L1sS713);
        moonbit_decref(_M0L1sS713);
        _M0L3endS2657 = _M0L7_2abindS715.$2;
        _M0L5startS2658 = _M0L7_2abindS715.$1;
        moonbit_decref(_M0L7_2abindS715.$0);
        _M0L6_2atmpS2656 = _M0L3endS2657 - _M0L5startS2658;
        _M0L6_2atmpS2652 = _M0L10size__hintS712 + _M0L6_2atmpS2656;
        _M0L3endS2654 = _M0L9separatorS716.$2;
        _M0L5startS2655 = _M0L9separatorS716.$1;
        _M0L6_2atmpS2653 = _M0L3endS2654 - _M0L5startS2655;
        _M0L6_2atmpS2651 = _M0L6_2atmpS2652 + _M0L6_2atmpS2653;
        _M0L2__S711 = _M0L6_2atmpS2650;
        _M0L10size__hintS712 = _M0L6_2atmpS2651;
        continue;
      } else {
        _M0L10size__hintS710 = _M0L10size__hintS712;
      }
      break;
    }
    _M0L10size__hintS717 = _M0L10size__hintS710 << 1;
    #line 1499 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
    _M0L3bufS718
    = _M0MPB13StringBuilder21StringBuilder_2einner(_M0L10size__hintS717);
    #line 1501 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
    _M0IPB13StringBuilderPB6Logger11write__view(_M0L3bufS718, _M0L2hdS708);
    moonbit_decref(_M0L2hdS708.$0);
    _M0L3endS2644 = _M0L9separatorS716.$2;
    _M0L5startS2645 = _M0L9separatorS716.$1;
    _M0L6_2atmpS2643 = _M0L3endS2644 - _M0L5startS2645;
    if (_M0L6_2atmpS2643 == 0) {
      int32_t _M0L7_2abindS719 = _M0L9_2ax__endS707 - _M0L11_2ax__startS706;
      int32_t _M0L2__S720 = 0;
      while (1) {
        if (_M0L2__S720 < _M0L7_2abindS719) {
          int32_t _M0L6_2atmpS2647 = _M0L11_2ax__startS706 + _M0L2__S720;
          moonbit_string_t _M0L1sS721 =
            (moonbit_string_t)_M0L9_2ax__bufS705[_M0L6_2atmpS2647];
          struct _M0TPC16string10StringView _M0L1sS722;
          int32_t _M0L6_2atmpS2646;
          moonbit_incref(_M0L1sS721);
          #line 1505 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
          _M0L1sS722
          = _M0IPC16string6StringPB12ToStringView16to__string__view(_M0L1sS721);
          moonbit_decref(_M0L1sS721);
          #line 1506 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
          _M0IPB13StringBuilderPB6Logger11write__view(_M0L3bufS718, _M0L1sS722);
          moonbit_decref(_M0L1sS722.$0);
          _M0L6_2atmpS2646 = _M0L2__S720 + 1;
          _M0L2__S720 = _M0L6_2atmpS2646;
          continue;
        } else {
          moonbit_decref(_M0L9_2ax__bufS705);
        }
        break;
      }
    } else {
      int32_t _M0L7_2abindS724 = _M0L9_2ax__endS707 - _M0L11_2ax__startS706;
      int32_t _M0L2__S725 = 0;
      while (1) {
        if (_M0L2__S725 < _M0L7_2abindS724) {
          int32_t _M0L6_2atmpS2649 = _M0L11_2ax__startS706 + _M0L2__S725;
          moonbit_string_t _M0L1sS726 =
            (moonbit_string_t)_M0L9_2ax__bufS705[_M0L6_2atmpS2649];
          struct _M0TPC16string10StringView _M0L1sS727;
          int32_t _M0L6_2atmpS2648;
          moonbit_incref(_M0L1sS726);
          #line 1510 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
          _M0L1sS727
          = _M0IPC16string6StringPB12ToStringView16to__string__view(_M0L1sS726);
          moonbit_decref(_M0L1sS726);
          #line 1511 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
          _M0IPB13StringBuilderPB6Logger11write__view(_M0L3bufS718, _M0L9separatorS716);
          #line 1513 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
          _M0IPB13StringBuilderPB6Logger11write__view(_M0L3bufS718, _M0L1sS727);
          moonbit_decref(_M0L1sS727.$0);
          _M0L6_2atmpS2648 = _M0L2__S725 + 1;
          _M0L2__S725 = _M0L6_2atmpS2648;
          continue;
        } else {
          moonbit_decref(_M0L9_2ax__bufS705);
        }
        break;
      }
    }
    #line 1516 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
    _result_4522 = _M0MPB13StringBuilder10to__string(_M0L3bufS718);
    moonbit_decref(_M0L3bufS718);
    return _result_4522;
  }
}

moonbit_string_t _M0MPC15array9ArrayView4joinGRPC16string10StringViewE(
  struct _M0TPB9ArrayViewGRPC16string10StringViewE _M0L4selfS729,
  struct _M0TPC16string10StringView _M0L9separatorS742
) {
  int32_t _M0L3endS2667;
  int32_t _M0L5startS2668;
  int32_t _M0L6_2atmpS2666;
  #line 1485 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
  _M0L3endS2667 = _M0L4selfS729.$2;
  _M0L5startS2668 = _M0L4selfS729.$1;
  _M0L6_2atmpS2666 = _M0L3endS2667 - _M0L5startS2668;
  if (_M0L6_2atmpS2666 == 0) {
    return (moonbit_string_t)moonbit_string_literal_1.data;
  } else {
    struct _M0TPC16string10StringView* _M0L3bufS2690 = _M0L4selfS729.$0;
    int32_t _M0L5startS2691 = _M0L4selfS729.$1;
    struct _M0TPC16string10StringView _M0L5_2ahdS730 =
      _M0L3bufS2690[_M0L5startS2691];
    struct _M0TPC16string10StringView* _M0L9_2ax__bufS731 = _M0L4selfS729.$0;
    int32_t _M0L5startS2689 = _M0L4selfS729.$1;
    int32_t _M0L11_2ax__startS732 = 1 + _M0L5startS2689;
    int32_t _M0L9_2ax__endS733 = _M0L4selfS729.$2;
    struct _M0TPC16string10StringView _M0L2hdS734;
    int32_t _M0L7_2abindS735;
    int32_t _M0L3endS2687;
    int32_t _M0L5startS2688;
    int32_t _M0L6_2atmpS2686;
    int32_t _M0L10size__hintS736;
    int32_t _M0L2__S737;
    int32_t _M0L10size__hintS738;
    int32_t _M0L10size__hintS743;
    struct _M0TPB13StringBuilder* _M0L3bufS744;
    int32_t _M0L3endS2670;
    int32_t _M0L5startS2671;
    int32_t _M0L6_2atmpS2669;
    moonbit_string_t _result_4526;
    moonbit_incref(_M0L9_2ax__bufS731);
    moonbit_incref(_M0L5_2ahdS730.$0);
    #line 1492 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
    _M0L2hdS734
    = _M0IPC16string10StringViewPB12ToStringView16to__string__view(_M0L5_2ahdS730);
    moonbit_decref(_M0L5_2ahdS730.$0);
    _M0L7_2abindS735 = _M0L9_2ax__endS733 - _M0L11_2ax__startS732;
    _M0L3endS2687 = _M0L2hdS734.$2;
    _M0L5startS2688 = _M0L2hdS734.$1;
    _M0L6_2atmpS2686 = _M0L3endS2687 - _M0L5startS2688;
    _M0L2__S737 = 0;
    _M0L10size__hintS738 = _M0L6_2atmpS2686;
    while (1) {
      if (_M0L2__S737 < _M0L7_2abindS735) {
        int32_t _M0L6_2atmpS2685 = _M0L11_2ax__startS732 + _M0L2__S737;
        struct _M0TPC16string10StringView _M0L1sS739 =
          _M0L9_2ax__bufS731[_M0L6_2atmpS2685];
        int32_t _M0L6_2atmpS2676 = _M0L2__S737 + 1;
        struct _M0TPC16string10StringView _M0L7_2abindS741;
        int32_t _M0L3endS2683;
        int32_t _M0L5startS2684;
        int32_t _M0L6_2atmpS2682;
        int32_t _M0L6_2atmpS2678;
        int32_t _M0L3endS2680;
        int32_t _M0L5startS2681;
        int32_t _M0L6_2atmpS2679;
        int32_t _M0L6_2atmpS2677;
        moonbit_incref(_M0L1sS739.$0);
        #line 1494 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
        _M0L7_2abindS741
        = _M0IPC16string10StringViewPB12ToStringView16to__string__view(_M0L1sS739);
        moonbit_decref(_M0L1sS739.$0);
        _M0L3endS2683 = _M0L7_2abindS741.$2;
        _M0L5startS2684 = _M0L7_2abindS741.$1;
        moonbit_decref(_M0L7_2abindS741.$0);
        _M0L6_2atmpS2682 = _M0L3endS2683 - _M0L5startS2684;
        _M0L6_2atmpS2678 = _M0L10size__hintS738 + _M0L6_2atmpS2682;
        _M0L3endS2680 = _M0L9separatorS742.$2;
        _M0L5startS2681 = _M0L9separatorS742.$1;
        _M0L6_2atmpS2679 = _M0L3endS2680 - _M0L5startS2681;
        _M0L6_2atmpS2677 = _M0L6_2atmpS2678 + _M0L6_2atmpS2679;
        _M0L2__S737 = _M0L6_2atmpS2676;
        _M0L10size__hintS738 = _M0L6_2atmpS2677;
        continue;
      } else {
        _M0L10size__hintS736 = _M0L10size__hintS738;
      }
      break;
    }
    _M0L10size__hintS743 = _M0L10size__hintS736 << 1;
    #line 1499 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
    _M0L3bufS744
    = _M0MPB13StringBuilder21StringBuilder_2einner(_M0L10size__hintS743);
    #line 1501 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
    _M0IPB13StringBuilderPB6Logger11write__view(_M0L3bufS744, _M0L2hdS734);
    moonbit_decref(_M0L2hdS734.$0);
    _M0L3endS2670 = _M0L9separatorS742.$2;
    _M0L5startS2671 = _M0L9separatorS742.$1;
    _M0L6_2atmpS2669 = _M0L3endS2670 - _M0L5startS2671;
    if (_M0L6_2atmpS2669 == 0) {
      int32_t _M0L7_2abindS745 = _M0L9_2ax__endS733 - _M0L11_2ax__startS732;
      int32_t _M0L2__S746 = 0;
      while (1) {
        if (_M0L2__S746 < _M0L7_2abindS745) {
          int32_t _M0L6_2atmpS2673 = _M0L11_2ax__startS732 + _M0L2__S746;
          struct _M0TPC16string10StringView _M0L1sS747 =
            _M0L9_2ax__bufS731[_M0L6_2atmpS2673];
          struct _M0TPC16string10StringView _M0L1sS748;
          int32_t _M0L6_2atmpS2672;
          moonbit_incref(_M0L1sS747.$0);
          #line 1505 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
          _M0L1sS748
          = _M0IPC16string10StringViewPB12ToStringView16to__string__view(_M0L1sS747);
          moonbit_decref(_M0L1sS747.$0);
          #line 1506 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
          _M0IPB13StringBuilderPB6Logger11write__view(_M0L3bufS744, _M0L1sS748);
          moonbit_decref(_M0L1sS748.$0);
          _M0L6_2atmpS2672 = _M0L2__S746 + 1;
          _M0L2__S746 = _M0L6_2atmpS2672;
          continue;
        } else {
          moonbit_decref(_M0L9_2ax__bufS731);
        }
        break;
      }
    } else {
      int32_t _M0L7_2abindS750 = _M0L9_2ax__endS733 - _M0L11_2ax__startS732;
      int32_t _M0L2__S751 = 0;
      while (1) {
        if (_M0L2__S751 < _M0L7_2abindS750) {
          int32_t _M0L6_2atmpS2675 = _M0L11_2ax__startS732 + _M0L2__S751;
          struct _M0TPC16string10StringView _M0L1sS752 =
            _M0L9_2ax__bufS731[_M0L6_2atmpS2675];
          struct _M0TPC16string10StringView _M0L1sS753;
          int32_t _M0L6_2atmpS2674;
          moonbit_incref(_M0L1sS752.$0);
          #line 1510 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
          _M0L1sS753
          = _M0IPC16string10StringViewPB12ToStringView16to__string__view(_M0L1sS752);
          moonbit_decref(_M0L1sS752.$0);
          #line 1511 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
          _M0IPB13StringBuilderPB6Logger11write__view(_M0L3bufS744, _M0L9separatorS742);
          #line 1513 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
          _M0IPB13StringBuilderPB6Logger11write__view(_M0L3bufS744, _M0L1sS753);
          moonbit_decref(_M0L1sS753.$0);
          _M0L6_2atmpS2674 = _M0L2__S751 + 1;
          _M0L2__S751 = _M0L6_2atmpS2674;
          continue;
        } else {
          moonbit_decref(_M0L9_2ax__bufS731);
        }
        break;
      }
    }
    #line 1516 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
    _result_4526 = _M0MPB13StringBuilder10to__string(_M0L3bufS744);
    moonbit_decref(_M0L3bufS744);
    return _result_4526;
  }
}

struct _M0TPB5ArrayGRPC15debug7ContentE* _M0MPC15array5Array12make__uninitGRPC15debug7ContentE(
  int32_t _M0L3lenS697
) {
  struct _M0TPC15debug7Content** _M0L6_2atmpS2634;
  struct _M0TPB5ArrayGRPC15debug7ContentE* _block_4527;
  #line 27 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L6_2atmpS2634
  = (struct _M0TPC15debug7Content**)moonbit_make_ref_array(_M0L3lenS697, 0);
  _block_4527
  = (struct _M0TPB5ArrayGRPC15debug7ContentE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGRPC15debug7ContentE));
  Moonbit_object_header(_block_4527)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 133, 0);
  _block_4527->$0 = _M0L6_2atmpS2634;
  _block_4527->$1 = _M0L3lenS697;
  return _block_4527;
}

struct _M0TPB5ArrayGRPC15debug13ContentParensE* _M0MPC15array5Array12make__uninitGRPC15debug13ContentParensE(
  int32_t _M0L3lenS698
) {
  struct _M0TPC15debug13ContentParens** _M0L6_2atmpS2635;
  struct _M0TPB5ArrayGRPC15debug13ContentParensE* _block_4528;
  #line 27 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L6_2atmpS2635
  = (struct _M0TPC15debug13ContentParens**)moonbit_make_ref_array(_M0L3lenS698, 0);
  _block_4528
  = (struct _M0TPB5ArrayGRPC15debug13ContentParensE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGRPC15debug13ContentParensE));
  Moonbit_object_header(_block_4528)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 47, 0);
  _block_4528->$0 = _M0L6_2atmpS2635;
  _block_4528->$1 = _M0L3lenS698;
  return _block_4528;
}

struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* _M0MPC15array5Array12make__uninitGRPC15debug9ReprDeltaE(
  int32_t _M0L3lenS699
) {
  void** _M0L6_2atmpS2636;
  struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* _block_4529;
  #line 27 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L6_2atmpS2636
  = (void**)moonbit_make_ref_array(_M0L3lenS699, (struct moonbit_object*)&moonbit_constant_constructor_0 + 1);
  set_cycle_capable(_M0L6_2atmpS2636);
  _block_4529
  = (struct _M0TPB5ArrayGRPC15debug9ReprDeltaE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGRPC15debug9ReprDeltaE));
  Moonbit_object_header(_block_4529)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 34, 0);
  set_cycle_capable(_block_4529);
  _block_4529->$0 = _M0L6_2atmpS2636;
  _block_4529->$1 = _M0L3lenS699;
  return _block_4529;
}

struct _M0TPB5ArrayGRPC15debug4ReprE* _M0MPC15array5Array12make__uninitGRPC15debug4ReprE(
  int32_t _M0L3lenS700
) {
  void** _M0L6_2atmpS2637;
  struct _M0TPB5ArrayGRPC15debug4ReprE* _block_4530;
  #line 27 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L6_2atmpS2637
  = (void**)moonbit_make_ref_array(_M0L3lenS700, (struct moonbit_object*)&moonbit_constant_constructor_0 + 1);
  set_cycle_capable(_M0L6_2atmpS2637);
  _block_4530
  = (struct _M0TPB5ArrayGRPC15debug4ReprE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGRPC15debug4ReprE));
  Moonbit_object_header(_block_4530)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 78, 0);
  set_cycle_capable(_block_4530);
  _block_4530->$0 = _M0L6_2atmpS2637;
  _block_4530->$1 = _M0L3lenS700;
  return _block_4530;
}

struct _M0TPB5ArrayGRPB5ArrayGsEE* _M0MPC15array5Array12make__uninitGRPB5ArrayGsEE(
  int32_t _M0L3lenS701
) {
  struct _M0TPB5ArrayGsE** _M0L6_2atmpS2638;
  struct _M0TPB5ArrayGRPB5ArrayGsEE* _block_4531;
  #line 27 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L6_2atmpS2638
  = (struct _M0TPB5ArrayGsE**)moonbit_make_ref_array(_M0L3lenS701, 0);
  _block_4531
  = (struct _M0TPB5ArrayGRPB5ArrayGsEE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGRPB5ArrayGsEE));
  Moonbit_object_header(_block_4531)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 136, 0);
  _block_4531->$0 = _M0L6_2atmpS2638;
  _block_4531->$1 = _M0L3lenS701;
  return _block_4531;
}

struct _M0TPB5ArrayGsE* _M0MPC15array5Array12make__uninitGsE(
  int32_t _M0L3lenS702
) {
  moonbit_string_t* _M0L6_2atmpS2639;
  struct _M0TPB5ArrayGsE* _block_4532;
  #line 27 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L6_2atmpS2639
  = (moonbit_string_t*)moonbit_make_ref_array(_M0L3lenS702, (moonbit_string_t)moonbit_string_literal_1.data);
  _block_4532
  = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
  Moonbit_object_header(_block_4532)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 24, 0);
  _block_4532->$0 = _M0L6_2atmpS2639;
  _block_4532->$1 = _M0L3lenS702;
  return _block_4532;
}

struct _M0TPB4IterGsE* _M0MPC15array13ReadOnlyArray4iterGsE(
  moonbit_string_t* _M0L4selfS696
) {
  moonbit_string_t* _M0L6_2atmpS2633;
  struct _M0TPB4IterGsE* _result_4533;
  #line 194 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\readonlyarray.mbt"
  moonbit_incref(_M0L4selfS696);
  _M0L6_2atmpS2633 = _M0L4selfS696;
  #line 196 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\readonlyarray.mbt"
  _result_4533 = _M0MPC15array10FixedArray4iterGsE(_M0L6_2atmpS2633);
  moonbit_decref(_M0L6_2atmpS2633);
  return _result_4533;
}

uint64_t _M0MPC15array13ReadOnlyArray2atGmE(
  uint64_t* _M0L4selfS692,
  int32_t _M0L5indexS693
) {
  uint64_t* _M0L6_2atmpS2631;
  uint64_t _result_4534;
  #line 38 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\readonlyarray.mbt"
  moonbit_incref(_M0L4selfS692);
  _M0L6_2atmpS2631 = _M0L4selfS692;
  if (
    _M0L5indexS693 < 0
    || _M0L5indexS693 >= Moonbit_array_length(_M0L6_2atmpS2631)
  ) {
    #line 40 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\readonlyarray.mbt"
    moonbit_panic();
  }
  _result_4534 = (uint64_t)_M0L6_2atmpS2631[_M0L5indexS693];
  moonbit_decref(_M0L6_2atmpS2631);
  return _result_4534;
}

uint32_t _M0MPC15array13ReadOnlyArray2atGjE(
  uint32_t* _M0L4selfS694,
  int32_t _M0L5indexS695
) {
  uint32_t* _M0L6_2atmpS2632;
  uint32_t _result_4535;
  #line 38 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\readonlyarray.mbt"
  moonbit_incref(_M0L4selfS694);
  _M0L6_2atmpS2632 = _M0L4selfS694;
  if (
    _M0L5indexS695 < 0
    || _M0L5indexS695 >= Moonbit_array_length(_M0L6_2atmpS2632)
  ) {
    #line 40 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\readonlyarray.mbt"
    moonbit_panic();
  }
  _result_4535 = (uint32_t)_M0L6_2atmpS2632[_M0L5indexS695];
  moonbit_decref(_M0L6_2atmpS2632);
  return _result_4535;
}

struct _M0TPB4IterGsE* _M0MPC15array5Array4iterGsE(
  struct _M0TPB5ArrayGsE* _M0L4selfS691
) {
  moonbit_string_t* _M0L3bufS2629;
  int32_t _M0L3lenS2630;
  struct _M0TPB9ArrayViewGsE _M0L6_2atmpS2628;
  struct _M0TPB4IterGsE* _result_4536;
  #line 1756 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L3bufS2629 = _M0L4selfS691->$0;
  _M0L3lenS2630 = _M0L4selfS691->$1;
  moonbit_incref(_M0L3bufS2629);
  _M0L6_2atmpS2628
  = (struct _M0TPB9ArrayViewGsE){
    .$0 = _M0L3bufS2629, .$1 = 0, .$2 = _M0L3lenS2630
  };
  #line 1758 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _result_4536 = _M0MPC15array9ArrayView4iterGsE(_M0L6_2atmpS2628);
  moonbit_decref(_M0L6_2atmpS2628.$0);
  return _result_4536;
}

struct _M0TPB4IterGsE* _M0MPC15array10FixedArray4iterGsE(
  moonbit_string_t* _M0L4selfS690
) {
  moonbit_string_t* _M0L6_2atmpS2626;
  int32_t _M0L6_2atmpS2627;
  struct _M0TPB9ArrayViewGsE _M0L6_2atmpS2625;
  struct _M0TPB4IterGsE* _result_4537;
  #line 1570 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray.mbt"
  _M0L6_2atmpS2626 = _M0L4selfS690;
  _M0L6_2atmpS2627 = Moonbit_array_length(_M0L4selfS690);
  moonbit_incref(_M0L6_2atmpS2626);
  _M0L6_2atmpS2625
  = (struct _M0TPB9ArrayViewGsE){
    .$0 = _M0L6_2atmpS2626, .$1 = 0, .$2 = _M0L6_2atmpS2627
  };
  #line 1572 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray.mbt"
  _result_4537 = _M0MPC15array9ArrayView4iterGsE(_M0L6_2atmpS2625);
  moonbit_decref(_M0L6_2atmpS2625.$0);
  return _result_4537;
}

struct _M0TPB4IterGsE* _M0MPC15array9ArrayView4iterGsE(
  struct _M0TPB9ArrayViewGsE _M0L4selfS688
) {
  struct _M0TPB8MutLocalGiE* _M0L1iS686;
  int32_t _M0L3endS2623;
  int32_t _M0L5startS2624;
  int32_t _M0L3lenS687;
  struct _M0R59ArrayView_3a_3aiter_7c_5bString_5d_7c_2eanon__u2613__l717__* _closure_4538;
  struct _M0TWEOs* _M0L6_2atmpS2611;
  int64_t _M0L6_2atmpS2612;
  #line 712 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
  _M0L1iS686
  = (struct _M0TPB8MutLocalGiE*)moonbit_malloc(sizeof(struct _M0TPB8MutLocalGiE));
  Moonbit_object_header(_M0L1iS686)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0);
  _M0L1iS686->$0 = 0;
  _M0L3endS2623 = _M0L4selfS688.$2;
  _M0L5startS2624 = _M0L4selfS688.$1;
  _M0L3lenS687 = _M0L3endS2623 - _M0L5startS2624;
  moonbit_incref(_M0L4selfS688.$0);
  _closure_4538
  = (struct _M0R59ArrayView_3a_3aiter_7c_5bString_5d_7c_2eanon__u2613__l717__*)moonbit_malloc(sizeof(struct _M0R59ArrayView_3a_3aiter_7c_5bString_5d_7c_2eanon__u2613__l717__));
  Moonbit_object_header(_closure_4538)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 142, 0);
  _closure_4538->code = &_M0MPC15array9ArrayView4iterGsEC2613l717;
  _closure_4538->$0 = _M0L4selfS688;
  _closure_4538->$1 = _M0L3lenS687;
  _closure_4538->$2 = _M0L1iS686;
  _M0L6_2atmpS2611 = (struct _M0TWEOs*)_closure_4538;
  _M0L6_2atmpS2612 = (int64_t)_M0L3lenS687;
  #line 716 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
  return _M0MPB4Iter3newGsE(_M0L6_2atmpS2611, _M0L6_2atmpS2612);
}

moonbit_string_t _M0MPC15array9ArrayView4iterGsEC2613l717(
  struct _M0TWEOs* _M0L6_2aenvS2614
) {
  struct _M0R59ArrayView_3a_3aiter_7c_5bString_5d_7c_2eanon__u2613__l717__* _M0L14_2acasted__envS2615;
  struct _M0TPB8MutLocalGiE* _M0L1iS686;
  int32_t _M0L3lenS687;
  struct _M0TPB9ArrayViewGsE _M0L4selfS688;
  int32_t _M0L3valS2616;
  #line 717 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arrayview.mbt"
  _M0L14_2acasted__envS2615
  = (struct _M0R59ArrayView_3a_3aiter_7c_5bString_5d_7c_2eanon__u2613__l717__*)_M0L6_2aenvS2614;
  _M0L1iS686 = _M0L14_2acasted__envS2615->$2;
  _M0L3lenS687 = _M0L14_2acasted__envS2615->$1;
  _M0L4selfS688 = _M0L14_2acasted__envS2615->$0;
  _M0L3valS2616 = _M0L1iS686->$0;
  if (_M0L3valS2616 < _M0L3lenS687) {
    moonbit_string_t* _M0L3bufS2619 = _M0L4selfS688.$0;
    int32_t _M0L5startS2621 = _M0L4selfS688.$1;
    int32_t _M0L3valS2622 = _M0L1iS686->$0;
    int32_t _M0L6_2atmpS2620 = _M0L5startS2621 + _M0L3valS2622;
    moonbit_string_t _M0L4elemS689 =
      (moonbit_string_t)_M0L3bufS2619[_M0L6_2atmpS2620];
    int32_t _M0L3valS2618 = _M0L1iS686->$0;
    int32_t _M0L6_2atmpS2617 = _M0L3valS2618 + 1;
    _M0L1iS686->$0 = _M0L6_2atmpS2617;
    moonbit_incref(_M0L4elemS689);
    return _M0L4elemS689;
  } else {
    return 0;
  }
}

moonbit_string_t _M0IPC16uint646UInt64PB4Show10to__string(
  uint64_t _M0L4selfS685
) {
  #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  #line 51 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  return _M0MPC16uint646UInt6418to__string_2einner(_M0L4selfS685, 10);
}

moonbit_string_t _M0IPC13int3IntPB4Show10to__string(int32_t _M0L4selfS684) {
  #line 35 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  #line 36 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  return _M0MPC13int3Int18to__string_2einner(_M0L4selfS684, 10);
}

moonbit_string_t _M0IPC14bool4BoolPB4Show10to__string(int32_t _M0L4selfS683) {
  #line 26 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  if (_M0L4selfS683) {
    return (moonbit_string_t)moonbit_string_literal_49.data;
  } else {
    return (moonbit_string_t)moonbit_string_literal_50.data;
  }
}

uint64_t _M0MPC14uint4UInt10to__uint64(uint32_t _M0L4selfS682) {
  #line 2495 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\intrinsics.mbt"
  return (uint64_t)_M0L4selfS682;
}

struct _M0TPC16string10StringView _M0IPC16string10StringViewPB12ToStringView16to__string__view(
  struct _M0TPC16string10StringView _M0L4selfS681
) {
  #line 29 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_like.mbt"
  moonbit_incref(_M0L4selfS681.$0);
  return _M0L4selfS681;
}

struct _M0TPC16string10StringView _M0IPC16string6StringPB12ToStringView16to__string__view(
  moonbit_string_t _M0L4selfS680
) {
  int32_t _M0L6_2atmpS2610;
  #line 24 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_like.mbt"
  _M0L6_2atmpS2610 = Moonbit_array_length(_M0L4selfS680);
  moonbit_incref(_M0L4selfS680);
  return (struct _M0TPC16string10StringView){.$0 = _M0L4selfS680,
                                               .$1 = 0,
                                               .$2 = _M0L6_2atmpS2610};
}

struct _M0TPB4IterGsE* _M0MPB4Iter3mapGssE(
  struct _M0TPB4IterGsE* _M0L4selfS676,
  struct _M0TWsEs* _M0L1fS679
) {
  struct _M0R65Iter_3a_3amap_7c_5bString_2c_20String_5d_7c_2eanon__u2606__l367__* _closure_4539;
  struct _M0TWEOs* _M0L6_2atmpS2604;
  int64_t _M0L10size__hintS2605;
  struct _M0TPB4IterGsE* _block_4540;
  #line 365 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\iterator.mbt"
  moonbit_incref(_M0L1fS679);
  moonbit_incref(_M0L4selfS676);
  _closure_4539
  = (struct _M0R65Iter_3a_3amap_7c_5bString_2c_20String_5d_7c_2eanon__u2606__l367__*)moonbit_malloc(sizeof(struct _M0R65Iter_3a_3amap_7c_5bString_2c_20String_5d_7c_2eanon__u2606__l367__));
  Moonbit_object_header(_closure_4539)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 146, 0);
  _closure_4539->code = &_M0MPB4Iter3mapGssEC2606l367;
  _closure_4539->$0 = _M0L1fS679;
  _closure_4539->$1 = _M0L4selfS676;
  _M0L6_2atmpS2604 = (struct _M0TWEOs*)_closure_4539;
  _M0L10size__hintS2605 = _M0L4selfS676->$1;
  _block_4540
  = (struct _M0TPB4IterGsE*)moonbit_malloc(sizeof(struct _M0TPB4IterGsE));
  Moonbit_object_header(_block_4540)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 150, 0);
  _block_4540->$0 = _M0L6_2atmpS2604;
  _block_4540->$1 = _M0L10size__hintS2605;
  return _block_4540;
}

moonbit_string_t _M0MPB4Iter3mapGssEC2606l367(
  struct _M0TWEOs* _M0L6_2aenvS2607
) {
  struct _M0R65Iter_3a_3amap_7c_5bString_2c_20String_5d_7c_2eanon__u2606__l367__* _M0L14_2acasted__envS2608;
  struct _M0TPB4IterGsE* _M0L4selfS676;
  struct _M0TWsEs* _M0L1fS679;
  moonbit_string_t _M0L7_2abindS675;
  #line 367 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\iterator.mbt"
  _M0L14_2acasted__envS2608
  = (struct _M0R65Iter_3a_3amap_7c_5bString_2c_20String_5d_7c_2eanon__u2606__l367__*)_M0L6_2aenvS2607;
  _M0L4selfS676 = _M0L14_2acasted__envS2608->$1;
  _M0L1fS679 = _M0L14_2acasted__envS2608->$0;
  #line 368 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\iterator.mbt"
  _M0L7_2abindS675 = _M0MPB4Iter4nextGsE(_M0L4selfS676);
  if (_M0L7_2abindS675 == 0) {
    if (_M0L7_2abindS675) {
      moonbit_decref(_M0L7_2abindS675);
    }
    return 0;
  } else {
    moonbit_string_t _M0L7_2aSomeS677 = _M0L7_2abindS675;
    moonbit_string_t _M0L4_2axS678 = _M0L7_2aSomeS677;
    moonbit_string_t _M0L6_2atmpS2609;
    #line 369 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\iterator.mbt"
    _M0L6_2atmpS2609 = _M0L1fS679->code(_M0L1fS679, _M0L4_2axS678);
    moonbit_decref(_M0L4_2axS678);
    return _M0L6_2atmpS2609;
  }
}

struct _M0TPC16string10StringView _M0MPC16string6String4trim(
  moonbit_string_t _M0L4selfS674,
  void* _M0L11chars_2eoptS672
) {
  struct _M0TPC16string10StringView _M0L5charsS671;
  struct _M0TPC16string10StringView _result_4541;
  switch (Moonbit_object_tag(_M0L11chars_2eoptS672)) {
    case 1: {
      struct _M0DTPC16option6OptionGRPC16string10StringViewE4Some* _M0L7_2aSomeS673 =
        (struct _M0DTPC16option6OptionGRPC16string10StringViewE4Some*)_M0L11chars_2eoptS672;
      struct _M0TPC16string10StringView _M0L8_2afieldS4165 =
        _M0L7_2aSomeS673->$0;
      moonbit_incref(_M0L8_2afieldS4165.$0);
      _M0L5charsS671 = _M0L8_2afieldS4165;
      break;
    }
    default: {
      int32_t _M0L6_2atmpS2603 =
        Moonbit_array_length(_M0MPC16string6String4trimN7_2abindS7401);
      moonbit_incref(_M0MPC16string6String4trimN7_2abindS7401);
      _M0L5charsS671
      = (struct _M0TPC16string10StringView){
        .$0 = _M0MPC16string6String4trimN7_2abindS7401,
          .$1 = 0,
          .$2 = _M0L6_2atmpS2603
      };
      break;
    }
  }
  _result_4541
  = _M0MPC16string6String12trim_2einner(_M0L4selfS674, _M0L5charsS671);
  moonbit_decref(_M0L5charsS671.$0);
  return _result_4541;
}

struct _M0TPC16string10StringView _M0MPC16string6String12trim_2einner(
  moonbit_string_t _M0L4selfS669,
  struct _M0TPC16string10StringView _M0L5charsS670
) {
  int32_t _M0L6_2atmpS2602;
  struct _M0TPC16string10StringView _M0L6_2atmpS2601;
  struct _M0TPC16string10StringView _result_4542;
  #line 824 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
  _M0L6_2atmpS2602 = Moonbit_array_length(_M0L4selfS669);
  moonbit_incref(_M0L4selfS669);
  _M0L6_2atmpS2601
  = (struct _M0TPC16string10StringView){
    .$0 = _M0L4selfS669, .$1 = 0, .$2 = _M0L6_2atmpS2602
  };
  #line 829 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
  _result_4542
  = _M0MPC16string10StringView12trim_2einner(_M0L6_2atmpS2601, _M0L5charsS670);
  moonbit_decref(_M0L6_2atmpS2601.$0);
  return _result_4542;
}

struct _M0TPC16string10StringView _M0MPC16string10StringView12trim_2einner(
  struct _M0TPC16string10StringView _M0L4selfS667,
  struct _M0TPC16string10StringView _M0L5charsS668
) {
  struct _M0TPC16string10StringView _M0L6_2atmpS2600;
  struct _M0TPC16string10StringView _result_4543;
  #line 813 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
  #line 818 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
  _M0L6_2atmpS2600
  = _M0MPC16string10StringView19trim__start_2einner(_M0L4selfS667, _M0L5charsS668);
  #line 818 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
  _result_4543
  = _M0MPC16string10StringView17trim__end_2einner(_M0L6_2atmpS2600, _M0L5charsS668);
  moonbit_decref(_M0L6_2atmpS2600.$0);
  return _result_4543;
}

struct _M0TPC16string10StringView _M0MPC16string10StringView17trim__end_2einner(
  struct _M0TPC16string10StringView _M0L4selfS666,
  struct _M0TPC16string10StringView _M0L5charsS665
) {
  struct _M0TPC16string10StringView _M0L1xS661;
  #line 764 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
  moonbit_incref(_M0L4selfS666.$0);
  _M0L1xS661 = _M0L4selfS666;
  while (1) {
    int32_t _M0L3endS2583 = _M0L1xS661.$2;
    int32_t _M0L5startS2584 = _M0L1xS661.$1;
    int32_t _M0L6_2atmpS2582 = _M0L3endS2583 - _M0L5startS2584;
    if (_M0L6_2atmpS2582 == 0) {
      return _M0L1xS661;
    } else {
      moonbit_string_t _M0L3strS2593 = _M0L1xS661.$0;
      moonbit_string_t _M0L3strS2596 = _M0L1xS661.$0;
      int32_t _M0L5startS2597 = _M0L1xS661.$1;
      int32_t _M0L3endS2599 = _M0L1xS661.$2;
      int64_t _M0L6_2atmpS2598 = (int64_t)_M0L3endS2599;
      int64_t _M0L6_2atmpS2595;
      int32_t _M0L6_2atmpS2594;
      int32_t _M0L4_2acS663;
      moonbit_string_t _M0L3strS2585;
      int32_t _M0L5startS2586;
      moonbit_string_t _M0L3strS2589;
      int32_t _M0L5startS2590;
      int32_t _M0L3endS2592;
      int64_t _M0L6_2atmpS2591;
      int64_t _M0L6_2atmpS2588;
      int32_t _M0L6_2atmpS2587;
      struct _M0TPC16string10StringView _M0L4_2axS664;
      moonbit_incref(_M0L3strS2596);
      moonbit_incref(_M0L3strS2593);
      #line 769 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
      _M0L6_2atmpS2595
      = _M0MPC16string6String29offset__of__nth__char_2einner(_M0L3strS2596, -1, _M0L5startS2597, _M0L6_2atmpS2598);
      moonbit_decref(_M0L3strS2596);
      _M0L6_2atmpS2594 = (int32_t)_M0L6_2atmpS2595;
      #line 769 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
      _M0L4_2acS663
      = _M0MPC16string6String16unsafe__char__at(_M0L3strS2593, _M0L6_2atmpS2594);
      moonbit_decref(_M0L3strS2593);
      _M0L3strS2585 = _M0L1xS661.$0;
      _M0L5startS2586 = _M0L1xS661.$1;
      _M0L3strS2589 = _M0L1xS661.$0;
      _M0L5startS2590 = _M0L1xS661.$1;
      _M0L3endS2592 = _M0L1xS661.$2;
      _M0L6_2atmpS2591 = (int64_t)_M0L3endS2592;
      moonbit_incref(_M0L3strS2589);
      moonbit_incref(_M0L3strS2585);
      #line 769 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
      _M0L6_2atmpS2588
      = _M0MPC16string6String29offset__of__nth__char_2einner(_M0L3strS2589, -1, _M0L5startS2590, _M0L6_2atmpS2591);
      moonbit_decref(_M0L3strS2589);
      _M0L6_2atmpS2587 = (int32_t)_M0L6_2atmpS2588;
      _M0L4_2axS664
      = (struct _M0TPC16string10StringView){
        .$0 = _M0L3strS2585, .$1 = _M0L5startS2586, .$2 = _M0L6_2atmpS2587
      };
      #line 773 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
      if (
        _M0MPC16string10StringView14contains__char(_M0L5charsS665, _M0L4_2acS663)
      ) {
        moonbit_decref(_M0L1xS661.$0);
        _M0L1xS661 = _M0L4_2axS664;
        continue;
      } else {
        moonbit_decref(_M0L4_2axS664.$0);
        return _M0L1xS661;
      }
    }
    break;
  }
}

struct _M0TPC16string10StringView _M0MPC16string10StringView19trim__start_2einner(
  struct _M0TPC16string10StringView _M0L4selfS660,
  struct _M0TPC16string10StringView _M0L5charsS659
) {
  struct _M0TPC16string10StringView _M0L1xS654;
  #line 716 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
  moonbit_incref(_M0L4selfS660.$0);
  _M0L1xS654 = _M0L4selfS660;
  while (1) {
    int32_t _M0L3endS2566 = _M0L1xS654.$2;
    int32_t _M0L5startS2567 = _M0L1xS654.$1;
    int32_t _M0L6_2atmpS2565 = _M0L3endS2566 - _M0L5startS2567;
    if (_M0L6_2atmpS2565 == 0) {
      return _M0L1xS654;
    } else {
      moonbit_string_t _M0L3strS2575 = _M0L1xS654.$0;
      moonbit_string_t _M0L3strS2578 = _M0L1xS654.$0;
      int32_t _M0L5startS2579 = _M0L1xS654.$1;
      int32_t _M0L3endS2581 = _M0L1xS654.$2;
      int64_t _M0L6_2atmpS2580 = (int64_t)_M0L3endS2581;
      int64_t _M0L6_2atmpS2577;
      int32_t _M0L6_2atmpS2576;
      int32_t _M0L4_2acS656;
      moonbit_string_t _M0L3strS2568;
      moonbit_string_t _M0L3strS2571;
      int32_t _M0L5startS2572;
      int32_t _M0L3endS2574;
      int64_t _M0L6_2atmpS2573;
      int64_t _M0L7_2abindS1935;
      int32_t _M0L6_2atmpS2569;
      int32_t _M0L3endS2570;
      struct _M0TPC16string10StringView _M0L4_2axS657;
      moonbit_incref(_M0L3strS2578);
      moonbit_incref(_M0L3strS2575);
      #line 721 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
      _M0L6_2atmpS2577
      = _M0MPC16string6String29offset__of__nth__char_2einner(_M0L3strS2578, 0, _M0L5startS2579, _M0L6_2atmpS2580);
      moonbit_decref(_M0L3strS2578);
      _M0L6_2atmpS2576 = (int32_t)_M0L6_2atmpS2577;
      #line 721 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
      _M0L4_2acS656
      = _M0MPC16string6String16unsafe__char__at(_M0L3strS2575, _M0L6_2atmpS2576);
      moonbit_decref(_M0L3strS2575);
      _M0L3strS2568 = _M0L1xS654.$0;
      _M0L3strS2571 = _M0L1xS654.$0;
      _M0L5startS2572 = _M0L1xS654.$1;
      _M0L3endS2574 = _M0L1xS654.$2;
      _M0L6_2atmpS2573 = (int64_t)_M0L3endS2574;
      moonbit_incref(_M0L3strS2571);
      moonbit_incref(_M0L3strS2568);
      #line 721 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
      _M0L7_2abindS1935
      = _M0MPC16string6String29offset__of__nth__char_2einner(_M0L3strS2571, 1, _M0L5startS2572, _M0L6_2atmpS2573);
      moonbit_decref(_M0L3strS2571);
      if (_M0L7_2abindS1935 == 4294967296ll) {
        _M0L6_2atmpS2569 = _M0L1xS654.$2;
      } else {
        int64_t _M0L7_2aSomeS658 = _M0L7_2abindS1935;
        _M0L6_2atmpS2569 = (int32_t)_M0L7_2aSomeS658;
      }
      _M0L3endS2570 = _M0L1xS654.$2;
      _M0L4_2axS657
      = (struct _M0TPC16string10StringView){
        .$0 = _M0L3strS2568, .$1 = _M0L6_2atmpS2569, .$2 = _M0L3endS2570
      };
      #line 725 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
      if (
        _M0MPC16string10StringView14contains__char(_M0L5charsS659, _M0L4_2acS656)
      ) {
        moonbit_decref(_M0L1xS654.$0);
        _M0L1xS654 = _M0L4_2axS657;
        continue;
      } else {
        moonbit_decref(_M0L4_2axS657.$0);
        return _M0L1xS654;
      }
    }
    break;
  }
}

int32_t _M0MPC16string10StringView14contains__char(
  struct _M0TPC16string10StringView _M0L4selfS645,
  int32_t _M0L1cS647
) {
  int32_t _M0L3endS2563;
  int32_t _M0L5startS2564;
  int32_t _M0L3lenS644;
  #line 652 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
  _M0L3endS2563 = _M0L4selfS645.$2;
  _M0L5startS2564 = _M0L4selfS645.$1;
  _M0L3lenS644 = _M0L3endS2563 - _M0L5startS2564;
  if (_M0L3lenS644 > 0) {
    int32_t _M0L1cS646 = _M0L1cS647;
    int32_t _if__result_4546;
    if (_M0L1cS646 >= 0) {
      _if__result_4546 = _M0L1cS646 <= 65535;
    } else {
      _if__result_4546 = 0;
    }
    if (_if__result_4546) {
      int32_t _M0L6_2atmpS2547 = (uint16_t)_M0L1cS646;
      #line 659 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
      return _M0MPC16string10StringView20contains__code__unit(_M0L4selfS645, _M0L6_2atmpS2547);
    } else if (_M0L1cS646 < 0) {
      return 0;
    } else if (_M0L3lenS644 >= 2) {
      int32_t _M0L3adjS648 = _M0L1cS646 - 65536;
      int32_t _M0L6_2atmpS2562 = _M0L3adjS648 >> 10;
      int32_t _M0L4highS649 = 55296 + _M0L6_2atmpS2562;
      if (_M0L4highS649 <= 65535) {
        int32_t _M0L4highS650 = (uint16_t)_M0L4highS649;
        int32_t _M0L6_2atmpS2561 = _M0L3adjS648 & 1023;
        int32_t _M0L6_2atmpS2560 = 56320 + _M0L6_2atmpS2561;
        int32_t _M0L3lowS651 = (uint16_t)_M0L6_2atmpS2560;
        int32_t _M0L1iS652 = 0;
        while (1) {
          int32_t _M0L6_2atmpS2548 = _M0L3lenS644 - 1;
          if (_M0L1iS652 < _M0L6_2atmpS2548) {
            moonbit_string_t _M0L3strS2550 = _M0L4selfS645.$0;
            int32_t _M0L5startS2552 = _M0L4selfS645.$1;
            int32_t _M0L6_2atmpS2551 = _M0L5startS2552 + _M0L1iS652;
            int32_t _M0L6_2atmpS2549 = _M0L3strS2550[_M0L6_2atmpS2551];
            int32_t _M0L6_2atmpS2559;
            if (_M0L6_2atmpS2549 == _M0L4highS650) {
              moonbit_string_t _M0L3strS2554 = _M0L4selfS645.$0;
              int32_t _M0L5startS2556 = _M0L4selfS645.$1;
              int32_t _M0L6_2atmpS2557 = _M0L1iS652 + 1;
              int32_t _M0L6_2atmpS2555 = _M0L5startS2556 + _M0L6_2atmpS2557;
              int32_t _M0L6_2atmpS2553 = _M0L3strS2554[_M0L6_2atmpS2555];
              int32_t _M0L6_2atmpS2558;
              if (_M0L6_2atmpS2553 == _M0L3lowS651) {
                return 1;
              }
              _M0L6_2atmpS2558 = _M0L1iS652 + 2;
              _M0L1iS652 = _M0L6_2atmpS2558;
              continue;
            }
            _M0L6_2atmpS2559 = _M0L1iS652 + 1;
            _M0L1iS652 = _M0L6_2atmpS2559;
            continue;
          }
          break;
        }
      } else {
        return 0;
      }
    } else {
      return 0;
    }
    return 0;
  } else {
    return 0;
  }
}

int32_t _M0MPC16string10StringView20contains__code__unit(
  struct _M0TPC16string10StringView _M0L4selfS642,
  int32_t _M0L4codeS643
) {
  moonbit_string_t _M0L3strS2544;
  int32_t _M0L5startS2545;
  int32_t _M0L3endS2546;
  int32_t _result_4548;
  #line 487 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
  _M0L3strS2544 = _M0L4selfS642.$0;
  _M0L5startS2545 = _M0L4selfS642.$1;
  _M0L3endS2546 = _M0L4selfS642.$2;
  moonbit_incref(_M0L3strS2544);
  #line 488 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
  _result_4548
  = _M0FPB28string__contains__code__unit(_M0L3strS2544, _M0L5startS2545, _M0L3endS2546, _M0L4codeS643);
  moonbit_decref(_M0L3strS2544);
  return _result_4548;
}

int32_t _M0FPB28string__contains__code__unit(
  moonbit_string_t _M0L3strS640,
  int32_t _M0L5startS634,
  int32_t _M0L3endS635,
  int32_t _M0L4codeS637
) {
  int32_t _M0L6_2atmpS2539;
  #line 522 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
  _M0L6_2atmpS2539 = _M0L5startS634 + 8;
  if (_M0L6_2atmpS2539 <= _M0L3endS635) {
    moonbit_v128_t _M0L6needleS636;
    int32_t _M0L11tail__startS638;
    int32_t _M0L3posS639;
    #line 532 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
    _M0L6needleS636 = Moonbit_simd_i16x8_splat(_M0L4codeS637);
    _M0L3posS639 = _M0L5startS634;
    while (1) {
      int32_t _M0L6_2atmpS2540 = _M0L3posS639 + 8;
      if (_M0L6_2atmpS2540 <= _M0L3endS635) {
        moonbit_v128_t _M0L6_2atmpS2542;
        moonbit_v128_t _M0L6_2atmpS2541;
        int32_t _M0L6_2atmpS2543;
        #line 534 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
        _M0L6_2atmpS2542
        = Moonbit_simd_v128_load_u16(_M0L3strS640, _M0L3posS639);
        #line 534 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
        _M0L6_2atmpS2541
        = Moonbit_simd_i16x8_eq(_M0L6_2atmpS2542, _M0L6needleS636);
        #line 534 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
        if (Moonbit_simd_v128_any_true(_M0L6_2atmpS2541)) {
          return 1;
        }
        _M0L6_2atmpS2543 = _M0L3posS639 + 8;
        _M0L3posS639 = _M0L6_2atmpS2543;
        continue;
      } else {
        _M0L11tail__startS638 = _M0L3posS639;
      }
      break;
    }
    #line 541 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
    return _M0FPB36string__contains__code__unit__scalar(_M0L3strS640, _M0L11tail__startS638, _M0L3endS635, _M0L4codeS637);
  } else {
    #line 530 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
    return _M0FPB36string__contains__code__unit__scalar(_M0L3strS640, _M0L5startS634, _M0L3endS635, _M0L4codeS637);
  }
}

int32_t _M0FPB15v128__any__true(moonbit_v128_t _M0L5valueS633) {
  uint64_t _M0L6_2atmpS2538;
  #line 130 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\simd.mbt"
  _M0L6_2atmpS2538 = Moonbit_v128_lo(_M0L5valueS633);
  if (_M0L6_2atmpS2538 != 0ull) {
    return 1;
  } else {
    uint64_t _M0L6_2atmpS2537 = Moonbit_v128_hi(_M0L5valueS633);
    return _M0L6_2atmpS2537 != 0ull;
  }
}

int32_t _M0FPB36string__contains__code__unit__scalar(
  moonbit_string_t _M0L3strS629,
  int32_t _M0L5startS632,
  int32_t _M0L3endS628,
  int32_t _M0L4codeS630
) {
  int32_t _M0L1iS627;
  #line 493 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
  _M0L1iS627 = _M0L5startS632;
  while (1) {
    if (_M0L1iS627 < _M0L3endS628) {
      int32_t _M0L6_2atmpS2535 = _M0L3strS629[_M0L1iS627];
      int32_t _M0L6_2atmpS2536;
      if (_M0L6_2atmpS2535 == _M0L4codeS630) {
        return 1;
      }
      _M0L6_2atmpS2536 = _M0L1iS627 + 1;
      _M0L1iS627 = _M0L6_2atmpS2536;
      continue;
    }
    break;
  }
  return 0;
}

int32_t _M0MPC15array5Array4pushGsE(
  struct _M0TPB5ArrayGsE* _M0L4selfS615,
  moonbit_string_t _M0L5valueS617
) {
  int32_t _M0L3lenS2507;
  moonbit_string_t* _M0L6_2atmpS2509;
  int32_t _M0L6_2atmpS2508;
  int32_t _M0L6lengthS616;
  moonbit_string_t* _M0L3bufS2512;
  moonbit_string_t _M0L6_2aoldS4166;
  int32_t _M0L6_2atmpS2513;
  #line 355 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L3lenS2507 = _M0L4selfS615->$1;
  #line 357 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L6_2atmpS2509 = _M0MPC15array5Array6bufferGsE(_M0L4selfS615);
  _M0L6_2atmpS2508 = Moonbit_array_length(_M0L6_2atmpS2509);
  moonbit_decref(_M0L6_2atmpS2509);
  if (_M0L3lenS2507 == _M0L6_2atmpS2508) {
    int32_t _M0L3lenS2511 = _M0L4selfS615->$1;
    int32_t _M0L6_2atmpS2510 = _M0L3lenS2511 + 1;
    #line 358 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
    _M0MPC15array5Array7reallocGsE(_M0L4selfS615, _M0L6_2atmpS2510);
  }
  _M0L6lengthS616 = _M0L4selfS615->$1;
  _M0L3bufS2512 = _M0L4selfS615->$0;
  _M0L6_2aoldS4166 = (moonbit_string_t)_M0L3bufS2512[_M0L6lengthS616];
  moonbit_decref(_M0L6_2aoldS4166);
  _M0L3bufS2512[_M0L6lengthS616] = _M0L5valueS617;
  _M0L6_2atmpS2513 = _M0L6lengthS616 + 1;
  _M0L4selfS615->$1 = _M0L6_2atmpS2513;
  return 0;
}

int32_t _M0MPC15array5Array4pushGUsiEE(
  struct _M0TPB5ArrayGUsiEE* _M0L4selfS618,
  struct _M0TUsiE* _M0L5valueS620
) {
  int32_t _M0L3lenS2514;
  struct _M0TUsiE** _M0L6_2atmpS2516;
  int32_t _M0L6_2atmpS2515;
  int32_t _M0L6lengthS619;
  struct _M0TUsiE** _M0L3bufS2519;
  struct _M0TUsiE* _M0L6_2aoldS4167;
  int32_t _M0L6_2atmpS2520;
  #line 355 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L3lenS2514 = _M0L4selfS618->$1;
  #line 357 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L6_2atmpS2516 = _M0MPC15array5Array6bufferGUsiEE(_M0L4selfS618);
  _M0L6_2atmpS2515 = Moonbit_array_length(_M0L6_2atmpS2516);
  moonbit_decref(_M0L6_2atmpS2516);
  if (_M0L3lenS2514 == _M0L6_2atmpS2515) {
    int32_t _M0L3lenS2518 = _M0L4selfS618->$1;
    int32_t _M0L6_2atmpS2517 = _M0L3lenS2518 + 1;
    #line 358 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
    _M0MPC15array5Array7reallocGUsiEE(_M0L4selfS618, _M0L6_2atmpS2517);
  }
  _M0L6lengthS619 = _M0L4selfS618->$1;
  _M0L3bufS2519 = _M0L4selfS618->$0;
  _M0L6_2aoldS4167 = (struct _M0TUsiE*)_M0L3bufS2519[_M0L6lengthS619];
  if (_M0L6_2aoldS4167) {
    moonbit_decref(_M0L6_2aoldS4167);
  }
  _M0L3bufS2519[_M0L6lengthS619] = _M0L5valueS620;
  _M0L6_2atmpS2520 = _M0L6lengthS619 + 1;
  _M0L4selfS618->$1 = _M0L6_2atmpS2520;
  return 0;
}

int32_t _M0MPC15array5Array4pushGRPC15debug9ReprDeltaE(
  struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* _M0L4selfS621,
  void* _M0L5valueS623
) {
  int32_t _M0L3lenS2521;
  void** _M0L6_2atmpS2523;
  int32_t _M0L6_2atmpS2522;
  int32_t _M0L6lengthS622;
  void** _M0L3bufS2526;
  void* _M0L6_2aoldS4168;
  int32_t _M0L6_2atmpS2527;
  #line 355 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L3lenS2521 = _M0L4selfS621->$1;
  #line 357 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L6_2atmpS2523
  = _M0MPC15array5Array6bufferGRPC15debug9ReprDeltaE(_M0L4selfS621);
  _M0L6_2atmpS2522 = Moonbit_array_length(_M0L6_2atmpS2523);
  moonbit_decref(_M0L6_2atmpS2523);
  if (_M0L3lenS2521 == _M0L6_2atmpS2522) {
    int32_t _M0L3lenS2525 = _M0L4selfS621->$1;
    int32_t _M0L6_2atmpS2524 = _M0L3lenS2525 + 1;
    #line 358 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
    _M0MPC15array5Array7reallocGRPC15debug9ReprDeltaE(_M0L4selfS621, _M0L6_2atmpS2524);
  }
  _M0L6lengthS622 = _M0L4selfS621->$1;
  _M0L3bufS2526 = _M0L4selfS621->$0;
  _M0L6_2aoldS4168 = (void*)_M0L3bufS2526[_M0L6lengthS622];
  moonbit_decref(_M0L6_2aoldS4168);
  _M0L3bufS2526[_M0L6lengthS622] = _M0L5valueS623;
  _M0L6_2atmpS2527 = _M0L6lengthS622 + 1;
  _M0L4selfS621->$1 = _M0L6_2atmpS2527;
  return 0;
}

int32_t _M0MPC15array5Array4pushGRPC16string10StringViewE(
  struct _M0TPB5ArrayGRPC16string10StringViewE* _M0L4selfS624,
  struct _M0TPC16string10StringView _M0L5valueS626
) {
  int32_t _M0L3lenS2528;
  struct _M0TPC16string10StringView* _M0L6_2atmpS2530;
  int32_t _M0L6_2atmpS2529;
  int32_t _M0L6lengthS625;
  struct _M0TPC16string10StringView* _M0L3bufS2533;
  struct _M0TPC16string10StringView _M0L6_2aoldS4169;
  int32_t _M0L6_2atmpS2534;
  #line 355 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L3lenS2528 = _M0L4selfS624->$1;
  #line 357 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L6_2atmpS2530
  = _M0MPC15array5Array6bufferGRPC16string10StringViewE(_M0L4selfS624);
  _M0L6_2atmpS2529 = Moonbit_array_length(_M0L6_2atmpS2530);
  moonbit_decref(_M0L6_2atmpS2530);
  if (_M0L3lenS2528 == _M0L6_2atmpS2529) {
    int32_t _M0L3lenS2532 = _M0L4selfS624->$1;
    int32_t _M0L6_2atmpS2531 = _M0L3lenS2532 + 1;
    #line 358 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
    _M0MPC15array5Array7reallocGRPC16string10StringViewE(_M0L4selfS624, _M0L6_2atmpS2531);
  }
  _M0L6lengthS625 = _M0L4selfS624->$1;
  _M0L3bufS2533 = _M0L4selfS624->$0;
  _M0L6_2aoldS4169 = _M0L3bufS2533[_M0L6lengthS625];
  moonbit_decref(_M0L6_2aoldS4169.$0);
  _M0L3bufS2533[_M0L6lengthS625] = _M0L5valueS626;
  _M0L6_2atmpS2534 = _M0L6lengthS625 + 1;
  _M0L4selfS624->$1 = _M0L6_2atmpS2534;
  return 0;
}

int32_t _M0MPC15array5Array7reallocGsE(
  struct _M0TPB5ArrayGsE* _M0L4selfS600,
  int32_t _M0L8requiredS602
) {
  int32_t _M0L8old__capS599;
  int32_t _M0L3lenS2503;
  int32_t _M0L8new__capS601;
  #line 294 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  #line 296 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8old__capS599 = _M0MPC15array5Array8capacityGsE(_M0L4selfS600);
  _M0L3lenS2503 = _M0L4selfS600->$1;
  #line 297 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8new__capS601
  = _M0FPB23array__growth__capacity(_M0L8old__capS599, _M0L3lenS2503, _M0L8requiredS602);
  #line 298 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0MPC15array5Array14resize__bufferGsE(_M0L4selfS600, _M0L8new__capS601);
  return 0;
}

int32_t _M0MPC15array5Array7reallocGUsiEE(
  struct _M0TPB5ArrayGUsiEE* _M0L4selfS604,
  int32_t _M0L8requiredS606
) {
  int32_t _M0L8old__capS603;
  int32_t _M0L3lenS2504;
  int32_t _M0L8new__capS605;
  #line 294 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  #line 296 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8old__capS603 = _M0MPC15array5Array8capacityGUsiEE(_M0L4selfS604);
  _M0L3lenS2504 = _M0L4selfS604->$1;
  #line 297 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8new__capS605
  = _M0FPB23array__growth__capacity(_M0L8old__capS603, _M0L3lenS2504, _M0L8requiredS606);
  #line 298 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0MPC15array5Array14resize__bufferGUsiEE(_M0L4selfS604, _M0L8new__capS605);
  return 0;
}

int32_t _M0MPC15array5Array7reallocGRPC15debug9ReprDeltaE(
  struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* _M0L4selfS608,
  int32_t _M0L8requiredS610
) {
  int32_t _M0L8old__capS607;
  int32_t _M0L3lenS2505;
  int32_t _M0L8new__capS609;
  #line 294 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  #line 296 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8old__capS607
  = _M0MPC15array5Array8capacityGRPC15debug9ReprDeltaE(_M0L4selfS608);
  _M0L3lenS2505 = _M0L4selfS608->$1;
  #line 297 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8new__capS609
  = _M0FPB23array__growth__capacity(_M0L8old__capS607, _M0L3lenS2505, _M0L8requiredS610);
  #line 298 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0MPC15array5Array14resize__bufferGRPC15debug9ReprDeltaE(_M0L4selfS608, _M0L8new__capS609);
  return 0;
}

int32_t _M0MPC15array5Array7reallocGRPC16string10StringViewE(
  struct _M0TPB5ArrayGRPC16string10StringViewE* _M0L4selfS612,
  int32_t _M0L8requiredS614
) {
  int32_t _M0L8old__capS611;
  int32_t _M0L3lenS2506;
  int32_t _M0L8new__capS613;
  #line 294 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  #line 296 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8old__capS611
  = _M0MPC15array5Array8capacityGRPC16string10StringViewE(_M0L4selfS612);
  _M0L3lenS2506 = _M0L4selfS612->$1;
  #line 297 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8new__capS613
  = _M0FPB23array__growth__capacity(_M0L8old__capS611, _M0L3lenS2506, _M0L8requiredS614);
  #line 298 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0MPC15array5Array14resize__bufferGRPC16string10StringViewE(_M0L4selfS612, _M0L8new__capS613);
  return 0;
}

int32_t _M0MPC15array5Array14resize__bufferGsE(
  struct _M0TPB5ArrayGsE* _M0L4selfS576,
  int32_t _M0L13new__capacityS579
) {
  moonbit_string_t* _M0L8old__bufS575;
  int32_t _M0L8old__capS577;
  int32_t _M0L9copy__lenS578;
  moonbit_string_t* _M0L8new__bufS580;
  moonbit_string_t* _M0L6_2aoldS4170;
  #line 237 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8old__bufS575 = _M0L4selfS576->$0;
  _M0L8old__capS577 = Moonbit_array_length(_M0L8old__bufS575);
  if (_M0L8old__capS577 < _M0L13new__capacityS579) {
    _M0L9copy__lenS578 = _M0L8old__capS577;
  } else {
    _M0L9copy__lenS578 = _M0L13new__capacityS579;
  }
  moonbit_incref(_M0L8old__bufS575);
  #line 241 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8new__bufS580
  = _M0MPB18UninitializedArray23make__and__blit_2einnerGsE(_M0L8old__bufS575, _M0L13new__capacityS579, _M0L9copy__lenS578, 0, 0);
  _M0L6_2aoldS4170 = _M0L4selfS576->$0;
  moonbit_decref(_M0L6_2aoldS4170);
  _M0L4selfS576->$0 = _M0L8new__bufS580;
  return 0;
}

int32_t _M0MPC15array5Array14resize__bufferGUsiEE(
  struct _M0TPB5ArrayGUsiEE* _M0L4selfS582,
  int32_t _M0L13new__capacityS585
) {
  struct _M0TUsiE** _M0L8old__bufS581;
  int32_t _M0L8old__capS583;
  int32_t _M0L9copy__lenS584;
  struct _M0TUsiE** _M0L8new__bufS586;
  struct _M0TUsiE** _M0L6_2aoldS4172;
  #line 237 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8old__bufS581 = _M0L4selfS582->$0;
  _M0L8old__capS583 = Moonbit_array_length(_M0L8old__bufS581);
  if (_M0L8old__capS583 < _M0L13new__capacityS585) {
    _M0L9copy__lenS584 = _M0L8old__capS583;
  } else {
    _M0L9copy__lenS584 = _M0L13new__capacityS585;
  }
  moonbit_incref(_M0L8old__bufS581);
  #line 241 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8new__bufS586
  = _M0MPB18UninitializedArray23make__and__blit_2einnerGUsiEE(_M0L8old__bufS581, _M0L13new__capacityS585, _M0L9copy__lenS584, 0, 0);
  _M0L6_2aoldS4172 = _M0L4selfS582->$0;
  moonbit_decref(_M0L6_2aoldS4172);
  _M0L4selfS582->$0 = _M0L8new__bufS586;
  return 0;
}

int32_t _M0MPC15array5Array14resize__bufferGRPC15debug9ReprDeltaE(
  struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* _M0L4selfS588,
  int32_t _M0L13new__capacityS591
) {
  void** _M0L8old__bufS587;
  int32_t _M0L8old__capS589;
  int32_t _M0L9copy__lenS590;
  void** _M0L8new__bufS592;
  void** _M0L6_2aoldS4174;
  #line 237 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8old__bufS587 = _M0L4selfS588->$0;
  _M0L8old__capS589 = Moonbit_array_length(_M0L8old__bufS587);
  if (_M0L8old__capS589 < _M0L13new__capacityS591) {
    _M0L9copy__lenS590 = _M0L8old__capS589;
  } else {
    _M0L9copy__lenS590 = _M0L13new__capacityS591;
  }
  moonbit_incref(_M0L8old__bufS587);
  #line 241 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8new__bufS592
  = _M0MPB18UninitializedArray23make__and__blit_2einnerGRPC15debug9ReprDeltaE(_M0L8old__bufS587, _M0L13new__capacityS591, _M0L9copy__lenS590, 0, 0);
  _M0L6_2aoldS4174 = _M0L4selfS588->$0;
  moonbit_decref(_M0L6_2aoldS4174);
  _M0L4selfS588->$0 = _M0L8new__bufS592;
  return 0;
}

int32_t _M0MPC15array5Array14resize__bufferGRPC16string10StringViewE(
  struct _M0TPB5ArrayGRPC16string10StringViewE* _M0L4selfS594,
  int32_t _M0L13new__capacityS597
) {
  struct _M0TPC16string10StringView* _M0L8old__bufS593;
  int32_t _M0L8old__capS595;
  int32_t _M0L9copy__lenS596;
  struct _M0TPC16string10StringView* _M0L8new__bufS598;
  struct _M0TPC16string10StringView* _M0L6_2aoldS4176;
  #line 237 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8old__bufS593 = _M0L4selfS594->$0;
  _M0L8old__capS595 = Moonbit_array_length(_M0L8old__bufS593);
  if (_M0L8old__capS595 < _M0L13new__capacityS597) {
    _M0L9copy__lenS596 = _M0L8old__capS595;
  } else {
    _M0L9copy__lenS596 = _M0L13new__capacityS597;
  }
  moonbit_incref(_M0L8old__bufS593);
  #line 241 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8new__bufS598
  = _M0MPB18UninitializedArray23make__and__blit_2einnerGRPC16string10StringViewE(_M0L8old__bufS593, _M0L13new__capacityS597, _M0L9copy__lenS596, 0, 0);
  _M0L6_2aoldS4176 = _M0L4selfS594->$0;
  moonbit_decref(_M0L6_2aoldS4176);
  _M0L4selfS594->$0 = _M0L8new__bufS598;
  return 0;
}

int32_t _M0MPC15array5Array8capacityGsE(
  struct _M0TPB5ArrayGsE* _M0L4selfS571
) {
  moonbit_string_t* _M0L6_2atmpS2499;
  int32_t _result_4551;
  #line 132 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  #line 133 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L6_2atmpS2499 = _M0MPC15array5Array6bufferGsE(_M0L4selfS571);
  _result_4551 = Moonbit_array_length(_M0L6_2atmpS2499);
  moonbit_decref(_M0L6_2atmpS2499);
  return _result_4551;
}

int32_t _M0MPC15array5Array8capacityGUsiEE(
  struct _M0TPB5ArrayGUsiEE* _M0L4selfS572
) {
  struct _M0TUsiE** _M0L6_2atmpS2500;
  int32_t _result_4552;
  #line 132 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  #line 133 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L6_2atmpS2500 = _M0MPC15array5Array6bufferGUsiEE(_M0L4selfS572);
  _result_4552 = Moonbit_array_length(_M0L6_2atmpS2500);
  moonbit_decref(_M0L6_2atmpS2500);
  return _result_4552;
}

int32_t _M0MPC15array5Array8capacityGRPC15debug9ReprDeltaE(
  struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* _M0L4selfS573
) {
  void** _M0L6_2atmpS2501;
  int32_t _result_4553;
  #line 132 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  #line 133 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L6_2atmpS2501
  = _M0MPC15array5Array6bufferGRPC15debug9ReprDeltaE(_M0L4selfS573);
  _result_4553 = Moonbit_array_length(_M0L6_2atmpS2501);
  moonbit_decref(_M0L6_2atmpS2501);
  return _result_4553;
}

int32_t _M0MPC15array5Array8capacityGRPC16string10StringViewE(
  struct _M0TPB5ArrayGRPC16string10StringViewE* _M0L4selfS574
) {
  struct _M0TPC16string10StringView* _M0L6_2atmpS2502;
  int32_t _result_4554;
  #line 132 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  #line 133 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L6_2atmpS2502
  = _M0MPC15array5Array6bufferGRPC16string10StringViewE(_M0L4selfS574);
  _result_4554 = Moonbit_array_length(_M0L6_2atmpS2502);
  moonbit_decref(_M0L6_2atmpS2502);
  return _result_4554;
}

int32_t _M0FPB23array__growth__capacity(
  int32_t _M0L7currentS567,
  int32_t _M0L3lenS565,
  int32_t _M0L8requiredS564
) {
  int32_t _M0L5startS566;
  int32_t _M0L5spaceS568;
  #line 195 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  if (_M0L8requiredS564 < _M0L3lenS565) {
    #line 198 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
    _M0FPC15abort5abortGuE((moonbit_string_t)moonbit_string_literal_51.data);
  }
  if (_M0L7currentS567 == 0) {
    _M0L5startS566 = 8;
  } else {
    _M0L5startS566 = _M0L7currentS567;
  }
  _M0L5spaceS568 = _M0L5startS566;
  while (1) {
    if (_M0L5spaceS568 < _M0L8requiredS564) {
      int32_t _M0L4nextS569 = _M0L5spaceS568 * 2;
      if (_M0L4nextS569 <= _M0L5spaceS568) {
        return _M0L8requiredS564;
      }
      _M0L5spaceS568 = _M0L4nextS569;
      continue;
    } else {
      return _M0L5spaceS568;
    }
    break;
  }
}

int32_t _M0MPC15array5Array6lengthGRP27walkzzz11mcp__server8CategoryE(
  struct _M0TPB5ArrayGRP27walkzzz11mcp__server8CategoryE* _M0L4selfS563
) {
  #line 143 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  return _M0L4selfS563->$1;
}

moonbit_string_t* _M0MPC15array5Array6bufferGsE(
  struct _M0TPB5ArrayGsE* _M0L4selfS558
) {
  moonbit_string_t* _M0L8_2afieldS4178;
  #line 187 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8_2afieldS4178 = _M0L4selfS558->$0;
  moonbit_incref(_M0L8_2afieldS4178);
  return _M0L8_2afieldS4178;
}

struct _M0TUsiE** _M0MPC15array5Array6bufferGUsiEE(
  struct _M0TPB5ArrayGUsiEE* _M0L4selfS559
) {
  struct _M0TUsiE** _M0L8_2afieldS4179;
  #line 187 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8_2afieldS4179 = _M0L4selfS559->$0;
  moonbit_incref(_M0L8_2afieldS4179);
  return _M0L8_2afieldS4179;
}

void** _M0MPC15array5Array6bufferGRPC15debug9ReprDeltaE(
  struct _M0TPB5ArrayGRPC15debug9ReprDeltaE* _M0L4selfS560
) {
  void** _M0L8_2afieldS4180;
  #line 187 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8_2afieldS4180 = _M0L4selfS560->$0;
  moonbit_incref(_M0L8_2afieldS4180);
  return _M0L8_2afieldS4180;
}

void** _M0MPC15array5Array6bufferGRPC15debug4ReprE(
  struct _M0TPB5ArrayGRPC15debug4ReprE* _M0L4selfS561
) {
  void** _M0L8_2afieldS4181;
  #line 187 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8_2afieldS4181 = _M0L4selfS561->$0;
  moonbit_incref(_M0L8_2afieldS4181);
  return _M0L8_2afieldS4181;
}

struct _M0TPC16string10StringView* _M0MPC15array5Array6bufferGRPC16string10StringViewE(
  struct _M0TPB5ArrayGRPC16string10StringViewE* _M0L4selfS562
) {
  struct _M0TPC16string10StringView* _M0L8_2afieldS4182;
  #line 187 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8_2afieldS4182 = _M0L4selfS562->$0;
  moonbit_incref(_M0L8_2afieldS4182);
  return _M0L8_2afieldS4182;
}

void* _M0MPC16string10StringView13strip__prefix(
  struct _M0TPC16string10StringView _M0L4selfS557,
  struct _M0TPC16string10StringView _M0L6prefixS556
) {
  int32_t _M0L3endS2497;
  int32_t _M0L5startS2498;
  int32_t _M0L11prefix__lenS555;
  int32_t _M0L3endS2494;
  int32_t _M0L5startS2495;
  int32_t _M0L6_2atmpS2493;
  int32_t _if__result_4556;
  #line 363 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
  _M0L3endS2497 = _M0L6prefixS556.$2;
  _M0L5startS2498 = _M0L6prefixS556.$1;
  _M0L11prefix__lenS555 = _M0L3endS2497 - _M0L5startS2498;
  _M0L3endS2494 = _M0L4selfS557.$2;
  _M0L5startS2495 = _M0L4selfS557.$1;
  _M0L6_2atmpS2493 = _M0L3endS2494 - _M0L5startS2495;
  if (_M0L6_2atmpS2493 >= _M0L11prefix__lenS555) {
    int64_t _M0L6_2atmpS2492 = (int64_t)_M0L11prefix__lenS555;
    struct _M0TPC16string10StringView _M0L6_2atmpS2491;
    #line 369 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
    _M0L6_2atmpS2491
    = _M0MPC16string10StringView12view_2einner(_M0L4selfS557, 0, _M0L6_2atmpS2492);
    #line 369 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
    _if__result_4556
    = _M0IPC16string10StringViewPB2Eq5equal(_M0L6_2atmpS2491, _M0L6prefixS556);
    moonbit_decref(_M0L6_2atmpS2491.$0);
  } else {
    _if__result_4556 = 0;
  }
  if (_if__result_4556) {
    struct _M0TPC16string10StringView _M0L6_2atmpS2496;
    void* _block_4557;
    #line 370 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
    _M0L6_2atmpS2496
    = _M0MPC16string10StringView12view_2einner(_M0L4selfS557, _M0L11prefix__lenS555, 4294967296ll);
    _block_4557
    = (void*)moonbit_malloc(sizeof(struct _M0DTPC16option6OptionGRPC16string10StringViewE4Some));
    Moonbit_object_header(_block_4557)->meta
    = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 153, 1);
    ((struct _M0DTPC16option6OptionGRPC16string10StringViewE4Some*)_block_4557)->$0
    = _M0L6_2atmpS2496;
    return _block_4557;
  } else {
    return (struct moonbit_object*)&moonbit_constant_constructor_0 + 1;
  }
}

void* _M0MPC16string6String13strip__suffix(
  moonbit_string_t _M0L4selfS553,
  struct _M0TPC16string10StringView _M0L6suffixS554
) {
  int32_t _M0L6_2atmpS2490;
  struct _M0TPC16string10StringView _M0L6_2atmpS2489;
  void* _result_4558;
  #line 296 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
  _M0L6_2atmpS2490 = Moonbit_array_length(_M0L4selfS553);
  moonbit_incref(_M0L4selfS553);
  _M0L6_2atmpS2489
  = (struct _M0TPC16string10StringView){
    .$0 = _M0L4selfS553, .$1 = 0, .$2 = _M0L6_2atmpS2490
  };
  #line 298 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
  _result_4558
  = _M0MPC16string10StringView13strip__suffix(_M0L6_2atmpS2489, _M0L6suffixS554);
  moonbit_decref(_M0L6_2atmpS2489.$0);
  return _result_4558;
}

void* _M0MPC16string10StringView13strip__suffix(
  struct _M0TPC16string10StringView _M0L4selfS550,
  struct _M0TPC16string10StringView _M0L6suffixS552
) {
  int32_t _M0L3endS2487;
  int32_t _M0L5startS2488;
  int32_t _M0L9self__lenS549;
  int32_t _M0L3endS2485;
  int32_t _M0L5startS2486;
  int32_t _M0L11suffix__lenS551;
  int32_t _if__result_4559;
  #line 393 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
  _M0L3endS2487 = _M0L4selfS550.$2;
  _M0L5startS2488 = _M0L4selfS550.$1;
  _M0L9self__lenS549 = _M0L3endS2487 - _M0L5startS2488;
  _M0L3endS2485 = _M0L6suffixS552.$2;
  _M0L5startS2486 = _M0L6suffixS552.$1;
  _M0L11suffix__lenS551 = _M0L3endS2485 - _M0L5startS2486;
  if (_M0L9self__lenS549 >= _M0L11suffix__lenS551) {
    int32_t _M0L6_2atmpS2481 = _M0L9self__lenS549 - _M0L11suffix__lenS551;
    struct _M0TPC16string10StringView _M0L6_2atmpS2480;
    #line 401 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
    _M0L6_2atmpS2480
    = _M0MPC16string10StringView12view_2einner(_M0L4selfS550, _M0L6_2atmpS2481, 4294967296ll);
    #line 401 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
    _if__result_4559
    = _M0IPC16string10StringViewPB2Eq5equal(_M0L6_2atmpS2480, _M0L6suffixS552);
    moonbit_decref(_M0L6_2atmpS2480.$0);
  } else {
    _if__result_4559 = 0;
  }
  if (_if__result_4559) {
    int32_t _M0L6_2atmpS2484 = _M0L9self__lenS549 - _M0L11suffix__lenS551;
    int64_t _M0L6_2atmpS2483 = (int64_t)_M0L6_2atmpS2484;
    struct _M0TPC16string10StringView _M0L6_2atmpS2482;
    void* _block_4560;
    #line 402 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
    _M0L6_2atmpS2482
    = _M0MPC16string10StringView12view_2einner(_M0L4selfS550, 0, _M0L6_2atmpS2483);
    _block_4560
    = (void*)moonbit_malloc(sizeof(struct _M0DTPC16option6OptionGRPC16string10StringViewE4Some));
    Moonbit_object_header(_block_4560)->meta
    = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 153, 1);
    ((struct _M0DTPC16option6OptionGRPC16string10StringViewE4Some*)_block_4560)->$0
    = _M0L6_2atmpS2482;
    return _block_4560;
  } else {
    return (struct moonbit_object*)&moonbit_constant_constructor_0 + 1;
  }
}

int32_t _M0MPC16string6String11has__suffix(
  moonbit_string_t _M0L4selfS547,
  struct _M0TPC16string10StringView _M0L3strS548
) {
  int32_t _M0L6_2atmpS2479;
  struct _M0TPC16string10StringView _M0L6_2atmpS2478;
  int32_t _result_4561;
  #line 207 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
  _M0L6_2atmpS2479 = Moonbit_array_length(_M0L4selfS547);
  moonbit_incref(_M0L4selfS547);
  _M0L6_2atmpS2478
  = (struct _M0TPC16string10StringView){
    .$0 = _M0L4selfS547, .$1 = 0, .$2 = _M0L6_2atmpS2479
  };
  #line 209 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
  _result_4561
  = _M0MPC16string10StringView11has__suffix(_M0L6_2atmpS2478, _M0L3strS548);
  moonbit_decref(_M0L6_2atmpS2478.$0);
  return _result_4561;
}

int32_t _M0MPC16string10StringView11has__suffix(
  struct _M0TPC16string10StringView _M0L4selfS543,
  struct _M0TPC16string10StringView _M0L3strS545
) {
  int32_t _M0L3endS2476;
  int32_t _M0L5startS2477;
  int32_t _M0L9self__lenS542;
  int32_t _M0L3endS2474;
  int32_t _M0L5startS2475;
  int32_t _M0L8str__lenS544;
  #line 184 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
  _M0L3endS2476 = _M0L4selfS543.$2;
  _M0L5startS2477 = _M0L4selfS543.$1;
  _M0L9self__lenS542 = _M0L3endS2476 - _M0L5startS2477;
  _M0L3endS2474 = _M0L3strS545.$2;
  _M0L5startS2475 = _M0L3strS545.$1;
  _M0L8str__lenS544 = _M0L3endS2474 - _M0L5startS2475;
  if (_M0L8str__lenS544 <= _M0L9self__lenS542) {
    int32_t _M0L5startS546 = _M0L9self__lenS542 - _M0L8str__lenS544;
    int32_t _if__result_4562;
    if (_M0L8str__lenS544 == 0) {
      _if__result_4562 = 1;
    } else {
      moonbit_string_t _M0L3strS2466 = _M0L4selfS543.$0;
      int32_t _M0L5startS2468 = _M0L4selfS543.$1;
      int32_t _M0L6_2atmpS2467 = _M0L5startS2468 + _M0L5startS546;
      int32_t _M0L6_2atmpS2462 = _M0L3strS2466[_M0L6_2atmpS2467];
      moonbit_string_t _M0L3strS2464 = _M0L3strS545.$0;
      int32_t _M0L5startS2465 = _M0L3strS545.$1;
      int32_t _M0L6_2atmpS2463 = _M0L3strS2464[_M0L5startS2465];
      _if__result_4562 = _M0L6_2atmpS2462 == _M0L6_2atmpS2463;
    }
    if (_if__result_4562) {
      moonbit_string_t _M0L3strS2469 = _M0L4selfS543.$0;
      int32_t _M0L5startS2473 = _M0L4selfS543.$1;
      int32_t _M0L6_2atmpS2470 = _M0L5startS2473 + _M0L5startS546;
      moonbit_string_t _M0L3strS2471 = _M0L3strS545.$0;
      int32_t _M0L5startS2472 = _M0L3strS545.$1;
      int32_t _result_4563;
      moonbit_incref(_M0L3strS2471);
      moonbit_incref(_M0L3strS2469);
      #line 195 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
      _result_4563
      = 0
        == memcmp(_M0L3strS2469 + _M0L6_2atmpS2470, _M0L3strS2471 + _M0L5startS2472, (size_t)_M0L8str__lenS544 * 2);
      moonbit_decref(_M0L3strS2469);
      moonbit_decref(_M0L3strS2471);
      return _result_4563;
    } else {
      return 0;
    }
  } else {
    return 0;
  }
}

moonbit_string_t _M0MPC16string6String6repeat(
  moonbit_string_t _M0L4selfS535,
  int32_t _M0L1nS534
) {
  #line 1079 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
  if (_M0L1nS534 < 0) {
    #line 1081 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
    return _M0FPC15abort5abortGsE((moonbit_string_t)moonbit_string_literal_52.data);
  } else if (_M0L1nS534 == 0) {
    return (moonbit_string_t)moonbit_string_literal_1.data;
  } else if (_M0L1nS534 == 1) {
    moonbit_incref(_M0L4selfS535);
    return _M0L4selfS535;
  } else {
    int32_t _M0L3lenS536 = Moonbit_array_length(_M0L4selfS535);
    int32_t _M0L5totalS537 = _M0L3lenS536 * _M0L1nS534;
    int32_t _if__result_4564;
    if (_M0L3lenS536 == 0) {
      _if__result_4564 = 1;
    } else {
      int32_t _M0L6_2atmpS2460 = _M0L5totalS537 / _M0L1nS534;
      _if__result_4564 = _M0L6_2atmpS2460 == _M0L3lenS536;
    }
    if (_if__result_4564) {
      struct _M0TPB13StringBuilder* _M0L3bufS538;
      moonbit_string_t _M0L3strS539;
      int32_t _M0L2__S540;
      moonbit_string_t _result_4566;
      #line 1090 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
      _M0L3bufS538
      = _M0MPB13StringBuilder21StringBuilder_2einner(_M0L5totalS537);
      #line 1091 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
      _M0L3strS539 = _M0IPC16string6StringPB4Show10to__string(_M0L4selfS535);
      _M0L2__S540 = 0;
      while (1) {
        if (_M0L2__S540 < _M0L1nS534) {
          int32_t _M0L6_2atmpS2461;
          #line 1093 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
          _M0IPB13StringBuilderPB6Logger13write__string(_M0L3bufS538, _M0L3strS539);
          _M0L6_2atmpS2461 = _M0L2__S540 + 1;
          _M0L2__S540 = _M0L6_2atmpS2461;
          continue;
        } else {
          moonbit_decref(_M0L3strS539);
        }
        break;
      }
      #line 1095 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
      _result_4566 = _M0MPB13StringBuilder10to__string(_M0L3bufS538);
      moonbit_decref(_M0L3bufS538);
      return _result_4566;
    } else {
      #line 1088 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string_methods.mbt"
      return _M0FPC15abort5abortGsE((moonbit_string_t)moonbit_string_literal_53.data);
    }
  }
}

moonbit_string_t _M0IPC16string6StringPB4Show10to__string(
  moonbit_string_t _M0L4selfS533
) {
  #line 222 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  moonbit_incref(_M0L4selfS533);
  return _M0L4selfS533;
}

moonbit_v128_t _M0FPB17v128__load__i16x8(
  moonbit_string_t _M0L3strS527,
  int32_t _M0L6offsetS528
) {
  uint64_t _M0L2loS523;
  int32_t _M0L1iS524;
  uint64_t _M0L4wordS525;
  uint64_t _M0L2hiS529;
  int32_t _M0L1iS530;
  uint64_t _M0L4wordS531;
  #line 66 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\simd.mbt"
  _M0L1iS524 = 0;
  _M0L4wordS525 = 0ull;
  while (1) {
    if (_M0L1iS524 < 4) {
      int32_t _M0L6_2atmpS2453 = _M0L1iS524 + 1;
      int32_t _M0L6_2atmpS2459 = _M0L6offsetS528 + _M0L1iS524;
      int32_t _M0L6_2atmpS2458 = _M0L3strS527[_M0L6_2atmpS2459];
      uint64_t _M0L6_2atmpS2456;
      int32_t _M0L6_2atmpS2457;
      uint64_t _M0L6_2atmpS2455;
      uint64_t _M0L6_2atmpS2454;
      #line 71 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\simd.mbt"
      _M0L6_2atmpS2456 = _M0MPC16uint166UInt1610to__uint64(_M0L6_2atmpS2458);
      _M0L6_2atmpS2457 = 16 * _M0L1iS524;
      _M0L6_2atmpS2455 = _M0L6_2atmpS2456 << (_M0L6_2atmpS2457 & 63);
      _M0L6_2atmpS2454 = _M0L4wordS525 | _M0L6_2atmpS2455;
      _M0L1iS524 = _M0L6_2atmpS2453;
      _M0L4wordS525 = _M0L6_2atmpS2454;
      continue;
    } else {
      _M0L2loS523 = _M0L4wordS525;
    }
    break;
  }
  _M0L1iS530 = 0;
  _M0L4wordS531 = 0ull;
  while (1) {
    if (_M0L1iS530 < 4) {
      int32_t _M0L6_2atmpS2445 = _M0L1iS530 + 1;
      int32_t _M0L6_2atmpS2452 = _M0L6offsetS528 + 4;
      int32_t _M0L6_2atmpS2451 = _M0L6_2atmpS2452 + _M0L1iS530;
      int32_t _M0L6_2atmpS2450 = _M0L3strS527[_M0L6_2atmpS2451];
      uint64_t _M0L6_2atmpS2448;
      int32_t _M0L6_2atmpS2449;
      uint64_t _M0L6_2atmpS2447;
      uint64_t _M0L6_2atmpS2446;
      #line 76 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\simd.mbt"
      _M0L6_2atmpS2448 = _M0MPC16uint166UInt1610to__uint64(_M0L6_2atmpS2450);
      _M0L6_2atmpS2449 = 16 * _M0L1iS530;
      _M0L6_2atmpS2447 = _M0L6_2atmpS2448 << (_M0L6_2atmpS2449 & 63);
      _M0L6_2atmpS2446 = _M0L4wordS531 | _M0L6_2atmpS2447;
      _M0L1iS530 = _M0L6_2atmpS2445;
      _M0L4wordS531 = _M0L6_2atmpS2446;
      continue;
    } else {
      _M0L2hiS529 = _M0L4wordS531;
    }
    break;
  }
  return Moonbit_v128_make(_M0L2loS523, _M0L2hiS529);
}

moonbit_v128_t _M0FPB12i16x8__splat(int32_t _M0L5valueS522) {
  uint64_t _M0L6_2atmpS2444;
  uint64_t _M0L4laneS521;
  #line 46 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\simd.mbt"
  #line 49 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\simd.mbt"
  _M0L6_2atmpS2444 = _M0MPC16uint166UInt1610to__uint64(_M0L5valueS522);
  _M0L4laneS521 = _M0L6_2atmpS2444 * 281479271743489ull;
  return Moonbit_v128_make(_M0L4laneS521, _M0L4laneS521);
}

moonbit_v128_t _M0FPB9i16x8__eq(
  moonbit_v128_t _M0L1aS519,
  moonbit_v128_t _M0L1bS520
) {
  uint64_t _M0L6_2atmpS2442;
  uint64_t _M0L6_2atmpS2443;
  uint64_t _M0L6_2atmpS2438;
  uint64_t _M0L6_2atmpS2440;
  uint64_t _M0L6_2atmpS2441;
  uint64_t _M0L6_2atmpS2439;
  #line 177 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\simd.mbt"
  _M0L6_2atmpS2442 = Moonbit_v128_lo(_M0L1aS519);
  _M0L6_2atmpS2443 = Moonbit_v128_lo(_M0L1bS520);
  #line 181 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\simd.mbt"
  _M0L6_2atmpS2438
  = _M0FPB18u64__u16__eq__mask(_M0L6_2atmpS2442, _M0L6_2atmpS2443);
  _M0L6_2atmpS2440 = Moonbit_v128_hi(_M0L1aS519);
  _M0L6_2atmpS2441 = Moonbit_v128_hi(_M0L1bS520);
  #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\simd.mbt"
  _M0L6_2atmpS2439
  = _M0FPB18u64__u16__eq__mask(_M0L6_2atmpS2440, _M0L6_2atmpS2441);
  return Moonbit_v128_make(_M0L6_2atmpS2438, _M0L6_2atmpS2439);
}

uint64_t _M0FPB18u64__u16__eq__mask(uint64_t _M0L1aS516, uint64_t _M0L1bS517) {
  int32_t _M0L1iS512;
  uint64_t _M0L6resultS513;
  #line 221 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\simd.mbt"
  _M0L1iS512 = 0;
  _M0L6resultS513 = 0ull;
  while (1) {
    if (_M0L1iS512 < 4) {
      int32_t _M0L5shiftS514 = 16 * _M0L1iS512;
      uint64_t _M0L6_2atmpS2437 = _M0L1aS516 >> (_M0L5shiftS514 & 63);
      uint64_t _M0L6_2atmpS2434 = _M0L6_2atmpS2437 & 65535ull;
      uint64_t _M0L6_2atmpS2436 = _M0L1bS517 >> (_M0L5shiftS514 & 63);
      uint64_t _M0L6_2atmpS2435 = _M0L6_2atmpS2436 & 65535ull;
      uint64_t _M0L4maskS515;
      int32_t _M0L6_2atmpS2431;
      uint64_t _M0L6_2atmpS2433;
      uint64_t _M0L6_2atmpS2432;
      if (_M0L6_2atmpS2434 == _M0L6_2atmpS2435) {
        _M0L4maskS515 = 65535ull;
      } else {
        _M0L4maskS515 = 0ull;
      }
      _M0L6_2atmpS2431 = _M0L1iS512 + 1;
      _M0L6_2atmpS2433 = _M0L4maskS515 << (_M0L5shiftS514 & 63);
      _M0L6_2atmpS2432 = _M0L6resultS513 | _M0L6_2atmpS2433;
      _M0L1iS512 = _M0L6_2atmpS2431;
      _M0L6resultS513 = _M0L6_2atmpS2432;
      continue;
    } else {
      return _M0L6resultS513;
    }
    break;
  }
}

int32_t _M0IPB13StringBuilderPB6Logger11write__view(
  struct _M0TPB13StringBuilder* _M0L4selfS511,
  struct _M0TPC16string10StringView _M0L3strS509
) {
  int32_t _M0L3endS2429;
  int32_t _M0L5startS2430;
  int32_t _M0L8str__lenS508;
  int32_t _M0L3lenS2428;
  int32_t _M0L8requiredS510;
  uint16_t* _M0L4dataS2421;
  int32_t _M0L6_2atmpS2420;
  int32_t _if__result_4570;
  uint16_t* _M0L4dataS2422;
  int32_t _M0L3lenS2423;
  moonbit_string_t _M0L6_2atmpS2424;
  int32_t _M0L6_2atmpS2425;
  int32_t _M0L3lenS2427;
  int32_t _M0L6_2atmpS2426;
  #line 160 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0L3endS2429 = _M0L3strS509.$2;
  _M0L5startS2430 = _M0L3strS509.$1;
  _M0L8str__lenS508 = _M0L3endS2429 - _M0L5startS2430;
  if (_M0L8str__lenS508 == 0) {
    return 0;
  }
  _M0L3lenS2428 = _M0L4selfS511->$1;
  _M0L8requiredS510 = _M0L3lenS2428 + _M0L8str__lenS508;
  _M0L4dataS2421 = _M0L4selfS511->$0;
  _M0L6_2atmpS2420 = Moonbit_array_length(_M0L4dataS2421);
  if (_M0L8requiredS510 > _M0L6_2atmpS2420) {
    _if__result_4570 = 1;
  } else {
    int32_t _M0L3lenS2419 = _M0L4selfS511->$1;
    _if__result_4570 = _M0L8requiredS510 < _M0L3lenS2419;
  }
  if (_if__result_4570) {
    #line 170 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
    _M0MPB13StringBuilder4grow(_M0L4selfS511, _M0L8requiredS510);
  }
  _M0L4dataS2422 = _M0L4selfS511->$0;
  _M0L3lenS2423 = _M0L4selfS511->$1;
  moonbit_incref(_M0L4dataS2422);
  #line 174 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0L6_2atmpS2424 = _M0MPC16string10StringView4data(_M0L3strS509);
  #line 175 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0L6_2atmpS2425 = _M0MPC16string10StringView13start__offset(_M0L3strS509);
  #line 172 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0MPC15array10FixedArray26unsafe__blit__from__string(_M0L4dataS2422, _M0L3lenS2423, _M0L6_2atmpS2424, _M0L6_2atmpS2425, _M0L8str__lenS508);
  moonbit_decref(_M0L4dataS2422);
  moonbit_decref(_M0L6_2atmpS2424);
  _M0L3lenS2427 = _M0L4selfS511->$1;
  _M0L6_2atmpS2426 = _M0L3lenS2427 + _M0L8str__lenS508;
  _M0L4selfS511->$1 = _M0L6_2atmpS2426;
  return 0;
}

int64_t _M0MPC16string6String29offset__of__nth__char_2einner(
  moonbit_string_t _M0L4selfS505,
  int32_t _M0L1iS506,
  int32_t _M0L13start__offsetS507,
  int64_t _M0L11end__offsetS503
) {
  int32_t _M0L11end__offsetS502;
  #line 483 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string.mbt"
  if (_M0L11end__offsetS503 == 4294967296ll) {
    _M0L11end__offsetS502 = Moonbit_array_length(_M0L4selfS505);
  } else {
    int64_t _M0L7_2aSomeS504 = _M0L11end__offsetS503;
    _M0L11end__offsetS502 = (int32_t)_M0L7_2aSomeS504;
  }
  if (_M0L1iS506 >= 0) {
    #line 492 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string.mbt"
    return _M0MPC16string6String30offset__of__nth__char__forward(_M0L4selfS505, _M0L1iS506, _M0L13start__offsetS507, _M0L11end__offsetS502);
  } else {
    int32_t _M0L6_2atmpS2418 = -_M0L1iS506;
    #line 495 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string.mbt"
    return _M0MPC16string6String31offset__of__nth__char__backward(_M0L4selfS505, _M0L6_2atmpS2418, _M0L13start__offsetS507, _M0L11end__offsetS502);
  }
}

int64_t _M0MPC16string6String30offset__of__nth__char__forward(
  moonbit_string_t _M0L4selfS500,
  int32_t _M0L1nS498,
  int32_t _M0L13start__offsetS494,
  int32_t _M0L11end__offsetS495
) {
  int32_t _if__result_4571;
  #line 412 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string.mbt"
  if (_M0L13start__offsetS494 >= 0) {
    _if__result_4571 = _M0L13start__offsetS494 <= _M0L11end__offsetS495;
  } else {
    _if__result_4571 = 0;
  }
  if (_if__result_4571) {
    int32_t _M0L13utf16__offsetS496 = _M0L13start__offsetS494;
    int32_t _M0L11char__countS497 = 0;
    while (1) {
      int32_t _if__result_4573;
      if (_M0L13utf16__offsetS496 < _M0L11end__offsetS495) {
        _if__result_4573 = _M0L11char__countS497 < _M0L1nS498;
      } else {
        _if__result_4573 = 0;
      }
      if (_if__result_4573) {
        int32_t _M0L1cS499 = _M0L4selfS500[_M0L13utf16__offsetS496];
        #line 426 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string.mbt"
        if (_M0MPC16uint166UInt1622is__leading__surrogate(_M0L1cS499)) {
          int32_t _M0L6_2atmpS2414 = _M0L13utf16__offsetS496 + 2;
          int32_t _M0L6_2atmpS2415 = _M0L11char__countS497 + 1;
          _M0L13utf16__offsetS496 = _M0L6_2atmpS2414;
          _M0L11char__countS497 = _M0L6_2atmpS2415;
          continue;
        } else {
          int32_t _M0L6_2atmpS2416 = _M0L13utf16__offsetS496 + 1;
          int32_t _M0L6_2atmpS2417 = _M0L11char__countS497 + 1;
          _M0L13utf16__offsetS496 = _M0L6_2atmpS2416;
          _M0L11char__countS497 = _M0L6_2atmpS2417;
          continue;
        }
      } else {
        int32_t _if__result_4574;
        if (_M0L11char__countS497 < _M0L1nS498) {
          _if__result_4574 = 1;
        } else {
          _if__result_4574 = _M0L13utf16__offsetS496 >= _M0L11end__offsetS495;
        }
        if (_if__result_4574) {
          return 4294967296ll;
        } else {
          return (int64_t)_M0L13utf16__offsetS496;
        }
      }
      break;
    }
  } else {
    #line 419 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string.mbt"
    return _M0FPC15abort5abortGOiE((moonbit_string_t)moonbit_string_literal_54.data);
  }
}

int64_t _M0MPC16string6String31offset__of__nth__char__backward(
  moonbit_string_t _M0L4selfS491,
  int32_t _M0L1nS489,
  int32_t _M0L13start__offsetS488,
  int32_t _M0L11end__offsetS493
) {
  int32_t _M0L13utf16__offsetS486;
  int32_t _M0L11char__countS487;
  #line 448 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string.mbt"
  _M0L13utf16__offsetS486 = _M0L11end__offsetS493;
  _M0L11char__countS487 = 0;
  while (1) {
    int32_t _M0L6_2atmpS2408 = _M0L13utf16__offsetS486 - 1;
    int32_t _if__result_4576;
    if (_M0L6_2atmpS2408 >= _M0L13start__offsetS488) {
      _if__result_4576 = _M0L11char__countS487 < _M0L1nS489;
    } else {
      _if__result_4576 = 0;
    }
    if (_if__result_4576) {
      int32_t _M0L6_2atmpS2413 = _M0L13utf16__offsetS486 - 1;
      int32_t _M0L1cS490 = _M0L4selfS491[_M0L6_2atmpS2413];
      #line 461 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string.mbt"
      if (_M0MPC16uint166UInt1623is__trailing__surrogate(_M0L1cS490)) {
        int32_t _M0L6_2atmpS2409 = _M0L13utf16__offsetS486 - 2;
        int32_t _M0L6_2atmpS2410 = _M0L11char__countS487 + 1;
        _M0L13utf16__offsetS486 = _M0L6_2atmpS2409;
        _M0L11char__countS487 = _M0L6_2atmpS2410;
        continue;
      } else {
        int32_t _M0L6_2atmpS2411 = _M0L13utf16__offsetS486 - 1;
        int32_t _M0L6_2atmpS2412 = _M0L11char__countS487 + 1;
        _M0L13utf16__offsetS486 = _M0L6_2atmpS2411;
        _M0L11char__countS487 = _M0L6_2atmpS2412;
        continue;
      }
    } else {
      int32_t _if__result_4577;
      if (_M0L11char__countS487 < _M0L1nS489) {
        _if__result_4577 = 1;
      } else {
        _if__result_4577 = _M0L13utf16__offsetS486 < _M0L13start__offsetS488;
      }
      if (_if__result_4577) {
        return 4294967296ll;
      } else {
        return (int64_t)_M0L13utf16__offsetS486;
      }
    }
    break;
  }
}

int32_t _M0IPC16string10StringViewPB2Eq5equal(
  struct _M0TPC16string10StringView _M0L4selfS484,
  struct _M0TPC16string10StringView _M0L5otherS485
) {
  int32_t _M0L3endS2406;
  int32_t _M0L5startS2407;
  int32_t _M0L3lenS483;
  int32_t _M0L3endS2396;
  int32_t _M0L5startS2397;
  int32_t _M0L6_2atmpS2395;
  #line 348 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
  _M0L3endS2406 = _M0L4selfS484.$2;
  _M0L5startS2407 = _M0L4selfS484.$1;
  _M0L3lenS483 = _M0L3endS2406 - _M0L5startS2407;
  _M0L3endS2396 = _M0L5otherS485.$2;
  _M0L5startS2397 = _M0L5otherS485.$1;
  _M0L6_2atmpS2395 = _M0L3endS2396 - _M0L5startS2397;
  if (_M0L3lenS483 == _M0L6_2atmpS2395) {
    moonbit_string_t _M0L3strS2400 = _M0L4selfS484.$0;
    moonbit_string_t _M0L3strS2401 = _M0L5otherS485.$0;
    int32_t _if__result_4578;
    moonbit_string_t _M0L3strS2402;
    int32_t _M0L5startS2403;
    moonbit_string_t _M0L3strS2404;
    int32_t _M0L5startS2405;
    int32_t _result_4579;
    if (_M0L3strS2400 == _M0L3strS2401) {
      int32_t _M0L5startS2398 = _M0L4selfS484.$1;
      int32_t _M0L5startS2399 = _M0L5otherS485.$1;
      _if__result_4578 = _M0L5startS2398 == _M0L5startS2399;
    } else {
      _if__result_4578 = 0;
    }
    if (_if__result_4578) {
      return 1;
    }
    _M0L3strS2402 = _M0L4selfS484.$0;
    _M0L5startS2403 = _M0L4selfS484.$1;
    _M0L3strS2404 = _M0L5otherS485.$0;
    _M0L5startS2405 = _M0L5otherS485.$1;
    moonbit_incref(_M0L3strS2404);
    moonbit_incref(_M0L3strS2402);
    #line 354 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
    _result_4579
    = 0
      == memcmp(_M0L3strS2402 + _M0L5startS2403, _M0L3strS2404 + _M0L5startS2405, (size_t)_M0L3lenS483 * 2);
    moonbit_decref(_M0L3strS2402);
    moonbit_decref(_M0L3strS2404);
    return _result_4579;
  } else {
    return 0;
  }
}

int32_t _M0MPC16string6String20unsafe__range__equal(
  moonbit_string_t _M0L4selfS478,
  int32_t _M0L9self__offS479,
  moonbit_string_t _M0L5otherS480,
  int32_t _M0L10other__offS481,
  int32_t _M0L3lenS477
) {
  int32_t _M0L1iS476;
  #line 126 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string.mbt"
  _M0L1iS476 = 0;
  while (1) {
    if (_M0L1iS476 < _M0L3lenS477) {
      int32_t _M0L6_2atmpS2393 = _M0L9self__offS479 + _M0L1iS476;
      int32_t _M0L6_2atmpS2390 = _M0L4selfS478[_M0L6_2atmpS2393];
      int32_t _M0L6_2atmpS2392 = _M0L10other__offS481 + _M0L1iS476;
      int32_t _M0L6_2atmpS2391 = _M0L5otherS480[_M0L6_2atmpS2392];
      int32_t _M0L6_2atmpS2394;
      if (_M0L6_2atmpS2390 == _M0L6_2atmpS2391) {
        
      } else {
        return 0;
      }
      _M0L6_2atmpS2394 = _M0L1iS476 + 1;
      _M0L1iS476 = _M0L6_2atmpS2394;
      continue;
    }
    break;
  }
  return 1;
}

int32_t _M0IPC16string10StringViewPB4Show6output(
  struct _M0TPC16string10StringView _M0L4selfS475,
  struct _M0TPB6Logger _M0L6loggerS474
) {
  #line 209 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
  #line 210 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
  _M0L6loggerS474.$0->$method_2(_M0L6loggerS474.$1, _M0L4selfS475);
  return 0;
}

moonbit_string_t _M0MPC16string6String17unsafe__substring(
  moonbit_string_t _M0L3strS471,
  int32_t _M0L5startS469,
  int32_t _M0L3endS470
) {
  int32_t _if__result_4581;
  int32_t _M0L3lenS472;
  int32_t _M0L6_2atmpS2389;
  moonbit_bytes_t _M0L5bytesS473;
  moonbit_bytes_t _M0L6_2atmpS2388;
  moonbit_string_t _result_4582;
  #line 91 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string.mbt"
  if (_M0L5startS469 == 0) {
    int32_t _M0L6_2atmpS2387 = Moonbit_array_length(_M0L3strS471);
    _if__result_4581 = _M0L3endS470 == _M0L6_2atmpS2387;
  } else {
    _if__result_4581 = 0;
  }
  if (_if__result_4581) {
    moonbit_incref(_M0L3strS471);
    return _M0L3strS471;
  }
  _M0L3lenS472 = _M0L3endS470 - _M0L5startS469;
  _M0L6_2atmpS2389 = _M0L3lenS472 * 2;
  _M0L5bytesS473 = (moonbit_bytes_t)moonbit_make_bytes(_M0L6_2atmpS2389, 0);
  #line 102 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string.mbt"
  _M0MPC15array10FixedArray18blit__from__string(_M0L5bytesS473, 0, _M0L3strS471, _M0L5startS469, _M0L3lenS472);
  _M0L6_2atmpS2388 = _M0L5bytesS473;
  #line 103 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string.mbt"
  _result_4582
  = _M0MPC15bytes5Bytes29to__unchecked__string_2einner(_M0L6_2atmpS2388, 0, 4294967296ll);
  moonbit_decref(_M0L6_2atmpS2388);
  return _result_4582;
}

moonbit_string_t _M0MPC15bytes5Bytes29to__unchecked__string_2einner(
  moonbit_bytes_t _M0L4selfS464,
  int32_t _M0L6offsetS468,
  int64_t _M0L6lengthS466
) {
  int32_t _M0L3lenS463;
  int32_t _M0L6lengthS465;
  int32_t _if__result_4583;
  #line 77 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\bytes.mbt"
  _M0L3lenS463 = Moonbit_array_length(_M0L4selfS464);
  if (_M0L6lengthS466 == 4294967296ll) {
    _M0L6lengthS465 = _M0L3lenS463 - _M0L6offsetS468;
  } else {
    int64_t _M0L7_2aSomeS467 = _M0L6lengthS466;
    _M0L6lengthS465 = (int32_t)_M0L7_2aSomeS467;
  }
  if (_M0L6offsetS468 >= 0) {
    if (_M0L6lengthS465 >= 0) {
      int32_t _M0L6_2atmpS2386 = _M0L6offsetS468 + _M0L6lengthS465;
      _if__result_4583 = _M0L6_2atmpS2386 <= _M0L3lenS463;
    } else {
      _if__result_4583 = 0;
    }
  } else {
    _if__result_4583 = 0;
  }
  if (_if__result_4583) {
    moonbit_incref(_M0L4selfS464);
    #line 85 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\bytes.mbt"
    return _M0FPB19unsafe__sub__string(_M0L4selfS464, _M0L6offsetS468, _M0L6lengthS465);
  } else {
    #line 84 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\bytes.mbt"
    moonbit_panic();
  }
}

int32_t _M0MPC15array10FixedArray18blit__from__string(
  moonbit_bytes_t _M0L4selfS455,
  int32_t _M0L13bytes__offsetS450,
  moonbit_string_t _M0L3strS457,
  int32_t _M0L11str__offsetS453,
  int32_t _M0L6lengthS451
) {
  int32_t _M0L6_2atmpS2385;
  int32_t _M0L6_2atmpS2384;
  int32_t _M0L2e1S449;
  int32_t _M0L6_2atmpS2383;
  int32_t _M0L2e2S452;
  int32_t _M0L4len1S454;
  int32_t _M0L4len2S456;
  int32_t _if__result_4584;
  #line 125 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\bytes.mbt"
  _M0L6_2atmpS2385 = _M0L6lengthS451 * 2;
  _M0L6_2atmpS2384 = _M0L13bytes__offsetS450 + _M0L6_2atmpS2385;
  _M0L2e1S449 = _M0L6_2atmpS2384 - 1;
  _M0L6_2atmpS2383 = _M0L11str__offsetS453 + _M0L6lengthS451;
  _M0L2e2S452 = _M0L6_2atmpS2383 - 1;
  _M0L4len1S454 = Moonbit_array_length(_M0L4selfS455);
  _M0L4len2S456 = Moonbit_array_length(_M0L3strS457);
  if (_M0L6lengthS451 >= 0) {
    if (_M0L13bytes__offsetS450 >= 0) {
      if (_M0L2e1S449 < _M0L4len1S454) {
        if (_M0L11str__offsetS453 >= 0) {
          _if__result_4584 = _M0L2e2S452 < _M0L4len2S456;
        } else {
          _if__result_4584 = 0;
        }
      } else {
        _if__result_4584 = 0;
      }
    } else {
      _if__result_4584 = 0;
    }
  } else {
    _if__result_4584 = 0;
  }
  if (_if__result_4584) {
    int32_t _M0L16end__str__offsetS458 =
      _M0L11str__offsetS453 + _M0L6lengthS451;
    int32_t _M0L1iS459 = _M0L11str__offsetS453;
    int32_t _M0L1jS460 = _M0L13bytes__offsetS450;
    while (1) {
      if (_M0L1iS459 < _M0L16end__str__offsetS458) {
        int32_t _M0L6_2atmpS2380 = _M0L3strS457[_M0L1iS459];
        int32_t _M0L6_2atmpS2379 = (int32_t)_M0L6_2atmpS2380;
        uint32_t _M0L1cS461 = *(uint32_t*)&_M0L6_2atmpS2379;
        uint32_t _M0L6_2atmpS2375 = _M0L1cS461 & 255u;
        int32_t _M0L6_2atmpS2374;
        int32_t _M0L6_2atmpS2376;
        uint32_t _M0L6_2atmpS2378;
        int32_t _M0L6_2atmpS2377;
        int32_t _M0L6_2atmpS2381;
        int32_t _M0L6_2atmpS2382;
        #line 142 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\bytes.mbt"
        _M0L6_2atmpS2374 = _M0MPC14uint4UInt8to__byte(_M0L6_2atmpS2375);
        if (
          _M0L1jS460 < 0 || _M0L1jS460 >= Moonbit_array_length(_M0L4selfS455)
        ) {
          #line 142 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\bytes.mbt"
          moonbit_panic();
        }
        _M0L4selfS455[_M0L1jS460] = _M0L6_2atmpS2374;
        _M0L6_2atmpS2376 = _M0L1jS460 + 1;
        _M0L6_2atmpS2378 = _M0L1cS461 >> 8;
        #line 143 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\bytes.mbt"
        _M0L6_2atmpS2377 = _M0MPC14uint4UInt8to__byte(_M0L6_2atmpS2378);
        if (
          _M0L6_2atmpS2376 < 0
          || _M0L6_2atmpS2376 >= Moonbit_array_length(_M0L4selfS455)
        ) {
          #line 143 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\bytes.mbt"
          moonbit_panic();
        }
        _M0L4selfS455[_M0L6_2atmpS2376] = _M0L6_2atmpS2377;
        _M0L6_2atmpS2381 = _M0L1iS459 + 1;
        _M0L6_2atmpS2382 = _M0L1jS460 + 2;
        _M0L1iS459 = _M0L6_2atmpS2381;
        _M0L1jS460 = _M0L6_2atmpS2382;
        continue;
      }
      break;
    }
  } else {
    #line 138 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\bytes.mbt"
    moonbit_panic();
  }
  return 0;
}

int32_t _M0MPC14uint4UInt8to__byte(uint32_t _M0L4selfS448) {
  int32_t _M0L6_2atmpS2373;
  #line 2520 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\intrinsics.mbt"
  _M0L6_2atmpS2373 = *(int32_t*)&_M0L4selfS448;
  return _M0L6_2atmpS2373 & 0xff;
}

struct _M0TPB4IterGsE* _M0MPB4Iter3newGsE(
  struct _M0TWEOs* _M0L1fS447,
  int64_t _M0L10size__hintS444
) {
  int64_t _M0L10size__hintS443;
  struct _M0TPB4IterGsE* _block_4586;
  #line 241 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\iterator.mbt"
  if (_M0L10size__hintS444 == 4294967296ll) {
    _M0L10size__hintS443 = 4294967296ll;
  } else {
    int64_t _M0L7_2aSomeS445 = _M0L10size__hintS444;
    int32_t _M0L4_2anS446 = (int32_t)_M0L7_2aSomeS445;
    if (_M0L4_2anS446 > 0) {
      _M0L10size__hintS443 = (int64_t)_M0L4_2anS446;
    } else {
      _M0L10size__hintS443 = _M0MPB4Iter3newN6constrS10376GsE;
    }
  }
  _block_4586
  = (struct _M0TPB4IterGsE*)moonbit_malloc(sizeof(struct _M0TPB4IterGsE));
  Moonbit_object_header(_block_4586)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 150, 0);
  _block_4586->$0 = _M0L1fS447;
  _block_4586->$1 = _M0L10size__hintS443;
  return _block_4586;
}

struct moonbit_result_0 _M0FPB4failGuE(
  struct _M0TPC16string10StringView _M0L3msgS442,
  moonbit_string_t _M0L3locS441
) {
  struct _M0TPB13StringBuilder* _M0L18_2astring__builderS440;
  moonbit_string_t _M0L6_2atmpS2372;
  void* _M0L48moonbitlang_2fcore_2fbuiltin_2eFailure_2eFailureS2371;
  struct moonbit_result_0 _result_4587;
  #line 56 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\failure.mbt"
  #line 58 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\failure.mbt"
  _M0L18_2astring__builderS440
  = _M0MPB13StringBuilder21StringBuilder_2einner(9);
  #line 58 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\failure.mbt"
  _M0MPB13StringBuilder13write__objectGRPB9SourceLocE(_M0L18_2astring__builderS440, _M0L3locS441);
  #line 58 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\failure.mbt"
  _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS440, (moonbit_string_t)moonbit_string_literal_55.data);
  #line 58 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\failure.mbt"
  _M0MPB13StringBuilder13write__objectGRPC16string10StringViewE(_M0L18_2astring__builderS440, _M0L3msgS442);
  #line 58 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\failure.mbt"
  _M0L6_2atmpS2372
  = _M0MPB13StringBuilder10to__string(_M0L18_2astring__builderS440);
  moonbit_decref(_M0L18_2astring__builderS440);
  _M0L48moonbitlang_2fcore_2fbuiltin_2eFailure_2eFailureS2371
  = (void*)moonbit_malloc(sizeof(struct _M0DTPC15error5Error48moonbitlang_2fcore_2fbuiltin_2eFailure_2eFailure));
  Moonbit_object_header(_M0L48moonbitlang_2fcore_2fbuiltin_2eFailure_2eFailureS2371)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 156, 0);
  ((struct _M0DTPC15error5Error48moonbitlang_2fcore_2fbuiltin_2eFailure_2eFailure*)_M0L48moonbitlang_2fcore_2fbuiltin_2eFailure_2eFailureS2371)->$0
  = _M0L6_2atmpS2372;
  _result_4587.tag = 0;
  _result_4587.data.err
  = _M0L48moonbitlang_2fcore_2fbuiltin_2eFailure_2eFailureS2371;
  return _result_4587;
}

moonbit_string_t _M0MPC16uint646UInt6418to__string_2einner(
  uint64_t _M0L4selfS432,
  int32_t _M0L5radixS431
) {
  int32_t _if__result_4588;
  uint16_t* _M0L6bufferS433;
  #line 607 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
  if (_M0L5radixS431 < 2) {
    _if__result_4588 = 1;
  } else {
    _if__result_4588 = _M0L5radixS431 > 36;
  }
  if (_if__result_4588) {
    #line 611 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
    _M0FPC15abort5abortGuE((moonbit_string_t)moonbit_string_literal_56.data);
  }
  if (_M0L4selfS432 == 0ull) {
    return (moonbit_string_t)moonbit_string_literal_44.data;
  }
  switch (_M0L5radixS431) {
    case 10: {
      int32_t _M0L3lenS434;
      uint16_t* _M0L6bufferS435;
      #line 622 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
      _M0L3lenS434 = _M0FPB12dec__count64(_M0L4selfS432);
      _M0L6bufferS435 = (uint16_t*)moonbit_make_string(_M0L3lenS434, 0);
      #line 624 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
      _M0FPB22int64__to__string__dec(_M0L6bufferS435, _M0L4selfS432, 0, _M0L3lenS434);
      _M0L6bufferS433 = _M0L6bufferS435;
      break;
    }
    
    case 16: {
      int32_t _M0L3lenS436;
      uint16_t* _M0L6bufferS437;
      #line 628 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
      _M0L3lenS436 = _M0FPB12hex__count64(_M0L4selfS432);
      _M0L6bufferS437 = (uint16_t*)moonbit_make_string(_M0L3lenS436, 0);
      #line 630 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
      _M0FPB22int64__to__string__hex(_M0L6bufferS437, _M0L4selfS432, 0, _M0L3lenS436);
      _M0L6bufferS433 = _M0L6bufferS437;
      break;
    }
    default: {
      int32_t _M0L3lenS438;
      uint16_t* _M0L6bufferS439;
      #line 634 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
      _M0L3lenS438 = _M0FPB14radix__count64(_M0L4selfS432, _M0L5radixS431);
      _M0L6bufferS439 = (uint16_t*)moonbit_make_string(_M0L3lenS438, 0);
      #line 636 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
      _M0FPB26int64__to__string__generic(_M0L6bufferS439, _M0L4selfS432, 0, _M0L3lenS438, _M0L5radixS431);
      _M0L6bufferS433 = _M0L6bufferS439;
      break;
    }
  }
  return _M0L6bufferS433;
}

int32_t _M0FPB22int64__to__string__dec(
  uint16_t* _M0L6bufferS417,
  uint64_t _M0L3numS429,
  int32_t _M0L12digit__startS418,
  int32_t _M0L10total__lenS430
) {
  int32_t _M0L6_2atmpS2370;
  uint64_t _M0L3numS407;
  int32_t _M0L6offsetS408;
  #line 493 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
  _M0L6_2atmpS2370 = _M0L10total__lenS430 - _M0L12digit__startS418;
  _M0L3numS407 = _M0L3numS429;
  _M0L6offsetS408 = _M0L6_2atmpS2370;
  while (1) {
    if (_M0L3numS407 >= 10000ull) {
      uint64_t _M0L1tS409 = _M0L3numS407 / 10000ull;
      uint64_t _M0L6_2atmpS2347 = _M0L3numS407 % 10000ull;
      int32_t _M0L1rS410 = (int32_t)_M0L6_2atmpS2347;
      int32_t _M0L2d1S411 = _M0L1rS410 / 100;
      int32_t _M0L2d2S412 = _M0L1rS410 % 100;
      int32_t _M0L6_2atmpS2346 = _M0L2d1S411 / 10;
      int32_t _M0L6_2atmpS2345 = 48 + _M0L6_2atmpS2346;
      int32_t _M0L6d1__hiS413 = (uint16_t)_M0L6_2atmpS2345;
      int32_t _M0L6_2atmpS2344 = _M0L2d1S411 % 10;
      int32_t _M0L6_2atmpS2343 = 48 + _M0L6_2atmpS2344;
      int32_t _M0L6d1__loS414 = (uint16_t)_M0L6_2atmpS2343;
      int32_t _M0L6_2atmpS2342 = _M0L2d2S412 / 10;
      int32_t _M0L6_2atmpS2341 = 48 + _M0L6_2atmpS2342;
      int32_t _M0L6d2__hiS415 = (uint16_t)_M0L6_2atmpS2341;
      int32_t _M0L6_2atmpS2340 = _M0L2d2S412 % 10;
      int32_t _M0L6_2atmpS2339 = 48 + _M0L6_2atmpS2340;
      int32_t _M0L6d2__loS416 = (uint16_t)_M0L6_2atmpS2339;
      int32_t _M0L6_2atmpS2331 = _M0L12digit__startS418 + _M0L6offsetS408;
      int32_t _M0L6_2atmpS2330 = _M0L6_2atmpS2331 - 4;
      int32_t _M0L6_2atmpS2333;
      int32_t _M0L6_2atmpS2332;
      int32_t _M0L6_2atmpS2335;
      int32_t _M0L6_2atmpS2334;
      int32_t _M0L6_2atmpS2337;
      int32_t _M0L6_2atmpS2336;
      int32_t _M0L6_2atmpS2338;
      _M0L6bufferS417[_M0L6_2atmpS2330] = _M0L6d1__hiS413;
      _M0L6_2atmpS2333 = _M0L12digit__startS418 + _M0L6offsetS408;
      _M0L6_2atmpS2332 = _M0L6_2atmpS2333 - 3;
      _M0L6bufferS417[_M0L6_2atmpS2332] = _M0L6d1__loS414;
      _M0L6_2atmpS2335 = _M0L12digit__startS418 + _M0L6offsetS408;
      _M0L6_2atmpS2334 = _M0L6_2atmpS2335 - 2;
      _M0L6bufferS417[_M0L6_2atmpS2334] = _M0L6d2__hiS415;
      _M0L6_2atmpS2337 = _M0L12digit__startS418 + _M0L6offsetS408;
      _M0L6_2atmpS2336 = _M0L6_2atmpS2337 - 1;
      _M0L6bufferS417[_M0L6_2atmpS2336] = _M0L6d2__loS416;
      _M0L6_2atmpS2338 = _M0L6offsetS408 - 4;
      _M0L3numS407 = _M0L1tS409;
      _M0L6offsetS408 = _M0L6_2atmpS2338;
      continue;
    } else {
      int32_t _M0L6_2atmpS2369 = (int32_t)_M0L3numS407;
      int32_t _M0L9remainingS420 = _M0L6_2atmpS2369;
      int32_t _M0L6offsetS421 = _M0L6offsetS408;
      while (1) {
        if (_M0L9remainingS420 >= 100) {
          int32_t _M0L1tS422 = _M0L9remainingS420 / 100;
          int32_t _M0L1dS423 = _M0L9remainingS420 % 100;
          int32_t _M0L6_2atmpS2356 = _M0L1dS423 / 10;
          int32_t _M0L6_2atmpS2355 = 48 + _M0L6_2atmpS2356;
          int32_t _M0L5d__hiS424 = (uint16_t)_M0L6_2atmpS2355;
          int32_t _M0L6_2atmpS2354 = _M0L1dS423 % 10;
          int32_t _M0L6_2atmpS2353 = 48 + _M0L6_2atmpS2354;
          int32_t _M0L5d__loS425 = (uint16_t)_M0L6_2atmpS2353;
          int32_t _M0L6_2atmpS2349 = _M0L12digit__startS418 + _M0L6offsetS421;
          int32_t _M0L6_2atmpS2348 = _M0L6_2atmpS2349 - 2;
          int32_t _M0L6_2atmpS2351;
          int32_t _M0L6_2atmpS2350;
          int32_t _M0L6_2atmpS2352;
          _M0L6bufferS417[_M0L6_2atmpS2348] = _M0L5d__hiS424;
          _M0L6_2atmpS2351 = _M0L12digit__startS418 + _M0L6offsetS421;
          _M0L6_2atmpS2350 = _M0L6_2atmpS2351 - 1;
          _M0L6bufferS417[_M0L6_2atmpS2350] = _M0L5d__loS425;
          _M0L6_2atmpS2352 = _M0L6offsetS421 - 2;
          _M0L9remainingS420 = _M0L1tS422;
          _M0L6offsetS421 = _M0L6_2atmpS2352;
          continue;
        } else if (_M0L9remainingS420 >= 10) {
          int32_t _M0L6_2atmpS2364 = _M0L9remainingS420 / 10;
          int32_t _M0L6_2atmpS2363 = 48 + _M0L6_2atmpS2364;
          int32_t _M0L5d__hiS427 = (uint16_t)_M0L6_2atmpS2363;
          int32_t _M0L6_2atmpS2362 = _M0L9remainingS420 % 10;
          int32_t _M0L6_2atmpS2361 = 48 + _M0L6_2atmpS2362;
          int32_t _M0L5d__loS428 = (uint16_t)_M0L6_2atmpS2361;
          int32_t _M0L6_2atmpS2358 = _M0L12digit__startS418 + _M0L6offsetS421;
          int32_t _M0L6_2atmpS2357 = _M0L6_2atmpS2358 - 2;
          int32_t _M0L6_2atmpS2360;
          int32_t _M0L6_2atmpS2359;
          _M0L6bufferS417[_M0L6_2atmpS2357] = _M0L5d__hiS427;
          _M0L6_2atmpS2360 = _M0L12digit__startS418 + _M0L6offsetS421;
          _M0L6_2atmpS2359 = _M0L6_2atmpS2360 - 1;
          _M0L6bufferS417[_M0L6_2atmpS2359] = _M0L5d__loS428;
        } else {
          int32_t _M0L6_2atmpS2368 = _M0L12digit__startS418 + _M0L6offsetS421;
          int32_t _M0L6_2atmpS2365 = _M0L6_2atmpS2368 - 1;
          int32_t _M0L6_2atmpS2367 = 48 + _M0L9remainingS420;
          int32_t _M0L6_2atmpS2366 = (uint16_t)_M0L6_2atmpS2367;
          _M0L6bufferS417[_M0L6_2atmpS2365] = _M0L6_2atmpS2366;
        }
        break;
      }
    }
    break;
  }
  return 0;
}

int32_t _M0FPB26int64__to__string__generic(
  uint16_t* _M0L6bufferS397,
  uint64_t _M0L3numS401,
  int32_t _M0L12digit__startS398,
  int32_t _M0L10total__lenS400,
  int32_t _M0L5radixS391
) {
  uint64_t _M0L4baseS390;
  int32_t _M0L6_2atmpS2315;
  int32_t _M0L6_2atmpS2314;
  #line 462 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
  #line 470 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
  _M0L4baseS390 = _M0MPC13int3Int10to__uint64(_M0L5radixS391);
  _M0L6_2atmpS2315 = _M0L5radixS391 - 1;
  _M0L6_2atmpS2314 = _M0L5radixS391 & _M0L6_2atmpS2315;
  if (_M0L6_2atmpS2314 == 0) {
    int32_t _M0L5shiftS392;
    uint64_t _M0L4maskS393;
    int32_t _M0L6_2atmpS2322;
    int32_t _M0L6offsetS394;
    uint64_t _M0L1nS395;
    #line 473 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
    _M0L5shiftS392 = moonbit_ctz32(_M0L5radixS391);
    _M0L4maskS393 = _M0L4baseS390 - 1ull;
    _M0L6_2atmpS2322 = _M0L10total__lenS400 - _M0L12digit__startS398;
    _M0L6offsetS394 = _M0L6_2atmpS2322;
    _M0L1nS395 = _M0L3numS401;
    while (1) {
      if (_M0L1nS395 > 0ull) {
        uint64_t _M0L6_2atmpS2321 = _M0L1nS395 & _M0L4maskS393;
        int32_t _M0L5digitS396 = (int32_t)_M0L6_2atmpS2321;
        int32_t _M0L6_2atmpS2318 = _M0L12digit__startS398 + _M0L6offsetS394;
        int32_t _M0L6_2atmpS2316 = _M0L6_2atmpS2318 - 1;
        int32_t _M0L6_2atmpS2317 =
          ((moonbit_string_t)moonbit_string_literal_57.data)[_M0L5digitS396];
        int32_t _M0L6_2atmpS2319;
        uint64_t _M0L6_2atmpS2320;
        _M0L6bufferS397[_M0L6_2atmpS2316] = _M0L6_2atmpS2317;
        _M0L6_2atmpS2319 = _M0L6offsetS394 - 1;
        _M0L6_2atmpS2320 = _M0L1nS395 >> (_M0L5shiftS392 & 63);
        _M0L6offsetS394 = _M0L6_2atmpS2319;
        _M0L1nS395 = _M0L6_2atmpS2320;
        continue;
      }
      break;
    }
  } else {
    int32_t _M0L6_2atmpS2329 = _M0L10total__lenS400 - _M0L12digit__startS398;
    int32_t _M0L6offsetS402 = _M0L6_2atmpS2329;
    uint64_t _M0L1nS403 = _M0L3numS401;
    while (1) {
      if (_M0L1nS403 > 0ull) {
        uint64_t _M0L1qS404 = _M0L1nS403 / _M0L4baseS390;
        uint64_t _M0L6_2atmpS2328 = _M0L1qS404 * _M0L4baseS390;
        uint64_t _M0L6_2atmpS2327 = _M0L1nS403 - _M0L6_2atmpS2328;
        int32_t _M0L5digitS405 = (int32_t)_M0L6_2atmpS2327;
        int32_t _M0L6_2atmpS2325 = _M0L12digit__startS398 + _M0L6offsetS402;
        int32_t _M0L6_2atmpS2323 = _M0L6_2atmpS2325 - 1;
        int32_t _M0L6_2atmpS2324 =
          ((moonbit_string_t)moonbit_string_literal_57.data)[_M0L5digitS405];
        int32_t _M0L6_2atmpS2326;
        _M0L6bufferS397[_M0L6_2atmpS2323] = _M0L6_2atmpS2324;
        _M0L6_2atmpS2326 = _M0L6offsetS402 - 1;
        _M0L6offsetS402 = _M0L6_2atmpS2326;
        _M0L1nS403 = _M0L1qS404;
        continue;
      }
      break;
    }
  }
  return 0;
}

int32_t _M0FPB22int64__to__string__hex(
  uint16_t* _M0L6bufferS384,
  uint64_t _M0L3numS389,
  int32_t _M0L12digit__startS385,
  int32_t _M0L10total__lenS388
) {
  int32_t _M0L6_2atmpS2313;
  int32_t _M0L6offsetS379;
  uint64_t _M0L1nS380;
  #line 434 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
  _M0L6_2atmpS2313 = _M0L10total__lenS388 - _M0L12digit__startS385;
  _M0L6offsetS379 = _M0L6_2atmpS2313;
  _M0L1nS380 = _M0L3numS389;
  while (1) {
    if (_M0L6offsetS379 >= 2) {
      uint64_t _M0L6_2atmpS2310 = _M0L1nS380 & 255ull;
      int32_t _M0L9byte__valS381 = (int32_t)_M0L6_2atmpS2310;
      int32_t _M0L2hiS382 = _M0L9byte__valS381 / 16;
      int32_t _M0L2loS383 = _M0L9byte__valS381 % 16;
      int32_t _M0L6_2atmpS2304 = _M0L12digit__startS385 + _M0L6offsetS379;
      int32_t _M0L6_2atmpS2302 = _M0L6_2atmpS2304 - 2;
      int32_t _M0L6_2atmpS2303 =
        ((moonbit_string_t)moonbit_string_literal_57.data)[_M0L2hiS382];
      int32_t _M0L6_2atmpS2307;
      int32_t _M0L6_2atmpS2305;
      int32_t _M0L6_2atmpS2306;
      int32_t _M0L6_2atmpS2308;
      uint64_t _M0L6_2atmpS2309;
      _M0L6bufferS384[_M0L6_2atmpS2302] = _M0L6_2atmpS2303;
      _M0L6_2atmpS2307 = _M0L12digit__startS385 + _M0L6offsetS379;
      _M0L6_2atmpS2305 = _M0L6_2atmpS2307 - 1;
      _M0L6_2atmpS2306
      = ((moonbit_string_t)moonbit_string_literal_57.data)[
        _M0L2loS383
      ];
      _M0L6bufferS384[_M0L6_2atmpS2305] = _M0L6_2atmpS2306;
      _M0L6_2atmpS2308 = _M0L6offsetS379 - 2;
      _M0L6_2atmpS2309 = _M0L1nS380 >> 8;
      _M0L6offsetS379 = _M0L6_2atmpS2308;
      _M0L1nS380 = _M0L6_2atmpS2309;
      continue;
    } else if (_M0L6offsetS379 == 1) {
      uint64_t _M0L6_2atmpS2312 = _M0L1nS380 & 15ull;
      int32_t _M0L6nibbleS387 = (int32_t)_M0L6_2atmpS2312;
      int32_t _M0L6_2atmpS2311 =
        ((moonbit_string_t)moonbit_string_literal_57.data)[_M0L6nibbleS387];
      _M0L6bufferS384[_M0L12digit__startS385] = _M0L6_2atmpS2311;
    }
    break;
  }
  return 0;
}

int32_t _M0FPB14radix__count64(
  uint64_t _M0L5valueS373,
  int32_t _M0L5radixS375
) {
  uint64_t _M0L4baseS374;
  uint64_t _M0L3numS376;
  int32_t _M0L5countS377;
  #line 419 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
  if (_M0L5valueS373 == 0ull) {
    return 1;
  }
  #line 424 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
  _M0L4baseS374 = _M0MPC13int3Int10to__uint64(_M0L5radixS375);
  _M0L3numS376 = _M0L5valueS373;
  _M0L5countS377 = 0;
  while (1) {
    if (_M0L3numS376 > 0ull) {
      uint64_t _M0L6_2atmpS2300 = _M0L3numS376 / _M0L4baseS374;
      int32_t _M0L6_2atmpS2301 = _M0L5countS377 + 1;
      _M0L3numS376 = _M0L6_2atmpS2300;
      _M0L5countS377 = _M0L6_2atmpS2301;
      continue;
    } else {
      return _M0L5countS377;
    }
    break;
  }
}

int32_t _M0FPB12hex__count64(uint64_t _M0L5valueS371) {
  #line 407 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
  if (_M0L5valueS371 == 0ull) {
    return 1;
  } else {
    int32_t _M0L14leading__zerosS372;
    int32_t _M0L6_2atmpS2299;
    int32_t _M0L6_2atmpS2298;
    #line 412 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
    _M0L14leading__zerosS372 = moonbit_clz64(_M0L5valueS371);
    _M0L6_2atmpS2299 = 63 - _M0L14leading__zerosS372;
    _M0L6_2atmpS2298 = _M0L6_2atmpS2299 / 4;
    return _M0L6_2atmpS2298 + 1;
  }
}

int32_t _M0FPB12dec__count64(uint64_t _M0L5valueS370) {
  #line 343 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
  if (_M0L5valueS370 >= 10000000000ull) {
    if (_M0L5valueS370 >= 100000000000000ull) {
      if (_M0L5valueS370 >= 10000000000000000ull) {
        if (_M0L5valueS370 >= 1000000000000000000ull) {
          if (_M0L5valueS370 >= 10000000000000000000ull) {
            return 20;
          } else {
            return 19;
          }
        } else if (_M0L5valueS370 >= 100000000000000000ull) {
          return 18;
        } else {
          return 17;
        }
      } else if (_M0L5valueS370 >= 1000000000000000ull) {
        return 16;
      } else {
        return 15;
      }
    } else if (_M0L5valueS370 >= 1000000000000ull) {
      if (_M0L5valueS370 >= 10000000000000ull) {
        return 14;
      } else {
        return 13;
      }
    } else if (_M0L5valueS370 >= 100000000000ull) {
      return 12;
    } else {
      return 11;
    }
  } else if (_M0L5valueS370 >= 100000ull) {
    if (_M0L5valueS370 >= 10000000ull) {
      if (_M0L5valueS370 >= 1000000000ull) {
        return 10;
      } else if (_M0L5valueS370 >= 100000000ull) {
        return 9;
      } else {
        return 8;
      }
    } else if (_M0L5valueS370 >= 1000000ull) {
      return 7;
    } else {
      return 6;
    }
  } else if (_M0L5valueS370 >= 1000ull) {
    if (_M0L5valueS370 >= 10000ull) {
      return 5;
    } else {
      return 4;
    }
  } else if (_M0L5valueS370 >= 100ull) {
    return 3;
  } else if (_M0L5valueS370 >= 10ull) {
    return 2;
  } else {
    return 1;
  }
}

moonbit_string_t _M0MPC13int3Int18to__string_2einner(
  int32_t _M0L4selfS354,
  int32_t _M0L5radixS353
) {
  int32_t _if__result_4595;
  int32_t _M0L12is__negativeS355;
  uint32_t _M0L3numS356;
  uint16_t* _M0L6bufferS357;
  #line 209 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
  if (_M0L5radixS353 < 2) {
    _if__result_4595 = 1;
  } else {
    _if__result_4595 = _M0L5radixS353 > 36;
  }
  if (_if__result_4595) {
    #line 213 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
    _M0FPC15abort5abortGuE((moonbit_string_t)moonbit_string_literal_56.data);
  }
  if (_M0L4selfS354 == 0) {
    return (moonbit_string_t)moonbit_string_literal_44.data;
  }
  _M0L12is__negativeS355 = _M0L4selfS354 < 0;
  if (_M0L12is__negativeS355) {
    int32_t _M0L6_2atmpS2297 = -_M0L4selfS354;
    _M0L3numS356 = *(uint32_t*)&_M0L6_2atmpS2297;
  } else {
    _M0L3numS356 = *(uint32_t*)&_M0L4selfS354;
  }
  switch (_M0L5radixS353) {
    case 10: {
      int32_t _M0L10digit__lenS358;
      int32_t _M0L6_2atmpS2294;
      int32_t _M0L10total__lenS359;
      uint16_t* _M0L6bufferS360;
      int32_t _M0L12digit__startS361;
      #line 235 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
      _M0L10digit__lenS358 = _M0FPB12dec__count32(_M0L3numS356);
      if (_M0L12is__negativeS355) {
        _M0L6_2atmpS2294 = 1;
      } else {
        _M0L6_2atmpS2294 = 0;
      }
      _M0L10total__lenS359 = _M0L10digit__lenS358 + _M0L6_2atmpS2294;
      _M0L6bufferS360
      = (uint16_t*)moonbit_make_string(_M0L10total__lenS359, 0);
      if (_M0L12is__negativeS355) {
        _M0L12digit__startS361 = 1;
      } else {
        _M0L12digit__startS361 = 0;
      }
      #line 239 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
      _M0FPB20int__to__string__dec(_M0L6bufferS360, _M0L3numS356, _M0L12digit__startS361, _M0L10total__lenS359);
      _M0L6bufferS357 = _M0L6bufferS360;
      break;
    }
    
    case 16: {
      int32_t _M0L10digit__lenS362;
      int32_t _M0L6_2atmpS2295;
      int32_t _M0L10total__lenS363;
      uint16_t* _M0L6bufferS364;
      int32_t _M0L12digit__startS365;
      #line 243 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
      _M0L10digit__lenS362 = _M0FPB12hex__count32(_M0L3numS356);
      if (_M0L12is__negativeS355) {
        _M0L6_2atmpS2295 = 1;
      } else {
        _M0L6_2atmpS2295 = 0;
      }
      _M0L10total__lenS363 = _M0L10digit__lenS362 + _M0L6_2atmpS2295;
      _M0L6bufferS364
      = (uint16_t*)moonbit_make_string(_M0L10total__lenS363, 0);
      if (_M0L12is__negativeS355) {
        _M0L12digit__startS365 = 1;
      } else {
        _M0L12digit__startS365 = 0;
      }
      #line 247 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
      _M0FPB20int__to__string__hex(_M0L6bufferS364, _M0L3numS356, _M0L12digit__startS365, _M0L10total__lenS363);
      _M0L6bufferS357 = _M0L6bufferS364;
      break;
    }
    default: {
      int32_t _M0L10digit__lenS366;
      int32_t _M0L6_2atmpS2296;
      int32_t _M0L10total__lenS367;
      uint16_t* _M0L6bufferS368;
      int32_t _M0L12digit__startS369;
      #line 251 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
      _M0L10digit__lenS366
      = _M0FPB14radix__count32(_M0L3numS356, _M0L5radixS353);
      if (_M0L12is__negativeS355) {
        _M0L6_2atmpS2296 = 1;
      } else {
        _M0L6_2atmpS2296 = 0;
      }
      _M0L10total__lenS367 = _M0L10digit__lenS366 + _M0L6_2atmpS2296;
      _M0L6bufferS368
      = (uint16_t*)moonbit_make_string(_M0L10total__lenS367, 0);
      if (_M0L12is__negativeS355) {
        _M0L12digit__startS369 = 1;
      } else {
        _M0L12digit__startS369 = 0;
      }
      #line 255 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
      _M0FPB24int__to__string__generic(_M0L6bufferS368, _M0L3numS356, _M0L12digit__startS369, _M0L10total__lenS367, _M0L5radixS353);
      _M0L6bufferS357 = _M0L6bufferS368;
      break;
    }
  }
  if (_M0L12is__negativeS355) {
    _M0L6bufferS357[0] = 45;
  }
  return _M0L6bufferS357;
}

int32_t _M0FPB14radix__count32(
  uint32_t _M0L5valueS347,
  int32_t _M0L5radixS349
) {
  uint32_t _M0L4baseS348;
  uint32_t _M0L3numS350;
  int32_t _M0L5countS351;
  #line 189 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
  if (_M0L5valueS347 == 0u) {
    return 1;
  }
  _M0L4baseS348 = *(uint32_t*)&_M0L5radixS349;
  _M0L3numS350 = _M0L5valueS347;
  _M0L5countS351 = 0;
  while (1) {
    if (_M0L3numS350 > 0u) {
      uint32_t _M0L6_2atmpS2292 = _M0L3numS350 / _M0L4baseS348;
      int32_t _M0L6_2atmpS2293 = _M0L5countS351 + 1;
      _M0L3numS350 = _M0L6_2atmpS2292;
      _M0L5countS351 = _M0L6_2atmpS2293;
      continue;
    } else {
      return _M0L5countS351;
    }
    break;
  }
}

int32_t _M0FPB12hex__count32(uint32_t _M0L5valueS345) {
  #line 177 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
  if (_M0L5valueS345 == 0u) {
    return 1;
  } else {
    int32_t _M0L14leading__zerosS346;
    int32_t _M0L6_2atmpS2291;
    int32_t _M0L6_2atmpS2290;
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
    _M0L14leading__zerosS346 = moonbit_clz32(_M0L5valueS345);
    _M0L6_2atmpS2291 = 31 - _M0L14leading__zerosS346;
    _M0L6_2atmpS2290 = _M0L6_2atmpS2291 / 4;
    return _M0L6_2atmpS2290 + 1;
  }
}

int32_t _M0FPB12dec__count32(uint32_t _M0L5valueS344) {
  #line 143 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
  if (_M0L5valueS344 >= 100000u) {
    if (_M0L5valueS344 >= 10000000u) {
      if (_M0L5valueS344 >= 1000000000u) {
        return 10;
      } else if (_M0L5valueS344 >= 100000000u) {
        return 9;
      } else {
        return 8;
      }
    } else if (_M0L5valueS344 >= 1000000u) {
      return 7;
    } else {
      return 6;
    }
  } else if (_M0L5valueS344 >= 1000u) {
    if (_M0L5valueS344 >= 10000u) {
      return 5;
    } else {
      return 4;
    }
  } else if (_M0L5valueS344 >= 100u) {
    return 3;
  } else if (_M0L5valueS344 >= 10u) {
    return 2;
  } else {
    return 1;
  }
}

int32_t _M0FPB20int__to__string__dec(
  uint16_t* _M0L6bufferS330,
  uint32_t _M0L3numS342,
  int32_t _M0L12digit__startS331,
  int32_t _M0L10total__lenS343
) {
  int32_t _M0L6_2atmpS2289;
  uint32_t _M0L3numS320;
  int32_t _M0L6offsetS321;
  #line 88 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
  _M0L6_2atmpS2289 = _M0L10total__lenS343 - _M0L12digit__startS331;
  _M0L3numS320 = _M0L3numS342;
  _M0L6offsetS321 = _M0L6_2atmpS2289;
  while (1) {
    if (_M0L3numS320 >= 10000u) {
      uint32_t _M0L1tS322 = _M0L3numS320 / 10000u;
      uint32_t _M0L6_2atmpS2266 = _M0L3numS320 % 10000u;
      int32_t _M0L1rS323 = *(int32_t*)&_M0L6_2atmpS2266;
      int32_t _M0L2d1S324 = _M0L1rS323 / 100;
      int32_t _M0L2d2S325 = _M0L1rS323 % 100;
      int32_t _M0L6_2atmpS2265 = _M0L2d1S324 / 10;
      int32_t _M0L6_2atmpS2264 = 48 + _M0L6_2atmpS2265;
      int32_t _M0L6d1__hiS326 = (uint16_t)_M0L6_2atmpS2264;
      int32_t _M0L6_2atmpS2263 = _M0L2d1S324 % 10;
      int32_t _M0L6_2atmpS2262 = 48 + _M0L6_2atmpS2263;
      int32_t _M0L6d1__loS327 = (uint16_t)_M0L6_2atmpS2262;
      int32_t _M0L6_2atmpS2261 = _M0L2d2S325 / 10;
      int32_t _M0L6_2atmpS2260 = 48 + _M0L6_2atmpS2261;
      int32_t _M0L6d2__hiS328 = (uint16_t)_M0L6_2atmpS2260;
      int32_t _M0L6_2atmpS2259 = _M0L2d2S325 % 10;
      int32_t _M0L6_2atmpS2258 = 48 + _M0L6_2atmpS2259;
      int32_t _M0L6d2__loS329 = (uint16_t)_M0L6_2atmpS2258;
      int32_t _M0L6_2atmpS2250 = _M0L12digit__startS331 + _M0L6offsetS321;
      int32_t _M0L6_2atmpS2249 = _M0L6_2atmpS2250 - 4;
      int32_t _M0L6_2atmpS2252;
      int32_t _M0L6_2atmpS2251;
      int32_t _M0L6_2atmpS2254;
      int32_t _M0L6_2atmpS2253;
      int32_t _M0L6_2atmpS2256;
      int32_t _M0L6_2atmpS2255;
      int32_t _M0L6_2atmpS2257;
      _M0L6bufferS330[_M0L6_2atmpS2249] = _M0L6d1__hiS326;
      _M0L6_2atmpS2252 = _M0L12digit__startS331 + _M0L6offsetS321;
      _M0L6_2atmpS2251 = _M0L6_2atmpS2252 - 3;
      _M0L6bufferS330[_M0L6_2atmpS2251] = _M0L6d1__loS327;
      _M0L6_2atmpS2254 = _M0L12digit__startS331 + _M0L6offsetS321;
      _M0L6_2atmpS2253 = _M0L6_2atmpS2254 - 2;
      _M0L6bufferS330[_M0L6_2atmpS2253] = _M0L6d2__hiS328;
      _M0L6_2atmpS2256 = _M0L12digit__startS331 + _M0L6offsetS321;
      _M0L6_2atmpS2255 = _M0L6_2atmpS2256 - 1;
      _M0L6bufferS330[_M0L6_2atmpS2255] = _M0L6d2__loS329;
      _M0L6_2atmpS2257 = _M0L6offsetS321 - 4;
      _M0L3numS320 = _M0L1tS322;
      _M0L6offsetS321 = _M0L6_2atmpS2257;
      continue;
    } else {
      int32_t _M0L6_2atmpS2288 = *(int32_t*)&_M0L3numS320;
      int32_t _M0L9remainingS333 = _M0L6_2atmpS2288;
      int32_t _M0L6offsetS334 = _M0L6offsetS321;
      while (1) {
        if (_M0L9remainingS333 >= 100) {
          int32_t _M0L1tS335 = _M0L9remainingS333 / 100;
          int32_t _M0L1dS336 = _M0L9remainingS333 % 100;
          int32_t _M0L6_2atmpS2275 = _M0L1dS336 / 10;
          int32_t _M0L6_2atmpS2274 = 48 + _M0L6_2atmpS2275;
          int32_t _M0L5d__hiS337 = (uint16_t)_M0L6_2atmpS2274;
          int32_t _M0L6_2atmpS2273 = _M0L1dS336 % 10;
          int32_t _M0L6_2atmpS2272 = 48 + _M0L6_2atmpS2273;
          int32_t _M0L5d__loS338 = (uint16_t)_M0L6_2atmpS2272;
          int32_t _M0L6_2atmpS2268 = _M0L12digit__startS331 + _M0L6offsetS334;
          int32_t _M0L6_2atmpS2267 = _M0L6_2atmpS2268 - 2;
          int32_t _M0L6_2atmpS2270;
          int32_t _M0L6_2atmpS2269;
          int32_t _M0L6_2atmpS2271;
          _M0L6bufferS330[_M0L6_2atmpS2267] = _M0L5d__hiS337;
          _M0L6_2atmpS2270 = _M0L12digit__startS331 + _M0L6offsetS334;
          _M0L6_2atmpS2269 = _M0L6_2atmpS2270 - 1;
          _M0L6bufferS330[_M0L6_2atmpS2269] = _M0L5d__loS338;
          _M0L6_2atmpS2271 = _M0L6offsetS334 - 2;
          _M0L9remainingS333 = _M0L1tS335;
          _M0L6offsetS334 = _M0L6_2atmpS2271;
          continue;
        } else if (_M0L9remainingS333 >= 10) {
          int32_t _M0L6_2atmpS2283 = _M0L9remainingS333 / 10;
          int32_t _M0L6_2atmpS2282 = 48 + _M0L6_2atmpS2283;
          int32_t _M0L5d__hiS340 = (uint16_t)_M0L6_2atmpS2282;
          int32_t _M0L6_2atmpS2281 = _M0L9remainingS333 % 10;
          int32_t _M0L6_2atmpS2280 = 48 + _M0L6_2atmpS2281;
          int32_t _M0L5d__loS341 = (uint16_t)_M0L6_2atmpS2280;
          int32_t _M0L6_2atmpS2277 = _M0L12digit__startS331 + _M0L6offsetS334;
          int32_t _M0L6_2atmpS2276 = _M0L6_2atmpS2277 - 2;
          int32_t _M0L6_2atmpS2279;
          int32_t _M0L6_2atmpS2278;
          _M0L6bufferS330[_M0L6_2atmpS2276] = _M0L5d__hiS340;
          _M0L6_2atmpS2279 = _M0L12digit__startS331 + _M0L6offsetS334;
          _M0L6_2atmpS2278 = _M0L6_2atmpS2279 - 1;
          _M0L6bufferS330[_M0L6_2atmpS2278] = _M0L5d__loS341;
        } else {
          int32_t _M0L6_2atmpS2287 = _M0L12digit__startS331 + _M0L6offsetS334;
          int32_t _M0L6_2atmpS2284 = _M0L6_2atmpS2287 - 1;
          int32_t _M0L6_2atmpS2286 = 48 + _M0L9remainingS333;
          int32_t _M0L6_2atmpS2285 = (uint16_t)_M0L6_2atmpS2286;
          _M0L6bufferS330[_M0L6_2atmpS2284] = _M0L6_2atmpS2285;
        }
        break;
      }
    }
    break;
  }
  return 0;
}

int32_t _M0FPB24int__to__string__generic(
  uint16_t* _M0L6bufferS310,
  uint32_t _M0L3numS314,
  int32_t _M0L12digit__startS311,
  int32_t _M0L10total__lenS313,
  int32_t _M0L5radixS304
) {
  uint32_t _M0L4baseS303;
  int32_t _M0L6_2atmpS2234;
  int32_t _M0L6_2atmpS2233;
  #line 57 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
  _M0L4baseS303 = *(uint32_t*)&_M0L5radixS304;
  _M0L6_2atmpS2234 = _M0L5radixS304 - 1;
  _M0L6_2atmpS2233 = _M0L5radixS304 & _M0L6_2atmpS2234;
  if (_M0L6_2atmpS2233 == 0) {
    int32_t _M0L5shiftS305;
    uint32_t _M0L4maskS306;
    int32_t _M0L6_2atmpS2241;
    int32_t _M0L6offsetS307;
    uint32_t _M0L1nS308;
    #line 68 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
    _M0L5shiftS305 = moonbit_ctz32(_M0L5radixS304);
    _M0L4maskS306 = _M0L4baseS303 - 1u;
    _M0L6_2atmpS2241 = _M0L10total__lenS313 - _M0L12digit__startS311;
    _M0L6offsetS307 = _M0L6_2atmpS2241;
    _M0L1nS308 = _M0L3numS314;
    while (1) {
      if (_M0L1nS308 > 0u) {
        uint32_t _M0L6_2atmpS2240 = _M0L1nS308 & _M0L4maskS306;
        int32_t _M0L5digitS309 = *(int32_t*)&_M0L6_2atmpS2240;
        int32_t _M0L6_2atmpS2237 = _M0L12digit__startS311 + _M0L6offsetS307;
        int32_t _M0L6_2atmpS2235 = _M0L6_2atmpS2237 - 1;
        int32_t _M0L6_2atmpS2236 =
          ((moonbit_string_t)moonbit_string_literal_57.data)[_M0L5digitS309];
        int32_t _M0L6_2atmpS2238;
        uint32_t _M0L6_2atmpS2239;
        _M0L6bufferS310[_M0L6_2atmpS2235] = _M0L6_2atmpS2236;
        _M0L6_2atmpS2238 = _M0L6offsetS307 - 1;
        _M0L6_2atmpS2239 = _M0L1nS308 >> (_M0L5shiftS305 & 31);
        _M0L6offsetS307 = _M0L6_2atmpS2238;
        _M0L1nS308 = _M0L6_2atmpS2239;
        continue;
      }
      break;
    }
  } else {
    int32_t _M0L6_2atmpS2248 = _M0L10total__lenS313 - _M0L12digit__startS311;
    int32_t _M0L6offsetS315 = _M0L6_2atmpS2248;
    uint32_t _M0L1nS316 = _M0L3numS314;
    while (1) {
      if (_M0L1nS316 > 0u) {
        uint32_t _M0L1qS317 = _M0L1nS316 / _M0L4baseS303;
        uint32_t _M0L6_2atmpS2247 = _M0L1qS317 * _M0L4baseS303;
        uint32_t _M0L6_2atmpS2246 = _M0L1nS316 - _M0L6_2atmpS2247;
        int32_t _M0L5digitS318 = *(int32_t*)&_M0L6_2atmpS2246;
        int32_t _M0L6_2atmpS2244 = _M0L12digit__startS311 + _M0L6offsetS315;
        int32_t _M0L6_2atmpS2242 = _M0L6_2atmpS2244 - 1;
        int32_t _M0L6_2atmpS2243 =
          ((moonbit_string_t)moonbit_string_literal_57.data)[_M0L5digitS318];
        int32_t _M0L6_2atmpS2245;
        _M0L6bufferS310[_M0L6_2atmpS2242] = _M0L6_2atmpS2243;
        _M0L6_2atmpS2245 = _M0L6offsetS315 - 1;
        _M0L6offsetS315 = _M0L6_2atmpS2245;
        _M0L1nS316 = _M0L1qS317;
        continue;
      }
      break;
    }
  }
  return 0;
}

int32_t _M0FPB20int__to__string__hex(
  uint16_t* _M0L6bufferS297,
  uint32_t _M0L3numS302,
  int32_t _M0L12digit__startS298,
  int32_t _M0L10total__lenS301
) {
  int32_t _M0L6_2atmpS2232;
  int32_t _M0L6offsetS292;
  uint32_t _M0L1nS293;
  #line 29 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
  _M0L6_2atmpS2232 = _M0L10total__lenS301 - _M0L12digit__startS298;
  _M0L6offsetS292 = _M0L6_2atmpS2232;
  _M0L1nS293 = _M0L3numS302;
  while (1) {
    if (_M0L6offsetS292 >= 2) {
      uint32_t _M0L6_2atmpS2229 = _M0L1nS293 & 255u;
      int32_t _M0L9byte__valS294 = *(int32_t*)&_M0L6_2atmpS2229;
      int32_t _M0L2hiS295 = _M0L9byte__valS294 / 16;
      int32_t _M0L2loS296 = _M0L9byte__valS294 % 16;
      int32_t _M0L6_2atmpS2223 = _M0L12digit__startS298 + _M0L6offsetS292;
      int32_t _M0L6_2atmpS2221 = _M0L6_2atmpS2223 - 2;
      int32_t _M0L6_2atmpS2222 =
        ((moonbit_string_t)moonbit_string_literal_57.data)[_M0L2hiS295];
      int32_t _M0L6_2atmpS2226;
      int32_t _M0L6_2atmpS2224;
      int32_t _M0L6_2atmpS2225;
      int32_t _M0L6_2atmpS2227;
      uint32_t _M0L6_2atmpS2228;
      _M0L6bufferS297[_M0L6_2atmpS2221] = _M0L6_2atmpS2222;
      _M0L6_2atmpS2226 = _M0L12digit__startS298 + _M0L6offsetS292;
      _M0L6_2atmpS2224 = _M0L6_2atmpS2226 - 1;
      _M0L6_2atmpS2225
      = ((moonbit_string_t)moonbit_string_literal_57.data)[
        _M0L2loS296
      ];
      _M0L6bufferS297[_M0L6_2atmpS2224] = _M0L6_2atmpS2225;
      _M0L6_2atmpS2227 = _M0L6offsetS292 - 2;
      _M0L6_2atmpS2228 = _M0L1nS293 >> 8;
      _M0L6offsetS292 = _M0L6_2atmpS2227;
      _M0L1nS293 = _M0L6_2atmpS2228;
      continue;
    } else if (_M0L6offsetS292 == 1) {
      uint32_t _M0L6_2atmpS2231 = _M0L1nS293 & 15u;
      int32_t _M0L6nibbleS300 = *(int32_t*)&_M0L6_2atmpS2231;
      int32_t _M0L6_2atmpS2230 =
        ((moonbit_string_t)moonbit_string_literal_57.data)[_M0L6nibbleS300];
      _M0L6bufferS297[_M0L12digit__startS298] = _M0L6_2atmpS2230;
    }
    break;
  }
  return 0;
}

moonbit_string_t _M0MPB4Iter4nextGsE(struct _M0TPB4IterGsE* _M0L4selfS287) {
  struct _M0TWEOs* _M0L7_2afuncS286;
  moonbit_string_t _M0L6resultS288;
  int64_t _M0L7_2abindS289;
  #line 38 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\iterator.mbt"
  _M0L7_2afuncS286 = _M0L4selfS287->$0;
  moonbit_incref(_M0L7_2afuncS286);
  #line 41 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\iterator.mbt"
  _M0L6resultS288 = _M0L7_2afuncS286->code(_M0L7_2afuncS286);
  moonbit_decref(_M0L7_2afuncS286);
  _M0L7_2abindS289 = _M0L4selfS287->$1;
  if (_M0L6resultS288 == 0) {
    _M0L4selfS287->$1 = _M0MPB4Iter4nextN6constrS10369GsE;
  } else if (_M0L7_2abindS289 == 4294967296ll) {
    
  } else {
    int64_t _M0L7_2aSomeS290 = _M0L7_2abindS289;
    int32_t _M0L4_2anS291 = (int32_t)_M0L7_2aSomeS290;
    int64_t _M0L6_2atmpS2219;
    if (_M0L4_2anS291 > 0) {
      int32_t _M0L6_2atmpS2220 = _M0L4_2anS291 - 1;
      _M0L6_2atmpS2219 = (int64_t)_M0L6_2atmpS2220;
    } else {
      _M0L6_2atmpS2219 = _M0MPB4Iter4nextN6constrS10368GsE;
    }
    _M0L4selfS287->$1 = _M0L6_2atmpS2219;
  }
  return _M0L6resultS288;
}

moonbit_string_t _M0IP016_24default__implPB4Show10to__stringGRPB7FailureE(
  void* _M0L4selfS285
) {
  struct _M0TPB13StringBuilder* _M0L6loggerS284;
  struct _M0TPB6Logger _M0L6_2atmpS2218;
  moonbit_string_t _result_4602;
  #line 165 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  #line 166 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0L6loggerS284 = _M0MPB13StringBuilder21StringBuilder_2einner(0);
  moonbit_incref(_M0L6loggerS284);
  _M0L6_2atmpS2218
  = (struct _M0TPB6Logger){
    _M0FP0119moonbitlang_2fcore_2fbuiltin_2fStringBuilder_2eas___40moonbitlang_2fcore_2fbuiltin_2eLogger_2estatic__method__table__id,
      _M0L6loggerS284
  };
  #line 167 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0IPB7FailurePB4Show6output(_M0L4selfS285, _M0L6_2atmpS2218);
  if (_M0L6_2atmpS2218.$1) {
    moonbit_decref(_M0L6_2atmpS2218.$1);
  }
  #line 168 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _result_4602 = _M0MPB13StringBuilder10to__string(_M0L6loggerS284);
  moonbit_decref(_M0L6loggerS284);
  return _result_4602;
}

int32_t _M0IP016_24default__implPB4Show6outputGsE(
  moonbit_string_t _M0L4selfS279,
  struct _M0TPB6Logger _M0L6loggerS278
) {
  moonbit_string_t _M0L6_2atmpS2215;
  #line 159 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  #line 160 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0L6_2atmpS2215 = _M0IPC16string6StringPB4Show10to__string(_M0L4selfS279);
  #line 160 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0L6loggerS278.$0->$method_0(_M0L6loggerS278.$1, _M0L6_2atmpS2215);
  moonbit_decref(_M0L6_2atmpS2215);
  return 0;
}

int32_t _M0IP016_24default__implPB4Show6outputGiE(
  int32_t _M0L4selfS281,
  struct _M0TPB6Logger _M0L6loggerS280
) {
  moonbit_string_t _M0L6_2atmpS2216;
  #line 159 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  #line 160 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0L6_2atmpS2216 = _M0IPC13int3IntPB4Show10to__string(_M0L4selfS281);
  #line 160 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0L6loggerS280.$0->$method_0(_M0L6loggerS280.$1, _M0L6_2atmpS2216);
  moonbit_decref(_M0L6_2atmpS2216);
  return 0;
}

int32_t _M0IP016_24default__implPB4Show6outputGmE(
  uint64_t _M0L4selfS283,
  struct _M0TPB6Logger _M0L6loggerS282
) {
  moonbit_string_t _M0L6_2atmpS2217;
  #line 159 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  #line 160 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0L6_2atmpS2217 = _M0IPC16uint646UInt64PB4Show10to__string(_M0L4selfS283);
  #line 160 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0L6loggerS282.$0->$method_0(_M0L6loggerS282.$1, _M0L6_2atmpS2217);
  moonbit_decref(_M0L6_2atmpS2217);
  return 0;
}

int32_t _M0MPC16string10StringView13start__offset(
  struct _M0TPC16string10StringView _M0L4selfS277
) {
  #line 99 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
  return _M0L4selfS277.$1;
}

moonbit_string_t _M0MPC16string10StringView4data(
  struct _M0TPC16string10StringView _M0L4selfS276
) {
  moonbit_string_t _M0L8_2afieldS4186;
  #line 92 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
  _M0L8_2afieldS4186 = _M0L4selfS276.$0;
  moonbit_incref(_M0L8_2afieldS4186);
  return _M0L8_2afieldS4186;
}

int32_t _M0IP016_24default__implPB6Logger16write__substringGRPB13StringBuilderE(
  struct _M0TPB13StringBuilder* _M0L4selfS272,
  moonbit_string_t _M0L5valueS273,
  int32_t _M0L5startS274,
  int32_t _M0L3lenS275
) {
  int32_t _M0L6_2atmpS2214;
  int64_t _M0L6_2atmpS2213;
  struct _M0TPC16string10StringView _M0L6_2atmpS2212;
  #line 122 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0L6_2atmpS2214 = _M0L5startS274 + _M0L3lenS275;
  _M0L6_2atmpS2213 = (int64_t)_M0L6_2atmpS2214;
  #line 123 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0L6_2atmpS2212
  = _M0MPC16string6String11sub_2einner(_M0L5valueS273, _M0L5startS274, _M0L6_2atmpS2213);
  #line 123 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0IPB13StringBuilderPB6Logger11write__view(_M0L4selfS272, _M0L6_2atmpS2212);
  moonbit_decref(_M0L6_2atmpS2212.$0);
  return 0;
}

struct _M0TPC16string10StringView _M0MPC16string6String11sub_2einner(
  moonbit_string_t _M0L4selfS264,
  int32_t _M0L5startS271,
  int64_t _M0L3endS268
) {
  int32_t _M0L3lenS263;
  int32_t _M0L3endS267;
  int32_t _M0L3endS265;
  int32_t _if__result_4604;
  #line 923 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
  _M0L3lenS263 = Moonbit_array_length(_M0L4selfS264);
  if (_M0L3endS268 == 4294967296ll) {
    _M0L3endS267 = _M0L3lenS263;
    goto join_266;
  } else {
    int64_t _M0L7_2aSomeS269 = _M0L3endS268;
    int32_t _M0L6_2aendS270 = (int32_t)_M0L7_2aSomeS269;
    _M0L3endS267 = _M0L6_2aendS270;
    goto join_266;
  }
  goto joinlet_4603;
  join_266:;
  _M0L3endS265 = _M0L3endS267;
  joinlet_4603:;
  if (_M0L5startS271 >= 0) {
    if (_M0L5startS271 <= _M0L3endS265) {
      _if__result_4604 = _M0L3endS265 <= _M0L3lenS263;
    } else {
      _if__result_4604 = 0;
    }
  } else {
    _if__result_4604 = 0;
  }
  if (_if__result_4604) {
    if (_M0L5startS271 < _M0L3lenS263) {
      int32_t _M0L6_2atmpS2209 = _M0L4selfS264[_M0L5startS271];
      int32_t _M0L6_2atmpS2208;
      #line 931 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
      _M0L6_2atmpS2208
      = _M0MPC16uint166UInt1623is__trailing__surrogate(_M0L6_2atmpS2209);
      if (!_M0L6_2atmpS2208) {
        
      } else {
        #line 931 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
        moonbit_panic();
      }
    }
    if (_M0L3endS265 < _M0L3lenS263) {
      int32_t _M0L6_2atmpS2211 = _M0L4selfS264[_M0L3endS265];
      int32_t _M0L6_2atmpS2210;
      #line 934 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
      _M0L6_2atmpS2210
      = _M0MPC16uint166UInt1623is__trailing__surrogate(_M0L6_2atmpS2211);
      if (!_M0L6_2atmpS2210) {
        
      } else {
        #line 934 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
        moonbit_panic();
      }
    }
    moonbit_incref(_M0L4selfS264);
    return (struct _M0TPC16string10StringView){.$0 = _M0L4selfS264,
                                                 .$1 = _M0L5startS271,
                                                 .$2 = _M0L3endS265};
  } else {
    #line 929 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
    moonbit_panic();
  }
}

int32_t _M0IP016_24default__implPB6Logger5writeGRPB13StringBuilderE(
  struct _M0TPB13StringBuilder* _M0L4selfS262,
  struct _M0TPB4Show _M0L4showS261
) {
  struct _M0TPB6Logger _M0L6_2atmpS2207;
  #line 116 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  moonbit_incref(_M0L4selfS262);
  _M0L6_2atmpS2207
  = (struct _M0TPB6Logger){
    _M0FP0119moonbitlang_2fcore_2fbuiltin_2fStringBuilder_2eas___40moonbitlang_2fcore_2fbuiltin_2eLogger_2estatic__method__table__id,
      _M0L4selfS262
  };
  #line 117 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0L4showS261.$0->$method_0(_M0L4showS261.$1, _M0L6_2atmpS2207);
  if (_M0L6_2atmpS2207.$1) {
    moonbit_decref(_M0L6_2atmpS2207.$1);
  }
  return 0;
}

int32_t _M0IP016_24default__implPB6Logger28write__string__interpolationGRPB13StringBuilderE(
  struct _M0TPB13StringBuilder* _M0L4selfS260,
  struct _M0TPB4Show _M0L4showS259
) {
  struct _M0TPB6Logger _M0L6_2atmpS2206;
  #line 111 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  moonbit_incref(_M0L4selfS260);
  _M0L6_2atmpS2206
  = (struct _M0TPB6Logger){
    _M0FP0119moonbitlang_2fcore_2fbuiltin_2fStringBuilder_2eas___40moonbitlang_2fcore_2fbuiltin_2eLogger_2estatic__method__table__id,
      _M0L4selfS260
  };
  #line 112 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0L4showS259.$0->$method_0(_M0L4showS259.$1, _M0L6_2atmpS2206);
  if (_M0L6_2atmpS2206.$1) {
    moonbit_decref(_M0L6_2atmpS2206.$1);
  }
  return 0;
}

int32_t _M0FPB13finalize__acc(uint32_t _M0L3accS258) {
  uint32_t _M0L6_2atmpS2205;
  #line 451 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\hasher.mbt"
  #line 452 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\hasher.mbt"
  _M0L6_2atmpS2205 = _M0FPB14avalanche__acc(_M0L3accS258);
  return *(int32_t*)&_M0L6_2atmpS2205;
}

uint32_t _M0FPB14avalanche__acc(uint32_t _M0L3accS257) {
  uint32_t _M0Lm3accS256;
  uint32_t _M0L6_2atmpS2194;
  uint32_t _M0L6_2atmpS2196;
  uint32_t _M0L6_2atmpS2195;
  uint32_t _M0L6_2atmpS2197;
  uint32_t _M0L6_2atmpS2198;
  uint32_t _M0L6_2atmpS2200;
  uint32_t _M0L6_2atmpS2199;
  uint32_t _M0L6_2atmpS2201;
  uint32_t _M0L6_2atmpS2202;
  uint32_t _M0L6_2atmpS2204;
  uint32_t _M0L6_2atmpS2203;
  #line 456 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\hasher.mbt"
  _M0Lm3accS256 = _M0L3accS257;
  _M0L6_2atmpS2194 = _M0Lm3accS256;
  _M0L6_2atmpS2196 = _M0Lm3accS256;
  _M0L6_2atmpS2195 = _M0L6_2atmpS2196 >> 15;
  _M0Lm3accS256 = _M0L6_2atmpS2194 ^ _M0L6_2atmpS2195;
  _M0L6_2atmpS2197 = _M0Lm3accS256;
  _M0Lm3accS256 = _M0L6_2atmpS2197 * 2246822519u;
  _M0L6_2atmpS2198 = _M0Lm3accS256;
  _M0L6_2atmpS2200 = _M0Lm3accS256;
  _M0L6_2atmpS2199 = _M0L6_2atmpS2200 >> 13;
  _M0Lm3accS256 = _M0L6_2atmpS2198 ^ _M0L6_2atmpS2199;
  _M0L6_2atmpS2201 = _M0Lm3accS256;
  _M0Lm3accS256 = _M0L6_2atmpS2201 * 3266489917u;
  _M0L6_2atmpS2202 = _M0Lm3accS256;
  _M0L6_2atmpS2204 = _M0Lm3accS256;
  _M0L6_2atmpS2203 = _M0L6_2atmpS2204 >> 16;
  _M0Lm3accS256 = _M0L6_2atmpS2202 ^ _M0L6_2atmpS2203;
  return _M0Lm3accS256;
}

int32_t _M0IP016_24default__implPB2Eq10not__equalGRPC16string10StringViewE(
  struct _M0TPC16string10StringView _M0L1xS252,
  struct _M0TPC16string10StringView _M0L1yS253
) {
  int32_t _M0L6_2atmpS2192;
  #line 23 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  #line 24 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0L6_2atmpS2192
  = _M0IPC16string10StringViewPB2Eq5equal(_M0L1xS252, _M0L1yS253);
  return !_M0L6_2atmpS2192;
}

int32_t _M0IP016_24default__implPB2Eq10not__equalGsE(
  moonbit_string_t _M0L1xS254,
  moonbit_string_t _M0L1yS255
) {
  int32_t _M0L6_2atmpS2193;
  #line 23 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  #line 24 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0L6_2atmpS2193
  = _M0L1xS254 == _M0L1yS255
    || Moonbit_array_length(_M0L1xS254) == Moonbit_array_length(_M0L1yS255)
       && 0
          == memcmp(_M0L1xS254, _M0L1yS255, Moonbit_array_length(_M0L1xS254) * 2);
  return !_M0L6_2atmpS2193;
}

uint64_t _M0MPC16uint166UInt1610to__uint64(int32_t _M0L4selfS251) {
  int32_t _M0L6_2atmpS2191;
  #line 218 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uint16_char.mbt"
  _M0L6_2atmpS2191 = (int32_t)_M0L4selfS251;
  #line 219 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uint16_char.mbt"
  return _M0MPC13int3Int10to__uint64(_M0L6_2atmpS2191);
}

uint64_t _M0MPC13int3Int10to__uint64(int32_t _M0L4selfS250) {
  int64_t _M0L6_2atmpS2190;
  #line 908 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\intrinsics.mbt"
  _M0L6_2atmpS2190 = (int64_t)_M0L4selfS250;
  return *(uint64_t*)&_M0L6_2atmpS2190;
}

int32_t _M0IPC16uint166UInt16PB7Default7default() {
  #line 201 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uint16_char.mbt"
  return 0;
}

int32_t _M0IPB13StringBuilderPB6Logger13write__string(
  struct _M0TPB13StringBuilder* _M0L4selfS249,
  moonbit_string_t _M0L3strS247
) {
  int32_t _M0L8str__lenS246;
  int32_t _M0L3lenS2189;
  int32_t _M0L8requiredS248;
  uint16_t* _M0L4dataS2184;
  int32_t _M0L6_2atmpS2183;
  int32_t _if__result_4605;
  uint16_t* _M0L4dataS2185;
  int32_t _M0L3lenS2186;
  int32_t _M0L3lenS2188;
  int32_t _M0L6_2atmpS2187;
  #line 105 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0L8str__lenS246 = Moonbit_array_length(_M0L3strS247);
  if (_M0L8str__lenS246 == 0) {
    return 0;
  }
  _M0L3lenS2189 = _M0L4selfS249->$1;
  _M0L8requiredS248 = _M0L3lenS2189 + _M0L8str__lenS246;
  _M0L4dataS2184 = _M0L4selfS249->$0;
  _M0L6_2atmpS2183 = Moonbit_array_length(_M0L4dataS2184);
  if (_M0L8requiredS248 > _M0L6_2atmpS2183) {
    _if__result_4605 = 1;
  } else {
    int32_t _M0L3lenS2182 = _M0L4selfS249->$1;
    _if__result_4605 = _M0L8requiredS248 < _M0L3lenS2182;
  }
  if (_if__result_4605) {
    #line 112 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
    _M0MPB13StringBuilder4grow(_M0L4selfS249, _M0L8requiredS248);
  }
  _M0L4dataS2185 = _M0L4selfS249->$0;
  _M0L3lenS2186 = _M0L4selfS249->$1;
  moonbit_incref(_M0L4dataS2185);
  #line 114 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0MPC15array10FixedArray26unsafe__blit__from__string(_M0L4dataS2185, _M0L3lenS2186, _M0L3strS247, 0, _M0L8str__lenS246);
  moonbit_decref(_M0L4dataS2185);
  _M0L3lenS2188 = _M0L4selfS249->$1;
  _M0L6_2atmpS2187 = _M0L3lenS2188 + _M0L8str__lenS246;
  _M0L4selfS249->$1 = _M0L6_2atmpS2187;
  return 0;
}

int32_t _M0MPC15array10FixedArray26unsafe__blit__from__string(
  uint16_t* _M0L4selfS242,
  int32_t _M0L11dst__offsetS245,
  moonbit_string_t _M0L3strS243,
  int32_t _M0L11str__offsetS238,
  int32_t _M0L3lenS239
) {
  int32_t _M0L16end__str__offsetS237;
  int32_t _M0L1iS240;
  int32_t _M0L1jS241;
  #line 90 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0L16end__str__offsetS237 = _M0L11str__offsetS238 + _M0L3lenS239;
  _M0L1iS240 = _M0L11str__offsetS238;
  _M0L1jS241 = _M0L11dst__offsetS245;
  while (1) {
    if (_M0L1iS240 < _M0L16end__str__offsetS237) {
      int32_t _M0L6_2atmpS2179 = _M0L3strS243[_M0L1iS240];
      int32_t _M0L6_2atmpS2180;
      int32_t _M0L6_2atmpS2181;
      _M0L4selfS242[_M0L1jS241] = _M0L6_2atmpS2179;
      _M0L6_2atmpS2180 = _M0L1iS240 + 1;
      _M0L6_2atmpS2181 = _M0L1jS241 + 1;
      _M0L1iS240 = _M0L6_2atmpS2180;
      _M0L1jS241 = _M0L6_2atmpS2181;
      continue;
    }
    break;
  }
  return 0;
}

struct _M0TPC16string10StringView _M0MPC16string10StringView12view_2einner(
  struct _M0TPC16string10StringView _M0L4selfS235,
  int32_t _M0L13start__offsetS236,
  int64_t _M0L11end__offsetS233
) {
  int32_t _M0L11end__offsetS232;
  int32_t _if__result_4607;
  #line 105 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
  if (_M0L11end__offsetS233 == 4294967296ll) {
    int32_t _M0L3endS2177 = _M0L4selfS235.$2;
    int32_t _M0L5startS2178 = _M0L4selfS235.$1;
    _M0L11end__offsetS232 = _M0L3endS2177 - _M0L5startS2178;
  } else {
    int64_t _M0L7_2aSomeS234 = _M0L11end__offsetS233;
    _M0L11end__offsetS232 = (int32_t)_M0L7_2aSomeS234;
  }
  if (_M0L13start__offsetS236 >= 0) {
    if (_M0L13start__offsetS236 <= _M0L11end__offsetS232) {
      int32_t _M0L3endS2170 = _M0L4selfS235.$2;
      int32_t _M0L5startS2171 = _M0L4selfS235.$1;
      int32_t _M0L6_2atmpS2169 = _M0L3endS2170 - _M0L5startS2171;
      _if__result_4607 = _M0L11end__offsetS232 <= _M0L6_2atmpS2169;
    } else {
      _if__result_4607 = 0;
    }
  } else {
    _if__result_4607 = 0;
  }
  if (_if__result_4607) {
    moonbit_string_t _M0L3strS2172 = _M0L4selfS235.$0;
    int32_t _M0L5startS2176 = _M0L4selfS235.$1;
    int32_t _M0L6_2atmpS2173 = _M0L5startS2176 + _M0L13start__offsetS236;
    int32_t _M0L5startS2175 = _M0L4selfS235.$1;
    int32_t _M0L6_2atmpS2174 = _M0L5startS2175 + _M0L11end__offsetS232;
    moonbit_incref(_M0L3strS2172);
    return (struct _M0TPC16string10StringView){.$0 = _M0L3strS2172,
                                                 .$1 = _M0L6_2atmpS2173,
                                                 .$2 = _M0L6_2atmpS2174};
  } else {
    #line 114 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
    return _M0FPC15abort5abortGRPC16string10StringViewE((moonbit_string_t)moonbit_string_literal_58.data);
  }
}

moonbit_string_t _M0MPC16string6String14escape_2einner(
  moonbit_string_t _M0L4selfS230,
  int32_t _M0L5quoteS231
) {
  struct _M0TPB13StringBuilder* _M0L3bufS229;
  int32_t _M0L6_2atmpS2168;
  struct _M0TPC16string10StringView _M0L6_2atmpS2166;
  struct _M0TPB6Logger _M0L6_2atmpS2167;
  moonbit_string_t _result_4608;
  #line 110 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  #line 111 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _M0L3bufS229 = _M0MPB13StringBuilder21StringBuilder_2einner(0);
  _M0L6_2atmpS2168 = Moonbit_array_length(_M0L4selfS230);
  moonbit_incref(_M0L4selfS230);
  _M0L6_2atmpS2166
  = (struct _M0TPC16string10StringView){
    .$0 = _M0L4selfS230, .$1 = 0, .$2 = _M0L6_2atmpS2168
  };
  moonbit_incref(_M0L3bufS229);
  _M0L6_2atmpS2167
  = (struct _M0TPB6Logger){
    _M0FP0119moonbitlang_2fcore_2fbuiltin_2fStringBuilder_2eas___40moonbitlang_2fcore_2fbuiltin_2eLogger_2estatic__method__table__id,
      _M0L3bufS229
  };
  #line 112 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _M0MPC16string10StringView18escape__to_2einner(_M0L6_2atmpS2166, _M0L6_2atmpS2167, _M0L5quoteS231);
  moonbit_decref(_M0L6_2atmpS2166.$0);
  if (_M0L6_2atmpS2167.$1) {
    moonbit_decref(_M0L6_2atmpS2167.$1);
  }
  #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _result_4608 = _M0MPB13StringBuilder10to__string(_M0L3bufS229);
  moonbit_decref(_M0L3bufS229);
  return _result_4608;
}

int32_t _M0MPC16string10StringView18escape__to_2einner(
  struct _M0TPC16string10StringView _M0L4selfS221,
  struct _M0TPB6Logger _M0L6loggerS219,
  int32_t _M0L5quoteS218
) {
  int32_t _M0L3endS2164;
  int32_t _M0L5startS2165;
  int32_t _M0L3lenS220;
  struct _M0TURPB6LoggerRPC16string10StringViewE* _M0L6_2aenvS222;
  int32_t _M0L1iS223;
  int32_t _M0L3segS224;
  #line 144 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  if (_M0L5quoteS218) {
    #line 150 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    _M0L6loggerS219.$0->$method_3(_M0L6loggerS219.$1, 34);
  }
  _M0L3endS2164 = _M0L4selfS221.$2;
  _M0L5startS2165 = _M0L4selfS221.$1;
  _M0L3lenS220 = _M0L3endS2164 - _M0L5startS2165;
  if (_M0L6loggerS219.$1) {
    moonbit_incref(_M0L6loggerS219.$1);
  }
  moonbit_incref(_M0L4selfS221.$0);
  _M0L6_2aenvS222
  = (struct _M0TURPB6LoggerRPC16string10StringViewE*)moonbit_malloc(sizeof(struct _M0TURPB6LoggerRPC16string10StringViewE));
  Moonbit_object_header(_M0L6_2aenvS222)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 163, 0);
  _M0L6_2aenvS222->$0 = _M0L6loggerS219;
  _M0L6_2aenvS222->$1 = _M0L4selfS221;
  _M0L1iS223 = 0;
  _M0L3segS224 = 0;
  _2afor_225:;
  while (1) {
    moonbit_string_t _M0L3strS2161;
    int32_t _M0L5startS2163;
    int32_t _M0L6_2atmpS2162;
    int32_t _M0L4codeS226;
    int32_t _M0L1cS228;
    int32_t _M0L6_2atmpS2145;
    int32_t _M0L6_2atmpS2146;
    int32_t _M0L6_2atmpS2147;
    if (_M0L1iS223 >= _M0L3lenS220) {
      #line 160 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
      _M0MPC16string10StringView18escape__to_2einnerN14flush__segmentS4266(_M0L6_2aenvS222, _M0L3segS224, _M0L1iS223);
      moonbit_decref(_M0L6_2aenvS222);
      break;
    }
    _M0L3strS2161 = _M0L4selfS221.$0;
    _M0L5startS2163 = _M0L4selfS221.$1;
    _M0L6_2atmpS2162 = _M0L5startS2163 + _M0L1iS223;
    _M0L4codeS226 = _M0L3strS2161[_M0L6_2atmpS2162];
    switch (_M0L4codeS226) {
      case 34: {
        _M0L1cS228 = _M0L4codeS226;
        goto join_227;
        break;
      }
      
      case 92: {
        _M0L1cS228 = _M0L4codeS226;
        goto join_227;
        break;
      }
      
      case 10: {
        int32_t _M0L6_2atmpS2148;
        int32_t _M0L6_2atmpS2149;
        #line 172 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
        _M0MPC16string10StringView18escape__to_2einnerN14flush__segmentS4266(_M0L6_2aenvS222, _M0L3segS224, _M0L1iS223);
        #line 173 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
        _M0L6loggerS219.$0->$method_0(_M0L6loggerS219.$1, (moonbit_string_t)moonbit_string_literal_39.data);
        _M0L6_2atmpS2148 = _M0L1iS223 + 1;
        _M0L6_2atmpS2149 = _M0L1iS223 + 1;
        _M0L1iS223 = _M0L6_2atmpS2148;
        _M0L3segS224 = _M0L6_2atmpS2149;
        goto _2afor_225;
        break;
      }
      
      case 13: {
        int32_t _M0L6_2atmpS2150;
        int32_t _M0L6_2atmpS2151;
        #line 177 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
        _M0MPC16string10StringView18escape__to_2einnerN14flush__segmentS4266(_M0L6_2aenvS222, _M0L3segS224, _M0L1iS223);
        #line 178 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
        _M0L6loggerS219.$0->$method_0(_M0L6loggerS219.$1, (moonbit_string_t)moonbit_string_literal_40.data);
        _M0L6_2atmpS2150 = _M0L1iS223 + 1;
        _M0L6_2atmpS2151 = _M0L1iS223 + 1;
        _M0L1iS223 = _M0L6_2atmpS2150;
        _M0L3segS224 = _M0L6_2atmpS2151;
        goto _2afor_225;
        break;
      }
      
      case 8: {
        int32_t _M0L6_2atmpS2152;
        int32_t _M0L6_2atmpS2153;
        #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
        _M0MPC16string10StringView18escape__to_2einnerN14flush__segmentS4266(_M0L6_2aenvS222, _M0L3segS224, _M0L1iS223);
        #line 183 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
        _M0L6loggerS219.$0->$method_0(_M0L6loggerS219.$1, (moonbit_string_t)moonbit_string_literal_41.data);
        _M0L6_2atmpS2152 = _M0L1iS223 + 1;
        _M0L6_2atmpS2153 = _M0L1iS223 + 1;
        _M0L1iS223 = _M0L6_2atmpS2152;
        _M0L3segS224 = _M0L6_2atmpS2153;
        goto _2afor_225;
        break;
      }
      
      case 9: {
        int32_t _M0L6_2atmpS2154;
        int32_t _M0L6_2atmpS2155;
        #line 187 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
        _M0MPC16string10StringView18escape__to_2einnerN14flush__segmentS4266(_M0L6_2aenvS222, _M0L3segS224, _M0L1iS223);
        #line 188 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
        _M0L6loggerS219.$0->$method_0(_M0L6loggerS219.$1, (moonbit_string_t)moonbit_string_literal_42.data);
        _M0L6_2atmpS2154 = _M0L1iS223 + 1;
        _M0L6_2atmpS2155 = _M0L1iS223 + 1;
        _M0L1iS223 = _M0L6_2atmpS2154;
        _M0L3segS224 = _M0L6_2atmpS2155;
        goto _2afor_225;
        break;
      }
      default: {
        if (_M0L4codeS226 < 32) {
          int32_t _M0L6_2atmpS2157;
          moonbit_string_t _M0L6_2atmpS2156;
          int32_t _M0L6_2atmpS2158;
          int32_t _M0L6_2atmpS2159;
          #line 193 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
          _M0MPC16string10StringView18escape__to_2einnerN14flush__segmentS4266(_M0L6_2aenvS222, _M0L3segS224, _M0L1iS223);
          #line 194 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
          _M0L6loggerS219.$0->$method_0(_M0L6loggerS219.$1, (moonbit_string_t)moonbit_string_literal_43.data);
          _M0L6_2atmpS2157 = _M0L4codeS226 & 0xff;
          #line 195 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
          _M0L6_2atmpS2156 = _M0MPC14byte4Byte7to__hex(_M0L6_2atmpS2157);
          #line 195 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
          _M0L6loggerS219.$0->$method_0(_M0L6loggerS219.$1, _M0L6_2atmpS2156);
          moonbit_decref(_M0L6_2atmpS2156);
          #line 196 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
          _M0L6loggerS219.$0->$method_3(_M0L6loggerS219.$1, 125);
          _M0L6_2atmpS2158 = _M0L1iS223 + 1;
          _M0L6_2atmpS2159 = _M0L1iS223 + 1;
          _M0L1iS223 = _M0L6_2atmpS2158;
          _M0L3segS224 = _M0L6_2atmpS2159;
          goto _2afor_225;
        } else {
          int32_t _M0L6_2atmpS2160 = _M0L1iS223 + 1;
          int32_t _tmp_4611 = _M0L3segS224;
          _M0L1iS223 = _M0L6_2atmpS2160;
          _M0L3segS224 = _tmp_4611;
          goto _2afor_225;
        }
        break;
      }
    }
    goto joinlet_4610;
    join_227:;
    #line 166 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    _M0MPC16string10StringView18escape__to_2einnerN14flush__segmentS4266(_M0L6_2aenvS222, _M0L3segS224, _M0L1iS223);
    #line 167 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    _M0L6loggerS219.$0->$method_3(_M0L6loggerS219.$1, 92);
    #line 168 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    _M0L6_2atmpS2145 = _M0MPC16uint166UInt1616unsafe__to__char(_M0L1cS228);
    #line 168 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    _M0L6loggerS219.$0->$method_3(_M0L6loggerS219.$1, _M0L6_2atmpS2145);
    _M0L6_2atmpS2146 = _M0L1iS223 + 1;
    _M0L6_2atmpS2147 = _M0L1iS223 + 1;
    _M0L1iS223 = _M0L6_2atmpS2146;
    _M0L3segS224 = _M0L6_2atmpS2147;
    continue;
    joinlet_4610:;
    break;
  }
  if (_M0L5quoteS218) {
    #line 204 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    _M0L6loggerS219.$0->$method_3(_M0L6loggerS219.$1, 34);
  }
  return 0;
}

int32_t _M0MPC16string10StringView18escape__to_2einnerN14flush__segmentS4266(
  struct _M0TURPB6LoggerRPC16string10StringViewE* _M0L6_2aenvS214,
  int32_t _M0L3segS217,
  int32_t _M0L1iS216
) {
  struct _M0TPC16string10StringView _M0L4selfS213;
  struct _M0TPB6Logger _M0L6loggerS215;
  #line 153 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _M0L4selfS213 = _M0L6_2aenvS214->$1;
  _M0L6loggerS215 = _M0L6_2aenvS214->$0;
  if (_M0L1iS216 > _M0L3segS217) {
    int64_t _M0L6_2atmpS2144 = (int64_t)_M0L1iS216;
    struct _M0TPC16string10StringView _M0L6_2atmpS2143;
    #line 155 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    _M0L6_2atmpS2143
    = _M0MPC16string10StringView11sub_2einner(_M0L4selfS213, _M0L3segS217, _M0L6_2atmpS2144);
    #line 155 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    _M0L6loggerS215.$0->$method_2(_M0L6loggerS215.$1, _M0L6_2atmpS2143);
    moonbit_decref(_M0L6_2atmpS2143.$0);
  }
  return 0;
}

struct _M0TPC16string10StringView _M0MPC16string10StringView11sub_2einner(
  struct _M0TPC16string10StringView _M0L4selfS206,
  int32_t _M0L5startS212,
  int64_t _M0L3endS208
) {
  moonbit_string_t _M0L3strS2142;
  int32_t _M0L8str__lenS205;
  int32_t _M0L8abs__endS207;
  int32_t _M0L5startS2140;
  int32_t _M0L10abs__startS211;
  int32_t _M0L5startS2132;
  int32_t _if__result_4612;
  #line 978 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
  _M0L3strS2142 = _M0L4selfS206.$0;
  _M0L8str__lenS205 = Moonbit_array_length(_M0L3strS2142);
  if (_M0L3endS208 == 4294967296ll) {
    _M0L8abs__endS207 = _M0L4selfS206.$2;
  } else {
    int64_t _M0L7_2aSomeS209 = _M0L3endS208;
    int32_t _M0L6_2aendS210 = (int32_t)_M0L7_2aSomeS209;
    int32_t _M0L5startS2141 = _M0L4selfS206.$1;
    _M0L8abs__endS207 = _M0L5startS2141 + _M0L6_2aendS210;
  }
  _M0L5startS2140 = _M0L4selfS206.$1;
  _M0L10abs__startS211 = _M0L5startS2140 + _M0L5startS212;
  _M0L5startS2132 = _M0L4selfS206.$1;
  if (_M0L10abs__startS211 >= _M0L5startS2132) {
    if (_M0L10abs__startS211 <= _M0L8abs__endS207) {
      int32_t _M0L3endS2131 = _M0L4selfS206.$2;
      _if__result_4612 = _M0L8abs__endS207 <= _M0L3endS2131;
    } else {
      _if__result_4612 = 0;
    }
  } else {
    _if__result_4612 = 0;
  }
  if (_if__result_4612) {
    moonbit_string_t _M0L3strS2139;
    if (_M0L10abs__startS211 < _M0L8str__lenS205) {
      moonbit_string_t _M0L3strS2135 = _M0L4selfS206.$0;
      int32_t _M0L6_2atmpS2134 = _M0L3strS2135[_M0L10abs__startS211];
      int32_t _M0L6_2atmpS2133;
      #line 1000 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
      _M0L6_2atmpS2133
      = _M0MPC16uint166UInt1623is__trailing__surrogate(_M0L6_2atmpS2134);
      if (!_M0L6_2atmpS2133) {
        
      } else {
        #line 1000 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
        moonbit_panic();
      }
    }
    if (_M0L8abs__endS207 < _M0L8str__lenS205) {
      moonbit_string_t _M0L3strS2138 = _M0L4selfS206.$0;
      int32_t _M0L6_2atmpS2137 = _M0L3strS2138[_M0L8abs__endS207];
      int32_t _M0L6_2atmpS2136;
      #line 1003 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
      _M0L6_2atmpS2136
      = _M0MPC16uint166UInt1623is__trailing__surrogate(_M0L6_2atmpS2137);
      if (!_M0L6_2atmpS2136) {
        
      } else {
        #line 1003 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
        moonbit_panic();
      }
    }
    _M0L3strS2139 = _M0L4selfS206.$0;
    moonbit_incref(_M0L3strS2139);
    return (struct _M0TPC16string10StringView){.$0 = _M0L3strS2139,
                                                 .$1 = _M0L10abs__startS211,
                                                 .$2 = _M0L8abs__endS207};
  } else {
    #line 994 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
    moonbit_panic();
  }
}

moonbit_string_t _M0MPC14byte4Byte7to__hex(int32_t _M0L1bS204) {
  struct _M0TPB13StringBuilder* _M0L7_2aselfS203;
  int32_t _M0L6_2atmpS2128;
  int32_t _M0L6_2atmpS2127;
  int32_t _M0L6_2atmpS2130;
  int32_t _M0L6_2atmpS2129;
  struct _M0TPB13StringBuilder* _M0L6_2atmpS2126;
  moonbit_string_t _result_4613;
  #line 74 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  #line 83 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _M0L7_2aselfS203 = _M0MPB13StringBuilder21StringBuilder_2einner(0);
  #line 83 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _M0L6_2atmpS2128 = _M0IPC14byte4BytePB3Div3div(_M0L1bS204, 16);
  #line 83 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _M0L6_2atmpS2127
  = _M0MPC14byte4Byte7to__hexN14to__hex__digitS4281(_M0L6_2atmpS2128);
  #line 83 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _M0IPB13StringBuilderPB6Logger11write__char(_M0L7_2aselfS203, _M0L6_2atmpS2127);
  #line 83 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _M0L6_2atmpS2130 = _M0IPC14byte4BytePB3Mod3mod(_M0L1bS204, 16);
  #line 83 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _M0L6_2atmpS2129
  = _M0MPC14byte4Byte7to__hexN14to__hex__digitS4281(_M0L6_2atmpS2130);
  #line 83 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _M0IPB13StringBuilderPB6Logger11write__char(_M0L7_2aselfS203, _M0L6_2atmpS2129);
  _M0L6_2atmpS2126 = _M0L7_2aselfS203;
  #line 83 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _result_4613 = _M0MPB13StringBuilder10to__string(_M0L6_2atmpS2126);
  moonbit_decref(_M0L6_2atmpS2126);
  return _result_4613;
}

int32_t _M0MPC14byte4Byte7to__hexN14to__hex__digitS4281(int32_t _M0L1iS202) {
  #line 75 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  if (_M0L1iS202 < 10) {
    int32_t _M0L6_2atmpS2123;
    #line 77 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    _M0L6_2atmpS2123 = _M0IPC14byte4BytePB3Add3add(_M0L1iS202, 48);
    #line 77 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    return _M0MPC14byte4Byte8to__char(_M0L6_2atmpS2123);
  } else {
    int32_t _M0L6_2atmpS2125;
    int32_t _M0L6_2atmpS2124;
    #line 79 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    _M0L6_2atmpS2125 = _M0IPC14byte4BytePB3Add3add(_M0L1iS202, 97);
    #line 79 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    _M0L6_2atmpS2124 = _M0IPC14byte4BytePB3Sub3sub(_M0L6_2atmpS2125, 10);
    #line 79 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    return _M0MPC14byte4Byte8to__char(_M0L6_2atmpS2124);
  }
}

int32_t _M0IPC14byte4BytePB3Sub3sub(
  int32_t _M0L4selfS200,
  int32_t _M0L4thatS201
) {
  int32_t _M0L6_2atmpS2121;
  int32_t _M0L6_2atmpS2122;
  int32_t _M0L6_2atmpS2120;
  #line 133 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\byte.mbt"
  _M0L6_2atmpS2121 = (int32_t)_M0L4selfS200;
  _M0L6_2atmpS2122 = (int32_t)_M0L4thatS201;
  _M0L6_2atmpS2120 = _M0L6_2atmpS2121 - _M0L6_2atmpS2122;
  return _M0L6_2atmpS2120 & 0xff;
}

int32_t _M0IPC14byte4BytePB3Mod3mod(
  int32_t _M0L4selfS198,
  int32_t _M0L4thatS199
) {
  int32_t _M0L6_2atmpS2118;
  int32_t _M0L6_2atmpS2119;
  int32_t _M0L6_2atmpS2117;
  #line 80 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\byte.mbt"
  _M0L6_2atmpS2118 = (int32_t)_M0L4selfS198;
  _M0L6_2atmpS2119 = (int32_t)_M0L4thatS199;
  _M0L6_2atmpS2117 = _M0L6_2atmpS2118 % _M0L6_2atmpS2119;
  return _M0L6_2atmpS2117 & 0xff;
}

int32_t _M0IPC14byte4BytePB3Div3div(
  int32_t _M0L4selfS196,
  int32_t _M0L4thatS197
) {
  int32_t _M0L6_2atmpS2115;
  int32_t _M0L6_2atmpS2116;
  int32_t _M0L6_2atmpS2114;
  #line 75 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\byte.mbt"
  _M0L6_2atmpS2115 = (int32_t)_M0L4selfS196;
  _M0L6_2atmpS2116 = (int32_t)_M0L4thatS197;
  _M0L6_2atmpS2114 = _M0L6_2atmpS2115 / _M0L6_2atmpS2116;
  return _M0L6_2atmpS2114 & 0xff;
}

int32_t _M0IPC14byte4BytePB3Add3add(
  int32_t _M0L4selfS194,
  int32_t _M0L4thatS195
) {
  int32_t _M0L6_2atmpS2112;
  int32_t _M0L6_2atmpS2113;
  int32_t _M0L6_2atmpS2111;
  #line 119 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\byte.mbt"
  _M0L6_2atmpS2112 = (int32_t)_M0L4selfS194;
  _M0L6_2atmpS2113 = (int32_t)_M0L4thatS195;
  _M0L6_2atmpS2111 = _M0L6_2atmpS2112 + _M0L6_2atmpS2113;
  return _M0L6_2atmpS2111 & 0xff;
}

int32_t _M0MPC16string6String16unsafe__char__at(
  moonbit_string_t _M0L4selfS191,
  int32_t _M0L5indexS192
) {
  int32_t _M0L2c1S190;
  #line 102 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\deprecated.mbt"
  _M0L2c1S190 = _M0L4selfS191[_M0L5indexS192];
  #line 105 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\deprecated.mbt"
  if (_M0MPC16uint166UInt1622is__leading__surrogate(_M0L2c1S190)) {
    int32_t _M0L6_2atmpS2110 = _M0L5indexS192 + 1;
    int32_t _M0L2c2S193 = _M0L4selfS191[_M0L6_2atmpS2110];
    int32_t _M0L6_2atmpS2108 = (int32_t)_M0L2c1S190;
    int32_t _M0L6_2atmpS2109 = (int32_t)_M0L2c2S193;
    #line 107 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\deprecated.mbt"
    return _M0FPB32code__point__of__surrogate__pair(_M0L6_2atmpS2108, _M0L6_2atmpS2109);
  } else {
    #line 109 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\deprecated.mbt"
    return _M0MPC16uint166UInt1616unsafe__to__char(_M0L2c1S190);
  }
}

int32_t _M0MPC16uint166UInt1616unsafe__to__char(int32_t _M0L4selfS189) {
  int32_t _M0L6_2atmpS2107;
  #line 81 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uint16_char.mbt"
  _M0L6_2atmpS2107 = (int32_t)_M0L4selfS189;
  return _M0L6_2atmpS2107;
}

int32_t _M0FPB32code__point__of__surrogate__pair(
  int32_t _M0L7leadingS187,
  int32_t _M0L8trailingS188
) {
  int32_t _M0L6_2atmpS2106;
  int32_t _M0L6_2atmpS2105;
  int32_t _M0L6_2atmpS2104;
  int32_t _M0L6_2atmpS2103;
  int32_t _M0L6_2atmpS2102;
  #line 40 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string.mbt"
  _M0L6_2atmpS2106 = _M0L7leadingS187 - 55296;
  _M0L6_2atmpS2105 = _M0L6_2atmpS2106 * 1024;
  _M0L6_2atmpS2104 = _M0L6_2atmpS2105 + _M0L8trailingS188;
  _M0L6_2atmpS2103 = _M0L6_2atmpS2104 - 56320;
  _M0L6_2atmpS2102 = _M0L6_2atmpS2103 + 65536;
  return _M0L6_2atmpS2102;
}

int32_t _M0MPC16uint166UInt1623is__trailing__surrogate(int32_t _M0L4selfS186) {
  #line 58 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uint16_char.mbt"
  if (_M0L4selfS186 >= 56320) {
    return _M0L4selfS186 <= 57343;
  } else {
    return 0;
  }
}

int32_t _M0MPC16uint166UInt1622is__leading__surrogate(int32_t _M0L4selfS185) {
  #line 28 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uint16_char.mbt"
  if (_M0L4selfS185 >= 55296) {
    return _M0L4selfS185 <= 56319;
  } else {
    return 0;
  }
}

int32_t _M0IPB13StringBuilderPB6Logger11write__char(
  struct _M0TPB13StringBuilder* _M0L4selfS183,
  int32_t _M0L2chS182
) {
  uint32_t _M0L4codeS181;
  #line 120 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  #line 121 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0L4codeS181 = _M0MPC14char4Char8to__uint(_M0L2chS182);
  if (_M0L4codeS181 <= 65535u) {
    int32_t _M0L3lenS2073 = _M0L4selfS183->$1;
    uint16_t* _M0L4dataS2075 = _M0L4selfS183->$0;
    int32_t _M0L6_2atmpS2074 = Moonbit_array_length(_M0L4dataS2075);
    uint16_t* _M0L4dataS2078;
    int32_t _M0L3lenS2079;
    int32_t _M0L6_2atmpS2080;
    int32_t _M0L3lenS2082;
    int32_t _M0L6_2atmpS2081;
    if (_M0L3lenS2073 >= _M0L6_2atmpS2074) {
      int32_t _M0L3lenS2077 = _M0L4selfS183->$1;
      int32_t _M0L6_2atmpS2076 = _M0L3lenS2077 + 1;
      #line 124 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
      _M0MPB13StringBuilder4grow(_M0L4selfS183, _M0L6_2atmpS2076);
    }
    _M0L4dataS2078 = _M0L4selfS183->$0;
    _M0L3lenS2079 = _M0L4selfS183->$1;
    moonbit_incref(_M0L4dataS2078);
    #line 126 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
    _M0L6_2atmpS2080 = _M0MPC14uint4UInt10to__uint16(_M0L4codeS181);
    if (
      _M0L3lenS2079 < 0
      || _M0L3lenS2079 >= Moonbit_array_length(_M0L4dataS2078)
    ) {
      #line 126 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
      moonbit_panic();
    }
    _M0L4dataS2078[_M0L3lenS2079] = _M0L6_2atmpS2080;
    moonbit_decref(_M0L4dataS2078);
    _M0L3lenS2082 = _M0L4selfS183->$1;
    _M0L6_2atmpS2081 = _M0L3lenS2082 + 1;
    _M0L4selfS183->$1 = _M0L6_2atmpS2081;
  } else if (_M0L4codeS181 <= 1114111u) {
    uint16_t* _M0L4dataS2086 = _M0L4selfS183->$0;
    int32_t _M0L6_2atmpS2084 = Moonbit_array_length(_M0L4dataS2086);
    int32_t _M0L3lenS2085 = _M0L4selfS183->$1;
    int32_t _M0L6_2atmpS2083 = _M0L6_2atmpS2084 - _M0L3lenS2085;
    uint32_t _M0L4codeS184;
    uint16_t* _M0L4dataS2089;
    int32_t _M0L3lenS2090;
    uint32_t _M0L6_2atmpS2093;
    uint32_t _M0L6_2atmpS2092;
    int32_t _M0L6_2atmpS2091;
    uint16_t* _M0L4dataS2094;
    int32_t _M0L3lenS2099;
    int32_t _M0L6_2atmpS2095;
    uint32_t _M0L6_2atmpS2098;
    uint32_t _M0L6_2atmpS2097;
    int32_t _M0L6_2atmpS2096;
    int32_t _M0L3lenS2101;
    int32_t _M0L6_2atmpS2100;
    if (_M0L6_2atmpS2083 < 2) {
      int32_t _M0L3lenS2088 = _M0L4selfS183->$1;
      int32_t _M0L6_2atmpS2087 = _M0L3lenS2088 + 2;
      #line 130 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
      _M0MPB13StringBuilder4grow(_M0L4selfS183, _M0L6_2atmpS2087);
    }
    _M0L4codeS184 = _M0L4codeS181 - 65536u;
    _M0L4dataS2089 = _M0L4selfS183->$0;
    _M0L3lenS2090 = _M0L4selfS183->$1;
    _M0L6_2atmpS2093 = _M0L4codeS184 >> 10;
    _M0L6_2atmpS2092 = 55296u + _M0L6_2atmpS2093;
    moonbit_incref(_M0L4dataS2089);
    #line 133 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
    _M0L6_2atmpS2091 = _M0MPC14uint4UInt10to__uint16(_M0L6_2atmpS2092);
    if (
      _M0L3lenS2090 < 0
      || _M0L3lenS2090 >= Moonbit_array_length(_M0L4dataS2089)
    ) {
      #line 133 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
      moonbit_panic();
    }
    _M0L4dataS2089[_M0L3lenS2090] = _M0L6_2atmpS2091;
    moonbit_decref(_M0L4dataS2089);
    _M0L4dataS2094 = _M0L4selfS183->$0;
    _M0L3lenS2099 = _M0L4selfS183->$1;
    _M0L6_2atmpS2095 = _M0L3lenS2099 + 1;
    _M0L6_2atmpS2098 = _M0L4codeS184 & 1023u;
    _M0L6_2atmpS2097 = 56320u + _M0L6_2atmpS2098;
    moonbit_incref(_M0L4dataS2094);
    #line 134 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
    _M0L6_2atmpS2096 = _M0MPC14uint4UInt10to__uint16(_M0L6_2atmpS2097);
    if (
      _M0L6_2atmpS2095 < 0
      || _M0L6_2atmpS2095 >= Moonbit_array_length(_M0L4dataS2094)
    ) {
      #line 134 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
      moonbit_panic();
    }
    _M0L4dataS2094[_M0L6_2atmpS2095] = _M0L6_2atmpS2096;
    moonbit_decref(_M0L4dataS2094);
    _M0L3lenS2101 = _M0L4selfS183->$1;
    _M0L6_2atmpS2100 = _M0L3lenS2101 + 2;
    _M0L4selfS183->$1 = _M0L6_2atmpS2100;
  } else {
    #line 137 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
    _M0FPC15abort5abortGuE((moonbit_string_t)moonbit_string_literal_59.data);
  }
  return 0;
}

int32_t _M0MPB13StringBuilder4grow(
  struct _M0TPB13StringBuilder* _M0L4selfS178,
  int32_t _M0L8requiredS179
) {
  uint16_t* _M0L4dataS2072;
  int32_t _M0L6_2atmpS2070;
  int32_t _M0L3lenS2071;
  int32_t _M0L13new__capacityS177;
  uint16_t* _M0L4dataS2067;
  int32_t _M0L6_2atmpS2068;
  int32_t _M0L3lenS2069;
  uint16_t* _M0L9new__dataS180;
  uint16_t* _M0L6_2aoldS4194;
  #line 74 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0L4dataS2072 = _M0L4selfS178->$0;
  _M0L6_2atmpS2070 = Moonbit_array_length(_M0L4dataS2072);
  _M0L3lenS2071 = _M0L4selfS178->$1;
  #line 75 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0L13new__capacityS177
  = _M0FPB31stringbuilder__growth__capacity(_M0L6_2atmpS2070, _M0L3lenS2071, _M0L8requiredS179);
  _M0L4dataS2067 = _M0L4selfS178->$0;
  moonbit_incref(_M0L4dataS2067);
  #line 83 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0L6_2atmpS2068 = _M0IPC16uint166UInt16PB7Default7default();
  _M0L3lenS2069 = _M0L4selfS178->$1;
  #line 80 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0L9new__dataS180
  = _M0MPC15array10FixedArray23make__and__blit_2einnerGkE(_M0L4dataS2067, _M0L13new__capacityS177, _M0L6_2atmpS2068, _M0L3lenS2069, 0, 0);
  _M0L6_2aoldS4194 = _M0L4selfS178->$0;
  moonbit_decref(_M0L6_2aoldS4194);
  _M0L4selfS178->$0 = _M0L9new__dataS180;
  return 0;
}

int32_t _M0FPB31stringbuilder__growth__capacity(
  int32_t _M0L7currentS176,
  int32_t _M0L3lenS172,
  int32_t _M0L8requiredS171
) {
  int32_t _M0L5spaceS173;
  #line 48 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  if (_M0L8requiredS171 < _M0L3lenS172) {
    #line 55 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
    _M0FPC15abort5abortGuE((moonbit_string_t)moonbit_string_literal_60.data);
  }
  _M0L5spaceS173 = _M0L7currentS176;
  while (1) {
    if (_M0L5spaceS173 < _M0L8requiredS171) {
      int32_t _M0L4nextS174 = _M0L5spaceS173 * 2;
      if (_M0L4nextS174 <= _M0L5spaceS173) {
        return _M0L8requiredS171;
      }
      _M0L5spaceS173 = _M0L4nextS174;
      continue;
    } else {
      return _M0L5spaceS173;
    }
    break;
  }
}

int32_t _M0MPC14uint4UInt10to__uint16(uint32_t _M0L4selfS170) {
  int32_t _M0L6_2atmpS2066;
  #line 2703 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\intrinsics.mbt"
  _M0L6_2atmpS2066 = *(int32_t*)&_M0L4selfS170;
  return (uint16_t)_M0L6_2atmpS2066;
}

uint32_t _M0MPC14char4Char8to__uint(int32_t _M0L4selfS169) {
  int32_t _M0L6_2atmpS2065;
  #line 1255 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\intrinsics.mbt"
  _M0L6_2atmpS2065 = _M0L4selfS169;
  return *(uint32_t*)&_M0L6_2atmpS2065;
}

moonbit_string_t _M0MPB13StringBuilder10to__string(
  struct _M0TPB13StringBuilder* _M0L4selfS167
) {
  int32_t _M0L3lenS2056;
  #line 183 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0L3lenS2056 = _M0L4selfS167->$1;
  if (_M0L3lenS2056 == 0) {
    return (moonbit_string_t)moonbit_string_literal_1.data;
  } else {
    int32_t _M0L3lenS2057 = _M0L4selfS167->$1;
    uint16_t* _M0L4dataS2059 = _M0L4selfS167->$0;
    int32_t _M0L6_2atmpS2058 = Moonbit_array_length(_M0L4dataS2059);
    if (_M0L3lenS2057 == _M0L6_2atmpS2058) {
      uint16_t* _M0L4dataS2060 = _M0L4selfS167->$0;
      moonbit_incref(_M0L4dataS2060);
      return _M0L4dataS2060;
    } else {
      uint16_t* _M0L4dataS2061 = _M0L4selfS167->$0;
      int32_t _M0L3lenS2062 = _M0L4selfS167->$1;
      int32_t _M0L6_2atmpS2063;
      int32_t _M0L3lenS2064;
      uint16_t* _M0L4dataS168;
      moonbit_incref(_M0L4dataS2061);
      #line 192 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
      _M0L6_2atmpS2063 = _M0IPC16uint166UInt16PB7Default7default();
      _M0L3lenS2064 = _M0L4selfS167->$1;
      #line 189 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
      _M0L4dataS168
      = _M0MPC15array10FixedArray23make__and__blit_2einnerGkE(_M0L4dataS2061, _M0L3lenS2062, _M0L6_2atmpS2063, _M0L3lenS2064, 0, 0);
      return _M0L4dataS168;
    }
  }
}

uint16_t* _M0MPC15array10FixedArray23make__and__blit_2einnerGkE(
  uint16_t* _M0L3srcS164,
  int32_t _M0L13allocate__lenS160,
  int32_t _M0L4initS165,
  int32_t _M0L3lenS161,
  int32_t _M0L11src__offsetS162,
  int32_t _M0L11dst__offsetS163
) {
  int32_t _if__result_4615;
  #line 97 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
  if (_M0L13allocate__lenS160 >= 0) {
    if (_M0L3lenS161 >= 0) {
      if (_M0L11src__offsetS162 >= 0) {
        if (_M0L11dst__offsetS163 >= 0) {
          int32_t _M0L6_2atmpS2052 = _M0L11src__offsetS162 + _M0L3lenS161;
          int32_t _M0L6_2atmpS2053 = Moonbit_array_length(_M0L3srcS164);
          if (_M0L6_2atmpS2052 <= _M0L6_2atmpS2053) {
            int32_t _M0L6_2atmpS2051 = _M0L11dst__offsetS163 + _M0L3lenS161;
            _if__result_4615 = _M0L6_2atmpS2051 <= _M0L13allocate__lenS160;
          } else {
            _if__result_4615 = 0;
          }
        } else {
          _if__result_4615 = 0;
        }
      } else {
        _if__result_4615 = 0;
      }
    } else {
      _if__result_4615 = 0;
    }
  } else {
    _if__result_4615 = 0;
  }
  if (_if__result_4615) {
    #line 116 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    return _M0MPC15array10FixedArray23unsafe__make__and__blitGkE(_M0L3srcS164, _M0L13allocate__lenS160, _M0L4initS165, _M0L11src__offsetS162, _M0L11dst__offsetS163, _M0L3lenS161);
  } else {
    struct _M0TPB13StringBuilder* _M0L18_2astring__builderS166;
    int32_t _M0L6_2atmpS2055;
    moonbit_string_t _M0L6_2atmpS2054;
    uint16_t* _result_4616;
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0L18_2astring__builderS166
    = _M0MPB13StringBuilder21StringBuilder_2einner(89);
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS166, (moonbit_string_t)moonbit_string_literal_61.data);
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS166, _M0L13allocate__lenS160);
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS166, (moonbit_string_t)moonbit_string_literal_62.data);
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS166, _M0L11src__offsetS162);
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS166, (moonbit_string_t)moonbit_string_literal_63.data);
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS166, _M0L11dst__offsetS163);
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS166, (moonbit_string_t)moonbit_string_literal_64.data);
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS166, _M0L3lenS161);
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS166, (moonbit_string_t)moonbit_string_literal_65.data);
    _M0L6_2atmpS2055 = Moonbit_array_length(_M0L3srcS164);
    moonbit_decref(_M0L3srcS164);
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS166, _M0L6_2atmpS2055);
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0L6_2atmpS2054
    = _M0MPB13StringBuilder10to__string(_M0L18_2astring__builderS166);
    moonbit_decref(_M0L18_2astring__builderS166);
    #line 112 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _result_4616 = _M0FPC15abort5abortGAkE(_M0L6_2atmpS2054);
    moonbit_decref(_M0L6_2atmpS2054);
    return _result_4616;
  }
}

uint16_t* _M0MPC15array10FixedArray23unsafe__make__and__blitGkE(
  uint16_t* _M0L3srcS157,
  int32_t _M0L13allocate__lenS154,
  int32_t _M0L4initS155,
  int32_t _M0L11src__offsetS158,
  int32_t _M0L11dst__offsetS156,
  int32_t _M0L9blit__lenS159
) {
  uint16_t* _M0L3dstS153;
  #line 79 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
  _M0L3dstS153
  = (uint16_t*)moonbit_make_string(_M0L13allocate__lenS154, _M0L4initS155);
  moonbit_incref(_M0L3dstS153);
  #line 90 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
  moonbit_unsafe_val_array_blit(_M0L3dstS153, _M0L11dst__offsetS156, _M0L3srcS157, _M0L11src__offsetS158, _M0L9blit__lenS159, sizeof(uint16_t));
  return _M0L3dstS153;
}

struct _M0TPB13StringBuilder* _M0MPB13StringBuilder21StringBuilder_2einner(
  int32_t _M0L10size__hintS151
) {
  int32_t _M0L7initialS150;
  uint16_t* _M0L4dataS152;
  struct _M0TPB13StringBuilder* _block_4617;
  #line 32 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  if (_M0L10size__hintS151 < 1) {
    _M0L7initialS150 = 1;
  } else {
    int32_t _M0L6_2atmpS2050 = _M0L10size__hintS151 + 1;
    _M0L7initialS150 = _M0L6_2atmpS2050 / 2;
  }
  _M0L4dataS152 = (uint16_t*)moonbit_make_string(_M0L7initialS150, 0);
  _block_4617
  = (struct _M0TPB13StringBuilder*)moonbit_malloc(sizeof(struct _M0TPB13StringBuilder));
  Moonbit_object_header(_block_4617)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 168, 0);
  _block_4617->$0 = _M0L4dataS152;
  _block_4617->$1 = 0;
  return _block_4617;
}

int32_t _M0MPC14byte4Byte8to__char(int32_t _M0L4selfS149) {
  int32_t _M0L6_2atmpS2049;
  #line 1869 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\intrinsics.mbt"
  _M0L6_2atmpS2049 = (int32_t)_M0L4selfS149;
  return _M0L6_2atmpS2049;
}

moonbit_string_t* _M0MPB18UninitializedArray23make__and__blit_2einnerGsE(
  moonbit_string_t* _M0L3srcS129,
  int32_t _M0L13allocate__lenS125,
  int32_t _M0L3lenS126,
  int32_t _M0L11src__offsetS127,
  int32_t _M0L11dst__offsetS128
) {
  int32_t _if__result_4618;
  #line 167 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  if (_M0L13allocate__lenS125 >= 0) {
    if (_M0L3lenS126 >= 0) {
      if (_M0L11src__offsetS127 >= 0) {
        if (_M0L11dst__offsetS128 >= 0) {
          int32_t _M0L6_2atmpS2030 = _M0L11src__offsetS127 + _M0L3lenS126;
          int32_t _M0L6_2atmpS2031;
          #line 179 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
          _M0L6_2atmpS2031
          = _M0MPB18UninitializedArray6lengthGsE(_M0L3srcS129);
          if (_M0L6_2atmpS2030 <= _M0L6_2atmpS2031) {
            int32_t _M0L6_2atmpS2029 = _M0L11dst__offsetS128 + _M0L3lenS126;
            _if__result_4618 = _M0L6_2atmpS2029 <= _M0L13allocate__lenS125;
          } else {
            _if__result_4618 = 0;
          }
        } else {
          _if__result_4618 = 0;
        }
      } else {
        _if__result_4618 = 0;
      }
    } else {
      _if__result_4618 = 0;
    }
  } else {
    _if__result_4618 = 0;
  }
  if (_if__result_4618) {
    #line 185 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    return (moonbit_string_t*)moonbit_make_ref_array_with_blit(_M0L13allocate__lenS125, (moonbit_string_t)moonbit_string_literal_1.data, _M0L3srcS129, _M0L11src__offsetS127, _M0L11dst__offsetS128, _M0L3lenS126);
  } else {
    struct _M0TPB13StringBuilder* _M0L18_2astring__builderS130;
    int32_t _M0L6_2atmpS2033;
    moonbit_string_t _M0L6_2atmpS2032;
    moonbit_string_t* _result_4619;
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0L18_2astring__builderS130
    = _M0MPB13StringBuilder21StringBuilder_2einner(89);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS130, (moonbit_string_t)moonbit_string_literal_61.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS130, _M0L13allocate__lenS125);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS130, (moonbit_string_t)moonbit_string_literal_62.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS130, _M0L11src__offsetS127);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS130, (moonbit_string_t)moonbit_string_literal_63.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS130, _M0L11dst__offsetS128);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS130, (moonbit_string_t)moonbit_string_literal_64.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS130, _M0L3lenS126);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS130, (moonbit_string_t)moonbit_string_literal_65.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0L6_2atmpS2033 = _M0MPB18UninitializedArray6lengthGsE(_M0L3srcS129);
    moonbit_decref(_M0L3srcS129);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS130, _M0L6_2atmpS2033);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0L6_2atmpS2032
    = _M0MPB13StringBuilder10to__string(_M0L18_2astring__builderS130);
    moonbit_decref(_M0L18_2astring__builderS130);
    #line 181 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _result_4619
    = _M0FPC15abort5abortGRPB18UninitializedArrayGsEE(_M0L6_2atmpS2032);
    moonbit_decref(_M0L6_2atmpS2032);
    return _result_4619;
  }
}

struct _M0TUsiE** _M0MPB18UninitializedArray23make__and__blit_2einnerGUsiEE(
  struct _M0TUsiE** _M0L3srcS135,
  int32_t _M0L13allocate__lenS131,
  int32_t _M0L3lenS132,
  int32_t _M0L11src__offsetS133,
  int32_t _M0L11dst__offsetS134
) {
  int32_t _if__result_4620;
  #line 167 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  if (_M0L13allocate__lenS131 >= 0) {
    if (_M0L3lenS132 >= 0) {
      if (_M0L11src__offsetS133 >= 0) {
        if (_M0L11dst__offsetS134 >= 0) {
          int32_t _M0L6_2atmpS2035 = _M0L11src__offsetS133 + _M0L3lenS132;
          int32_t _M0L6_2atmpS2036;
          #line 179 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
          _M0L6_2atmpS2036
          = _M0MPB18UninitializedArray6lengthGUsiEE(_M0L3srcS135);
          if (_M0L6_2atmpS2035 <= _M0L6_2atmpS2036) {
            int32_t _M0L6_2atmpS2034 = _M0L11dst__offsetS134 + _M0L3lenS132;
            _if__result_4620 = _M0L6_2atmpS2034 <= _M0L13allocate__lenS131;
          } else {
            _if__result_4620 = 0;
          }
        } else {
          _if__result_4620 = 0;
        }
      } else {
        _if__result_4620 = 0;
      }
    } else {
      _if__result_4620 = 0;
    }
  } else {
    _if__result_4620 = 0;
  }
  if (_if__result_4620) {
    #line 185 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    return (struct _M0TUsiE**)moonbit_make_ref_array_with_blit(_M0L13allocate__lenS131, 0, _M0L3srcS135, _M0L11src__offsetS133, _M0L11dst__offsetS134, _M0L3lenS132);
  } else {
    struct _M0TPB13StringBuilder* _M0L18_2astring__builderS136;
    int32_t _M0L6_2atmpS2038;
    moonbit_string_t _M0L6_2atmpS2037;
    struct _M0TUsiE** _result_4621;
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0L18_2astring__builderS136
    = _M0MPB13StringBuilder21StringBuilder_2einner(89);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS136, (moonbit_string_t)moonbit_string_literal_61.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS136, _M0L13allocate__lenS131);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS136, (moonbit_string_t)moonbit_string_literal_62.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS136, _M0L11src__offsetS133);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS136, (moonbit_string_t)moonbit_string_literal_63.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS136, _M0L11dst__offsetS134);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS136, (moonbit_string_t)moonbit_string_literal_64.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS136, _M0L3lenS132);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS136, (moonbit_string_t)moonbit_string_literal_65.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0L6_2atmpS2038 = _M0MPB18UninitializedArray6lengthGUsiEE(_M0L3srcS135);
    moonbit_decref(_M0L3srcS135);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS136, _M0L6_2atmpS2038);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0L6_2atmpS2037
    = _M0MPB13StringBuilder10to__string(_M0L18_2astring__builderS136);
    moonbit_decref(_M0L18_2astring__builderS136);
    #line 181 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _result_4621
    = _M0FPC15abort5abortGRPB18UninitializedArrayGUsiEEE(_M0L6_2atmpS2037);
    moonbit_decref(_M0L6_2atmpS2037);
    return _result_4621;
  }
}

void** _M0MPB18UninitializedArray23make__and__blit_2einnerGRPC15debug9ReprDeltaE(
  void** _M0L3srcS141,
  int32_t _M0L13allocate__lenS137,
  int32_t _M0L3lenS138,
  int32_t _M0L11src__offsetS139,
  int32_t _M0L11dst__offsetS140
) {
  int32_t _if__result_4622;
  #line 167 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  if (_M0L13allocate__lenS137 >= 0) {
    if (_M0L3lenS138 >= 0) {
      if (_M0L11src__offsetS139 >= 0) {
        if (_M0L11dst__offsetS140 >= 0) {
          int32_t _M0L6_2atmpS2040 = _M0L11src__offsetS139 + _M0L3lenS138;
          int32_t _M0L6_2atmpS2041;
          #line 179 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
          _M0L6_2atmpS2041
          = _M0MPB18UninitializedArray6lengthGRPC15debug9ReprDeltaE(_M0L3srcS141);
          if (_M0L6_2atmpS2040 <= _M0L6_2atmpS2041) {
            int32_t _M0L6_2atmpS2039 = _M0L11dst__offsetS140 + _M0L3lenS138;
            _if__result_4622 = _M0L6_2atmpS2039 <= _M0L13allocate__lenS137;
          } else {
            _if__result_4622 = 0;
          }
        } else {
          _if__result_4622 = 0;
        }
      } else {
        _if__result_4622 = 0;
      }
    } else {
      _if__result_4622 = 0;
    }
  } else {
    _if__result_4622 = 0;
  }
  if (_if__result_4622) {
    void** _arr_4623;
    #line 185 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _arr_4623
    = (void**)moonbit_make_ref_array_with_blit(_M0L13allocate__lenS137, (struct moonbit_object*)&moonbit_constant_constructor_0 + 1, _M0L3srcS141, _M0L11src__offsetS139, _M0L11dst__offsetS140, _M0L3lenS138);
    set_cycle_capable(_arr_4623);
    return _arr_4623;
  } else {
    struct _M0TPB13StringBuilder* _M0L18_2astring__builderS142;
    int32_t _M0L6_2atmpS2043;
    moonbit_string_t _M0L6_2atmpS2042;
    void** _result_4624;
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0L18_2astring__builderS142
    = _M0MPB13StringBuilder21StringBuilder_2einner(89);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS142, (moonbit_string_t)moonbit_string_literal_61.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS142, _M0L13allocate__lenS137);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS142, (moonbit_string_t)moonbit_string_literal_62.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS142, _M0L11src__offsetS139);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS142, (moonbit_string_t)moonbit_string_literal_63.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS142, _M0L11dst__offsetS140);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS142, (moonbit_string_t)moonbit_string_literal_64.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS142, _M0L3lenS138);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS142, (moonbit_string_t)moonbit_string_literal_65.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0L6_2atmpS2043
    = _M0MPB18UninitializedArray6lengthGRPC15debug9ReprDeltaE(_M0L3srcS141);
    moonbit_decref(_M0L3srcS141);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS142, _M0L6_2atmpS2043);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0L6_2atmpS2042
    = _M0MPB13StringBuilder10to__string(_M0L18_2astring__builderS142);
    moonbit_decref(_M0L18_2astring__builderS142);
    #line 181 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _result_4624
    = _M0FPC15abort5abortGRPB18UninitializedArrayGRPC15debug9ReprDeltaEE(_M0L6_2atmpS2042);
    moonbit_decref(_M0L6_2atmpS2042);
    return _result_4624;
  }
}

struct _M0TPC16string10StringView* _M0MPB18UninitializedArray23make__and__blit_2einnerGRPC16string10StringViewE(
  struct _M0TPC16string10StringView* _M0L3srcS147,
  int32_t _M0L13allocate__lenS143,
  int32_t _M0L3lenS144,
  int32_t _M0L11src__offsetS145,
  int32_t _M0L11dst__offsetS146
) {
  int32_t _if__result_4625;
  #line 167 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  if (_M0L13allocate__lenS143 >= 0) {
    if (_M0L3lenS144 >= 0) {
      if (_M0L11src__offsetS145 >= 0) {
        if (_M0L11dst__offsetS146 >= 0) {
          int32_t _M0L6_2atmpS2045 = _M0L11src__offsetS145 + _M0L3lenS144;
          int32_t _M0L6_2atmpS2046;
          #line 179 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
          _M0L6_2atmpS2046
          = _M0MPB18UninitializedArray6lengthGRPC16string10StringViewE(_M0L3srcS147);
          if (_M0L6_2atmpS2045 <= _M0L6_2atmpS2046) {
            int32_t _M0L6_2atmpS2044 = _M0L11dst__offsetS146 + _M0L3lenS144;
            _if__result_4625 = _M0L6_2atmpS2044 <= _M0L13allocate__lenS143;
          } else {
            _if__result_4625 = 0;
          }
        } else {
          _if__result_4625 = 0;
        }
      } else {
        _if__result_4625 = 0;
      }
    } else {
      _if__result_4625 = 0;
    }
  } else {
    _if__result_4625 = 0;
  }
  if (_if__result_4625) {
    #line 185 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    return _M0MPB18UninitializedArray23unsafe__make__and__blitGRPC16string10StringViewE(_M0L3srcS147, _M0L13allocate__lenS143, _M0L11src__offsetS145, _M0L11dst__offsetS146, _M0L3lenS144);
  } else {
    struct _M0TPB13StringBuilder* _M0L18_2astring__builderS148;
    int32_t _M0L6_2atmpS2048;
    moonbit_string_t _M0L6_2atmpS2047;
    struct _M0TPC16string10StringView* _result_4626;
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0L18_2astring__builderS148
    = _M0MPB13StringBuilder21StringBuilder_2einner(89);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS148, (moonbit_string_t)moonbit_string_literal_61.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS148, _M0L13allocate__lenS143);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS148, (moonbit_string_t)moonbit_string_literal_62.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS148, _M0L11src__offsetS145);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS148, (moonbit_string_t)moonbit_string_literal_63.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS148, _M0L11dst__offsetS146);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS148, (moonbit_string_t)moonbit_string_literal_64.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS148, _M0L3lenS144);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS148, (moonbit_string_t)moonbit_string_literal_65.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0L6_2atmpS2048
    = _M0MPB18UninitializedArray6lengthGRPC16string10StringViewE(_M0L3srcS147);
    moonbit_decref(_M0L3srcS147);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS148, _M0L6_2atmpS2048);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0L6_2atmpS2047
    = _M0MPB13StringBuilder10to__string(_M0L18_2astring__builderS148);
    moonbit_decref(_M0L18_2astring__builderS148);
    #line 181 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _result_4626
    = _M0FPC15abort5abortGRPB18UninitializedArrayGRPC16string10StringViewEE(_M0L6_2atmpS2047);
    moonbit_decref(_M0L6_2atmpS2047);
    return _result_4626;
  }
}

int32_t _M0MPB13StringBuilder13write__objectGsE(
  struct _M0TPB13StringBuilder* _M0L4selfS116,
  moonbit_string_t _M0L3objS115
) {
  struct _M0TPB6Logger _M0L6_2atmpS2024;
  #line 17 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder.mbt"
  moonbit_incref(_M0L4selfS116);
  _M0L6_2atmpS2024
  = (struct _M0TPB6Logger){
    _M0FP0119moonbitlang_2fcore_2fbuiltin_2fStringBuilder_2eas___40moonbitlang_2fcore_2fbuiltin_2eLogger_2estatic__method__table__id,
      _M0L4selfS116
  };
  #line 23 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder.mbt"
  _M0IP016_24default__implPB4Show6outputGsE(_M0L3objS115, _M0L6_2atmpS2024);
  if (_M0L6_2atmpS2024.$1) {
    moonbit_decref(_M0L6_2atmpS2024.$1);
  }
  return 0;
}

int32_t _M0MPB13StringBuilder13write__objectGiE(
  struct _M0TPB13StringBuilder* _M0L4selfS118,
  int32_t _M0L3objS117
) {
  struct _M0TPB6Logger _M0L6_2atmpS2025;
  #line 17 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder.mbt"
  moonbit_incref(_M0L4selfS118);
  _M0L6_2atmpS2025
  = (struct _M0TPB6Logger){
    _M0FP0119moonbitlang_2fcore_2fbuiltin_2fStringBuilder_2eas___40moonbitlang_2fcore_2fbuiltin_2eLogger_2estatic__method__table__id,
      _M0L4selfS118
  };
  #line 23 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder.mbt"
  _M0IP016_24default__implPB4Show6outputGiE(_M0L3objS117, _M0L6_2atmpS2025);
  if (_M0L6_2atmpS2025.$1) {
    moonbit_decref(_M0L6_2atmpS2025.$1);
  }
  return 0;
}

int32_t _M0MPB13StringBuilder13write__objectGRPB9SourceLocE(
  struct _M0TPB13StringBuilder* _M0L4selfS120,
  moonbit_string_t _M0L3objS119
) {
  struct _M0TPB6Logger _M0L6_2atmpS2026;
  #line 17 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder.mbt"
  moonbit_incref(_M0L4selfS120);
  _M0L6_2atmpS2026
  = (struct _M0TPB6Logger){
    _M0FP0119moonbitlang_2fcore_2fbuiltin_2fStringBuilder_2eas___40moonbitlang_2fcore_2fbuiltin_2eLogger_2estatic__method__table__id,
      _M0L4selfS120
  };
  #line 23 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder.mbt"
  _M0IPB9SourceLocPB4Show6output(_M0L3objS119, _M0L6_2atmpS2026);
  if (_M0L6_2atmpS2026.$1) {
    moonbit_decref(_M0L6_2atmpS2026.$1);
  }
  return 0;
}

int32_t _M0MPB13StringBuilder13write__objectGRPC16string10StringViewE(
  struct _M0TPB13StringBuilder* _M0L4selfS122,
  struct _M0TPC16string10StringView _M0L3objS121
) {
  struct _M0TPB6Logger _M0L6_2atmpS2027;
  #line 17 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder.mbt"
  moonbit_incref(_M0L4selfS122);
  _M0L6_2atmpS2027
  = (struct _M0TPB6Logger){
    _M0FP0119moonbitlang_2fcore_2fbuiltin_2fStringBuilder_2eas___40moonbitlang_2fcore_2fbuiltin_2eLogger_2estatic__method__table__id,
      _M0L4selfS122
  };
  #line 23 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder.mbt"
  _M0IPC16string10StringViewPB4Show6output(_M0L3objS121, _M0L6_2atmpS2027);
  if (_M0L6_2atmpS2027.$1) {
    moonbit_decref(_M0L6_2atmpS2027.$1);
  }
  return 0;
}

int32_t _M0MPB13StringBuilder13write__objectGmE(
  struct _M0TPB13StringBuilder* _M0L4selfS124,
  uint64_t _M0L3objS123
) {
  struct _M0TPB6Logger _M0L6_2atmpS2028;
  #line 17 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder.mbt"
  moonbit_incref(_M0L4selfS124);
  _M0L6_2atmpS2028
  = (struct _M0TPB6Logger){
    _M0FP0119moonbitlang_2fcore_2fbuiltin_2fStringBuilder_2eas___40moonbitlang_2fcore_2fbuiltin_2eLogger_2estatic__method__table__id,
      _M0L4selfS124
  };
  #line 23 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder.mbt"
  _M0IP016_24default__implPB4Show6outputGmE(_M0L3objS123, _M0L6_2atmpS2028);
  if (_M0L6_2atmpS2028.$1) {
    moonbit_decref(_M0L6_2atmpS2028.$1);
  }
  return 0;
}

moonbit_string_t* _M0MPB18UninitializedArray23unsafe__make__and__blitGsE(
  moonbit_string_t* _M0L3srcS94,
  int32_t _M0L13allocate__lenS92,
  int32_t _M0L11src__offsetS95,
  int32_t _M0L11dst__offsetS93,
  int32_t _M0L9blit__lenS96
) {
  moonbit_string_t* _M0L3dstS91;
  #line 132 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  _M0L3dstS91
  = (moonbit_string_t*)moonbit_make_ref_array(_M0L13allocate__lenS92, (moonbit_string_t)moonbit_string_literal_1.data);
  #line 142 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  _M0MPB18UninitializedArray12unsafe__blitGsE(_M0L3dstS91, _M0L11dst__offsetS93, _M0L3srcS94, _M0L11src__offsetS95, _M0L9blit__lenS96);
  moonbit_decref(_M0L3srcS94);
  return _M0L3dstS91;
}

struct _M0TUsiE** _M0MPB18UninitializedArray23unsafe__make__and__blitGUsiEE(
  struct _M0TUsiE** _M0L3srcS100,
  int32_t _M0L13allocate__lenS98,
  int32_t _M0L11src__offsetS101,
  int32_t _M0L11dst__offsetS99,
  int32_t _M0L9blit__lenS102
) {
  struct _M0TUsiE** _M0L3dstS97;
  #line 132 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  _M0L3dstS97
  = (struct _M0TUsiE**)moonbit_make_ref_array(_M0L13allocate__lenS98, 0);
  #line 142 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  _M0MPB18UninitializedArray12unsafe__blitGUsiEE(_M0L3dstS97, _M0L11dst__offsetS99, _M0L3srcS100, _M0L11src__offsetS101, _M0L9blit__lenS102);
  moonbit_decref(_M0L3srcS100);
  return _M0L3dstS97;
}

void** _M0MPB18UninitializedArray23unsafe__make__and__blitGRPC15debug9ReprDeltaE(
  void** _M0L3srcS106,
  int32_t _M0L13allocate__lenS104,
  int32_t _M0L11src__offsetS107,
  int32_t _M0L11dst__offsetS105,
  int32_t _M0L9blit__lenS108
) {
  void** _M0L3dstS103;
  #line 132 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  _M0L3dstS103
  = (void**)moonbit_make_ref_array(_M0L13allocate__lenS104, (struct moonbit_object*)&moonbit_constant_constructor_0 + 1);
  set_cycle_capable(_M0L3dstS103);
  #line 142 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  _M0MPB18UninitializedArray12unsafe__blitGRPC15debug9ReprDeltaE(_M0L3dstS103, _M0L11dst__offsetS105, _M0L3srcS106, _M0L11src__offsetS107, _M0L9blit__lenS108);
  moonbit_decref(_M0L3srcS106);
  return _M0L3dstS103;
}

struct _M0TPC16string10StringView* _M0MPB18UninitializedArray23unsafe__make__and__blitGRPC16string10StringViewE(
  struct _M0TPC16string10StringView* _M0L3srcS112,
  int32_t _M0L13allocate__lenS110,
  int32_t _M0L11src__offsetS113,
  int32_t _M0L11dst__offsetS111,
  int32_t _M0L9blit__lenS114
) {
  struct _M0TPC16string10StringView* _M0L3dstS109;
  #line 132 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  _M0L3dstS109
  = (struct _M0TPC16string10StringView*)moonbit_make_ref_valtype_array(_M0L13allocate__lenS110, sizeof(struct _M0TPC16string10StringView), Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 71, 0), &(struct _M0TPC16string10StringView){.$0 = (moonbit_string_t)moonbit_string_literal_1.data, .$1 = 0, .$2 = 0});
  #line 142 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  _M0MPB18UninitializedArray12unsafe__blitGRPC16string10StringViewE(_M0L3dstS109, _M0L11dst__offsetS111, _M0L3srcS112, _M0L11src__offsetS113, _M0L9blit__lenS114);
  moonbit_decref(_M0L3srcS112);
  return _M0L3dstS109;
}

int32_t _M0MPB18UninitializedArray12unsafe__blitGsE(
  moonbit_string_t* _M0L3dstS71,
  int32_t _M0L11dst__offsetS72,
  moonbit_string_t* _M0L3srcS73,
  int32_t _M0L11src__offsetS74,
  int32_t _M0L3lenS75
) {
  #line 118 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  moonbit_incref(_M0L3srcS73);
  moonbit_incref(_M0L3dstS71);
  #line 127 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  moonbit_unsafe_ref_array_blit(_M0L3dstS71, _M0L11dst__offsetS72, _M0L3srcS73, _M0L11src__offsetS74, _M0L3lenS75);
  return 0;
}

int32_t _M0MPB18UninitializedArray12unsafe__blitGUsiEE(
  struct _M0TUsiE** _M0L3dstS76,
  int32_t _M0L11dst__offsetS77,
  struct _M0TUsiE** _M0L3srcS78,
  int32_t _M0L11src__offsetS79,
  int32_t _M0L3lenS80
) {
  #line 118 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  moonbit_incref(_M0L3srcS78);
  moonbit_incref(_M0L3dstS76);
  #line 127 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  moonbit_unsafe_ref_array_blit(_M0L3dstS76, _M0L11dst__offsetS77, _M0L3srcS78, _M0L11src__offsetS79, _M0L3lenS80);
  return 0;
}

int32_t _M0MPB18UninitializedArray12unsafe__blitGRPC15debug9ReprDeltaE(
  void** _M0L3dstS81,
  int32_t _M0L11dst__offsetS82,
  void** _M0L3srcS83,
  int32_t _M0L11src__offsetS84,
  int32_t _M0L3lenS85
) {
  #line 118 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  moonbit_incref(_M0L3srcS83);
  moonbit_incref(_M0L3dstS81);
  #line 127 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  moonbit_unsafe_ref_array_blit(_M0L3dstS81, _M0L11dst__offsetS82, _M0L3srcS83, _M0L11src__offsetS84, _M0L3lenS85);
  return 0;
}

int32_t _M0MPB18UninitializedArray12unsafe__blitGRPC16string10StringViewE(
  struct _M0TPC16string10StringView* _M0L3dstS86,
  int32_t _M0L11dst__offsetS87,
  struct _M0TPC16string10StringView* _M0L3srcS88,
  int32_t _M0L11src__offsetS89,
  int32_t _M0L3lenS90
) {
  #line 118 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  moonbit_incref(_M0L3srcS88);
  moonbit_incref(_M0L3dstS86);
  #line 127 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  _M0MPC15array10FixedArray12unsafe__blitGRPB17UnsafeMaybeUninitGRPC16string10StringViewEE(_M0L3dstS86, _M0L11dst__offsetS87, _M0L3srcS88, _M0L11src__offsetS89, _M0L3lenS90);
  return 0;
}

int32_t _M0MPC15array10FixedArray12unsafe__blitGkE(
  uint16_t* _M0L3dstS26,
  int32_t _M0L11dst__offsetS28,
  uint16_t* _M0L3srcS27,
  int32_t _M0L11src__offsetS29,
  int32_t _M0L3lenS31
) {
  int32_t _if__result_4627;
  #line 38 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
  if (_M0L3dstS26 == _M0L3srcS27) {
    _if__result_4627 = _M0L11dst__offsetS28 < _M0L11src__offsetS29;
  } else {
    _if__result_4627 = 0;
  }
  if (_if__result_4627) {
    int32_t _M0L1iS30 = 0;
    while (1) {
      if (_M0L1iS30 < _M0L3lenS31) {
        int32_t _M0L6_2atmpS1979 = _M0L11dst__offsetS28 + _M0L1iS30;
        int32_t _M0L6_2atmpS1981 = _M0L11src__offsetS29 + _M0L1iS30;
        int32_t _M0L6_2atmpS1980;
        int32_t _M0L6_2atmpS1982;
        if (
          _M0L6_2atmpS1981 < 0
          || _M0L6_2atmpS1981 >= Moonbit_array_length(_M0L3srcS27)
        ) {
          #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2atmpS1980 = (int32_t)_M0L3srcS27[_M0L6_2atmpS1981];
        if (
          _M0L6_2atmpS1979 < 0
          || _M0L6_2atmpS1979 >= Moonbit_array_length(_M0L3dstS26)
        ) {
          #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L3dstS26[_M0L6_2atmpS1979] = _M0L6_2atmpS1980;
        _M0L6_2atmpS1982 = _M0L1iS30 + 1;
        _M0L1iS30 = _M0L6_2atmpS1982;
        continue;
      } else {
        moonbit_decref(_M0L3srcS27);
        moonbit_decref(_M0L3dstS26);
      }
      break;
    }
  } else {
    int32_t _M0L6_2atmpS1987 = _M0L3lenS31 - 1;
    int32_t _M0L1iS33 = _M0L6_2atmpS1987;
    while (1) {
      if (_M0L1iS33 >= 0) {
        int32_t _M0L6_2atmpS1983 = _M0L11dst__offsetS28 + _M0L1iS33;
        int32_t _M0L6_2atmpS1985 = _M0L11src__offsetS29 + _M0L1iS33;
        int32_t _M0L6_2atmpS1984;
        int32_t _M0L6_2atmpS1986;
        if (
          _M0L6_2atmpS1985 < 0
          || _M0L6_2atmpS1985 >= Moonbit_array_length(_M0L3srcS27)
        ) {
          #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2atmpS1984 = (int32_t)_M0L3srcS27[_M0L6_2atmpS1985];
        if (
          _M0L6_2atmpS1983 < 0
          || _M0L6_2atmpS1983 >= Moonbit_array_length(_M0L3dstS26)
        ) {
          #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L3dstS26[_M0L6_2atmpS1983] = _M0L6_2atmpS1984;
        _M0L6_2atmpS1986 = _M0L1iS33 - 1;
        _M0L1iS33 = _M0L6_2atmpS1986;
        continue;
      } else {
        moonbit_decref(_M0L3srcS27);
        moonbit_decref(_M0L3dstS26);
      }
      break;
    }
  }
  return 0;
}

int32_t _M0MPC15array10FixedArray12unsafe__blitGRPB17UnsafeMaybeUninitGsEE(
  moonbit_string_t* _M0L3dstS35,
  int32_t _M0L11dst__offsetS37,
  moonbit_string_t* _M0L3srcS36,
  int32_t _M0L11src__offsetS38,
  int32_t _M0L3lenS40
) {
  int32_t _if__result_4630;
  #line 38 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
  if (_M0L3dstS35 == _M0L3srcS36) {
    _if__result_4630 = _M0L11dst__offsetS37 < _M0L11src__offsetS38;
  } else {
    _if__result_4630 = 0;
  }
  if (_if__result_4630) {
    int32_t _M0L1iS39 = 0;
    while (1) {
      if (_M0L1iS39 < _M0L3lenS40) {
        int32_t _M0L6_2atmpS1988 = _M0L11dst__offsetS37 + _M0L1iS39;
        int32_t _M0L6_2atmpS1990 = _M0L11src__offsetS38 + _M0L1iS39;
        moonbit_string_t _M0L6_2atmpS1989;
        moonbit_string_t _M0L6_2aoldS4200;
        int32_t _M0L6_2atmpS1991;
        if (
          _M0L6_2atmpS1990 < 0
          || _M0L6_2atmpS1990 >= Moonbit_array_length(_M0L3srcS36)
        ) {
          #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2atmpS1989 = (moonbit_string_t)_M0L3srcS36[_M0L6_2atmpS1990];
        if (
          _M0L6_2atmpS1988 < 0
          || _M0L6_2atmpS1988 >= Moonbit_array_length(_M0L3dstS35)
        ) {
          #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2aoldS4200 = (moonbit_string_t)_M0L3dstS35[_M0L6_2atmpS1988];
        moonbit_incref(_M0L6_2atmpS1989);
        moonbit_decref(_M0L6_2aoldS4200);
        _M0L3dstS35[_M0L6_2atmpS1988] = _M0L6_2atmpS1989;
        _M0L6_2atmpS1991 = _M0L1iS39 + 1;
        _M0L1iS39 = _M0L6_2atmpS1991;
        continue;
      } else {
        moonbit_decref(_M0L3srcS36);
        moonbit_decref(_M0L3dstS35);
      }
      break;
    }
  } else {
    int32_t _M0L6_2atmpS1996 = _M0L3lenS40 - 1;
    int32_t _M0L1iS42 = _M0L6_2atmpS1996;
    while (1) {
      if (_M0L1iS42 >= 0) {
        int32_t _M0L6_2atmpS1992 = _M0L11dst__offsetS37 + _M0L1iS42;
        int32_t _M0L6_2atmpS1994 = _M0L11src__offsetS38 + _M0L1iS42;
        moonbit_string_t _M0L6_2atmpS1993;
        moonbit_string_t _M0L6_2aoldS4202;
        int32_t _M0L6_2atmpS1995;
        if (
          _M0L6_2atmpS1994 < 0
          || _M0L6_2atmpS1994 >= Moonbit_array_length(_M0L3srcS36)
        ) {
          #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2atmpS1993 = (moonbit_string_t)_M0L3srcS36[_M0L6_2atmpS1994];
        if (
          _M0L6_2atmpS1992 < 0
          || _M0L6_2atmpS1992 >= Moonbit_array_length(_M0L3dstS35)
        ) {
          #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2aoldS4202 = (moonbit_string_t)_M0L3dstS35[_M0L6_2atmpS1992];
        moonbit_incref(_M0L6_2atmpS1993);
        moonbit_decref(_M0L6_2aoldS4202);
        _M0L3dstS35[_M0L6_2atmpS1992] = _M0L6_2atmpS1993;
        _M0L6_2atmpS1995 = _M0L1iS42 - 1;
        _M0L1iS42 = _M0L6_2atmpS1995;
        continue;
      } else {
        moonbit_decref(_M0L3srcS36);
        moonbit_decref(_M0L3dstS35);
      }
      break;
    }
  }
  return 0;
}

int32_t _M0MPC15array10FixedArray12unsafe__blitGRPB17UnsafeMaybeUninitGUsiEEE(
  struct _M0TUsiE** _M0L3dstS44,
  int32_t _M0L11dst__offsetS46,
  struct _M0TUsiE** _M0L3srcS45,
  int32_t _M0L11src__offsetS47,
  int32_t _M0L3lenS49
) {
  int32_t _if__result_4633;
  #line 38 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
  if (_M0L3dstS44 == _M0L3srcS45) {
    _if__result_4633 = _M0L11dst__offsetS46 < _M0L11src__offsetS47;
  } else {
    _if__result_4633 = 0;
  }
  if (_if__result_4633) {
    int32_t _M0L1iS48 = 0;
    while (1) {
      if (_M0L1iS48 < _M0L3lenS49) {
        int32_t _M0L6_2atmpS1997 = _M0L11dst__offsetS46 + _M0L1iS48;
        int32_t _M0L6_2atmpS1999 = _M0L11src__offsetS47 + _M0L1iS48;
        struct _M0TUsiE* _M0L6_2atmpS1998;
        struct _M0TUsiE* _M0L6_2aoldS4204;
        int32_t _M0L6_2atmpS2000;
        if (
          _M0L6_2atmpS1999 < 0
          || _M0L6_2atmpS1999 >= Moonbit_array_length(_M0L3srcS45)
        ) {
          #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2atmpS1998 = (struct _M0TUsiE*)_M0L3srcS45[_M0L6_2atmpS1999];
        if (
          _M0L6_2atmpS1997 < 0
          || _M0L6_2atmpS1997 >= Moonbit_array_length(_M0L3dstS44)
        ) {
          #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2aoldS4204 = (struct _M0TUsiE*)_M0L3dstS44[_M0L6_2atmpS1997];
        if (_M0L6_2atmpS1998) {
          moonbit_incref(_M0L6_2atmpS1998);
        }
        if (_M0L6_2aoldS4204) {
          moonbit_decref(_M0L6_2aoldS4204);
        }
        _M0L3dstS44[_M0L6_2atmpS1997] = _M0L6_2atmpS1998;
        _M0L6_2atmpS2000 = _M0L1iS48 + 1;
        _M0L1iS48 = _M0L6_2atmpS2000;
        continue;
      } else {
        moonbit_decref(_M0L3srcS45);
        moonbit_decref(_M0L3dstS44);
      }
      break;
    }
  } else {
    int32_t _M0L6_2atmpS2005 = _M0L3lenS49 - 1;
    int32_t _M0L1iS51 = _M0L6_2atmpS2005;
    while (1) {
      if (_M0L1iS51 >= 0) {
        int32_t _M0L6_2atmpS2001 = _M0L11dst__offsetS46 + _M0L1iS51;
        int32_t _M0L6_2atmpS2003 = _M0L11src__offsetS47 + _M0L1iS51;
        struct _M0TUsiE* _M0L6_2atmpS2002;
        struct _M0TUsiE* _M0L6_2aoldS4206;
        int32_t _M0L6_2atmpS2004;
        if (
          _M0L6_2atmpS2003 < 0
          || _M0L6_2atmpS2003 >= Moonbit_array_length(_M0L3srcS45)
        ) {
          #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2atmpS2002 = (struct _M0TUsiE*)_M0L3srcS45[_M0L6_2atmpS2003];
        if (
          _M0L6_2atmpS2001 < 0
          || _M0L6_2atmpS2001 >= Moonbit_array_length(_M0L3dstS44)
        ) {
          #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2aoldS4206 = (struct _M0TUsiE*)_M0L3dstS44[_M0L6_2atmpS2001];
        if (_M0L6_2atmpS2002) {
          moonbit_incref(_M0L6_2atmpS2002);
        }
        if (_M0L6_2aoldS4206) {
          moonbit_decref(_M0L6_2aoldS4206);
        }
        _M0L3dstS44[_M0L6_2atmpS2001] = _M0L6_2atmpS2002;
        _M0L6_2atmpS2004 = _M0L1iS51 - 1;
        _M0L1iS51 = _M0L6_2atmpS2004;
        continue;
      } else {
        moonbit_decref(_M0L3srcS45);
        moonbit_decref(_M0L3dstS44);
      }
      break;
    }
  }
  return 0;
}

int32_t _M0MPC15array10FixedArray12unsafe__blitGRPB17UnsafeMaybeUninitGRPC15debug9ReprDeltaEE(
  void** _M0L3dstS53,
  int32_t _M0L11dst__offsetS55,
  void** _M0L3srcS54,
  int32_t _M0L11src__offsetS56,
  int32_t _M0L3lenS58
) {
  int32_t _if__result_4636;
  #line 38 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
  if (_M0L3dstS53 == _M0L3srcS54) {
    _if__result_4636 = _M0L11dst__offsetS55 < _M0L11src__offsetS56;
  } else {
    _if__result_4636 = 0;
  }
  if (_if__result_4636) {
    int32_t _M0L1iS57 = 0;
    while (1) {
      if (_M0L1iS57 < _M0L3lenS58) {
        int32_t _M0L6_2atmpS2006 = _M0L11dst__offsetS55 + _M0L1iS57;
        int32_t _M0L6_2atmpS2008 = _M0L11src__offsetS56 + _M0L1iS57;
        void* _M0L6_2atmpS2007;
        void* _M0L6_2aoldS4208;
        int32_t _M0L6_2atmpS2009;
        if (
          _M0L6_2atmpS2008 < 0
          || _M0L6_2atmpS2008 >= Moonbit_array_length(_M0L3srcS54)
        ) {
          #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2atmpS2007 = (void*)_M0L3srcS54[_M0L6_2atmpS2008];
        if (
          _M0L6_2atmpS2006 < 0
          || _M0L6_2atmpS2006 >= Moonbit_array_length(_M0L3dstS53)
        ) {
          #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2aoldS4208 = (void*)_M0L3dstS53[_M0L6_2atmpS2006];
        moonbit_incref(_M0L6_2atmpS2007);
        moonbit_decref(_M0L6_2aoldS4208);
        _M0L3dstS53[_M0L6_2atmpS2006] = _M0L6_2atmpS2007;
        _M0L6_2atmpS2009 = _M0L1iS57 + 1;
        _M0L1iS57 = _M0L6_2atmpS2009;
        continue;
      } else {
        moonbit_decref(_M0L3srcS54);
        moonbit_decref(_M0L3dstS53);
      }
      break;
    }
  } else {
    int32_t _M0L6_2atmpS2014 = _M0L3lenS58 - 1;
    int32_t _M0L1iS60 = _M0L6_2atmpS2014;
    while (1) {
      if (_M0L1iS60 >= 0) {
        int32_t _M0L6_2atmpS2010 = _M0L11dst__offsetS55 + _M0L1iS60;
        int32_t _M0L6_2atmpS2012 = _M0L11src__offsetS56 + _M0L1iS60;
        void* _M0L6_2atmpS2011;
        void* _M0L6_2aoldS4210;
        int32_t _M0L6_2atmpS2013;
        if (
          _M0L6_2atmpS2012 < 0
          || _M0L6_2atmpS2012 >= Moonbit_array_length(_M0L3srcS54)
        ) {
          #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2atmpS2011 = (void*)_M0L3srcS54[_M0L6_2atmpS2012];
        if (
          _M0L6_2atmpS2010 < 0
          || _M0L6_2atmpS2010 >= Moonbit_array_length(_M0L3dstS53)
        ) {
          #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2aoldS4210 = (void*)_M0L3dstS53[_M0L6_2atmpS2010];
        moonbit_incref(_M0L6_2atmpS2011);
        moonbit_decref(_M0L6_2aoldS4210);
        _M0L3dstS53[_M0L6_2atmpS2010] = _M0L6_2atmpS2011;
        _M0L6_2atmpS2013 = _M0L1iS60 - 1;
        _M0L1iS60 = _M0L6_2atmpS2013;
        continue;
      } else {
        moonbit_decref(_M0L3srcS54);
        moonbit_decref(_M0L3dstS53);
      }
      break;
    }
  }
  return 0;
}

int32_t _M0MPC15array10FixedArray12unsafe__blitGRPB17UnsafeMaybeUninitGRPC16string10StringViewEE(
  struct _M0TPC16string10StringView* _M0L3dstS62,
  int32_t _M0L11dst__offsetS64,
  struct _M0TPC16string10StringView* _M0L3srcS63,
  int32_t _M0L11src__offsetS65,
  int32_t _M0L3lenS67
) {
  int32_t _if__result_4639;
  #line 38 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
  if (_M0L3dstS62 == _M0L3srcS63) {
    _if__result_4639 = _M0L11dst__offsetS64 < _M0L11src__offsetS65;
  } else {
    _if__result_4639 = 0;
  }
  if (_if__result_4639) {
    int32_t _M0L1iS66 = 0;
    while (1) {
      if (_M0L1iS66 < _M0L3lenS67) {
        int32_t _M0L6_2atmpS2015 = _M0L11dst__offsetS64 + _M0L1iS66;
        int32_t _M0L6_2atmpS2017 = _M0L11src__offsetS65 + _M0L1iS66;
        struct _M0TPC16string10StringView _M0L6_2atmpS2016;
        struct _M0TPC16string10StringView _M0L6_2aoldS4212;
        int32_t _M0L6_2atmpS2018;
        if (
          _M0L6_2atmpS2017 < 0
          || _M0L6_2atmpS2017 >= Moonbit_array_length(_M0L3srcS63)
        ) {
          #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2atmpS2016 = _M0L3srcS63[_M0L6_2atmpS2017];
        if (
          _M0L6_2atmpS2015 < 0
          || _M0L6_2atmpS2015 >= Moonbit_array_length(_M0L3dstS62)
        ) {
          #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2aoldS4212 = _M0L3dstS62[_M0L6_2atmpS2015];
        moonbit_incref(_M0L6_2atmpS2016.$0);
        moonbit_decref(_M0L6_2aoldS4212.$0);
        _M0L3dstS62[_M0L6_2atmpS2015] = _M0L6_2atmpS2016;
        _M0L6_2atmpS2018 = _M0L1iS66 + 1;
        _M0L1iS66 = _M0L6_2atmpS2018;
        continue;
      } else {
        moonbit_decref(_M0L3srcS63);
        moonbit_decref(_M0L3dstS62);
      }
      break;
    }
  } else {
    int32_t _M0L6_2atmpS2023 = _M0L3lenS67 - 1;
    int32_t _M0L1iS69 = _M0L6_2atmpS2023;
    while (1) {
      if (_M0L1iS69 >= 0) {
        int32_t _M0L6_2atmpS2019 = _M0L11dst__offsetS64 + _M0L1iS69;
        int32_t _M0L6_2atmpS2021 = _M0L11src__offsetS65 + _M0L1iS69;
        struct _M0TPC16string10StringView _M0L6_2atmpS2020;
        struct _M0TPC16string10StringView _M0L6_2aoldS4214;
        int32_t _M0L6_2atmpS2022;
        if (
          _M0L6_2atmpS2021 < 0
          || _M0L6_2atmpS2021 >= Moonbit_array_length(_M0L3srcS63)
        ) {
          #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2atmpS2020 = _M0L3srcS63[_M0L6_2atmpS2021];
        if (
          _M0L6_2atmpS2019 < 0
          || _M0L6_2atmpS2019 >= Moonbit_array_length(_M0L3dstS62)
        ) {
          #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2aoldS4214 = _M0L3dstS62[_M0L6_2atmpS2019];
        moonbit_incref(_M0L6_2atmpS2020.$0);
        moonbit_decref(_M0L6_2aoldS4214.$0);
        _M0L3dstS62[_M0L6_2atmpS2019] = _M0L6_2atmpS2020;
        _M0L6_2atmpS2022 = _M0L1iS69 - 1;
        _M0L1iS69 = _M0L6_2atmpS2022;
        continue;
      } else {
        moonbit_decref(_M0L3srcS63);
        moonbit_decref(_M0L3dstS62);
      }
      break;
    }
  }
  return 0;
}

int32_t _M0MPB18UninitializedArray6lengthGsE(moonbit_string_t* _M0L4selfS22) {
  #line 112 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  return Moonbit_array_length(_M0L4selfS22);
}

int32_t _M0MPB18UninitializedArray6lengthGUsiEE(
  struct _M0TUsiE** _M0L4selfS23
) {
  #line 112 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  return Moonbit_array_length(_M0L4selfS23);
}

int32_t _M0MPB18UninitializedArray6lengthGRPC15debug9ReprDeltaE(
  void** _M0L4selfS24
) {
  #line 112 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  return Moonbit_array_length(_M0L4selfS24);
}

int32_t _M0MPB18UninitializedArray6lengthGRPC16string10StringViewE(
  struct _M0TPC16string10StringView* _M0L4selfS25
) {
  #line 112 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  return Moonbit_array_length(_M0L4selfS25);
}

uint32_t _M0FPB13consume4__acc(uint32_t _M0L3accS20, uint32_t _M0L5inputS21) {
  uint32_t _M0L6_2atmpS1978;
  uint32_t _M0L6_2atmpS1977;
  uint32_t _M0L6_2atmpS1976;
  #line 472 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\hasher.mbt"
  _M0L6_2atmpS1978 = _M0L5inputS21 * 3266489917u;
  _M0L6_2atmpS1977 = _M0L3accS20 + _M0L6_2atmpS1978;
  #line 473 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\hasher.mbt"
  _M0L6_2atmpS1976 = _M0FPB4rotl(_M0L6_2atmpS1977, 17);
  return _M0L6_2atmpS1976 * 668265263u;
}

uint32_t _M0FPB4rotl(uint32_t _M0L1xS18, int32_t _M0L1rS19) {
  uint32_t _M0L6_2atmpS1973;
  int32_t _M0L6_2atmpS1975;
  uint32_t _M0L6_2atmpS1974;
  #line 482 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\hasher.mbt"
  _M0L6_2atmpS1973 = _M0L1xS18 << (_M0L1rS19 & 31);
  _M0L6_2atmpS1975 = 32 - _M0L1rS19;
  _M0L6_2atmpS1974 = _M0L1xS18 >> (_M0L6_2atmpS1975 & 31);
  return _M0L6_2atmpS1973 | _M0L6_2atmpS1974;
}

int32_t _M0IPB7FailurePB4Show6output(
  void* _M0L10_2ax__6124S14,
  struct _M0TPB6Logger _M0L10_2ax__6125S17
) {
  struct _M0DTPC15error5Error48moonbitlang_2fcore_2fbuiltin_2eFailure_2eFailure* _M0L10_2aFailureS15;
  moonbit_string_t _M0L15_2a_2aarg__6126S16;
  #line 37 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\failure.mbt"
  _M0L10_2aFailureS15
  = (struct _M0DTPC15error5Error48moonbitlang_2fcore_2fbuiltin_2eFailure_2eFailure*)_M0L10_2ax__6124S14;
  _M0L15_2a_2aarg__6126S16 = _M0L10_2aFailureS15->$0;
  #line 37 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\failure.mbt"
  _M0L10_2ax__6125S17.$0->$method_0(_M0L10_2ax__6125S17.$1, (moonbit_string_t)moonbit_string_literal_66.data);
  #line 37 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\failure.mbt"
  _M0MPB6Logger13write__objectGsE(_M0L10_2ax__6125S17, _M0L15_2a_2aarg__6126S16);
  #line 37 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\failure.mbt"
  _M0L10_2ax__6125S17.$0->$method_0(_M0L10_2ax__6125S17.$1, (moonbit_string_t)moonbit_string_literal_23.data);
  return 0;
}

int32_t _M0MPB6Logger13write__objectGsE(
  struct _M0TPB6Logger _M0L4selfS13,
  moonbit_string_t _M0L3objS12
) {
  #line 173 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  #line 174 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0IP016_24default__implPB4Show6outputGsE(_M0L3objS12, _M0L4selfS13);
  return 0;
}

int32_t _M0FPC15abort5abortGuE(moonbit_string_t _M0L3msgS1) {
  #line 47 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  #line 49 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_println(_M0L3msgS1);
  #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_panic();
  return 0;
}

uint16_t* _M0FPC15abort5abortGAkE(moonbit_string_t _M0L3msgS2) {
  #line 47 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  #line 49 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_println(_M0L3msgS2);
  #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_panic();
}

moonbit_string_t* _M0FPC15abort5abortGRPB18UninitializedArrayGsEE(
  moonbit_string_t _M0L3msgS3
) {
  #line 47 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  #line 49 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_println(_M0L3msgS3);
  #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_panic();
}

struct _M0TUsiE** _M0FPC15abort5abortGRPB18UninitializedArrayGUsiEEE(
  moonbit_string_t _M0L3msgS4
) {
  #line 47 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  #line 49 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_println(_M0L3msgS4);
  #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_panic();
}

struct _M0TPB9ArrayViewGRPC15debug4ReprE _M0FPC15abort5abortGRPB9ArrayViewGRPC15debug4ReprEE(
  moonbit_string_t _M0L3msgS5
) {
  #line 47 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  #line 49 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_println(_M0L3msgS5);
  #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_panic();
}

moonbit_string_t _M0FPC15abort5abortGsE(moonbit_string_t _M0L3msgS6) {
  #line 47 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  #line 49 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_println(_M0L3msgS6);
  #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_panic();
}

struct _M0TPC16string10StringView _M0FPC15abort5abortGRPC16string10StringViewE(
  moonbit_string_t _M0L3msgS7
) {
  #line 47 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  #line 49 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_println(_M0L3msgS7);
  #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_panic();
}

void** _M0FPC15abort5abortGRPB18UninitializedArrayGRPC15debug9ReprDeltaEE(
  moonbit_string_t _M0L3msgS8
) {
  #line 47 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  #line 49 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_println(_M0L3msgS8);
  #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_panic();
}

int32_t _M0FPC15abort5abortGiE(moonbit_string_t _M0L3msgS9) {
  #line 47 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  #line 49 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_println(_M0L3msgS9);
  #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_panic();
}

struct _M0TPC16string10StringView* _M0FPC15abort5abortGRPB18UninitializedArrayGRPC16string10StringViewEE(
  moonbit_string_t _M0L3msgS10
) {
  #line 47 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  #line 49 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_println(_M0L3msgS10);
  #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_panic();
}

int64_t _M0FPC15abort5abortGOiE(moonbit_string_t _M0L3msgS11) {
  #line 47 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  #line 49 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_println(_M0L3msgS11);
  #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_panic();
}

moonbit_string_t _M0FP15Error10to__string(void* _M0L4_2aeS1934) {
  switch (Moonbit_object_tag(_M0L4_2aeS1934)) {
    case 2: {
      return (moonbit_string_t)moonbit_string_literal_67.data;
      break;
    }
    
    case 4: {
      return (moonbit_string_t)moonbit_string_literal_68.data;
      break;
    }
    
    case 0: {
      return _M0IP016_24default__implPB4Show10to__stringGRPB7FailureE(_M0L4_2aeS1934);
      break;
    }
    
    case 3: {
      return (moonbit_string_t)moonbit_string_literal_69.data;
      break;
    }
    default: {
      return (moonbit_string_t)moonbit_string_literal_70.data;
      break;
    }
  }
}

int32_t _M0IP016_24default__implPB6Logger61write_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLoggerGRPB13StringBuilderE(
  void* _M0L11_2aobj__ptrS1958,
  struct _M0TPB4Show _M0L8_2aparamS1957
) {
  struct _M0TPB13StringBuilder* _M0L7_2aselfS1956 =
    (struct _M0TPB13StringBuilder*)_M0L11_2aobj__ptrS1958;
  _M0IP016_24default__implPB6Logger5writeGRPB13StringBuilderE(_M0L7_2aselfS1956, _M0L8_2aparamS1957);
  return 0;
}

int32_t _M0IP016_24default__implPB6Logger84write__string__interpolation_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLoggerGRPB13StringBuilderE(
  void* _M0L11_2aobj__ptrS1955,
  struct _M0TPB4Show _M0L8_2aparamS1954
) {
  struct _M0TPB13StringBuilder* _M0L7_2aselfS1953 =
    (struct _M0TPB13StringBuilder*)_M0L11_2aobj__ptrS1955;
  _M0IP016_24default__implPB6Logger28write__string__interpolationGRPB13StringBuilderE(_M0L7_2aselfS1953, _M0L8_2aparamS1954);
  return 0;
}

int32_t _M0IPB13StringBuilderPB6Logger67write__char_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLogger(
  void* _M0L11_2aobj__ptrS1952,
  int32_t _M0L8_2aparamS1951
) {
  struct _M0TPB13StringBuilder* _M0L7_2aselfS1950 =
    (struct _M0TPB13StringBuilder*)_M0L11_2aobj__ptrS1952;
  _M0IPB13StringBuilderPB6Logger11write__char(_M0L7_2aselfS1950, _M0L8_2aparamS1951);
  return 0;
}

int32_t _M0IPB13StringBuilderPB6Logger67write__view_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLogger(
  void* _M0L11_2aobj__ptrS1949,
  struct _M0TPC16string10StringView _M0L8_2aparamS1948
) {
  struct _M0TPB13StringBuilder* _M0L7_2aselfS1947 =
    (struct _M0TPB13StringBuilder*)_M0L11_2aobj__ptrS1949;
  _M0IPB13StringBuilderPB6Logger11write__view(_M0L7_2aselfS1947, _M0L8_2aparamS1948);
  return 0;
}

int32_t _M0IP016_24default__implPB6Logger72write__substring_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLoggerGRPB13StringBuilderE(
  void* _M0L11_2aobj__ptrS1946,
  moonbit_string_t _M0L8_2aparamS1943,
  int32_t _M0L8_2aparamS1944,
  int32_t _M0L8_2aparamS1945
) {
  struct _M0TPB13StringBuilder* _M0L7_2aselfS1942 =
    (struct _M0TPB13StringBuilder*)_M0L11_2aobj__ptrS1946;
  _M0IP016_24default__implPB6Logger16write__substringGRPB13StringBuilderE(_M0L7_2aselfS1942, _M0L8_2aparamS1943, _M0L8_2aparamS1944, _M0L8_2aparamS1945);
  return 0;
}

int32_t _M0IPB13StringBuilderPB6Logger69write__string_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLogger(
  void* _M0L11_2aobj__ptrS1941,
  moonbit_string_t _M0L8_2aparamS1940
) {
  struct _M0TPB13StringBuilder* _M0L7_2aselfS1939 =
    (struct _M0TPB13StringBuilder*)_M0L11_2aobj__ptrS1941;
  _M0IPB13StringBuilderPB6Logger13write__string(_M0L7_2aselfS1939, _M0L8_2aparamS1940);
  return 0;
}

void moonbit_init() {
  moonbit_layout_table = moonbit_layout_table_data;
  moonbit_string_t* _M0L6_2atmpS1972 =
    (moonbit_string_t*)moonbit_make_ref_array_raw(1);
  struct _M0TUWEuQRPC15error5ErrorNsE* _M0L8_2atupleS1971;
  struct _M0TUiUWEuQRPC15error5ErrorNsEE* _M0L8_2atupleS1970;
  struct _M0TUiUWEuQRPC15error5ErrorNsEE** _M0L7_2abindS1857;
  struct _M0TUiUWEuQRPC15error5ErrorNsEE** _M0L6_2atmpS1969;
  struct _M0TPB9ArrayViewGUiUWEuQRPC15error5ErrorNsEEE _M0L6_2atmpS1968;
  struct _M0TPB3MapGiUWEuQRPC15error5ErrorNsEE* _M0L6_2atmpS1967;
  struct _M0TUsRPB3MapGiUWEuQRPC15error5ErrorNsEEE* _M0L8_2atupleS1966;
  struct _M0TUsRPB3MapGiUWEuQRPC15error5ErrorNsEEE** _M0L7_2abindS1856;
  struct _M0TUsRPB3MapGiUWEuQRPC15error5ErrorNsEEE** _M0L6_2atmpS1965;
  struct _M0TPB9ArrayViewGUsRPB3MapGiUWEuQRPC15error5ErrorNsEEEE _M0L6_2atmpS1964;
  _M0L6_2atmpS1972[0] = (moonbit_string_t)moonbit_string_literal_71.data;
  moonbit_incref(_M0FP27walkzzz27mcp__server__blackbox__test41____test__657870656e73652e6d6274__0_2eclo);
  _M0L8_2atupleS1971
  = (struct _M0TUWEuQRPC15error5ErrorNsE*)moonbit_malloc(sizeof(struct _M0TUWEuQRPC15error5ErrorNsE));
  Moonbit_object_header(_M0L8_2atupleS1971)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 171, 0);
  _M0L8_2atupleS1971->$0
  = _M0FP27walkzzz27mcp__server__blackbox__test41____test__657870656e73652e6d6274__0_2eclo;
  _M0L8_2atupleS1971->$1 = _M0L6_2atmpS1972;
  _M0L8_2atupleS1970
  = (struct _M0TUiUWEuQRPC15error5ErrorNsEE*)moonbit_malloc(sizeof(struct _M0TUiUWEuQRPC15error5ErrorNsEE));
  Moonbit_object_header(_M0L8_2atupleS1970)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 175, 0);
  _M0L8_2atupleS1970->$0 = 0;
  _M0L8_2atupleS1970->$1 = _M0L8_2atupleS1971;
  _M0L7_2abindS1857
  = (struct _M0TUiUWEuQRPC15error5ErrorNsEE**)moonbit_make_ref_array_raw(1);
  _M0L7_2abindS1857[0] = _M0L8_2atupleS1970;
  _M0L6_2atmpS1969 = _M0L7_2abindS1857;
  _M0L6_2atmpS1968
  = (struct _M0TPB9ArrayViewGUiUWEuQRPC15error5ErrorNsEEE){
    .$0 = _M0L6_2atmpS1969, .$1 = 0, .$2 = 1
  };
  #line 448 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L6_2atmpS1967
  = _M0MPB3Map3MapGiUWEuQRPC15error5ErrorNsEE(_M0L6_2atmpS1968, 4294967296ll);
  moonbit_decref(_M0L6_2atmpS1968.$0);
  _M0L8_2atupleS1966
  = (struct _M0TUsRPB3MapGiUWEuQRPC15error5ErrorNsEEE*)moonbit_malloc(sizeof(struct _M0TUsRPB3MapGiUWEuQRPC15error5ErrorNsEEE));
  Moonbit_object_header(_M0L8_2atupleS1966)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 178, 0);
  _M0L8_2atupleS1966->$0 = (moonbit_string_t)moonbit_string_literal_72.data;
  _M0L8_2atupleS1966->$1 = _M0L6_2atmpS1967;
  _M0L7_2abindS1856
  = (struct _M0TUsRPB3MapGiUWEuQRPC15error5ErrorNsEEE**)moonbit_make_ref_array_raw(1);
  _M0L7_2abindS1856[0] = _M0L8_2atupleS1966;
  _M0L6_2atmpS1965 = _M0L7_2abindS1856;
  _M0L6_2atmpS1964
  = (struct _M0TPB9ArrayViewGUsRPB3MapGiUWEuQRPC15error5ErrorNsEEEE){
    .$0 = _M0L6_2atmpS1965, .$1 = 0, .$2 = 1
  };
  #line 447 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0FP27walkzzz27mcp__server__blackbox__test48moonbit__test__driver__internal__no__args__tests
  = _M0MPB3Map3MapGsRPB3MapGiUWEuQRPC15error5ErrorNsEEE(_M0L6_2atmpS1964, 4294967296ll);
  moonbit_decref(_M0L6_2atmpS1964.$0);
}

int main(int argc, char** argv) {
  struct _M0TWWuEuWRPC15error5ErrorEuEOuQRPC15error5Error** _M0L6_2atmpS1963;
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE* _M0L12async__testsS1928;
  struct _M0TPB5ArrayGUsiEE* _M0L7_2abindS1929;
  int32_t _M0L7_2abindS1930;
  int32_t _M0L2__S1931;
  moonbit_runtime_init(argc, argv);
  moonbit_init();
  _M0L6_2atmpS1963
  = (struct _M0TWWuEuWRPC15error5ErrorEuEOuQRPC15error5Error**)moonbit_empty_ref_array;
  _M0L12async__testsS1928
  = (struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE));
  Moonbit_object_header(_M0L12async__testsS1928)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 182, 0);
  _M0L12async__testsS1928->$0 = _M0L6_2atmpS1963;
  _M0L12async__testsS1928->$1 = 0;
  #line 490 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0L7_2abindS1929
  = _M0FP27walkzzz27mcp__server__blackbox__test52moonbit__test__driver__internal__native__parse__args();
  _M0L7_2abindS1930 = _M0L7_2abindS1929->$1;
  _M0L2__S1931 = 0;
  while (1) {
    if (_M0L2__S1931 < _M0L7_2abindS1930) {
      struct _M0TUsiE** _M0L3bufS1962 = _M0L7_2abindS1929->$0;
      struct _M0TUsiE* _M0L3argS1932 =
        (struct _M0TUsiE*)_M0L3bufS1962[_M0L2__S1931];
      moonbit_string_t _M0L6_2atmpS1959 = _M0L3argS1932->$0;
      int32_t _M0L6_2atmpS1960 = _M0L3argS1932->$1;
      int32_t _M0L6_2atmpS1961;
      moonbit_incref(_M0L6_2atmpS1959);
      #line 491 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
      _M0FP27walkzzz27mcp__server__blackbox__test44moonbit__test__driver__internal__do__execute(_M0L12async__testsS1928, _M0L6_2atmpS1959, _M0L6_2atmpS1960);
      moonbit_decref(_M0L6_2atmpS1959);
      _M0L6_2atmpS1961 = _M0L2__S1931 + 1;
      _M0L2__S1931 = _M0L6_2atmpS1961;
      continue;
    } else {
      moonbit_decref(_M0L7_2abindS1929);
    }
    break;
  }
  #line 493 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_blackbox_test.mbt"
  _M0IP016_24default__implP27walkzzz27mcp__server__blackbox__test28MoonBit__Async__Test__Driver17run__async__testsGRP27walkzzz27mcp__server__blackbox__test34MoonBit__Async__Test__Driver__ImplE(_M0L12async__testsS1928);
  moonbit_decref(_M0L12async__testsS1928);
  return 0;
}