#ifdef __cplusplus
extern "C" {
#endif

#include "moonbit.h"
#include "moonbit_runtime.h"
#include "moonbit_simd.h"

#ifdef _MSC_VER
#define _Noreturn __declspec(noreturn)
#endif

#if defined(__clang__)
#pragma clang diagnostic ignored "-Wshift-op-parentheses"
#pragma clang diagnostic ignored "-Wtautological-compare"
#endif

// TinyCC's in-memory run mode has no executable of its own; an OS lookup would
// report the host process instead.
#if defined(__TCC_RUN__)
#define moonbit_rt_get_current_exe moonbit_rt_get_current_exe_tcc
#endif

MOONBIT_EXPORT _Noreturn void moonbit_panic(void);
MOONBIT_EXPORT void *moonbit_malloc_array(enum moonbit_block_kind kind,
                                          int elem_size_shift, int32_t len);
int memcmp(const void *s1, const void *s2, size_t n);
MOONBIT_EXPORT int moonbit_val_array_equal_sized(const void *lhs,
                                                 const void *rhs,
                                                 int32_t elem_size);
MOONBIT_EXPORT moonbit_string_t moonbit_add_string(moonbit_string_t s1,
                                                   moonbit_string_t s2);
MOONBIT_EXPORT void moonbit_unsafe_bytes_blit(moonbit_bytes_t dst,
                                              int32_t dst_start,
                                              moonbit_bytes_t src,
                                              int32_t src_offset, int32_t len);
MOONBIT_EXPORT moonbit_string_t moonbit_unsafe_bytes_sub_string(
    moonbit_bytes_t bytes, int32_t start, int32_t len);
MOONBIT_EXPORT int32_t moonbit_unsafe_val_array_blit(void *dst,
                                                     int32_t dst_offset,
                                                     void *src,
                                                     int32_t src_offset,
                                                     int32_t len,
                                                     int32_t elem_size);
MOONBIT_EXPORT int32_t moonbit_unsafe_ref_array_blit(void *dst,
                                                     int32_t dst_offset,
                                                     void *src,
                                                     int32_t src_offset,
                                                     int32_t len);
MOONBIT_EXPORT void moonbit_println(moonbit_string_t str);
MOONBIT_EXPORT moonbit_bytes_t *moonbit_get_cli_args(void);
MOONBIT_EXPORT void moonbit_runtime_init(int argc, char **argv);
MOONBIT_EXPORT void moonbit_drop_object(void *);
// Slow paths of the inlined value-enum retain/release below (defined in
// runtime.c). Internal helpers, so declared here rather than in the public
// moonbit.h; reached only when a value's current variant carries references.
MOONBIT_EXPORT void moonbit_incref_value_enum_loop(void *p);
MOONBIT_EXPORT void moonbit_decref_value_enum_loop(void *p);
MOONBIT_EXPORT int32_t moonbit_utf16_len_from_utf8(moonbit_bytes_t src,
                                                   int32_t src_offset,
                                                   int32_t src_length);
MOONBIT_EXPORT int32_t moonbit_utf8_decode_into_utf16(
    moonbit_bytes_t src, int32_t src_offset, int32_t src_length,
    moonbit_string_t dst, int32_t dst_offset);
MOONBIT_EXPORT int32_t moonbit_utf8_decode_lossy_into_utf16(
    moonbit_bytes_t src, int32_t src_offset, int32_t src_length,
    moonbit_string_t dst, int32_t dst_offset);
MOONBIT_EXPORT int32_t moonbit_utf8_len_from_utf16(moonbit_string_t src,
                                                   int32_t src_offset,
                                                   int32_t src_length);
MOONBIT_EXPORT int32_t moonbit_utf8_encode_from_utf16(
    moonbit_string_t src, int32_t src_offset, int32_t src_length,
    moonbit_bytes_t dst, int32_t dst_offset);

#if !defined(_WIN64) && !defined(_WIN32)
void *malloc(size_t size);
void free(void *ptr);
#define libc_malloc malloc
#define libc_free free
#endif

// several important runtime functions are inlined
static void *moonbit_malloc_inlined(size_t size) {
  struct moonbit_object *ptr = (struct moonbit_object *)libc_malloc(
      sizeof(struct moonbit_object) + size);
  Moonbit_init_dynamic_rc(ptr, moonbit_BLOCK_KIND_REGULAR);
  return ptr + 1;
}

#define moonbit_malloc(obj) moonbit_malloc_inlined(obj)
#define moonbit_free(obj) libc_free(Moonbit_object_header(obj))

#define MOONBIT_RC_COUNT_UNIT ((int32_t)(1u << MOONBIT_RC_COUNT_SHIFT))
#define raw_rc_is_dynamic(rc) ((int32_t)(rc) >= MOONBIT_RC_COUNT_UNIT)
#define raw_rc_is_shared(rc) ((int32_t)(rc) >= (MOONBIT_RC_COUNT_UNIT * 2))

static inline int32_t moonbit_unsafe_obj_cycle_capable(void *ptr) {
  return MOONBIT_IN_ROOT(ptr) ||
         !MOONBIT_CHECK_CYCLE_STATUS(
             ptr, moonbit_CYCLE_STATUS_ACYCLIC_OR_CANDIDATE);
}

extern const uint32_t *moonbit_layout_table;

static void moonbit_incref_inlined(void *ptr) {
  struct moonbit_object *header = Moonbit_object_header(ptr);
  int32_t const rc = header->rc;
  if (raw_rc_is_dynamic(rc)) {
    Moonbit_increase_rc_count(header);
  }
}

#define moonbit_incref moonbit_incref_inlined

static void moonbit_decref_inlined(void *ptr) {
  struct moonbit_object *header = Moonbit_object_header(ptr);
  int32_t const rc = header->rc;
  if (raw_rc_is_shared(rc)) {
    header->rc = rc - MOONBIT_RC_COUNT_UNIT;
  } else if (raw_rc_is_dynamic(rc)) {
    moonbit_drop_object(ptr);
  }
}

#define moonbit_decref moonbit_decref_inlined

// Value-enum retain/release: inline the cheap "does the current variant carry
// references?" test (a header read + class compare) so scalar-tag moves pay no
// call, and delegate the reference-walking loop to the out-of-line slow path in
// runtime.c. Mirrors the moonbit_incref/decref fast/slow split above.
static inline void moonbit_incref_value_enum_inlined(void *p) {
  if (Moonbit_header_layout_class(*(uint32_t *)p) ==
      MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED)
    moonbit_incref_value_enum_loop(p);
}

#define moonbit_incref_value_enum moonbit_incref_value_enum_inlined

static inline void moonbit_decref_value_enum_inlined(void *p) {
  if (Moonbit_header_layout_class(*(uint32_t *)p) ==
      MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED)
    moonbit_decref_value_enum_loop(p);
}

#define moonbit_decref_value_enum moonbit_decref_value_enum_inlined

#define moonbit_unsafe_make_string moonbit_make_string

#if defined(MOONBIT_V128_NEON)
#define Moonbit_v128_make(lo, hi)                                             \
  vreinterpretq_u8_u64(                                                       \
      vcombine_u64(vcreate_u64((uint64_t)(lo)), vcreate_u64((uint64_t)(hi))))
#define Moonbit_v128_lo(v) vgetq_lane_u64(vreinterpretq_u64_u8(v), 0)
#define Moonbit_v128_hi(v) vgetq_lane_u64(vreinterpretq_u64_u8(v), 1)
#define Moonbit_v128_load_storage(p) vld1q_u8((const uint8_t *)(p))
#define Moonbit_v128_store_storage(p, v) vst1q_u8((uint8_t *)(p), (v))
#elif defined(MOONBIT_V128_SSE2)
#define Moonbit_v128_make(lo, hi) _mm_set_epi64x((int64_t)(hi), (int64_t)(lo))
#define Moonbit_v128_lo(v) ((uint64_t)_mm_cvtsi128_si64(v))
#define Moonbit_v128_hi(v) ((uint64_t)_mm_cvtsi128_si64(_mm_srli_si128((v), 8)))
#define Moonbit_v128_load_storage(p) _mm_loadu_si128((const __m128i *)(p))
#define Moonbit_v128_store_storage(p, v) _mm_storeu_si128((__m128i *)(p), (v))
#else
#define Moonbit_v128_make(lo, hi) ((moonbit_v128_t){(lo), (hi)})
#define Moonbit_v128_lo(v) ((v).lo)
#define Moonbit_v128_hi(v) ((v).hi)
#define Moonbit_v128_load_storage(p) (*(p))
#define Moonbit_v128_store_storage(p, v) (*(p) = (v))
#endif

// detect whether compiler builtins exist for advanced bitwise operations
#ifdef __has_builtin

#if __has_builtin(__builtin_clz)
#define HAS_BUILTIN_CLZ
#endif

#if __has_builtin(__builtin_ctz)
#define HAS_BUILTIN_CTZ
#endif

#if __has_builtin(__builtin_popcount)
#define HAS_BUILTIN_POPCNT
#endif

#if __has_builtin(__builtin_sqrt)
#define HAS_BUILTIN_SQRT
#endif

#if __has_builtin(__builtin_sqrtf)
#define HAS_BUILTIN_SQRTF
#endif

#if __has_builtin(__builtin_fabs)
#define HAS_BUILTIN_FABS
#endif

#if __has_builtin(__builtin_fabsf)
#define HAS_BUILTIN_FABSF
#endif

#endif

// if there is no builtin operators, use software implementation
#ifdef HAS_BUILTIN_CLZ
static inline int32_t moonbit_clz32(int32_t x) {
  return x == 0 ? 32 : __builtin_clz(x);
}

static inline int32_t moonbit_clz64(int64_t x) {
  return x == 0 ? 64 : __builtin_clzll(x);
}

#undef HAS_BUILTIN_CLZ
#else
// table for [clz] value of 4bit integer.
static const uint8_t moonbit_clz4[] = {4, 3, 2, 2, 1, 1, 1, 1,
                                       0, 0, 0, 0, 0, 0, 0, 0};

int32_t moonbit_clz32(uint32_t x) {
  /* The ideas is to:

     1. narrow down the 4bit block where the most signficant "1" bit lies,
        using binary search
     2. find the number of leading zeros in that 4bit block via table lookup

     Different time/space tradeoff can be made here by enlarging the table
     and do less binary search.
     One benefit of the 4bit lookup table is that it can fit into a single cache
     line.
  */
  int32_t result = 0;
  if (x > 0xffff) {
    x >>= 16;
  } else {
    result += 16;
  }
  if (x > 0xff) {
    x >>= 8;
  } else {
    result += 8;
  }
  if (x > 0xf) {
    x >>= 4;
  } else {
    result += 4;
  }
  return result + moonbit_clz4[x];
}

int32_t moonbit_clz64(uint64_t x) {
  int32_t result = 0;
  if (x > 0xffffffff) {
    x >>= 32;
  } else {
    result += 32;
  }
  return result + moonbit_clz32((uint32_t)x);
}
#endif

#ifdef HAS_BUILTIN_CTZ
static inline int32_t moonbit_ctz32(int32_t x) {
  return x == 0 ? 32 : __builtin_ctz(x);
}

static inline int32_t moonbit_ctz64(int64_t x) {
  return x == 0 ? 64 : __builtin_ctzll(x);
}

#undef HAS_BUILTIN_CTZ
#else
int32_t moonbit_ctz32(int32_t x) {
  /* The algorithm comes from:

       Leiserson, Charles E. et al. “Using de Bruijn Sequences to Index a 1 in a
     Computer Word.” (1998).

     The ideas is:

     1. leave only the least significant "1" bit in the input,
        set all other bits to "0". This is achieved via [x & -x]
     2. now we have [x * n == n << ctz(x)], if [n] is a de bruijn sequence
        (every 5bit pattern occurn exactly once when you cycle through the bit
     string), we can find [ctz(x)] from the most significant 5 bits of [x * n]
 */
  static const uint32_t de_bruijn_32 = 0x077CB531;
  static const uint8_t index32[] = {0,  1,  28, 2,  29, 14, 24, 3,  30, 22, 20,
                                    15, 25, 17, 4,  8,  31, 27, 13, 23, 21, 19,
                                    16, 7,  26, 12, 18, 6,  11, 5,  10, 9};
  return (x == 0) * 32 + index32[(de_bruijn_32 * (x & -x)) >> 27];
}

int32_t moonbit_ctz64(int64_t x) {
  static const uint64_t de_bruijn_64 = 0x0218A392CD3D5DBF;
  static const uint8_t index64[] = {
      0,  1,  2,  7,  3,  13, 8,  19, 4,  25, 14, 28, 9,  34, 20, 40,
      5,  17, 26, 38, 15, 46, 29, 48, 10, 31, 35, 54, 21, 50, 41, 57,
      63, 6,  12, 18, 24, 27, 33, 39, 16, 37, 45, 47, 30, 53, 49, 56,
      62, 11, 23, 32, 36, 44, 52, 55, 61, 22, 43, 51, 60, 42, 59, 58};
  return (x == 0) * 64 + index64[(de_bruijn_64 * (x & -x)) >> 58];
}
#endif

#ifdef HAS_BUILTIN_POPCNT

#define moonbit_popcnt32 __builtin_popcount
#define moonbit_popcnt64 __builtin_popcountll
#undef HAS_BUILTIN_POPCNT

#else
int32_t moonbit_popcnt32(uint32_t x) {
  /* The classic SIMD Within A Register algorithm.
     ref: [https://nimrod.blog/posts/algorithms-behind-popcount/]
 */
  x = x - ((x >> 1) & 0x55555555);
  x = (x & 0x33333333) + ((x >> 2) & 0x33333333);
  x = (x + (x >> 4)) & 0x0F0F0F0F;
  return (x * 0x01010101) >> 24;
}

int32_t moonbit_popcnt64(uint64_t x) {
  x = x - ((x >> 1) & 0x5555555555555555);
  x = (x & 0x3333333333333333) + ((x >> 2) & 0x3333333333333333);
  x = (x + (x >> 4)) & 0x0F0F0F0F0F0F0F0F;
  return (x * 0x0101010101010101) >> 56;
}
#endif

/* Full 64x64->128 multiplication. Write directly into the destination value
   struct so the generated code does not depend on a matching runtime struct
   layout. Compilers without native 128-bit integers (e.g. tcc, MSVC) use the
   32x32 schoolbook decomposition. */
static inline void moonbit_umul_wide(uint64_t *out_lo, uint64_t *out_hi,
                                     uint64_t a, uint64_t b) {
#if defined(__SIZEOF_INT128__)
  unsigned __int128 r = (unsigned __int128)a * (unsigned __int128)b;
  *out_lo = (uint64_t)r;
  *out_hi = (uint64_t)(r >> 64);
#else
  uint64_t alo = a & 0xffffffff, ahi = a >> 32;
  uint64_t blo = b & 0xffffffff, bhi = b >> 32;
  uint64_t ll = alo * blo;
  uint64_t lh = alo * bhi;
  uint64_t hl = ahi * blo;
  uint64_t hh = ahi * bhi;
  uint64_t mid = (ll >> 32) + (lh & 0xffffffff) + (hl & 0xffffffff);
  *out_lo = a * b;
  *out_hi = hh + (lh >> 32) + (hl >> 32) + (mid >> 32);
#endif
}

static inline void moonbit_smul_wide(uint64_t *out_lo, int64_t *out_hi,
                                     int64_t a, int64_t b) {
#if defined(__SIZEOF_INT128__)
  __int128 r = (__int128)a * (__int128)b;
  *out_lo = (uint64_t)r;
  *out_hi = (int64_t)(r >> 64);
#else
  uint64_t hi;
  moonbit_umul_wide(out_lo, &hi, (uint64_t)a, (uint64_t)b);
  uint64_t correction_a = a < 0 ? (uint64_t)b : 0;
  uint64_t correction_b = b < 0 ? (uint64_t)a : 0;
  *out_hi = (int64_t)(hi - correction_a - correction_b);
#endif
}

/* The following sqrt implementation comes from
   [musl](https://git.musl-libc.org/cgit/musl),
   with some helpers inlined to make it zero dependency.
 */
#ifdef MOONBIT_NATIVE_NO_SYS_HEADER
const uint16_t __rsqrt_tab[128] = {
    0xb451, 0xb2f0, 0xb196, 0xb044, 0xaef9, 0xadb6, 0xac79, 0xab43, 0xaa14,
    0xa8eb, 0xa7c8, 0xa6aa, 0xa592, 0xa480, 0xa373, 0xa26b, 0xa168, 0xa06a,
    0x9f70, 0x9e7b, 0x9d8a, 0x9c9d, 0x9bb5, 0x9ad1, 0x99f0, 0x9913, 0x983a,
    0x9765, 0x9693, 0x95c4, 0x94f8, 0x9430, 0x936b, 0x92a9, 0x91ea, 0x912e,
    0x9075, 0x8fbe, 0x8f0a, 0x8e59, 0x8daa, 0x8cfe, 0x8c54, 0x8bac, 0x8b07,
    0x8a64, 0x89c4, 0x8925, 0x8889, 0x87ee, 0x8756, 0x86c0, 0x862b, 0x8599,
    0x8508, 0x8479, 0x83ec, 0x8361, 0x82d8, 0x8250, 0x81c9, 0x8145, 0x80c2,
    0x8040, 0xff02, 0xfd0e, 0xfb25, 0xf947, 0xf773, 0xf5aa, 0xf3ea, 0xf234,
    0xf087, 0xeee3, 0xed47, 0xebb3, 0xea27, 0xe8a3, 0xe727, 0xe5b2, 0xe443,
    0xe2dc, 0xe17a, 0xe020, 0xdecb, 0xdd7d, 0xdc34, 0xdaf1, 0xd9b3, 0xd87b,
    0xd748, 0xd61a, 0xd4f1, 0xd3cd, 0xd2ad, 0xd192, 0xd07b, 0xcf69, 0xce5b,
    0xcd51, 0xcc4a, 0xcb48, 0xca4a, 0xc94f, 0xc858, 0xc764, 0xc674, 0xc587,
    0xc49d, 0xc3b7, 0xc2d4, 0xc1f4, 0xc116, 0xc03c, 0xbf65, 0xbe90, 0xbdbe,
    0xbcef, 0xbc23, 0xbb59, 0xba91, 0xb9cc, 0xb90a, 0xb84a, 0xb78c, 0xb6d0,
    0xb617, 0xb560,
};

/* returns a*b*2^-32 - e, with error 0 <= e < 1.  */
static inline uint32_t mul32(uint32_t a, uint32_t b) {
  return (uint64_t)a * b >> 32;
}
#endif

#ifdef MOONBIT_NATIVE_NO_SYS_HEADER
float sqrtf(float x) {
  uint32_t ix, m, m1, m0, even, ey;

  ix = *(uint32_t *)&x;
  if (ix - 0x00800000 >= 0x7f800000 - 0x00800000) {
    /* x < 0x1p-126 or inf or nan.  */
    if (ix * 2 == 0)
      return x;
    if (ix == 0x7f800000)
      return x;
    if (ix > 0x7f800000)
      return (x - x) / (x - x);
    /* x is subnormal, normalize it.  */
    x *= 0x1p23f;
    ix = *(uint32_t *)&x;
    ix -= 23 << 23;
  }

  /* x = 4^e m; with int e and m in [1, 4).  */
  even = ix & 0x00800000;
  m1 = (ix << 8) | 0x80000000;
  m0 = (ix << 7) & 0x7fffffff;
  m = even ? m0 : m1;

  /* 2^e is the exponent part of the return value.  */
  ey = ix >> 1;
  ey += 0x3f800000 >> 1;
  ey &= 0x7f800000;

  /* compute r ~ 1/sqrt(m), s ~ sqrt(m) with 2 goldschmidt iterations.  */
  static const uint32_t three = 0xc0000000;
  uint32_t r, s, d, u, i;
  i = (ix >> 17) % 128;
  r = (uint32_t)__rsqrt_tab[i] << 16;
  /* |r*sqrt(m) - 1| < 0x1p-8 */
  s = mul32(m, r);
  /* |s/sqrt(m) - 1| < 0x1p-8 */
  d = mul32(s, r);
  u = three - d;
  r = mul32(r, u) << 1;
  /* |r*sqrt(m) - 1| < 0x1.7bp-16 */
  s = mul32(s, u) << 1;
  /* |s/sqrt(m) - 1| < 0x1.7bp-16 */
  d = mul32(s, r);
  u = three - d;
  s = mul32(s, u);
  /* -0x1.03p-28 < s/sqrt(m) - 1 < 0x1.fp-31 */
  s = (s - 1) >> 6;
  /* s < sqrt(m) < s + 0x1.08p-23 */

  /* compute nearest rounded result.  */
  uint32_t d0, d1, d2;
  float y, t;
  d0 = (m << 16) - s * s;
  d1 = s - d0;
  d2 = d1 + s + 1;
  s += d1 >> 31;
  s &= 0x007fffff;
  s |= ey;
  y = *(float *)&s;
  /* handle rounding and inexact exception. */
  uint32_t tiny = d2 == 0 ? 0 : 0x01000000;
  tiny |= (d1 ^ d2) & 0x80000000;
  t = *(float *)&tiny;
  y = y + t;
  return y;
}
#endif

#ifdef MOONBIT_NATIVE_NO_SYS_HEADER
/* returns a*b*2^-64 - e, with error 0 <= e < 3.  */
static inline uint64_t mul64(uint64_t a, uint64_t b) {
  uint64_t ahi = a >> 32;
  uint64_t alo = a & 0xffffffff;
  uint64_t bhi = b >> 32;
  uint64_t blo = b & 0xffffffff;
  return ahi * bhi + (ahi * blo >> 32) + (alo * bhi >> 32);
}

double sqrt(double x) {
  uint64_t ix, top, m;

  /* special case handling.  */
  ix = *(uint64_t *)&x;
  top = ix >> 52;
  if (top - 0x001 >= 0x7ff - 0x001) {
    /* x < 0x1p-1022 or inf or nan.  */
    if (ix * 2 == 0)
      return x;
    if (ix == 0x7ff0000000000000)
      return x;
    if (ix > 0x7ff0000000000000)
      return (x - x) / (x - x);
    /* x is subnormal, normalize it.  */
    x *= 0x1p52;
    ix = *(uint64_t *)&x;
    top = ix >> 52;
    top -= 52;
  }

  /* argument reduction:
     x = 4^e m; with integer e, and m in [1, 4)
     m: fixed point representation [2.62]
     2^e is the exponent part of the result.  */
  int even = top & 1;
  m = (ix << 11) | 0x8000000000000000;
  if (even)
    m >>= 1;
  top = (top + 0x3ff) >> 1;

  /* approximate r ~ 1/sqrt(m) and s ~ sqrt(m) when m in [1,4)

     initial estimate:
     7bit table lookup (1bit exponent and 6bit significand).

     iterative approximation:
     using 2 goldschmidt iterations with 32bit int arithmetics
     and a final iteration with 64bit int arithmetics.

     details:

     the relative error (e = r0 sqrt(m)-1) of a linear estimate
     (r0 = a m + b) is |e| < 0.085955 ~ 0x1.6p-4 at best,
     a table lookup is faster and needs one less iteration
     6 bit lookup table (128b) gives |e| < 0x1.f9p-8
     7 bit lookup table (256b) gives |e| < 0x1.fdp-9
     for single and double prec 6bit is enough but for quad
     prec 7bit is needed (or modified iterations). to avoid
     one more iteration >=13bit table would be needed (16k).

     a newton-raphson iteration for r is
       w = r*r
       u = 3 - m*w
       r = r*u/2
     can use a goldschmidt iteration for s at the end or
       s = m*r

     first goldschmidt iteration is
       s = m*r
       u = 3 - s*r
       r = r*u/2
       s = s*u/2
     next goldschmidt iteration is
       u = 3 - s*r
       r = r*u/2
       s = s*u/2
     and at the end r is not computed only s.

     they use the same amount of operations and converge at the
     same quadratic rate, i.e. if
       r1 sqrt(m) - 1 = e, then
       r2 sqrt(m) - 1 = -3/2 e^2 - 1/2 e^3
     the advantage of goldschmidt is that the mul for s and r
     are independent (computed in parallel), however it is not
     "self synchronizing": it only uses the input m in the
     first iteration so rounding errors accumulate. at the end
     or when switching to larger precision arithmetics rounding
     errors dominate so the first iteration should be used.

     the fixed point representations are
       m: 2.30 r: 0.32, s: 2.30, d: 2.30, u: 2.30, three: 2.30
     and after switching to 64 bit
       m: 2.62 r: 0.64, s: 2.62, d: 2.62, u: 2.62, three: 2.62  */

  static const uint64_t three = 0xc0000000;
  uint64_t r, s, d, u, i;

  i = (ix >> 46) % 128;
  r = (uint32_t)__rsqrt_tab[i] << 16;
  /* |r sqrt(m) - 1| < 0x1.fdp-9 */
  s = mul32(m >> 32, r);
  /* |s/sqrt(m) - 1| < 0x1.fdp-9 */
  d = mul32(s, r);
  u = three - d;
  r = mul32(r, u) << 1;
  /* |r sqrt(m) - 1| < 0x1.7bp-16 */
  s = mul32(s, u) << 1;
  /* |s/sqrt(m) - 1| < 0x1.7bp-16 */
  d = mul32(s, r);
  u = three - d;
  r = mul32(r, u) << 1;
  /* |r sqrt(m) - 1| < 0x1.3704p-29 (measured worst-case) */
  r = r << 32;
  s = mul64(m, r);
  d = mul64(s, r);
  u = (three << 32) - d;
  s = mul64(s, u); /* repr: 3.61 */
  /* -0x1p-57 < s - sqrt(m) < 0x1.8001p-61 */
  s = (s - 2) >> 9; /* repr: 12.52 */
  /* -0x1.09p-52 < s - sqrt(m) < -0x1.fffcp-63 */

  /* s < sqrt(m) < s + 0x1.09p-52,
     compute nearest rounded result:
     the nearest result to 52 bits is either s or s+0x1p-52,
     we can decide by comparing (2^52 s + 0.5)^2 to 2^104 m.  */
  uint64_t d0, d1, d2;
  double y, t;
  d0 = (m << 42) - s * s;
  d1 = s - d0;
  d2 = d1 + s + 1;
  s += d1 >> 63;
  s &= 0x000fffffffffffff;
  s |= top << 52;
  y = *(double *)&s;
  return y;
}
#endif

#ifdef MOONBIT_NATIVE_NO_SYS_HEADER
double fabs(double x) {
  union {
    double f;
    uint64_t i;
  } u = {x};
  u.i &= 0x7fffffffffffffffULL;
  return u.f;
}
#endif

#ifdef MOONBIT_NATIVE_NO_SYS_HEADER
float fabsf(float x) {
  union {
    float f;
    uint32_t i;
  } u = {x};
  u.i &= 0x7fffffff;
  return u.f;
}
#endif

#ifdef _MSC_VER
/* MSVC treats syntactic division by zero as fatal error,
   even for float point numbers,
   so we have to use a constant variable to work around this */
static const int MOONBIT_ZERO = 0;
#else
#define MOONBIT_ZERO 0
#endif

#ifdef __cplusplus
}
#endif
struct _M0DTPC15error5Error93walkzzz_2fmcp__server_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTest;

struct _M0TPB8MutLocalGiE;

struct _M0DTPC15error5Error48moonbitlang_2fcore_2fbuiltin_2eFailure_2eFailure;

struct _M0DTPC15error5Error58moonbitlang_2fcore_2fbuiltin_2eInspectError_2eInspectError;

struct _M0TWRPC15error5ErrorEs;

struct _M0TPB4Show;

struct _M0TWssbEu;

struct _M0TUsiE;

struct _M0R94_24walkzzz_2fmcp__server_2emoonbit__test__driver__internal__do__execute_2ehandle__result_7c409;

struct _M0TPB13StringBuilder;

struct _M0R93_24walkzzz_2fmcp__server_2emoonbit__test__driver__internal__do__execute_2ehandle__start_7c404;

struct _M0TWWuEuWRPC15error5ErrorEuEOuQRPC15error5Error;

struct _M0DTPC15error5Error91walkzzz_2fmcp__server_2eMoonBitTestDriverInternalJsError_2eMoonBitTestDriverInternalJsError;

struct _M0DTPC16result6ResultGOuRPC15error5ErrorE3Err;

struct _M0BTPB6Logger;

struct _M0BTPB4Show;

struct _M0TWuEu;

struct _M0DTPC16result6ResultGbRP27walkzzz11mcp__server33MoonBitTestDriverInternalSkipTestE2Ok;

struct _M0TPC16string10StringView;

struct _M0KTPB6LoggerTPB13StringBuilder;

struct _M0TPB6Logger;

struct _M0TPB5ArrayGUsiEE;

struct _M0TPB5ArrayGsE;

struct _M0DTPC16result6ResultGOuRPC15error5ErrorE2Ok;

struct _M0TWEu;

struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE;

struct _M0TURPB6LoggerRPC16string10StringViewE;

struct _M0DTPC16result6ResultGbRP27walkzzz11mcp__server33MoonBitTestDriverInternalSkipTestE3Err;

struct _M0DTPC15error5Error60moonbitlang_2fcore_2fbuiltin_2eSnapshotError_2eSnapshotError;

struct _M0TWRPC15error5ErrorEu;

struct _M0DTPC15error5Error93walkzzz_2fmcp__server_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTest {
  moonbit_string_t $0;
  
};

struct _M0TPB8MutLocalGiE {
  int32_t $0;
  
};

struct _M0DTPC15error5Error48moonbitlang_2fcore_2fbuiltin_2eFailure_2eFailure {
  moonbit_string_t $0;
  
};

struct _M0DTPC15error5Error58moonbitlang_2fcore_2fbuiltin_2eInspectError_2eInspectError {
  moonbit_string_t $0;
  
};

struct _M0TWRPC15error5ErrorEs {
  moonbit_string_t(* code)(struct _M0TWRPC15error5ErrorEs*, void*);
  
};

struct _M0TPB4Show {
  struct _M0BTPB4Show* $0;
  void* $1;
  
};

struct _M0TWssbEu {
  int32_t(* code)(
    struct _M0TWssbEu*,
    moonbit_string_t,
    moonbit_string_t,
    int32_t
  );
  
};

struct _M0TUsiE {
  moonbit_string_t $0;
  int32_t $1;
  
};

struct _M0R94_24walkzzz_2fmcp__server_2emoonbit__test__driver__internal__do__execute_2ehandle__result_7c409 {
  int32_t(* code)(
    struct _M0TWssbEu*,
    moonbit_string_t,
    moonbit_string_t,
    int32_t
  );
  int32_t $0;
  moonbit_string_t $1;
  
};

struct _M0TPB13StringBuilder {
  uint16_t* $0;
  int32_t $1;
  
};

struct _M0R93_24walkzzz_2fmcp__server_2emoonbit__test__driver__internal__do__execute_2ehandle__start_7c404 {
  int32_t(* code)(struct _M0TWEu*);
  int32_t $0;
  moonbit_string_t $1;
  
};

struct _M0TWWuEuWRPC15error5ErrorEuEOuQRPC15error5Error {
  struct moonbit_result_0(* code)(
    struct _M0TWWuEuWRPC15error5ErrorEuEOuQRPC15error5Error*,
    struct _M0TWuEu*,
    struct _M0TWRPC15error5ErrorEu*
  );
  
};

struct _M0DTPC15error5Error91walkzzz_2fmcp__server_2eMoonBitTestDriverInternalJsError_2eMoonBitTestDriverInternalJsError {
  moonbit_string_t $0;
  
};

struct _M0DTPC16result6ResultGOuRPC15error5ErrorE3Err {
  void* $0;
  
};

struct _M0BTPB6Logger {
  int32_t(* $method_0)(void*, moonbit_string_t);
  int32_t(* $method_1)(void*, moonbit_string_t, int32_t, int32_t);
  int32_t(* $method_2)(void*, struct _M0TPC16string10StringView);
  int32_t(* $method_3)(void*, int32_t);
  int32_t(* $method_4)(void*, struct _M0TPB4Show);
  int32_t(* $method_5)(void*, struct _M0TPB4Show);
  
};

struct _M0BTPB4Show {
  int32_t(* $method_0)(void*, struct _M0TPB6Logger);
  moonbit_string_t(* $method_1)(void*);
  
};

struct _M0TWuEu {
  int32_t(* code)(struct _M0TWuEu*, int32_t);
  
};

struct _M0DTPC16result6ResultGbRP27walkzzz11mcp__server33MoonBitTestDriverInternalSkipTestE2Ok {
  int32_t $0;
  
};

struct _M0TPC16string10StringView {
  moonbit_string_t $0;
  int32_t $1;
  int32_t $2;
  
};

struct _M0KTPB6LoggerTPB13StringBuilder {
  struct _M0BTPB6Logger* $0;
  void* $1;
  
};

struct _M0TPB6Logger {
  struct _M0BTPB6Logger* $0;
  void* $1;
  
};

struct _M0TPB5ArrayGUsiEE {
  struct _M0TUsiE** $0;
  int32_t $1;
  
};

struct _M0TPB5ArrayGsE {
  moonbit_string_t* $0;
  int32_t $1;
  
};

struct _M0DTPC16result6ResultGOuRPC15error5ErrorE2Ok {
  int32_t $0;
  
};

struct _M0TWEu {
  int32_t(* code)(struct _M0TWEu*);
  
};

struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE {
  struct _M0TWWuEuWRPC15error5ErrorEuEOuQRPC15error5Error** $0;
  int32_t $1;
  
};

struct _M0TURPB6LoggerRPC16string10StringViewE {
  struct _M0TPB6Logger $0;
  struct _M0TPC16string10StringView $1;
  
};

struct _M0DTPC16result6ResultGbRP27walkzzz11mcp__server33MoonBitTestDriverInternalSkipTestE3Err {
  void* $0;
  
};

struct _M0DTPC15error5Error60moonbitlang_2fcore_2fbuiltin_2eSnapshotError_2eSnapshotError {
  moonbit_string_t $0;
  
};

struct _M0TWRPC15error5ErrorEu {
  int32_t(* code)(struct _M0TWRPC15error5ErrorEu*, void*);
  
};

struct moonbit_result_0 {
  int tag;
  union { int32_t ok; void* err;  } data;
  
};

int32_t _M0IP016_24default__implP27walkzzz11mcp__server28MoonBit__Async__Test__Driver30is__being__cancelled_2edyncallGRP27walkzzz11mcp__server34MoonBit__Async__Test__Driver__ImplE(
  struct _M0TWEu*
);

int32_t _M0FP27walkzzz11mcp__server44moonbit__test__driver__internal__do__execute(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE*,
  moonbit_string_t,
  int32_t
);

moonbit_string_t _M0FP27walkzzz11mcp__server44moonbit__test__driver__internal__do__executeN17error__to__stringS416(
  struct _M0TWRPC15error5ErrorEs*,
  void*
);

int32_t _M0FP27walkzzz11mcp__server44moonbit__test__driver__internal__do__executeN14handle__resultS409(
  struct _M0TWssbEu*,
  moonbit_string_t,
  moonbit_string_t,
  int32_t
);

int32_t _M0FP27walkzzz11mcp__server44moonbit__test__driver__internal__do__executeN13handle__startS404(
  struct _M0TWEu*
);

struct _M0TPB5ArrayGUsiEE* _M0FP27walkzzz11mcp__server52moonbit__test__driver__internal__native__parse__args(
  
);

struct _M0TPB5ArrayGsE* _M0FP27walkzzz11mcp__server52moonbit__test__driver__internal__native__parse__argsN51moonbit__test__driver__internal__split__mbt__stringS382(
  int32_t,
  moonbit_string_t,
  int32_t
);

int32_t _M0FP27walkzzz11mcp__server52moonbit__test__driver__internal__native__parse__argsN45moonbit__test__driver__internal__parse__int__S375(
  int32_t,
  moonbit_string_t
);

#define _M0FP27walkzzz11mcp__server52moonbit__test__driver__internal__get__cli__args__ffi moonbit_rt_get_cli_args

moonbit_string_t _M0MP27walkzzz11mcp__server33MoonBitTestDriverInternalOsString10to__string(
  moonbit_string_t
);

struct moonbit_result_0 _M0IP016_24default__implP27walkzzz11mcp__server21MoonBit__Test__Driver9run__testGRP27walkzzz11mcp__server41MoonBit__Test__Driver__Internal__No__ArgsE(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE*,
  moonbit_string_t,
  int32_t,
  struct _M0TWEu*,
  struct _M0TWssbEu*,
  struct _M0TWRPC15error5ErrorEs*
);

struct moonbit_result_0 _M0IP016_24default__implP27walkzzz11mcp__server21MoonBit__Test__Driver9run__testGRP27walkzzz11mcp__server43MoonBit__Test__Driver__Internal__With__ArgsE(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE*,
  moonbit_string_t,
  int32_t,
  struct _M0TWEu*,
  struct _M0TWssbEu*,
  struct _M0TWRPC15error5ErrorEs*
);

struct moonbit_result_0 _M0IP016_24default__implP27walkzzz11mcp__server21MoonBit__Test__Driver9run__testGRP27walkzzz11mcp__server48MoonBit__Test__Driver__Internal__Async__No__ArgsE(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE*,
  moonbit_string_t,
  int32_t,
  struct _M0TWEu*,
  struct _M0TWssbEu*,
  struct _M0TWRPC15error5ErrorEs*
);

struct moonbit_result_0 _M0IP016_24default__implP27walkzzz11mcp__server21MoonBit__Test__Driver9run__testGRP27walkzzz11mcp__server50MoonBit__Test__Driver__Internal__Async__With__ArgsE(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE*,
  moonbit_string_t,
  int32_t,
  struct _M0TWEu*,
  struct _M0TWssbEu*,
  struct _M0TWRPC15error5ErrorEs*
);

struct moonbit_result_0 _M0IP016_24default__implP27walkzzz11mcp__server21MoonBit__Test__Driver9run__testGRP27walkzzz11mcp__server50MoonBit__Test__Driver__Internal__With__Bench__ArgsE(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE*,
  moonbit_string_t,
  int32_t,
  struct _M0TWEu*,
  struct _M0TWssbEu*,
  struct _M0TWRPC15error5ErrorEs*
);

int32_t _M0IP016_24default__implP27walkzzz11mcp__server28MoonBit__Async__Test__Driver20is__being__cancelledGRP27walkzzz11mcp__server34MoonBit__Async__Test__Driver__ImplE(
  
);

int32_t _M0IP016_24default__implP27walkzzz11mcp__server28MoonBit__Async__Test__Driver17run__async__testsGRP27walkzzz11mcp__server34MoonBit__Async__Test__Driver__ImplE(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE*
);

moonbit_string_t _M0MPC15array5Array2atGsE(struct _M0TPB5ArrayGsE*, int32_t);

int32_t _M0FPB7printlnGsE(moonbit_string_t);

moonbit_string_t _M0IPC13int3IntPB4Show10to__string(int32_t);

int32_t _M0MPC15array5Array4pushGsE(
  struct _M0TPB5ArrayGsE*,
  moonbit_string_t
);

int32_t _M0MPC15array5Array4pushGUsiEE(
  struct _M0TPB5ArrayGUsiEE*,
  struct _M0TUsiE*
);

int32_t _M0MPC15array5Array7reallocGsE(struct _M0TPB5ArrayGsE*, int32_t);

int32_t _M0MPC15array5Array7reallocGUsiEE(
  struct _M0TPB5ArrayGUsiEE*,
  int32_t
);

int32_t _M0MPC15array5Array14resize__bufferGsE(
  struct _M0TPB5ArrayGsE*,
  int32_t
);

int32_t _M0MPC15array5Array14resize__bufferGUsiEE(
  struct _M0TPB5ArrayGUsiEE*,
  int32_t
);

int32_t _M0MPC15array5Array8capacityGsE(struct _M0TPB5ArrayGsE*);

int32_t _M0MPC15array5Array8capacityGUsiEE(struct _M0TPB5ArrayGUsiEE*);

int32_t _M0FPB23array__growth__capacity(int32_t, int32_t, int32_t);

moonbit_string_t* _M0MPC15array5Array6bufferGsE(struct _M0TPB5ArrayGsE*);

struct _M0TUsiE** _M0MPC15array5Array6bufferGUsiEE(
  struct _M0TPB5ArrayGUsiEE*
);

moonbit_string_t _M0IPC16string6StringPB4Show10to__string(moonbit_string_t);

int32_t _M0IPB13StringBuilderPB6Logger11write__view(
  struct _M0TPB13StringBuilder*,
  struct _M0TPC16string10StringView
);

moonbit_string_t _M0MPC16string6String17unsafe__substring(
  moonbit_string_t,
  int32_t,
  int32_t
);

moonbit_string_t _M0MPC15bytes5Bytes29to__unchecked__string_2einner(
  moonbit_bytes_t,
  int32_t,
  int64_t
);

#define _M0FPB19unsafe__sub__string moonbit_unsafe_bytes_sub_string

int32_t _M0MPC15array10FixedArray18blit__from__string(
  moonbit_bytes_t,
  int32_t,
  moonbit_string_t,
  int32_t,
  int32_t
);

int32_t _M0MPC14uint4UInt8to__byte(uint32_t);

moonbit_string_t _M0MPC13int3Int18to__string_2einner(int32_t, int32_t);

int32_t _M0FPB14radix__count32(uint32_t, int32_t);

int32_t _M0FPB12hex__count32(uint32_t);

int32_t _M0FPB12dec__count32(uint32_t);

int32_t _M0FPB20int__to__string__dec(uint16_t*, uint32_t, int32_t, int32_t);

int32_t _M0FPB24int__to__string__generic(
  uint16_t*,
  uint32_t,
  int32_t,
  int32_t,
  int32_t
);

int32_t _M0FPB20int__to__string__hex(uint16_t*, uint32_t, int32_t, int32_t);

moonbit_string_t _M0IP016_24default__implPB4Show10to__stringGRPB7FailureE(
  void*
);

int32_t _M0IP016_24default__implPB4Show6outputGsE(
  moonbit_string_t,
  struct _M0TPB6Logger
);

int32_t _M0IP016_24default__implPB4Show6outputGiE(
  int32_t,
  struct _M0TPB6Logger
);

int32_t _M0MPC16string10StringView13start__offset(
  struct _M0TPC16string10StringView
);

moonbit_string_t _M0MPC16string10StringView4data(
  struct _M0TPC16string10StringView
);

int32_t _M0IP016_24default__implPB6Logger16write__substringGRPB13StringBuilderE(
  struct _M0TPB13StringBuilder*,
  moonbit_string_t,
  int32_t,
  int32_t
);

struct _M0TPC16string10StringView _M0MPC16string6String11sub_2einner(
  moonbit_string_t,
  int32_t,
  int64_t
);

int32_t _M0IP016_24default__implPB6Logger5writeGRPB13StringBuilderE(
  struct _M0TPB13StringBuilder*,
  struct _M0TPB4Show
);

int32_t _M0IP016_24default__implPB6Logger28write__string__interpolationGRPB13StringBuilderE(
  struct _M0TPB13StringBuilder*,
  struct _M0TPB4Show
);

int32_t _M0IPC16uint166UInt16PB7Default7default();

int32_t _M0IPB13StringBuilderPB6Logger13write__string(
  struct _M0TPB13StringBuilder*,
  moonbit_string_t
);

int32_t _M0MPC15array10FixedArray26unsafe__blit__from__string(
  uint16_t*,
  int32_t,
  moonbit_string_t,
  int32_t,
  int32_t
);

moonbit_string_t _M0MPC16string6String14escape_2einner(
  moonbit_string_t,
  int32_t
);

int32_t _M0MPC16string10StringView18escape__to_2einner(
  struct _M0TPC16string10StringView,
  struct _M0TPB6Logger,
  int32_t
);

int32_t _M0MPC16string10StringView18escape__to_2einnerN14flush__segmentS4266(
  struct _M0TURPB6LoggerRPC16string10StringViewE*,
  int32_t,
  int32_t
);

struct _M0TPC16string10StringView _M0MPC16string10StringView11sub_2einner(
  struct _M0TPC16string10StringView,
  int32_t,
  int64_t
);

moonbit_string_t _M0MPC14byte4Byte7to__hex(int32_t);

int32_t _M0MPC14byte4Byte7to__hexN14to__hex__digitS4281(int32_t);

int32_t _M0IPC14byte4BytePB3Sub3sub(int32_t, int32_t);

int32_t _M0IPC14byte4BytePB3Mod3mod(int32_t, int32_t);

int32_t _M0IPC14byte4BytePB3Div3div(int32_t, int32_t);

int32_t _M0IPC14byte4BytePB3Add3add(int32_t, int32_t);

int32_t _M0MPC16uint166UInt1616unsafe__to__char(int32_t);

int32_t _M0MPC16uint166UInt1623is__trailing__surrogate(int32_t);

int32_t _M0IPB13StringBuilderPB6Logger11write__char(
  struct _M0TPB13StringBuilder*,
  int32_t
);

int32_t _M0MPB13StringBuilder4grow(struct _M0TPB13StringBuilder*, int32_t);

int32_t _M0FPB31stringbuilder__growth__capacity(int32_t, int32_t, int32_t);

int32_t _M0MPC14uint4UInt10to__uint16(uint32_t);

uint32_t _M0MPC14char4Char8to__uint(int32_t);

moonbit_string_t _M0MPB13StringBuilder10to__string(
  struct _M0TPB13StringBuilder*
);

uint16_t* _M0MPC15array10FixedArray23make__and__blit_2einnerGkE(
  uint16_t*,
  int32_t,
  int32_t,
  int32_t,
  int32_t,
  int32_t
);

uint16_t* _M0MPC15array10FixedArray23unsafe__make__and__blitGkE(
  uint16_t*,
  int32_t,
  int32_t,
  int32_t,
  int32_t,
  int32_t
);

struct _M0TPB13StringBuilder* _M0MPB13StringBuilder21StringBuilder_2einner(
  int32_t
);

int32_t _M0MPC14byte4Byte8to__char(int32_t);

moonbit_string_t* _M0MPB18UninitializedArray23make__and__blit_2einnerGsE(
  moonbit_string_t*,
  int32_t,
  int32_t,
  int32_t,
  int32_t
);

struct _M0TUsiE** _M0MPB18UninitializedArray23make__and__blit_2einnerGUsiEE(
  struct _M0TUsiE**,
  int32_t,
  int32_t,
  int32_t,
  int32_t
);

int32_t _M0MPB13StringBuilder13write__objectGsE(
  struct _M0TPB13StringBuilder*,
  moonbit_string_t
);

int32_t _M0MPB13StringBuilder13write__objectGiE(
  struct _M0TPB13StringBuilder*,
  int32_t
);

moonbit_string_t* _M0MPB18UninitializedArray23unsafe__make__and__blitGsE(
  moonbit_string_t*,
  int32_t,
  int32_t,
  int32_t,
  int32_t
);

struct _M0TUsiE** _M0MPB18UninitializedArray23unsafe__make__and__blitGUsiEE(
  struct _M0TUsiE**,
  int32_t,
  int32_t,
  int32_t,
  int32_t
);

int32_t _M0MPB18UninitializedArray12unsafe__blitGsE(
  moonbit_string_t*,
  int32_t,
  moonbit_string_t*,
  int32_t,
  int32_t
);

int32_t _M0MPB18UninitializedArray12unsafe__blitGUsiEE(
  struct _M0TUsiE**,
  int32_t,
  struct _M0TUsiE**,
  int32_t,
  int32_t
);

int32_t _M0MPC15array10FixedArray12unsafe__blitGkE(
  uint16_t*,
  int32_t,
  uint16_t*,
  int32_t,
  int32_t
);

int32_t _M0MPC15array10FixedArray12unsafe__blitGRPB17UnsafeMaybeUninitGsEE(
  moonbit_string_t*,
  int32_t,
  moonbit_string_t*,
  int32_t,
  int32_t
);

int32_t _M0MPC15array10FixedArray12unsafe__blitGRPB17UnsafeMaybeUninitGUsiEEE(
  struct _M0TUsiE**,
  int32_t,
  struct _M0TUsiE**,
  int32_t,
  int32_t
);

int32_t _M0MPB18UninitializedArray6lengthGsE(moonbit_string_t*);

int32_t _M0MPB18UninitializedArray6lengthGUsiEE(struct _M0TUsiE**);

int32_t _M0IPB7FailurePB4Show6output(void*, struct _M0TPB6Logger);

int32_t _M0MPB6Logger13write__objectGsE(
  struct _M0TPB6Logger,
  moonbit_string_t
);

int32_t _M0FPC15abort5abortGuE(moonbit_string_t);

uint16_t* _M0FPC15abort5abortGAkE(moonbit_string_t);

moonbit_string_t* _M0FPC15abort5abortGRPB18UninitializedArrayGsEE(
  moonbit_string_t
);

struct _M0TUsiE** _M0FPC15abort5abortGRPB18UninitializedArrayGUsiEEE(
  moonbit_string_t
);

moonbit_string_t _M0FP15Error10to__string(void*);

int32_t _M0IP016_24default__implPB6Logger61write_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLoggerGRPB13StringBuilderE(
  void*,
  struct _M0TPB4Show
);

int32_t _M0IP016_24default__implPB6Logger84write__string__interpolation_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLoggerGRPB13StringBuilderE(
  void*,
  struct _M0TPB4Show
);

int32_t _M0IPB13StringBuilderPB6Logger67write__char_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLogger(
  void*,
  int32_t
);

int32_t _M0IPB13StringBuilderPB6Logger67write__view_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLogger(
  void*,
  struct _M0TPC16string10StringView
);

int32_t _M0IP016_24default__implPB6Logger72write__substring_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLoggerGRPB13StringBuilderE(
  void*,
  moonbit_string_t,
  int32_t,
  int32_t
);

int32_t _M0IPB13StringBuilderPB6Logger69write__string_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLogger(
  void*,
  moonbit_string_t
);

moonbit_string_t* moonbit_rt_get_cli_args();

struct { int32_t rc; uint32_t meta; uint16_t const data[35]; 
} const moonbit_string_literal_2 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 34, 45, 45, 
    45, 45, 45, 32, 66, 69, 71, 73, 78, 32, 77, 79, 79, 78, 32, 84, 69, 
    83, 84, 32, 82, 69, 83, 85, 76, 84, 32, 45, 45, 45, 45, 45, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[13]; 
} const moonbit_string_literal_1 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 12, 115, 107, 
    105, 112, 112, 101, 100, 32, 116, 101, 115, 116, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[1]; 
} const moonbit_string_literal_0 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 0, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[3]; 
} const moonbit_string_literal_16 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 2, 92, 116, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[3]; 
} const moonbit_string_literal_14 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 2, 92, 114, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[87]; 
} const moonbit_string_literal_28 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 86, 119, 97, 
    108, 107, 122, 122, 122, 47, 109, 99, 112, 95, 115, 101, 114, 118, 
    101, 114, 46, 77, 111, 111, 110, 66, 105, 116, 84, 101, 115, 116, 
    68, 114, 105, 118, 101, 114, 73, 110, 116, 101, 114, 110, 97, 108, 
    83, 107, 105, 112, 84, 101, 115, 116, 46, 77, 111, 111, 110, 66, 
    105, 116, 84, 101, 115, 116, 68, 114, 105, 118, 101, 114, 73, 110, 
    116, 101, 114, 110, 97, 108, 83, 107, 105, 112, 84, 101, 115, 116, 
    0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[16]; 
} const moonbit_string_literal_22 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 15, 44, 32, 
    100, 115, 116, 95, 111, 102, 102, 115, 101, 116, 32, 61, 32, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[19]; 
} const moonbit_string_literal_18 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 18, 105, 110, 
    118, 97, 108, 105, 100, 32, 99, 111, 100, 101, 32, 112, 111, 105, 
    110, 116, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[12]; 
} const moonbit_string_literal_5 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 11, 44, 34, 
    109, 101, 115, 115, 97, 103, 101, 34, 58, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[53]; 
} const moonbit_string_literal_29 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 52, 109, 111, 
    111, 110, 98, 105, 116, 108, 97, 110, 103, 47, 99, 111, 114, 101, 
    47, 98, 117, 105, 108, 116, 105, 110, 46, 83, 110, 97, 112, 115, 
    104, 111, 116, 69, 114, 114, 111, 114, 46, 83, 110, 97, 112, 115, 
    104, 111, 116, 69, 114, 114, 111, 114, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[3]; 
} const moonbit_string_literal_13 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 2, 92, 110, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[31]; 
} const moonbit_string_literal_10 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 30, 114, 97, 
    100, 105, 120, 32, 109, 117, 115, 116, 32, 98, 101, 32, 98, 101, 
    116, 119, 101, 101, 110, 32, 50, 32, 97, 110, 100, 32, 51, 54, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[25]; 
} const moonbit_string_literal_3 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 24, 123, 34, 
    116, 121, 112, 101, 34, 58, 34, 114, 101, 115, 117, 108, 116, 34, 
    44, 34, 102, 105, 108, 101, 34, 58, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[2]; 
} const moonbit_string_literal_11 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 1, 48, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[9]; 
} const moonbit_string_literal_23 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 8, 44, 32, 
    108, 101, 110, 32, 61, 32, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[37]; 
} const moonbit_string_literal_20 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 36, 98, 111, 
    117, 110, 100, 115, 32, 99, 104, 101, 99, 107, 32, 102, 97, 105, 
    108, 101, 100, 58, 32, 97, 108, 108, 111, 99, 97, 116, 101, 95, 108, 
    101, 110, 32, 61, 32, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[4]; 
} const moonbit_string_literal_17 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 3, 92, 117, 123, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[2]; 
} const moonbit_string_literal_26 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 1, 41, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[37]; 
} const moonbit_string_literal_12 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 36, 48, 49, 
    50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102, 103, 104, 
    105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 
    118, 119, 120, 121, 122, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[3]; 
} const moonbit_string_literal_15 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 2, 92, 98, 0};

struct { int32_t rc; uint32_t meta; uint16_t const data[51]; 
} const moonbit_string_literal_27 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 50, 109, 111, 
    111, 110, 98, 105, 116, 108, 97, 110, 103, 47, 99, 111, 114, 101, 
    47, 98, 117, 105, 108, 116, 105, 110, 46, 73, 110, 115, 112, 101, 
    99, 116, 69, 114, 114, 111, 114, 46, 73, 110, 115, 112, 101, 99, 
    116, 69, 114, 114, 111, 114, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[16]; 
} const moonbit_string_literal_24 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 15, 44, 32, 
    115, 114, 99, 46, 108, 101, 110, 103, 116, 104, 32, 61, 32, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[33]; 
} const moonbit_string_literal_7 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 32, 45, 45, 
    45, 45, 45, 32, 69, 78, 68, 32, 77, 79, 79, 78, 32, 84, 69, 83, 84, 
    32, 82, 69, 83, 85, 76, 84, 32, 45, 45, 45, 45, 45, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[16]; 
} const moonbit_string_literal_21 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 15, 44, 32, 
    115, 114, 99, 95, 111, 102, 102, 115, 101, 116, 32, 61, 32, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[24]; 
} const moonbit_string_literal_8 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 23, 123, 34, 
    116, 121, 112, 101, 34, 58, 34, 115, 116, 97, 114, 116, 34, 44, 34, 
    102, 105, 108, 101, 34, 58, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[85]; 
} const moonbit_string_literal_30 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 84, 119, 97, 
    108, 107, 122, 122, 122, 47, 109, 99, 112, 95, 115, 101, 114, 118, 
    101, 114, 46, 77, 111, 111, 110, 66, 105, 116, 84, 101, 115, 116, 
    68, 114, 105, 118, 101, 114, 73, 110, 116, 101, 114, 110, 97, 108, 
    74, 115, 69, 114, 114, 111, 114, 46, 77, 111, 111, 110, 66, 105, 
    116, 84, 101, 115, 116, 68, 114, 105, 118, 101, 114, 73, 110, 116, 
    101, 114, 110, 97, 108, 74, 115, 69, 114, 114, 111, 114, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[24]; 
} const moonbit_string_literal_9 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 23, 65, 114, 
    114, 97, 121, 32, 99, 97, 112, 97, 99, 105, 116, 121, 32, 111, 118, 
    101, 114, 102, 108, 111, 119, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[10]; 
} const moonbit_string_literal_4 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 9, 44, 34, 
    105, 110, 100, 101, 120, 34, 58, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[9]; 
} const moonbit_string_literal_25 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 8, 70, 97, 
    105, 108, 117, 114, 101, 40, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[32]; 
} const moonbit_string_literal_19 =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 31, 83, 116, 
    114, 105, 110, 103, 66, 117, 105, 108, 100, 101, 114, 32, 99, 97, 
    112, 97, 99, 105, 116, 121, 32, 111, 118, 101, 114, 102, 108, 111, 
    119, 0
  };

struct { int32_t rc; uint32_t meta; uint16_t const data[2]; 
} const moonbit_string_literal_6 =
  { Moonbit_make_static_rc(moonbit_BLOCK_KIND_VAL_ARRAY), 1, 125, 0};

struct { int32_t rc; uint32_t meta; struct _M0TWEu data; 
} const _M0IP016_24default__implP27walkzzz11mcp__server28MoonBit__Async__Test__Driver30is__being__cancelled_2edyncallGRP27walkzzz11mcp__server34MoonBit__Async__Test__Driver__ImplE$closure =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0),
    _M0IP016_24default__implP27walkzzz11mcp__server28MoonBit__Async__Test__Driver30is__being__cancelled_2edyncallGRP27walkzzz11mcp__server34MoonBit__Async__Test__Driver__ImplE
  };

struct { int32_t rc; uint32_t meta; struct _M0TWRPC15error5ErrorEs data; 
} const _M0FP27walkzzz11mcp__server44moonbit__test__driver__internal__do__executeN17error__to__stringS416$closure =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0),
    _M0FP27walkzzz11mcp__server44moonbit__test__driver__internal__do__executeN17error__to__stringS416
  };

uint32_t const moonbit_layout_table_data[36] =
  {
    sizeof(struct _M0R93_24walkzzz_2fmcp__server_2emoonbit__test__driver__internal__do__execute_2ehandle__start_7c404)
    / 4, 1,
    offsetof(struct _M0R93_24walkzzz_2fmcp__server_2emoonbit__test__driver__internal__do__execute_2ehandle__start_7c404, $1)
    / 4
    * 2,
    sizeof(struct _M0R94_24walkzzz_2fmcp__server_2emoonbit__test__driver__internal__do__execute_2ehandle__result_7c409)
    / 4, 1,
    offsetof(struct _M0R94_24walkzzz_2fmcp__server_2emoonbit__test__driver__internal__do__execute_2ehandle__result_7c409, $1)
    / 4
    * 2,
    sizeof(struct _M0DTPC15error5Error93walkzzz_2fmcp__server_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTest)
    / 4, 1,
    offsetof(struct _M0DTPC15error5Error93walkzzz_2fmcp__server_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTest, $0)
    / 4
    * 2, sizeof(struct _M0TPB5ArrayGUsiEE) / 4, 1,
    offsetof(struct _M0TPB5ArrayGUsiEE, $0) / 4 * 2,
    sizeof(struct _M0TUsiE) / 4, 1, offsetof(struct _M0TUsiE, $0) / 4 * 2,
    sizeof(struct _M0TPB5ArrayGsE) / 4, 1,
    offsetof(struct _M0TPB5ArrayGsE, $0) / 4 * 2,
    sizeof(struct _M0TPB6Logger) / 4, 2,
    offsetof(struct _M0TPB6Logger, $0) / 4 * 2,
    offsetof(struct _M0TPB6Logger, $1) / 4 * 2,
    sizeof(struct _M0TPC16string10StringView) / 4, 1,
    offsetof(struct _M0TPC16string10StringView, $0) / 4 * 2,
    sizeof(struct _M0TURPB6LoggerRPC16string10StringViewE) / 4, 3,
    (offsetof(struct _M0TURPB6LoggerRPC16string10StringViewE, $0)
     + offsetof(struct _M0TPB6Logger, $0))
    / 4
    * 2,
    (offsetof(struct _M0TURPB6LoggerRPC16string10StringViewE, $0)
     + offsetof(struct _M0TPB6Logger, $1))
    / 4
    * 2,
    (offsetof(struct _M0TURPB6LoggerRPC16string10StringViewE, $1)
     + offsetof(struct _M0TPC16string10StringView, $0))
    / 4
    * 2, sizeof(struct _M0TPB13StringBuilder) / 4, 1,
    offsetof(struct _M0TPB13StringBuilder, $0) / 4 * 2,
    sizeof(struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE) / 4, 1,
    offsetof(struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE, $0) / 4 * 2
  };

struct _M0TWEu* _M0IP016_24default__implP27walkzzz11mcp__server28MoonBit__Async__Test__Driver26is__being__cancelled_2ecloGRP27walkzzz11mcp__server34MoonBit__Async__Test__Driver__ImplE =
  (struct _M0TWEu*)&_M0IP016_24default__implP27walkzzz11mcp__server28MoonBit__Async__Test__Driver30is__being__cancelled_2edyncallGRP27walkzzz11mcp__server34MoonBit__Async__Test__Driver__ImplE$closure.data;

struct { int32_t rc; uint32_t meta; struct _M0BTPB6Logger data; 
} _M0FP0119moonbitlang_2fcore_2fbuiltin_2fStringBuilder_2eas___40moonbitlang_2fcore_2fbuiltin_2eLogger_2estatic__method__table__id$object =
  {
    Moonbit_make_static_rc(moonbit_BLOCK_KIND_REGULAR),
    Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0),
    {.$method_0 = _M0IPB13StringBuilderPB6Logger69write__string_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLogger,
       .$method_1 = _M0IP016_24default__implPB6Logger72write__substring_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLoggerGRPB13StringBuilderE,
       .$method_2 = _M0IPB13StringBuilderPB6Logger67write__view_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLogger,
       .$method_3 = _M0IPB13StringBuilderPB6Logger67write__char_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLogger,
       .$method_4 = _M0IP016_24default__implPB6Logger84write__string__interpolation_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLoggerGRPB13StringBuilderE,
       .$method_5 = _M0IP016_24default__implPB6Logger61write_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLoggerGRPB13StringBuilderE}
  };

struct _M0BTPB6Logger* _M0FP0119moonbitlang_2fcore_2fbuiltin_2fStringBuilder_2eas___40moonbitlang_2fcore_2fbuiltin_2eLogger_2estatic__method__table__id =
  &_M0FP0119moonbitlang_2fcore_2fbuiltin_2fStringBuilder_2eas___40moonbitlang_2fcore_2fbuiltin_2eLogger_2estatic__method__table__id$object.data;

int32_t _M0IP016_24default__implP27walkzzz11mcp__server28MoonBit__Async__Test__Driver30is__being__cancelled_2edyncallGRP27walkzzz11mcp__server34MoonBit__Async__Test__Driver__ImplE(
  struct _M0TWEu* _M0L6_2aenvS827
) {
  return _M0IP016_24default__implP27walkzzz11mcp__server28MoonBit__Async__Test__Driver20is__being__cancelledGRP27walkzzz11mcp__server34MoonBit__Async__Test__Driver__ImplE();
}

int32_t _M0FP27walkzzz11mcp__server44moonbit__test__driver__internal__do__execute(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE* _M0L12async__testsS437,
  moonbit_string_t _M0L8filenameS406,
  int32_t _M0L5indexS408
) {
  struct _M0R93_24walkzzz_2fmcp__server_2emoonbit__test__driver__internal__do__execute_2ehandle__start_7c404* _closure_867;
  struct _M0TWEu* _M0L13handle__startS404;
  struct _M0R94_24walkzzz_2fmcp__server_2emoonbit__test__driver__internal__do__execute_2ehandle__result_7c409* _closure_868;
  struct _M0TWssbEu* _M0L14handle__resultS409;
  struct _M0TWRPC15error5ErrorEs* _M0L17error__to__stringS416;
  void* _M0L11_2atry__errS431;
  struct moonbit_result_0 _tmp_870;
  int32_t _handle__error__result_871;
  int32_t _M0L6_2atmpS815;
  void* _M0L3errS432;
  moonbit_string_t _M0L4nameS434;
  struct _M0DTPC15error5Error93walkzzz_2fmcp__server_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTest* _M0L36_2aMoonBitTestDriverInternalSkipTestS435;
  moonbit_string_t _M0L7_2anameS436;
  int32_t _M0L6_2acntS865;
  #line 563 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  moonbit_incref(_M0L8filenameS406);
  _closure_867
  = (struct _M0R93_24walkzzz_2fmcp__server_2emoonbit__test__driver__internal__do__execute_2ehandle__start_7c404*)moonbit_malloc(sizeof(struct _M0R93_24walkzzz_2fmcp__server_2emoonbit__test__driver__internal__do__execute_2ehandle__start_7c404));
  Moonbit_object_header(_closure_867)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 0, 0);
  _closure_867->code
  = &_M0FP27walkzzz11mcp__server44moonbit__test__driver__internal__do__executeN13handle__startS404;
  _closure_867->$0 = _M0L5indexS408;
  _closure_867->$1 = _M0L8filenameS406;
  _M0L13handle__startS404 = (struct _M0TWEu*)_closure_867;
  moonbit_incref(_M0L8filenameS406);
  _closure_868
  = (struct _M0R94_24walkzzz_2fmcp__server_2emoonbit__test__driver__internal__do__execute_2ehandle__result_7c409*)moonbit_malloc(sizeof(struct _M0R94_24walkzzz_2fmcp__server_2emoonbit__test__driver__internal__do__execute_2ehandle__result_7c409));
  Moonbit_object_header(_closure_868)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 3, 0);
  _closure_868->code
  = &_M0FP27walkzzz11mcp__server44moonbit__test__driver__internal__do__executeN14handle__resultS409;
  _closure_868->$0 = _M0L5indexS408;
  _closure_868->$1 = _M0L8filenameS406;
  _M0L14handle__resultS409 = (struct _M0TWssbEu*)_closure_868;
  _M0L17error__to__stringS416
  = (struct _M0TWRPC15error5ErrorEs*)&_M0FP27walkzzz11mcp__server44moonbit__test__driver__internal__do__executeN17error__to__stringS416$closure.data;
  #line 605 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _tmp_870
  = _M0IP016_24default__implP27walkzzz11mcp__server21MoonBit__Test__Driver9run__testGRP27walkzzz11mcp__server41MoonBit__Test__Driver__Internal__No__ArgsE(_M0L12async__testsS437, _M0L8filenameS406, _M0L5indexS408, _M0L13handle__startS404, _M0L14handle__resultS409, _M0L17error__to__stringS416);
  if (_tmp_870.tag) {
    int32_t const _M0L5_2aokS824 = _tmp_870.data.ok;
    _handle__error__result_871 = _M0L5_2aokS824;
  } else {
    void* const _M0L6_2aerrS825 = _tmp_870.data.err;
    moonbit_decref(_M0L17error__to__stringS416);
    moonbit_decref(_M0L13handle__startS404);
    _M0L11_2atry__errS431 = _M0L6_2aerrS825;
    goto join_430;
  }
  if (_handle__error__result_871) {
    moonbit_decref(_M0L17error__to__stringS416);
    moonbit_decref(_M0L13handle__startS404);
    _M0L6_2atmpS815 = 1;
  } else {
    struct moonbit_result_0 _tmp_872;
    int32_t _handle__error__result_873;
    #line 608 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
    _tmp_872
    = _M0IP016_24default__implP27walkzzz11mcp__server21MoonBit__Test__Driver9run__testGRP27walkzzz11mcp__server43MoonBit__Test__Driver__Internal__With__ArgsE(_M0L12async__testsS437, _M0L8filenameS406, _M0L5indexS408, _M0L13handle__startS404, _M0L14handle__resultS409, _M0L17error__to__stringS416);
    if (_tmp_872.tag) {
      int32_t const _M0L5_2aokS822 = _tmp_872.data.ok;
      _handle__error__result_873 = _M0L5_2aokS822;
    } else {
      void* const _M0L6_2aerrS823 = _tmp_872.data.err;
      moonbit_decref(_M0L17error__to__stringS416);
      moonbit_decref(_M0L13handle__startS404);
      _M0L11_2atry__errS431 = _M0L6_2aerrS823;
      goto join_430;
    }
    if (_handle__error__result_873) {
      moonbit_decref(_M0L17error__to__stringS416);
      moonbit_decref(_M0L13handle__startS404);
      _M0L6_2atmpS815 = 1;
    } else {
      struct moonbit_result_0 _tmp_874;
      int32_t _handle__error__result_875;
      #line 611 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
      _tmp_874
      = _M0IP016_24default__implP27walkzzz11mcp__server21MoonBit__Test__Driver9run__testGRP27walkzzz11mcp__server48MoonBit__Test__Driver__Internal__Async__No__ArgsE(_M0L12async__testsS437, _M0L8filenameS406, _M0L5indexS408, _M0L13handle__startS404, _M0L14handle__resultS409, _M0L17error__to__stringS416);
      if (_tmp_874.tag) {
        int32_t const _M0L5_2aokS820 = _tmp_874.data.ok;
        _handle__error__result_875 = _M0L5_2aokS820;
      } else {
        void* const _M0L6_2aerrS821 = _tmp_874.data.err;
        moonbit_decref(_M0L17error__to__stringS416);
        moonbit_decref(_M0L13handle__startS404);
        _M0L11_2atry__errS431 = _M0L6_2aerrS821;
        goto join_430;
      }
      if (_handle__error__result_875) {
        moonbit_decref(_M0L17error__to__stringS416);
        moonbit_decref(_M0L13handle__startS404);
        _M0L6_2atmpS815 = 1;
      } else {
        struct moonbit_result_0 _tmp_876;
        int32_t _handle__error__result_877;
        #line 614 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
        _tmp_876
        = _M0IP016_24default__implP27walkzzz11mcp__server21MoonBit__Test__Driver9run__testGRP27walkzzz11mcp__server50MoonBit__Test__Driver__Internal__Async__With__ArgsE(_M0L12async__testsS437, _M0L8filenameS406, _M0L5indexS408, _M0L13handle__startS404, _M0L14handle__resultS409, _M0L17error__to__stringS416);
        if (_tmp_876.tag) {
          int32_t const _M0L5_2aokS818 = _tmp_876.data.ok;
          _handle__error__result_877 = _M0L5_2aokS818;
        } else {
          void* const _M0L6_2aerrS819 = _tmp_876.data.err;
          moonbit_decref(_M0L17error__to__stringS416);
          moonbit_decref(_M0L13handle__startS404);
          _M0L11_2atry__errS431 = _M0L6_2aerrS819;
          goto join_430;
        }
        if (_handle__error__result_877) {
          moonbit_decref(_M0L17error__to__stringS416);
          moonbit_decref(_M0L13handle__startS404);
          _M0L6_2atmpS815 = 1;
        } else {
          struct moonbit_result_0 _tmp_878;
          #line 617 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
          _tmp_878
          = _M0IP016_24default__implP27walkzzz11mcp__server21MoonBit__Test__Driver9run__testGRP27walkzzz11mcp__server50MoonBit__Test__Driver__Internal__With__Bench__ArgsE(_M0L12async__testsS437, _M0L8filenameS406, _M0L5indexS408, _M0L13handle__startS404, _M0L14handle__resultS409, _M0L17error__to__stringS416);
          moonbit_decref(_M0L13handle__startS404);
          moonbit_decref(_M0L17error__to__stringS416);
          if (_tmp_878.tag) {
            int32_t const _M0L5_2aokS816 = _tmp_878.data.ok;
            _M0L6_2atmpS815 = _M0L5_2aokS816;
          } else {
            void* const _M0L6_2aerrS817 = _tmp_878.data.err;
            _M0L11_2atry__errS431 = _M0L6_2aerrS817;
            goto join_430;
          }
        }
      }
    }
  }
  if (!_M0L6_2atmpS815) {
    void* _M0L93walkzzz_2fmcp__server_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTestS826 =
      (void*)moonbit_malloc(sizeof(struct _M0DTPC15error5Error93walkzzz_2fmcp__server_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTest));
    Moonbit_object_header(_M0L93walkzzz_2fmcp__server_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTestS826)->meta
    = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 6, 1);
    ((struct _M0DTPC15error5Error93walkzzz_2fmcp__server_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTest*)_M0L93walkzzz_2fmcp__server_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTestS826)->$0
    = (moonbit_string_t)moonbit_string_literal_0.data;
    _M0L11_2atry__errS431
    = _M0L93walkzzz_2fmcp__server_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTestS826;
    goto join_430;
  } else {
    moonbit_decref(_M0L14handle__resultS409);
  }
  goto joinlet_869;
  join_430:;
  _M0L3errS432 = _M0L11_2atry__errS431;
  _M0L36_2aMoonBitTestDriverInternalSkipTestS435
  = (struct _M0DTPC15error5Error93walkzzz_2fmcp__server_2eMoonBitTestDriverInternalSkipTest_2eMoonBitTestDriverInternalSkipTest*)_M0L3errS432;
  _M0L7_2anameS436 = _M0L36_2aMoonBitTestDriverInternalSkipTestS435->$0;
  _M0L6_2acntS865
  = Moonbit_rc_count(Moonbit_object_header(_M0L36_2aMoonBitTestDriverInternalSkipTestS435));
  if (_M0L6_2acntS865 > 1) {
    int32_t _M0L11_2anew__cntS866 = _M0L6_2acntS865 - 1;
    Moonbit_set_rc_count(Moonbit_object_header(_M0L36_2aMoonBitTestDriverInternalSkipTestS435), _M0L11_2anew__cntS866);
    moonbit_incref(_M0L7_2anameS436);
  } else if (_M0L6_2acntS865 == 1) {
    #line 624 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
    moonbit_free(_M0L36_2aMoonBitTestDriverInternalSkipTestS435);
  }
  _M0L4nameS434 = _M0L7_2anameS436;
  goto join_433;
  goto joinlet_879;
  join_433:;
  #line 625 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0FP27walkzzz11mcp__server44moonbit__test__driver__internal__do__executeN14handle__resultS409(_M0L14handle__resultS409, _M0L4nameS434, (moonbit_string_t)moonbit_string_literal_1.data, 1);
  moonbit_decref(_M0L14handle__resultS409);
  moonbit_decref(_M0L4nameS434);
  joinlet_879:;
  joinlet_869:;
  return 0;
}

moonbit_string_t _M0FP27walkzzz11mcp__server44moonbit__test__driver__internal__do__executeN17error__to__stringS416(
  struct _M0TWRPC15error5ErrorEs* _M0L6_2aenvS814,
  void* _M0L3errS417
) {
  void* _M0L1eS419;
  moonbit_string_t _M0L1eS421;
  moonbit_string_t _result_882;
  #line 594 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  switch (Moonbit_object_tag(_M0L3errS417)) {
    case 0: {
      struct _M0DTPC15error5Error48moonbitlang_2fcore_2fbuiltin_2eFailure_2eFailure* _M0L10_2aFailureS422 =
        (struct _M0DTPC15error5Error48moonbitlang_2fcore_2fbuiltin_2eFailure_2eFailure*)_M0L3errS417;
      moonbit_string_t _M0L4_2aeS423 = _M0L10_2aFailureS422->$0;
      moonbit_incref(_M0L4_2aeS423);
      _M0L1eS421 = _M0L4_2aeS423;
      goto join_420;
      break;
    }
    
    case 2: {
      struct _M0DTPC15error5Error58moonbitlang_2fcore_2fbuiltin_2eInspectError_2eInspectError* _M0L15_2aInspectErrorS424 =
        (struct _M0DTPC15error5Error58moonbitlang_2fcore_2fbuiltin_2eInspectError_2eInspectError*)_M0L3errS417;
      moonbit_string_t _M0L4_2aeS425 = _M0L15_2aInspectErrorS424->$0;
      moonbit_incref(_M0L4_2aeS425);
      _M0L1eS421 = _M0L4_2aeS425;
      goto join_420;
      break;
    }
    
    case 3: {
      struct _M0DTPC15error5Error60moonbitlang_2fcore_2fbuiltin_2eSnapshotError_2eSnapshotError* _M0L16_2aSnapshotErrorS426 =
        (struct _M0DTPC15error5Error60moonbitlang_2fcore_2fbuiltin_2eSnapshotError_2eSnapshotError*)_M0L3errS417;
      moonbit_string_t _M0L4_2aeS427 = _M0L16_2aSnapshotErrorS426->$0;
      moonbit_incref(_M0L4_2aeS427);
      _M0L1eS421 = _M0L4_2aeS427;
      goto join_420;
      break;
    }
    
    case 4: {
      struct _M0DTPC15error5Error91walkzzz_2fmcp__server_2eMoonBitTestDriverInternalJsError_2eMoonBitTestDriverInternalJsError* _M0L35_2aMoonBitTestDriverInternalJsErrorS428 =
        (struct _M0DTPC15error5Error91walkzzz_2fmcp__server_2eMoonBitTestDriverInternalJsError_2eMoonBitTestDriverInternalJsError*)_M0L3errS417;
      moonbit_string_t _M0L4_2aeS429 =
        _M0L35_2aMoonBitTestDriverInternalJsErrorS428->$0;
      moonbit_incref(_M0L4_2aeS429);
      _M0L1eS421 = _M0L4_2aeS429;
      goto join_420;
      break;
    }
    default: {
      moonbit_incref(_M0L3errS417);
      _M0L1eS419 = _M0L3errS417;
      goto join_418;
      break;
    }
  }
  join_420:;
  return _M0L1eS421;
  join_418:;
  #line 600 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _result_882 = _M0FP15Error10to__string(_M0L1eS419);
  moonbit_decref(_M0L1eS419);
  return _result_882;
}

int32_t _M0FP27walkzzz11mcp__server44moonbit__test__driver__internal__do__executeN14handle__resultS409(
  struct _M0TWssbEu* _M0L6_2aenvS811,
  moonbit_string_t _M0L10__testnameS410,
  moonbit_string_t _M0L7messageS411,
  int32_t _M0L7skippedS412
) {
  struct _M0R94_24walkzzz_2fmcp__server_2emoonbit__test__driver__internal__do__execute_2ehandle__result_7c409* _M0L14_2acasted__envS812;
  moonbit_string_t _M0L8filenameS406;
  int32_t _M0L5indexS408;
  int32_t _if__result_883;
  moonbit_string_t _M0L10file__nameS413;
  moonbit_string_t _M0L7messageS414;
  struct _M0TPB13StringBuilder* _M0L18_2astring__builderS415;
  moonbit_string_t _M0L6_2atmpS813;
  #line 579 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0L14_2acasted__envS812
  = (struct _M0R94_24walkzzz_2fmcp__server_2emoonbit__test__driver__internal__do__execute_2ehandle__result_7c409*)_M0L6_2aenvS811;
  _M0L8filenameS406 = _M0L14_2acasted__envS812->$1;
  _M0L5indexS408 = _M0L14_2acasted__envS812->$0;
  if (!_M0L7skippedS412) {
    _if__result_883 = 1;
  } else {
    _if__result_883 = 0;
  }
  if (_if__result_883) {
    
  }
  #line 585 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0L10file__nameS413
  = _M0MPC16string6String14escape_2einner(_M0L8filenameS406, 1);
  #line 586 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0L7messageS414
  = _M0MPC16string6String14escape_2einner(_M0L7messageS411, 1);
  #line 587 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0FPB7printlnGsE((moonbit_string_t)moonbit_string_literal_2.data);
  #line 589 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0L18_2astring__builderS415
  = _M0MPB13StringBuilder21StringBuilder_2einner(45);
  #line 589 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS415, (moonbit_string_t)moonbit_string_literal_3.data);
  #line 589 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0MPB13StringBuilder13write__objectGsE(_M0L18_2astring__builderS415, _M0L10file__nameS413);
  moonbit_decref(_M0L10file__nameS413);
  #line 589 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS415, (moonbit_string_t)moonbit_string_literal_4.data);
  #line 589 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS415, _M0L5indexS408);
  #line 589 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS415, (moonbit_string_t)moonbit_string_literal_5.data);
  #line 589 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0MPB13StringBuilder13write__objectGsE(_M0L18_2astring__builderS415, _M0L7messageS414);
  moonbit_decref(_M0L7messageS414);
  #line 589 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS415, (moonbit_string_t)moonbit_string_literal_6.data);
  #line 589 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0L6_2atmpS813
  = _M0MPB13StringBuilder10to__string(_M0L18_2astring__builderS415);
  moonbit_decref(_M0L18_2astring__builderS415);
  #line 588 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0FPB7printlnGsE(_M0L6_2atmpS813);
  moonbit_decref(_M0L6_2atmpS813);
  #line 591 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0FPB7printlnGsE((moonbit_string_t)moonbit_string_literal_7.data);
  return 0;
}

int32_t _M0FP27walkzzz11mcp__server44moonbit__test__driver__internal__do__executeN13handle__startS404(
  struct _M0TWEu* _M0L6_2aenvS808
) {
  struct _M0R93_24walkzzz_2fmcp__server_2emoonbit__test__driver__internal__do__execute_2ehandle__start_7c404* _M0L14_2acasted__envS809;
  moonbit_string_t _M0L8filenameS406;
  int32_t _M0L5indexS408;
  moonbit_string_t _M0L10file__nameS405;
  struct _M0TPB13StringBuilder* _M0L18_2astring__builderS407;
  moonbit_string_t _M0L6_2atmpS810;
  #line 570 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0L14_2acasted__envS809
  = (struct _M0R93_24walkzzz_2fmcp__server_2emoonbit__test__driver__internal__do__execute_2ehandle__start_7c404*)_M0L6_2aenvS808;
  _M0L8filenameS406 = _M0L14_2acasted__envS809->$1;
  _M0L5indexS408 = _M0L14_2acasted__envS809->$0;
  #line 571 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0L10file__nameS405
  = _M0MPC16string6String14escape_2einner(_M0L8filenameS406, 1);
  #line 572 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0FPB7printlnGsE((moonbit_string_t)moonbit_string_literal_2.data);
  #line 574 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0L18_2astring__builderS407
  = _M0MPB13StringBuilder21StringBuilder_2einner(33);
  #line 574 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS407, (moonbit_string_t)moonbit_string_literal_8.data);
  #line 574 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0MPB13StringBuilder13write__objectGsE(_M0L18_2astring__builderS407, _M0L10file__nameS405);
  moonbit_decref(_M0L10file__nameS405);
  #line 574 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS407, (moonbit_string_t)moonbit_string_literal_4.data);
  #line 574 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS407, _M0L5indexS408);
  #line 574 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS407, (moonbit_string_t)moonbit_string_literal_6.data);
  #line 574 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0L6_2atmpS810
  = _M0MPB13StringBuilder10to__string(_M0L18_2astring__builderS407);
  moonbit_decref(_M0L18_2astring__builderS407);
  #line 573 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0FPB7printlnGsE(_M0L6_2atmpS810);
  moonbit_decref(_M0L6_2atmpS810);
  #line 576 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0FPB7printlnGsE((moonbit_string_t)moonbit_string_literal_7.data);
  return 0;
}

struct _M0TPB5ArrayGUsiEE* _M0FP27walkzzz11mcp__server52moonbit__test__driver__internal__native__parse__args(
  
) {
  int32_t _M0L45moonbit__test__driver__internal__parse__int__S375;
  int32_t _M0L51moonbit__test__driver__internal__split__mbt__stringS382;
  struct _M0TUsiE** _M0L6_2atmpS807;
  struct _M0TPB5ArrayGUsiEE* _M0L16file__and__indexS389;
  moonbit_string_t* _M0L9cli__argsS390;
  moonbit_string_t _M0L6_2atmpS829;
  moonbit_string_t _M0L6_2atmpS806;
  moonbit_string_t _M0L6_2atmpS805;
  struct _M0TPB5ArrayGsE* _M0L10test__argsS391;
  int32_t _M0L7_2abindS392;
  int32_t _M0L2__S393;
  #line 295 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0L45moonbit__test__driver__internal__parse__int__S375 = 0;
  _M0L51moonbit__test__driver__internal__split__mbt__stringS382 = 0;
  _M0L6_2atmpS807 = (struct _M0TUsiE**)moonbit_empty_ref_array;
  _M0L16file__and__indexS389
  = (struct _M0TPB5ArrayGUsiEE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGUsiEE));
  Moonbit_object_header(_M0L16file__and__indexS389)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 9, 0);
  _M0L16file__and__indexS389->$0 = _M0L6_2atmpS807;
  _M0L16file__and__indexS389->$1 = 0;
  #line 329 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0L9cli__argsS390
  = _M0FP27walkzzz11mcp__server52moonbit__test__driver__internal__get__cli__args__ffi();
  if (1 < 0 || 1 >= Moonbit_array_length(_M0L9cli__argsS390)) {
    #line 331 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
    moonbit_panic();
  }
  _M0L6_2atmpS829 = (moonbit_string_t)_M0L9cli__argsS390[1];
  moonbit_incref(_M0L6_2atmpS829);
  moonbit_decref(_M0L9cli__argsS390);
  _M0L6_2atmpS806 = _M0L6_2atmpS829;
  #line 331 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0L6_2atmpS805
  = _M0MP27walkzzz11mcp__server33MoonBitTestDriverInternalOsString10to__string(_M0L6_2atmpS806);
  moonbit_decref(_M0L6_2atmpS806);
  #line 330 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0L10test__argsS391
  = _M0FP27walkzzz11mcp__server52moonbit__test__driver__internal__native__parse__argsN51moonbit__test__driver__internal__split__mbt__stringS382(_M0L51moonbit__test__driver__internal__split__mbt__stringS382, _M0L6_2atmpS805, 47);
  moonbit_decref(_M0L6_2atmpS805);
  _M0L7_2abindS392 = _M0L10test__argsS391->$1;
  _M0L2__S393 = 0;
  while (1) {
    if (_M0L2__S393 < _M0L7_2abindS392) {
      moonbit_string_t* _M0L3bufS804 = _M0L10test__argsS391->$0;
      moonbit_string_t _M0L3argS394 =
        (moonbit_string_t)_M0L3bufS804[_M0L2__S393];
      struct _M0TPB5ArrayGsE* _M0L16file__and__rangeS395;
      moonbit_string_t _M0L4fileS396;
      moonbit_string_t _M0L5rangeS397;
      struct _M0TPB5ArrayGsE* _M0L15start__and__endS398;
      moonbit_string_t _M0L6_2atmpS802;
      int32_t _M0L5startS399;
      moonbit_string_t _M0L6_2atmpS801;
      int32_t _M0L3endS400;
      int32_t _M0L1iS401;
      int32_t _M0L6_2atmpS803;
      moonbit_incref(_M0L3argS394);
      #line 335 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
      _M0L16file__and__rangeS395
      = _M0FP27walkzzz11mcp__server52moonbit__test__driver__internal__native__parse__argsN51moonbit__test__driver__internal__split__mbt__stringS382(_M0L51moonbit__test__driver__internal__split__mbt__stringS382, _M0L3argS394, 58);
      moonbit_decref(_M0L3argS394);
      #line 336 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
      _M0L4fileS396
      = _M0MPC15array5Array2atGsE(_M0L16file__and__rangeS395, 0);
      #line 337 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
      _M0L5rangeS397
      = _M0MPC15array5Array2atGsE(_M0L16file__and__rangeS395, 1);
      moonbit_decref(_M0L16file__and__rangeS395);
      #line 338 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
      _M0L15start__and__endS398
      = _M0FP27walkzzz11mcp__server52moonbit__test__driver__internal__native__parse__argsN51moonbit__test__driver__internal__split__mbt__stringS382(_M0L51moonbit__test__driver__internal__split__mbt__stringS382, _M0L5rangeS397, 45);
      moonbit_decref(_M0L5rangeS397);
      #line 341 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
      _M0L6_2atmpS802
      = _M0MPC15array5Array2atGsE(_M0L15start__and__endS398, 0);
      #line 341 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
      _M0L5startS399
      = _M0FP27walkzzz11mcp__server52moonbit__test__driver__internal__native__parse__argsN45moonbit__test__driver__internal__parse__int__S375(_M0L45moonbit__test__driver__internal__parse__int__S375, _M0L6_2atmpS802);
      moonbit_decref(_M0L6_2atmpS802);
      #line 342 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
      _M0L6_2atmpS801
      = _M0MPC15array5Array2atGsE(_M0L15start__and__endS398, 1);
      moonbit_decref(_M0L15start__and__endS398);
      #line 342 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
      _M0L3endS400
      = _M0FP27walkzzz11mcp__server52moonbit__test__driver__internal__native__parse__argsN45moonbit__test__driver__internal__parse__int__S375(_M0L45moonbit__test__driver__internal__parse__int__S375, _M0L6_2atmpS801);
      moonbit_decref(_M0L6_2atmpS801);
      _M0L1iS401 = _M0L5startS399;
      while (1) {
        if (_M0L1iS401 < _M0L3endS400) {
          struct _M0TUsiE* _M0L8_2atupleS799;
          int32_t _M0L6_2atmpS800;
          moonbit_incref(_M0L4fileS396);
          _M0L8_2atupleS799
          = (struct _M0TUsiE*)moonbit_malloc(sizeof(struct _M0TUsiE));
          Moonbit_object_header(_M0L8_2atupleS799)->meta
          = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 12, 0);
          _M0L8_2atupleS799->$0 = _M0L4fileS396;
          _M0L8_2atupleS799->$1 = _M0L1iS401;
          #line 344 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
          _M0MPC15array5Array4pushGUsiEE(_M0L16file__and__indexS389, _M0L8_2atupleS799);
          _M0L6_2atmpS800 = _M0L1iS401 + 1;
          _M0L1iS401 = _M0L6_2atmpS800;
          continue;
        } else {
          moonbit_decref(_M0L4fileS396);
        }
        break;
      }
      _M0L6_2atmpS803 = _M0L2__S393 + 1;
      _M0L2__S393 = _M0L6_2atmpS803;
      continue;
    } else {
      moonbit_decref(_M0L10test__argsS391);
    }
    break;
  }
  return _M0L16file__and__indexS389;
}

struct _M0TPB5ArrayGsE* _M0FP27walkzzz11mcp__server52moonbit__test__driver__internal__native__parse__argsN51moonbit__test__driver__internal__split__mbt__stringS382(
  int32_t _M0L6_2aenvS780,
  moonbit_string_t _M0L1sS383,
  int32_t _M0L3sepS384
) {
  moonbit_string_t* _M0L6_2atmpS798;
  struct _M0TPB5ArrayGsE* _M0L3resS385;
  struct _M0TPB8MutLocalGiE* _M0L1iS386;
  struct _M0TPB8MutLocalGiE* _M0L5startS387;
  int32_t _M0L3valS793;
  int32_t _M0L6_2atmpS794;
  #line 308 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0L6_2atmpS798 = (moonbit_string_t*)moonbit_empty_ref_array;
  _M0L3resS385
  = (struct _M0TPB5ArrayGsE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGsE));
  Moonbit_object_header(_M0L3resS385)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 15, 0);
  _M0L3resS385->$0 = _M0L6_2atmpS798;
  _M0L3resS385->$1 = 0;
  _M0L1iS386
  = (struct _M0TPB8MutLocalGiE*)moonbit_malloc(sizeof(struct _M0TPB8MutLocalGiE));
  Moonbit_object_header(_M0L1iS386)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0);
  _M0L1iS386->$0 = 0;
  _M0L5startS387
  = (struct _M0TPB8MutLocalGiE*)moonbit_malloc(sizeof(struct _M0TPB8MutLocalGiE));
  Moonbit_object_header(_M0L5startS387)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0);
  _M0L5startS387->$0 = 0;
  while (1) {
    int32_t _M0L3valS781 = _M0L1iS386->$0;
    int32_t _M0L6_2atmpS782 = Moonbit_array_length(_M0L1sS383);
    if (_M0L3valS781 < _M0L6_2atmpS782) {
      int32_t _M0L3valS785 = _M0L1iS386->$0;
      int32_t _M0L6_2atmpS784;
      int32_t _M0L6_2atmpS783;
      int32_t _M0L3valS792;
      int32_t _M0L6_2atmpS791;
      if (
        _M0L3valS785 < 0 || _M0L3valS785 >= Moonbit_array_length(_M0L1sS383)
      ) {
        #line 316 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
        moonbit_panic();
      }
      _M0L6_2atmpS784 = _M0L1sS383[_M0L3valS785];
      _M0L6_2atmpS783 = _M0L6_2atmpS784;
      if (_M0L6_2atmpS783 == _M0L3sepS384) {
        int32_t _M0L3valS787 = _M0L5startS387->$0;
        int32_t _M0L3valS788 = _M0L1iS386->$0;
        moonbit_string_t _M0L6_2atmpS786;
        int32_t _M0L3valS790;
        int32_t _M0L6_2atmpS789;
        #line 317 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
        _M0L6_2atmpS786
        = _M0MPC16string6String17unsafe__substring(_M0L1sS383, _M0L3valS787, _M0L3valS788);
        #line 317 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
        _M0MPC15array5Array4pushGsE(_M0L3resS385, _M0L6_2atmpS786);
        _M0L3valS790 = _M0L1iS386->$0;
        _M0L6_2atmpS789 = _M0L3valS790 + 1;
        _M0L5startS387->$0 = _M0L6_2atmpS789;
      }
      _M0L3valS792 = _M0L1iS386->$0;
      _M0L6_2atmpS791 = _M0L3valS792 + 1;
      _M0L1iS386->$0 = _M0L6_2atmpS791;
      continue;
    } else {
      moonbit_decref(_M0L1iS386);
    }
    break;
  }
  _M0L3valS793 = _M0L5startS387->$0;
  _M0L6_2atmpS794 = Moonbit_array_length(_M0L1sS383);
  if (_M0L3valS793 < _M0L6_2atmpS794) {
    int32_t _M0L3valS796 = _M0L5startS387->$0;
    int32_t _M0L6_2atmpS797;
    moonbit_string_t _M0L6_2atmpS795;
    moonbit_decref(_M0L5startS387);
    _M0L6_2atmpS797 = Moonbit_array_length(_M0L1sS383);
    #line 323 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
    _M0L6_2atmpS795
    = _M0MPC16string6String17unsafe__substring(_M0L1sS383, _M0L3valS796, _M0L6_2atmpS797);
    #line 323 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
    _M0MPC15array5Array4pushGsE(_M0L3resS385, _M0L6_2atmpS795);
  } else {
    moonbit_decref(_M0L5startS387);
  }
  return _M0L3resS385;
}

int32_t _M0FP27walkzzz11mcp__server52moonbit__test__driver__internal__native__parse__argsN45moonbit__test__driver__internal__parse__int__S375(
  int32_t _M0L6_2aenvS773,
  moonbit_string_t _M0L1sS376
) {
  struct _M0TPB8MutLocalGiE* _M0L3resS377;
  int32_t _M0L3lenS378;
  int32_t _M0L7_2abindS379;
  int32_t _M0L1iS380;
  int32_t _result_888;
  #line 299 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0L3resS377
  = (struct _M0TPB8MutLocalGiE*)moonbit_malloc(sizeof(struct _M0TPB8MutLocalGiE));
  Moonbit_object_header(_M0L3resS377)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_SCALAR, 0, 0);
  _M0L3resS377->$0 = 0;
  _M0L3lenS378 = Moonbit_array_length(_M0L1sS376);
  _M0L7_2abindS379 = 0;
  _M0L1iS380 = _M0L7_2abindS379;
  while (1) {
    if (_M0L1iS380 < _M0L3lenS378) {
      int32_t _M0L3valS778 = _M0L3resS377->$0;
      int32_t _M0L6_2atmpS775 = _M0L3valS778 * 10;
      int32_t _M0L6_2atmpS777;
      int32_t _M0L6_2atmpS776;
      int32_t _M0L6_2atmpS774;
      int32_t _M0L6_2atmpS779;
      if (_M0L1iS380 < 0 || _M0L1iS380 >= Moonbit_array_length(_M0L1sS376)) {
        #line 303 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
        moonbit_panic();
      }
      _M0L6_2atmpS777 = _M0L1sS376[_M0L1iS380];
      _M0L6_2atmpS776 = _M0L6_2atmpS777 - 48;
      _M0L6_2atmpS774 = _M0L6_2atmpS775 + _M0L6_2atmpS776;
      _M0L3resS377->$0 = _M0L6_2atmpS774;
      _M0L6_2atmpS779 = _M0L1iS380 + 1;
      _M0L1iS380 = _M0L6_2atmpS779;
      continue;
    }
    break;
  }
  _result_888 = _M0L3resS377->$0;
  moonbit_decref(_M0L3resS377);
  return _result_888;
}

moonbit_string_t _M0MP27walkzzz11mcp__server33MoonBitTestDriverInternalOsString10to__string(
  moonbit_string_t _M0L4selfS374
) {
  #line 164 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  moonbit_incref(_M0L4selfS374);
  return _M0L4selfS374;
}

struct moonbit_result_0 _M0IP016_24default__implP27walkzzz11mcp__server21MoonBit__Test__Driver9run__testGRP27walkzzz11mcp__server41MoonBit__Test__Driver__Internal__No__ArgsE(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE* _M0L12_2adiscard__S344,
  moonbit_string_t _M0L12_2adiscard__S345,
  int32_t _M0L12_2adiscard__S346,
  struct _M0TWEu* _M0L12_2adiscard__S347,
  struct _M0TWssbEu* _M0L12_2adiscard__S348,
  struct _M0TWRPC15error5ErrorEs* _M0L12_2adiscard__S349
) {
  struct moonbit_result_0 _result_889;
  #line 35 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _result_889.tag = 1;
  _result_889.data.ok = 0;
  return _result_889;
}

struct moonbit_result_0 _M0IP016_24default__implP27walkzzz11mcp__server21MoonBit__Test__Driver9run__testGRP27walkzzz11mcp__server43MoonBit__Test__Driver__Internal__With__ArgsE(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE* _M0L12_2adiscard__S350,
  moonbit_string_t _M0L12_2adiscard__S351,
  int32_t _M0L12_2adiscard__S352,
  struct _M0TWEu* _M0L12_2adiscard__S353,
  struct _M0TWssbEu* _M0L12_2adiscard__S354,
  struct _M0TWRPC15error5ErrorEs* _M0L12_2adiscard__S355
) {
  struct moonbit_result_0 _result_890;
  #line 35 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _result_890.tag = 1;
  _result_890.data.ok = 0;
  return _result_890;
}

struct moonbit_result_0 _M0IP016_24default__implP27walkzzz11mcp__server21MoonBit__Test__Driver9run__testGRP27walkzzz11mcp__server48MoonBit__Test__Driver__Internal__Async__No__ArgsE(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE* _M0L12_2adiscard__S356,
  moonbit_string_t _M0L12_2adiscard__S357,
  int32_t _M0L12_2adiscard__S358,
  struct _M0TWEu* _M0L12_2adiscard__S359,
  struct _M0TWssbEu* _M0L12_2adiscard__S360,
  struct _M0TWRPC15error5ErrorEs* _M0L12_2adiscard__S361
) {
  struct moonbit_result_0 _result_891;
  #line 35 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _result_891.tag = 1;
  _result_891.data.ok = 0;
  return _result_891;
}

struct moonbit_result_0 _M0IP016_24default__implP27walkzzz11mcp__server21MoonBit__Test__Driver9run__testGRP27walkzzz11mcp__server50MoonBit__Test__Driver__Internal__Async__With__ArgsE(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE* _M0L12_2adiscard__S362,
  moonbit_string_t _M0L12_2adiscard__S363,
  int32_t _M0L12_2adiscard__S364,
  struct _M0TWEu* _M0L12_2adiscard__S365,
  struct _M0TWssbEu* _M0L12_2adiscard__S366,
  struct _M0TWRPC15error5ErrorEs* _M0L12_2adiscard__S367
) {
  struct moonbit_result_0 _result_892;
  #line 35 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _result_892.tag = 1;
  _result_892.data.ok = 0;
  return _result_892;
}

struct moonbit_result_0 _M0IP016_24default__implP27walkzzz11mcp__server21MoonBit__Test__Driver9run__testGRP27walkzzz11mcp__server50MoonBit__Test__Driver__Internal__With__Bench__ArgsE(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE* _M0L12_2adiscard__S368,
  moonbit_string_t _M0L12_2adiscard__S369,
  int32_t _M0L12_2adiscard__S370,
  struct _M0TWEu* _M0L12_2adiscard__S371,
  struct _M0TWssbEu* _M0L12_2adiscard__S372,
  struct _M0TWRPC15error5ErrorEs* _M0L12_2adiscard__S373
) {
  struct moonbit_result_0 _result_893;
  #line 35 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _result_893.tag = 1;
  _result_893.data.ok = 0;
  return _result_893;
}

int32_t _M0IP016_24default__implP27walkzzz11mcp__server28MoonBit__Async__Test__Driver20is__being__cancelledGRP27walkzzz11mcp__server34MoonBit__Async__Test__Driver__ImplE(
  
) {
  #line 17 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  return 0;
}

int32_t _M0IP016_24default__implP27walkzzz11mcp__server28MoonBit__Async__Test__Driver17run__async__testsGRP27walkzzz11mcp__server34MoonBit__Async__Test__Driver__ImplE(
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE* _M0L12_2adiscard__S343
) {
  #line 12 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  return 0;
}

moonbit_string_t _M0MPC15array5Array2atGsE(
  struct _M0TPB5ArrayGsE* _M0L4selfS341,
  int32_t _M0L5indexS342
) {
  int32_t _M0L3lenS340;
  int32_t _if__result_894;
  #line 183 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L3lenS340 = _M0L4selfS341->$1;
  if (_M0L5indexS342 >= 0) {
    _if__result_894 = _M0L5indexS342 < _M0L3lenS340;
  } else {
    _if__result_894 = 0;
  }
  if (_if__result_894) {
    moonbit_string_t* _M0L6_2atmpS772;
    moonbit_string_t _M0L6_2atmpS830;
    #line 188 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
    _M0L6_2atmpS772 = _M0MPC15array5Array6bufferGsE(_M0L4selfS341);
    _M0L6_2atmpS830 = (moonbit_string_t)_M0L6_2atmpS772[_M0L5indexS342];
    moonbit_incref(_M0L6_2atmpS830);
    moonbit_decref(_M0L6_2atmpS772);
    return _M0L6_2atmpS830;
  } else {
    #line 187 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
    moonbit_panic();
  }
}

int32_t _M0FPB7printlnGsE(moonbit_string_t _M0L5inputS339) {
  moonbit_string_t _M0L6_2atmpS771;
  #line 36 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\console.mbt"
  #line 37 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\console.mbt"
  _M0L6_2atmpS771 = _M0IPC16string6StringPB4Show10to__string(_M0L5inputS339);
  #line 37 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\console.mbt"
  moonbit_println(_M0L6_2atmpS771);
  moonbit_decref(_M0L6_2atmpS771);
  return 0;
}

moonbit_string_t _M0IPC13int3IntPB4Show10to__string(int32_t _M0L4selfS338) {
  #line 35 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  #line 36 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  return _M0MPC13int3Int18to__string_2einner(_M0L4selfS338, 10);
}

int32_t _M0MPC15array5Array4pushGsE(
  struct _M0TPB5ArrayGsE* _M0L4selfS332,
  moonbit_string_t _M0L5valueS334
) {
  int32_t _M0L3lenS757;
  moonbit_string_t* _M0L6_2atmpS759;
  int32_t _M0L6_2atmpS758;
  int32_t _M0L6lengthS333;
  moonbit_string_t* _M0L3bufS762;
  moonbit_string_t _M0L6_2aoldS831;
  int32_t _M0L6_2atmpS763;
  #line 355 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L3lenS757 = _M0L4selfS332->$1;
  #line 357 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L6_2atmpS759 = _M0MPC15array5Array6bufferGsE(_M0L4selfS332);
  _M0L6_2atmpS758 = Moonbit_array_length(_M0L6_2atmpS759);
  moonbit_decref(_M0L6_2atmpS759);
  if (_M0L3lenS757 == _M0L6_2atmpS758) {
    int32_t _M0L3lenS761 = _M0L4selfS332->$1;
    int32_t _M0L6_2atmpS760 = _M0L3lenS761 + 1;
    #line 358 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
    _M0MPC15array5Array7reallocGsE(_M0L4selfS332, _M0L6_2atmpS760);
  }
  _M0L6lengthS333 = _M0L4selfS332->$1;
  _M0L3bufS762 = _M0L4selfS332->$0;
  _M0L6_2aoldS831 = (moonbit_string_t)_M0L3bufS762[_M0L6lengthS333];
  moonbit_decref(_M0L6_2aoldS831);
  _M0L3bufS762[_M0L6lengthS333] = _M0L5valueS334;
  _M0L6_2atmpS763 = _M0L6lengthS333 + 1;
  _M0L4selfS332->$1 = _M0L6_2atmpS763;
  return 0;
}

int32_t _M0MPC15array5Array4pushGUsiEE(
  struct _M0TPB5ArrayGUsiEE* _M0L4selfS335,
  struct _M0TUsiE* _M0L5valueS337
) {
  int32_t _M0L3lenS764;
  struct _M0TUsiE** _M0L6_2atmpS766;
  int32_t _M0L6_2atmpS765;
  int32_t _M0L6lengthS336;
  struct _M0TUsiE** _M0L3bufS769;
  struct _M0TUsiE* _M0L6_2aoldS832;
  int32_t _M0L6_2atmpS770;
  #line 355 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L3lenS764 = _M0L4selfS335->$1;
  #line 357 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L6_2atmpS766 = _M0MPC15array5Array6bufferGUsiEE(_M0L4selfS335);
  _M0L6_2atmpS765 = Moonbit_array_length(_M0L6_2atmpS766);
  moonbit_decref(_M0L6_2atmpS766);
  if (_M0L3lenS764 == _M0L6_2atmpS765) {
    int32_t _M0L3lenS768 = _M0L4selfS335->$1;
    int32_t _M0L6_2atmpS767 = _M0L3lenS768 + 1;
    #line 358 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
    _M0MPC15array5Array7reallocGUsiEE(_M0L4selfS335, _M0L6_2atmpS767);
  }
  _M0L6lengthS336 = _M0L4selfS335->$1;
  _M0L3bufS769 = _M0L4selfS335->$0;
  _M0L6_2aoldS832 = (struct _M0TUsiE*)_M0L3bufS769[_M0L6lengthS336];
  if (_M0L6_2aoldS832) {
    moonbit_decref(_M0L6_2aoldS832);
  }
  _M0L3bufS769[_M0L6lengthS336] = _M0L5valueS337;
  _M0L6_2atmpS770 = _M0L6lengthS336 + 1;
  _M0L4selfS335->$1 = _M0L6_2atmpS770;
  return 0;
}

int32_t _M0MPC15array5Array7reallocGsE(
  struct _M0TPB5ArrayGsE* _M0L4selfS325,
  int32_t _M0L8requiredS327
) {
  int32_t _M0L8old__capS324;
  int32_t _M0L3lenS755;
  int32_t _M0L8new__capS326;
  #line 294 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  #line 296 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8old__capS324 = _M0MPC15array5Array8capacityGsE(_M0L4selfS325);
  _M0L3lenS755 = _M0L4selfS325->$1;
  #line 297 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8new__capS326
  = _M0FPB23array__growth__capacity(_M0L8old__capS324, _M0L3lenS755, _M0L8requiredS327);
  #line 298 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0MPC15array5Array14resize__bufferGsE(_M0L4selfS325, _M0L8new__capS326);
  return 0;
}

int32_t _M0MPC15array5Array7reallocGUsiEE(
  struct _M0TPB5ArrayGUsiEE* _M0L4selfS329,
  int32_t _M0L8requiredS331
) {
  int32_t _M0L8old__capS328;
  int32_t _M0L3lenS756;
  int32_t _M0L8new__capS330;
  #line 294 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  #line 296 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8old__capS328 = _M0MPC15array5Array8capacityGUsiEE(_M0L4selfS329);
  _M0L3lenS756 = _M0L4selfS329->$1;
  #line 297 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8new__capS330
  = _M0FPB23array__growth__capacity(_M0L8old__capS328, _M0L3lenS756, _M0L8requiredS331);
  #line 298 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0MPC15array5Array14resize__bufferGUsiEE(_M0L4selfS329, _M0L8new__capS330);
  return 0;
}

int32_t _M0MPC15array5Array14resize__bufferGsE(
  struct _M0TPB5ArrayGsE* _M0L4selfS313,
  int32_t _M0L13new__capacityS316
) {
  moonbit_string_t* _M0L8old__bufS312;
  int32_t _M0L8old__capS314;
  int32_t _M0L9copy__lenS315;
  moonbit_string_t* _M0L8new__bufS317;
  moonbit_string_t* _M0L6_2aoldS833;
  #line 237 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8old__bufS312 = _M0L4selfS313->$0;
  _M0L8old__capS314 = Moonbit_array_length(_M0L8old__bufS312);
  if (_M0L8old__capS314 < _M0L13new__capacityS316) {
    _M0L9copy__lenS315 = _M0L8old__capS314;
  } else {
    _M0L9copy__lenS315 = _M0L13new__capacityS316;
  }
  moonbit_incref(_M0L8old__bufS312);
  #line 241 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8new__bufS317
  = _M0MPB18UninitializedArray23make__and__blit_2einnerGsE(_M0L8old__bufS312, _M0L13new__capacityS316, _M0L9copy__lenS315, 0, 0);
  _M0L6_2aoldS833 = _M0L4selfS313->$0;
  moonbit_decref(_M0L6_2aoldS833);
  _M0L4selfS313->$0 = _M0L8new__bufS317;
  return 0;
}

int32_t _M0MPC15array5Array14resize__bufferGUsiEE(
  struct _M0TPB5ArrayGUsiEE* _M0L4selfS319,
  int32_t _M0L13new__capacityS322
) {
  struct _M0TUsiE** _M0L8old__bufS318;
  int32_t _M0L8old__capS320;
  int32_t _M0L9copy__lenS321;
  struct _M0TUsiE** _M0L8new__bufS323;
  struct _M0TUsiE** _M0L6_2aoldS835;
  #line 237 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8old__bufS318 = _M0L4selfS319->$0;
  _M0L8old__capS320 = Moonbit_array_length(_M0L8old__bufS318);
  if (_M0L8old__capS320 < _M0L13new__capacityS322) {
    _M0L9copy__lenS321 = _M0L8old__capS320;
  } else {
    _M0L9copy__lenS321 = _M0L13new__capacityS322;
  }
  moonbit_incref(_M0L8old__bufS318);
  #line 241 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8new__bufS323
  = _M0MPB18UninitializedArray23make__and__blit_2einnerGUsiEE(_M0L8old__bufS318, _M0L13new__capacityS322, _M0L9copy__lenS321, 0, 0);
  _M0L6_2aoldS835 = _M0L4selfS319->$0;
  moonbit_decref(_M0L6_2aoldS835);
  _M0L4selfS319->$0 = _M0L8new__bufS323;
  return 0;
}

int32_t _M0MPC15array5Array8capacityGsE(
  struct _M0TPB5ArrayGsE* _M0L4selfS310
) {
  moonbit_string_t* _M0L6_2atmpS753;
  int32_t _result_895;
  #line 132 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  #line 133 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L6_2atmpS753 = _M0MPC15array5Array6bufferGsE(_M0L4selfS310);
  _result_895 = Moonbit_array_length(_M0L6_2atmpS753);
  moonbit_decref(_M0L6_2atmpS753);
  return _result_895;
}

int32_t _M0MPC15array5Array8capacityGUsiEE(
  struct _M0TPB5ArrayGUsiEE* _M0L4selfS311
) {
  struct _M0TUsiE** _M0L6_2atmpS754;
  int32_t _result_896;
  #line 132 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  #line 133 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\array.mbt"
  _M0L6_2atmpS754 = _M0MPC15array5Array6bufferGUsiEE(_M0L4selfS311);
  _result_896 = Moonbit_array_length(_M0L6_2atmpS754);
  moonbit_decref(_M0L6_2atmpS754);
  return _result_896;
}

int32_t _M0FPB23array__growth__capacity(
  int32_t _M0L7currentS306,
  int32_t _M0L3lenS304,
  int32_t _M0L8requiredS303
) {
  int32_t _M0L5startS305;
  int32_t _M0L5spaceS307;
  #line 195 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  if (_M0L8requiredS303 < _M0L3lenS304) {
    #line 198 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
    _M0FPC15abort5abortGuE((moonbit_string_t)moonbit_string_literal_9.data);
  }
  if (_M0L7currentS306 == 0) {
    _M0L5startS305 = 8;
  } else {
    _M0L5startS305 = _M0L7currentS306;
  }
  _M0L5spaceS307 = _M0L5startS305;
  while (1) {
    if (_M0L5spaceS307 < _M0L8requiredS303) {
      int32_t _M0L4nextS308 = _M0L5spaceS307 * 2;
      if (_M0L4nextS308 <= _M0L5spaceS307) {
        return _M0L8requiredS303;
      }
      _M0L5spaceS307 = _M0L4nextS308;
      continue;
    } else {
      return _M0L5spaceS307;
    }
    break;
  }
}

moonbit_string_t* _M0MPC15array5Array6bufferGsE(
  struct _M0TPB5ArrayGsE* _M0L4selfS301
) {
  moonbit_string_t* _M0L8_2afieldS837;
  #line 187 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8_2afieldS837 = _M0L4selfS301->$0;
  moonbit_incref(_M0L8_2afieldS837);
  return _M0L8_2afieldS837;
}

struct _M0TUsiE** _M0MPC15array5Array6bufferGUsiEE(
  struct _M0TPB5ArrayGUsiEE* _M0L4selfS302
) {
  struct _M0TUsiE** _M0L8_2afieldS838;
  #line 187 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\arraycore_nonjs.mbt"
  _M0L8_2afieldS838 = _M0L4selfS302->$0;
  moonbit_incref(_M0L8_2afieldS838);
  return _M0L8_2afieldS838;
}

moonbit_string_t _M0IPC16string6StringPB4Show10to__string(
  moonbit_string_t _M0L4selfS300
) {
  #line 222 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  moonbit_incref(_M0L4selfS300);
  return _M0L4selfS300;
}

int32_t _M0IPB13StringBuilderPB6Logger11write__view(
  struct _M0TPB13StringBuilder* _M0L4selfS299,
  struct _M0TPC16string10StringView _M0L3strS297
) {
  int32_t _M0L3endS751;
  int32_t _M0L5startS752;
  int32_t _M0L8str__lenS296;
  int32_t _M0L3lenS750;
  int32_t _M0L8requiredS298;
  uint16_t* _M0L4dataS743;
  int32_t _M0L6_2atmpS742;
  int32_t _if__result_898;
  uint16_t* _M0L4dataS744;
  int32_t _M0L3lenS745;
  moonbit_string_t _M0L6_2atmpS746;
  int32_t _M0L6_2atmpS747;
  int32_t _M0L3lenS749;
  int32_t _M0L6_2atmpS748;
  #line 160 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0L3endS751 = _M0L3strS297.$2;
  _M0L5startS752 = _M0L3strS297.$1;
  _M0L8str__lenS296 = _M0L3endS751 - _M0L5startS752;
  if (_M0L8str__lenS296 == 0) {
    return 0;
  }
  _M0L3lenS750 = _M0L4selfS299->$1;
  _M0L8requiredS298 = _M0L3lenS750 + _M0L8str__lenS296;
  _M0L4dataS743 = _M0L4selfS299->$0;
  _M0L6_2atmpS742 = Moonbit_array_length(_M0L4dataS743);
  if (_M0L8requiredS298 > _M0L6_2atmpS742) {
    _if__result_898 = 1;
  } else {
    int32_t _M0L3lenS741 = _M0L4selfS299->$1;
    _if__result_898 = _M0L8requiredS298 < _M0L3lenS741;
  }
  if (_if__result_898) {
    #line 170 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
    _M0MPB13StringBuilder4grow(_M0L4selfS299, _M0L8requiredS298);
  }
  _M0L4dataS744 = _M0L4selfS299->$0;
  _M0L3lenS745 = _M0L4selfS299->$1;
  moonbit_incref(_M0L4dataS744);
  #line 174 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0L6_2atmpS746 = _M0MPC16string10StringView4data(_M0L3strS297);
  #line 175 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0L6_2atmpS747 = _M0MPC16string10StringView13start__offset(_M0L3strS297);
  #line 172 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0MPC15array10FixedArray26unsafe__blit__from__string(_M0L4dataS744, _M0L3lenS745, _M0L6_2atmpS746, _M0L6_2atmpS747, _M0L8str__lenS296);
  moonbit_decref(_M0L4dataS744);
  moonbit_decref(_M0L6_2atmpS746);
  _M0L3lenS749 = _M0L4selfS299->$1;
  _M0L6_2atmpS748 = _M0L3lenS749 + _M0L8str__lenS296;
  _M0L4selfS299->$1 = _M0L6_2atmpS748;
  return 0;
}

moonbit_string_t _M0MPC16string6String17unsafe__substring(
  moonbit_string_t _M0L3strS293,
  int32_t _M0L5startS291,
  int32_t _M0L3endS292
) {
  int32_t _if__result_899;
  int32_t _M0L3lenS294;
  int32_t _M0L6_2atmpS740;
  moonbit_bytes_t _M0L5bytesS295;
  moonbit_bytes_t _M0L6_2atmpS739;
  moonbit_string_t _result_900;
  #line 91 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string.mbt"
  if (_M0L5startS291 == 0) {
    int32_t _M0L6_2atmpS738 = Moonbit_array_length(_M0L3strS293);
    _if__result_899 = _M0L3endS292 == _M0L6_2atmpS738;
  } else {
    _if__result_899 = 0;
  }
  if (_if__result_899) {
    moonbit_incref(_M0L3strS293);
    return _M0L3strS293;
  }
  _M0L3lenS294 = _M0L3endS292 - _M0L5startS291;
  _M0L6_2atmpS740 = _M0L3lenS294 * 2;
  _M0L5bytesS295 = (moonbit_bytes_t)moonbit_make_bytes(_M0L6_2atmpS740, 0);
  #line 102 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string.mbt"
  _M0MPC15array10FixedArray18blit__from__string(_M0L5bytesS295, 0, _M0L3strS293, _M0L5startS291, _M0L3lenS294);
  _M0L6_2atmpS739 = _M0L5bytesS295;
  #line 103 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\string.mbt"
  _result_900
  = _M0MPC15bytes5Bytes29to__unchecked__string_2einner(_M0L6_2atmpS739, 0, 4294967296ll);
  moonbit_decref(_M0L6_2atmpS739);
  return _result_900;
}

moonbit_string_t _M0MPC15bytes5Bytes29to__unchecked__string_2einner(
  moonbit_bytes_t _M0L4selfS286,
  int32_t _M0L6offsetS290,
  int64_t _M0L6lengthS288
) {
  int32_t _M0L3lenS285;
  int32_t _M0L6lengthS287;
  int32_t _if__result_901;
  #line 77 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\bytes.mbt"
  _M0L3lenS285 = Moonbit_array_length(_M0L4selfS286);
  if (_M0L6lengthS288 == 4294967296ll) {
    _M0L6lengthS287 = _M0L3lenS285 - _M0L6offsetS290;
  } else {
    int64_t _M0L7_2aSomeS289 = _M0L6lengthS288;
    _M0L6lengthS287 = (int32_t)_M0L7_2aSomeS289;
  }
  if (_M0L6offsetS290 >= 0) {
    if (_M0L6lengthS287 >= 0) {
      int32_t _M0L6_2atmpS737 = _M0L6offsetS290 + _M0L6lengthS287;
      _if__result_901 = _M0L6_2atmpS737 <= _M0L3lenS285;
    } else {
      _if__result_901 = 0;
    }
  } else {
    _if__result_901 = 0;
  }
  if (_if__result_901) {
    moonbit_incref(_M0L4selfS286);
    #line 85 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\bytes.mbt"
    return _M0FPB19unsafe__sub__string(_M0L4selfS286, _M0L6offsetS290, _M0L6lengthS287);
  } else {
    #line 84 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\bytes.mbt"
    moonbit_panic();
  }
}

int32_t _M0MPC15array10FixedArray18blit__from__string(
  moonbit_bytes_t _M0L4selfS277,
  int32_t _M0L13bytes__offsetS272,
  moonbit_string_t _M0L3strS279,
  int32_t _M0L11str__offsetS275,
  int32_t _M0L6lengthS273
) {
  int32_t _M0L6_2atmpS736;
  int32_t _M0L6_2atmpS735;
  int32_t _M0L2e1S271;
  int32_t _M0L6_2atmpS734;
  int32_t _M0L2e2S274;
  int32_t _M0L4len1S276;
  int32_t _M0L4len2S278;
  int32_t _if__result_902;
  #line 125 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\bytes.mbt"
  _M0L6_2atmpS736 = _M0L6lengthS273 * 2;
  _M0L6_2atmpS735 = _M0L13bytes__offsetS272 + _M0L6_2atmpS736;
  _M0L2e1S271 = _M0L6_2atmpS735 - 1;
  _M0L6_2atmpS734 = _M0L11str__offsetS275 + _M0L6lengthS273;
  _M0L2e2S274 = _M0L6_2atmpS734 - 1;
  _M0L4len1S276 = Moonbit_array_length(_M0L4selfS277);
  _M0L4len2S278 = Moonbit_array_length(_M0L3strS279);
  if (_M0L6lengthS273 >= 0) {
    if (_M0L13bytes__offsetS272 >= 0) {
      if (_M0L2e1S271 < _M0L4len1S276) {
        if (_M0L11str__offsetS275 >= 0) {
          _if__result_902 = _M0L2e2S274 < _M0L4len2S278;
        } else {
          _if__result_902 = 0;
        }
      } else {
        _if__result_902 = 0;
      }
    } else {
      _if__result_902 = 0;
    }
  } else {
    _if__result_902 = 0;
  }
  if (_if__result_902) {
    int32_t _M0L16end__str__offsetS280 =
      _M0L11str__offsetS275 + _M0L6lengthS273;
    int32_t _M0L1iS281 = _M0L11str__offsetS275;
    int32_t _M0L1jS282 = _M0L13bytes__offsetS272;
    while (1) {
      if (_M0L1iS281 < _M0L16end__str__offsetS280) {
        int32_t _M0L6_2atmpS731 = _M0L3strS279[_M0L1iS281];
        int32_t _M0L6_2atmpS730 = (int32_t)_M0L6_2atmpS731;
        uint32_t _M0L1cS283 = *(uint32_t*)&_M0L6_2atmpS730;
        uint32_t _M0L6_2atmpS726 = _M0L1cS283 & 255u;
        int32_t _M0L6_2atmpS725;
        int32_t _M0L6_2atmpS727;
        uint32_t _M0L6_2atmpS729;
        int32_t _M0L6_2atmpS728;
        int32_t _M0L6_2atmpS732;
        int32_t _M0L6_2atmpS733;
        #line 142 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\bytes.mbt"
        _M0L6_2atmpS725 = _M0MPC14uint4UInt8to__byte(_M0L6_2atmpS726);
        if (
          _M0L1jS282 < 0 || _M0L1jS282 >= Moonbit_array_length(_M0L4selfS277)
        ) {
          #line 142 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\bytes.mbt"
          moonbit_panic();
        }
        _M0L4selfS277[_M0L1jS282] = _M0L6_2atmpS725;
        _M0L6_2atmpS727 = _M0L1jS282 + 1;
        _M0L6_2atmpS729 = _M0L1cS283 >> 8;
        #line 143 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\bytes.mbt"
        _M0L6_2atmpS728 = _M0MPC14uint4UInt8to__byte(_M0L6_2atmpS729);
        if (
          _M0L6_2atmpS727 < 0
          || _M0L6_2atmpS727 >= Moonbit_array_length(_M0L4selfS277)
        ) {
          #line 143 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\bytes.mbt"
          moonbit_panic();
        }
        _M0L4selfS277[_M0L6_2atmpS727] = _M0L6_2atmpS728;
        _M0L6_2atmpS732 = _M0L1iS281 + 1;
        _M0L6_2atmpS733 = _M0L1jS282 + 2;
        _M0L1iS281 = _M0L6_2atmpS732;
        _M0L1jS282 = _M0L6_2atmpS733;
        continue;
      }
      break;
    }
  } else {
    #line 138 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\bytes.mbt"
    moonbit_panic();
  }
  return 0;
}

int32_t _M0MPC14uint4UInt8to__byte(uint32_t _M0L4selfS270) {
  int32_t _M0L6_2atmpS724;
  #line 2520 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\intrinsics.mbt"
  _M0L6_2atmpS724 = *(int32_t*)&_M0L4selfS270;
  return _M0L6_2atmpS724 & 0xff;
}

moonbit_string_t _M0MPC13int3Int18to__string_2einner(
  int32_t _M0L4selfS254,
  int32_t _M0L5radixS253
) {
  int32_t _if__result_904;
  int32_t _M0L12is__negativeS255;
  uint32_t _M0L3numS256;
  uint16_t* _M0L6bufferS257;
  #line 209 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
  if (_M0L5radixS253 < 2) {
    _if__result_904 = 1;
  } else {
    _if__result_904 = _M0L5radixS253 > 36;
  }
  if (_if__result_904) {
    #line 213 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
    _M0FPC15abort5abortGuE((moonbit_string_t)moonbit_string_literal_10.data);
  }
  if (_M0L4selfS254 == 0) {
    return (moonbit_string_t)moonbit_string_literal_11.data;
  }
  _M0L12is__negativeS255 = _M0L4selfS254 < 0;
  if (_M0L12is__negativeS255) {
    int32_t _M0L6_2atmpS723 = -_M0L4selfS254;
    _M0L3numS256 = *(uint32_t*)&_M0L6_2atmpS723;
  } else {
    _M0L3numS256 = *(uint32_t*)&_M0L4selfS254;
  }
  switch (_M0L5radixS253) {
    case 10: {
      int32_t _M0L10digit__lenS258;
      int32_t _M0L6_2atmpS720;
      int32_t _M0L10total__lenS259;
      uint16_t* _M0L6bufferS260;
      int32_t _M0L12digit__startS261;
      #line 235 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
      _M0L10digit__lenS258 = _M0FPB12dec__count32(_M0L3numS256);
      if (_M0L12is__negativeS255) {
        _M0L6_2atmpS720 = 1;
      } else {
        _M0L6_2atmpS720 = 0;
      }
      _M0L10total__lenS259 = _M0L10digit__lenS258 + _M0L6_2atmpS720;
      _M0L6bufferS260
      = (uint16_t*)moonbit_make_string(_M0L10total__lenS259, 0);
      if (_M0L12is__negativeS255) {
        _M0L12digit__startS261 = 1;
      } else {
        _M0L12digit__startS261 = 0;
      }
      #line 239 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
      _M0FPB20int__to__string__dec(_M0L6bufferS260, _M0L3numS256, _M0L12digit__startS261, _M0L10total__lenS259);
      _M0L6bufferS257 = _M0L6bufferS260;
      break;
    }
    
    case 16: {
      int32_t _M0L10digit__lenS262;
      int32_t _M0L6_2atmpS721;
      int32_t _M0L10total__lenS263;
      uint16_t* _M0L6bufferS264;
      int32_t _M0L12digit__startS265;
      #line 243 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
      _M0L10digit__lenS262 = _M0FPB12hex__count32(_M0L3numS256);
      if (_M0L12is__negativeS255) {
        _M0L6_2atmpS721 = 1;
      } else {
        _M0L6_2atmpS721 = 0;
      }
      _M0L10total__lenS263 = _M0L10digit__lenS262 + _M0L6_2atmpS721;
      _M0L6bufferS264
      = (uint16_t*)moonbit_make_string(_M0L10total__lenS263, 0);
      if (_M0L12is__negativeS255) {
        _M0L12digit__startS265 = 1;
      } else {
        _M0L12digit__startS265 = 0;
      }
      #line 247 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
      _M0FPB20int__to__string__hex(_M0L6bufferS264, _M0L3numS256, _M0L12digit__startS265, _M0L10total__lenS263);
      _M0L6bufferS257 = _M0L6bufferS264;
      break;
    }
    default: {
      int32_t _M0L10digit__lenS266;
      int32_t _M0L6_2atmpS722;
      int32_t _M0L10total__lenS267;
      uint16_t* _M0L6bufferS268;
      int32_t _M0L12digit__startS269;
      #line 251 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
      _M0L10digit__lenS266
      = _M0FPB14radix__count32(_M0L3numS256, _M0L5radixS253);
      if (_M0L12is__negativeS255) {
        _M0L6_2atmpS722 = 1;
      } else {
        _M0L6_2atmpS722 = 0;
      }
      _M0L10total__lenS267 = _M0L10digit__lenS266 + _M0L6_2atmpS722;
      _M0L6bufferS268
      = (uint16_t*)moonbit_make_string(_M0L10total__lenS267, 0);
      if (_M0L12is__negativeS255) {
        _M0L12digit__startS269 = 1;
      } else {
        _M0L12digit__startS269 = 0;
      }
      #line 255 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
      _M0FPB24int__to__string__generic(_M0L6bufferS268, _M0L3numS256, _M0L12digit__startS269, _M0L10total__lenS267, _M0L5radixS253);
      _M0L6bufferS257 = _M0L6bufferS268;
      break;
    }
  }
  if (_M0L12is__negativeS255) {
    _M0L6bufferS257[0] = 45;
  }
  return _M0L6bufferS257;
}

int32_t _M0FPB14radix__count32(
  uint32_t _M0L5valueS247,
  int32_t _M0L5radixS249
) {
  uint32_t _M0L4baseS248;
  uint32_t _M0L3numS250;
  int32_t _M0L5countS251;
  #line 189 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
  if (_M0L5valueS247 == 0u) {
    return 1;
  }
  _M0L4baseS248 = *(uint32_t*)&_M0L5radixS249;
  _M0L3numS250 = _M0L5valueS247;
  _M0L5countS251 = 0;
  while (1) {
    if (_M0L3numS250 > 0u) {
      uint32_t _M0L6_2atmpS718 = _M0L3numS250 / _M0L4baseS248;
      int32_t _M0L6_2atmpS719 = _M0L5countS251 + 1;
      _M0L3numS250 = _M0L6_2atmpS718;
      _M0L5countS251 = _M0L6_2atmpS719;
      continue;
    } else {
      return _M0L5countS251;
    }
    break;
  }
}

int32_t _M0FPB12hex__count32(uint32_t _M0L5valueS245) {
  #line 177 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
  if (_M0L5valueS245 == 0u) {
    return 1;
  } else {
    int32_t _M0L14leading__zerosS246;
    int32_t _M0L6_2atmpS717;
    int32_t _M0L6_2atmpS716;
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
    _M0L14leading__zerosS246 = moonbit_clz32(_M0L5valueS245);
    _M0L6_2atmpS717 = 31 - _M0L14leading__zerosS246;
    _M0L6_2atmpS716 = _M0L6_2atmpS717 / 4;
    return _M0L6_2atmpS716 + 1;
  }
}

int32_t _M0FPB12dec__count32(uint32_t _M0L5valueS244) {
  #line 143 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
  if (_M0L5valueS244 >= 100000u) {
    if (_M0L5valueS244 >= 10000000u) {
      if (_M0L5valueS244 >= 1000000000u) {
        return 10;
      } else if (_M0L5valueS244 >= 100000000u) {
        return 9;
      } else {
        return 8;
      }
    } else if (_M0L5valueS244 >= 1000000u) {
      return 7;
    } else {
      return 6;
    }
  } else if (_M0L5valueS244 >= 1000u) {
    if (_M0L5valueS244 >= 10000u) {
      return 5;
    } else {
      return 4;
    }
  } else if (_M0L5valueS244 >= 100u) {
    return 3;
  } else if (_M0L5valueS244 >= 10u) {
    return 2;
  } else {
    return 1;
  }
}

int32_t _M0FPB20int__to__string__dec(
  uint16_t* _M0L6bufferS230,
  uint32_t _M0L3numS242,
  int32_t _M0L12digit__startS231,
  int32_t _M0L10total__lenS243
) {
  int32_t _M0L6_2atmpS715;
  uint32_t _M0L3numS220;
  int32_t _M0L6offsetS221;
  #line 88 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
  _M0L6_2atmpS715 = _M0L10total__lenS243 - _M0L12digit__startS231;
  _M0L3numS220 = _M0L3numS242;
  _M0L6offsetS221 = _M0L6_2atmpS715;
  while (1) {
    if (_M0L3numS220 >= 10000u) {
      uint32_t _M0L1tS222 = _M0L3numS220 / 10000u;
      uint32_t _M0L6_2atmpS692 = _M0L3numS220 % 10000u;
      int32_t _M0L1rS223 = *(int32_t*)&_M0L6_2atmpS692;
      int32_t _M0L2d1S224 = _M0L1rS223 / 100;
      int32_t _M0L2d2S225 = _M0L1rS223 % 100;
      int32_t _M0L6_2atmpS691 = _M0L2d1S224 / 10;
      int32_t _M0L6_2atmpS690 = 48 + _M0L6_2atmpS691;
      int32_t _M0L6d1__hiS226 = (uint16_t)_M0L6_2atmpS690;
      int32_t _M0L6_2atmpS689 = _M0L2d1S224 % 10;
      int32_t _M0L6_2atmpS688 = 48 + _M0L6_2atmpS689;
      int32_t _M0L6d1__loS227 = (uint16_t)_M0L6_2atmpS688;
      int32_t _M0L6_2atmpS687 = _M0L2d2S225 / 10;
      int32_t _M0L6_2atmpS686 = 48 + _M0L6_2atmpS687;
      int32_t _M0L6d2__hiS228 = (uint16_t)_M0L6_2atmpS686;
      int32_t _M0L6_2atmpS685 = _M0L2d2S225 % 10;
      int32_t _M0L6_2atmpS684 = 48 + _M0L6_2atmpS685;
      int32_t _M0L6d2__loS229 = (uint16_t)_M0L6_2atmpS684;
      int32_t _M0L6_2atmpS676 = _M0L12digit__startS231 + _M0L6offsetS221;
      int32_t _M0L6_2atmpS675 = _M0L6_2atmpS676 - 4;
      int32_t _M0L6_2atmpS678;
      int32_t _M0L6_2atmpS677;
      int32_t _M0L6_2atmpS680;
      int32_t _M0L6_2atmpS679;
      int32_t _M0L6_2atmpS682;
      int32_t _M0L6_2atmpS681;
      int32_t _M0L6_2atmpS683;
      _M0L6bufferS230[_M0L6_2atmpS675] = _M0L6d1__hiS226;
      _M0L6_2atmpS678 = _M0L12digit__startS231 + _M0L6offsetS221;
      _M0L6_2atmpS677 = _M0L6_2atmpS678 - 3;
      _M0L6bufferS230[_M0L6_2atmpS677] = _M0L6d1__loS227;
      _M0L6_2atmpS680 = _M0L12digit__startS231 + _M0L6offsetS221;
      _M0L6_2atmpS679 = _M0L6_2atmpS680 - 2;
      _M0L6bufferS230[_M0L6_2atmpS679] = _M0L6d2__hiS228;
      _M0L6_2atmpS682 = _M0L12digit__startS231 + _M0L6offsetS221;
      _M0L6_2atmpS681 = _M0L6_2atmpS682 - 1;
      _M0L6bufferS230[_M0L6_2atmpS681] = _M0L6d2__loS229;
      _M0L6_2atmpS683 = _M0L6offsetS221 - 4;
      _M0L3numS220 = _M0L1tS222;
      _M0L6offsetS221 = _M0L6_2atmpS683;
      continue;
    } else {
      int32_t _M0L6_2atmpS714 = *(int32_t*)&_M0L3numS220;
      int32_t _M0L9remainingS233 = _M0L6_2atmpS714;
      int32_t _M0L6offsetS234 = _M0L6offsetS221;
      while (1) {
        if (_M0L9remainingS233 >= 100) {
          int32_t _M0L1tS235 = _M0L9remainingS233 / 100;
          int32_t _M0L1dS236 = _M0L9remainingS233 % 100;
          int32_t _M0L6_2atmpS701 = _M0L1dS236 / 10;
          int32_t _M0L6_2atmpS700 = 48 + _M0L6_2atmpS701;
          int32_t _M0L5d__hiS237 = (uint16_t)_M0L6_2atmpS700;
          int32_t _M0L6_2atmpS699 = _M0L1dS236 % 10;
          int32_t _M0L6_2atmpS698 = 48 + _M0L6_2atmpS699;
          int32_t _M0L5d__loS238 = (uint16_t)_M0L6_2atmpS698;
          int32_t _M0L6_2atmpS694 = _M0L12digit__startS231 + _M0L6offsetS234;
          int32_t _M0L6_2atmpS693 = _M0L6_2atmpS694 - 2;
          int32_t _M0L6_2atmpS696;
          int32_t _M0L6_2atmpS695;
          int32_t _M0L6_2atmpS697;
          _M0L6bufferS230[_M0L6_2atmpS693] = _M0L5d__hiS237;
          _M0L6_2atmpS696 = _M0L12digit__startS231 + _M0L6offsetS234;
          _M0L6_2atmpS695 = _M0L6_2atmpS696 - 1;
          _M0L6bufferS230[_M0L6_2atmpS695] = _M0L5d__loS238;
          _M0L6_2atmpS697 = _M0L6offsetS234 - 2;
          _M0L9remainingS233 = _M0L1tS235;
          _M0L6offsetS234 = _M0L6_2atmpS697;
          continue;
        } else if (_M0L9remainingS233 >= 10) {
          int32_t _M0L6_2atmpS709 = _M0L9remainingS233 / 10;
          int32_t _M0L6_2atmpS708 = 48 + _M0L6_2atmpS709;
          int32_t _M0L5d__hiS240 = (uint16_t)_M0L6_2atmpS708;
          int32_t _M0L6_2atmpS707 = _M0L9remainingS233 % 10;
          int32_t _M0L6_2atmpS706 = 48 + _M0L6_2atmpS707;
          int32_t _M0L5d__loS241 = (uint16_t)_M0L6_2atmpS706;
          int32_t _M0L6_2atmpS703 = _M0L12digit__startS231 + _M0L6offsetS234;
          int32_t _M0L6_2atmpS702 = _M0L6_2atmpS703 - 2;
          int32_t _M0L6_2atmpS705;
          int32_t _M0L6_2atmpS704;
          _M0L6bufferS230[_M0L6_2atmpS702] = _M0L5d__hiS240;
          _M0L6_2atmpS705 = _M0L12digit__startS231 + _M0L6offsetS234;
          _M0L6_2atmpS704 = _M0L6_2atmpS705 - 1;
          _M0L6bufferS230[_M0L6_2atmpS704] = _M0L5d__loS241;
        } else {
          int32_t _M0L6_2atmpS713 = _M0L12digit__startS231 + _M0L6offsetS234;
          int32_t _M0L6_2atmpS710 = _M0L6_2atmpS713 - 1;
          int32_t _M0L6_2atmpS712 = 48 + _M0L9remainingS233;
          int32_t _M0L6_2atmpS711 = (uint16_t)_M0L6_2atmpS712;
          _M0L6bufferS230[_M0L6_2atmpS710] = _M0L6_2atmpS711;
        }
        break;
      }
    }
    break;
  }
  return 0;
}

int32_t _M0FPB24int__to__string__generic(
  uint16_t* _M0L6bufferS210,
  uint32_t _M0L3numS214,
  int32_t _M0L12digit__startS211,
  int32_t _M0L10total__lenS213,
  int32_t _M0L5radixS204
) {
  uint32_t _M0L4baseS203;
  int32_t _M0L6_2atmpS660;
  int32_t _M0L6_2atmpS659;
  #line 57 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
  _M0L4baseS203 = *(uint32_t*)&_M0L5radixS204;
  _M0L6_2atmpS660 = _M0L5radixS204 - 1;
  _M0L6_2atmpS659 = _M0L5radixS204 & _M0L6_2atmpS660;
  if (_M0L6_2atmpS659 == 0) {
    int32_t _M0L5shiftS205;
    uint32_t _M0L4maskS206;
    int32_t _M0L6_2atmpS667;
    int32_t _M0L6offsetS207;
    uint32_t _M0L1nS208;
    #line 68 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
    _M0L5shiftS205 = moonbit_ctz32(_M0L5radixS204);
    _M0L4maskS206 = _M0L4baseS203 - 1u;
    _M0L6_2atmpS667 = _M0L10total__lenS213 - _M0L12digit__startS211;
    _M0L6offsetS207 = _M0L6_2atmpS667;
    _M0L1nS208 = _M0L3numS214;
    while (1) {
      if (_M0L1nS208 > 0u) {
        uint32_t _M0L6_2atmpS666 = _M0L1nS208 & _M0L4maskS206;
        int32_t _M0L5digitS209 = *(int32_t*)&_M0L6_2atmpS666;
        int32_t _M0L6_2atmpS663 = _M0L12digit__startS211 + _M0L6offsetS207;
        int32_t _M0L6_2atmpS661 = _M0L6_2atmpS663 - 1;
        int32_t _M0L6_2atmpS662 =
          ((moonbit_string_t)moonbit_string_literal_12.data)[_M0L5digitS209];
        int32_t _M0L6_2atmpS664;
        uint32_t _M0L6_2atmpS665;
        _M0L6bufferS210[_M0L6_2atmpS661] = _M0L6_2atmpS662;
        _M0L6_2atmpS664 = _M0L6offsetS207 - 1;
        _M0L6_2atmpS665 = _M0L1nS208 >> (_M0L5shiftS205 & 31);
        _M0L6offsetS207 = _M0L6_2atmpS664;
        _M0L1nS208 = _M0L6_2atmpS665;
        continue;
      }
      break;
    }
  } else {
    int32_t _M0L6_2atmpS674 = _M0L10total__lenS213 - _M0L12digit__startS211;
    int32_t _M0L6offsetS215 = _M0L6_2atmpS674;
    uint32_t _M0L1nS216 = _M0L3numS214;
    while (1) {
      if (_M0L1nS216 > 0u) {
        uint32_t _M0L1qS217 = _M0L1nS216 / _M0L4baseS203;
        uint32_t _M0L6_2atmpS673 = _M0L1qS217 * _M0L4baseS203;
        uint32_t _M0L6_2atmpS672 = _M0L1nS216 - _M0L6_2atmpS673;
        int32_t _M0L5digitS218 = *(int32_t*)&_M0L6_2atmpS672;
        int32_t _M0L6_2atmpS670 = _M0L12digit__startS211 + _M0L6offsetS215;
        int32_t _M0L6_2atmpS668 = _M0L6_2atmpS670 - 1;
        int32_t _M0L6_2atmpS669 =
          ((moonbit_string_t)moonbit_string_literal_12.data)[_M0L5digitS218];
        int32_t _M0L6_2atmpS671;
        _M0L6bufferS210[_M0L6_2atmpS668] = _M0L6_2atmpS669;
        _M0L6_2atmpS671 = _M0L6offsetS215 - 1;
        _M0L6offsetS215 = _M0L6_2atmpS671;
        _M0L1nS216 = _M0L1qS217;
        continue;
      }
      break;
    }
  }
  return 0;
}

int32_t _M0FPB20int__to__string__hex(
  uint16_t* _M0L6bufferS197,
  uint32_t _M0L3numS202,
  int32_t _M0L12digit__startS198,
  int32_t _M0L10total__lenS201
) {
  int32_t _M0L6_2atmpS658;
  int32_t _M0L6offsetS192;
  uint32_t _M0L1nS193;
  #line 29 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\to_string.mbt"
  _M0L6_2atmpS658 = _M0L10total__lenS201 - _M0L12digit__startS198;
  _M0L6offsetS192 = _M0L6_2atmpS658;
  _M0L1nS193 = _M0L3numS202;
  while (1) {
    if (_M0L6offsetS192 >= 2) {
      uint32_t _M0L6_2atmpS655 = _M0L1nS193 & 255u;
      int32_t _M0L9byte__valS194 = *(int32_t*)&_M0L6_2atmpS655;
      int32_t _M0L2hiS195 = _M0L9byte__valS194 / 16;
      int32_t _M0L2loS196 = _M0L9byte__valS194 % 16;
      int32_t _M0L6_2atmpS649 = _M0L12digit__startS198 + _M0L6offsetS192;
      int32_t _M0L6_2atmpS647 = _M0L6_2atmpS649 - 2;
      int32_t _M0L6_2atmpS648 =
        ((moonbit_string_t)moonbit_string_literal_12.data)[_M0L2hiS195];
      int32_t _M0L6_2atmpS652;
      int32_t _M0L6_2atmpS650;
      int32_t _M0L6_2atmpS651;
      int32_t _M0L6_2atmpS653;
      uint32_t _M0L6_2atmpS654;
      _M0L6bufferS197[_M0L6_2atmpS647] = _M0L6_2atmpS648;
      _M0L6_2atmpS652 = _M0L12digit__startS198 + _M0L6offsetS192;
      _M0L6_2atmpS650 = _M0L6_2atmpS652 - 1;
      _M0L6_2atmpS651
      = ((moonbit_string_t)moonbit_string_literal_12.data)[
        _M0L2loS196
      ];
      _M0L6bufferS197[_M0L6_2atmpS650] = _M0L6_2atmpS651;
      _M0L6_2atmpS653 = _M0L6offsetS192 - 2;
      _M0L6_2atmpS654 = _M0L1nS193 >> 8;
      _M0L6offsetS192 = _M0L6_2atmpS653;
      _M0L1nS193 = _M0L6_2atmpS654;
      continue;
    } else if (_M0L6offsetS192 == 1) {
      uint32_t _M0L6_2atmpS657 = _M0L1nS193 & 15u;
      int32_t _M0L6nibbleS200 = *(int32_t*)&_M0L6_2atmpS657;
      int32_t _M0L6_2atmpS656 =
        ((moonbit_string_t)moonbit_string_literal_12.data)[_M0L6nibbleS200];
      _M0L6bufferS197[_M0L12digit__startS198] = _M0L6_2atmpS656;
    }
    break;
  }
  return 0;
}

moonbit_string_t _M0IP016_24default__implPB4Show10to__stringGRPB7FailureE(
  void* _M0L4selfS191
) {
  struct _M0TPB13StringBuilder* _M0L6loggerS190;
  struct _M0TPB6Logger _M0L6_2atmpS646;
  moonbit_string_t _result_911;
  #line 165 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  #line 166 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0L6loggerS190 = _M0MPB13StringBuilder21StringBuilder_2einner(0);
  moonbit_incref(_M0L6loggerS190);
  _M0L6_2atmpS646
  = (struct _M0TPB6Logger){
    _M0FP0119moonbitlang_2fcore_2fbuiltin_2fStringBuilder_2eas___40moonbitlang_2fcore_2fbuiltin_2eLogger_2estatic__method__table__id,
      _M0L6loggerS190
  };
  #line 167 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0IPB7FailurePB4Show6output(_M0L4selfS191, _M0L6_2atmpS646);
  if (_M0L6_2atmpS646.$1) {
    moonbit_decref(_M0L6_2atmpS646.$1);
  }
  #line 168 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _result_911 = _M0MPB13StringBuilder10to__string(_M0L6loggerS190);
  moonbit_decref(_M0L6loggerS190);
  return _result_911;
}

int32_t _M0IP016_24default__implPB4Show6outputGsE(
  moonbit_string_t _M0L4selfS187,
  struct _M0TPB6Logger _M0L6loggerS186
) {
  moonbit_string_t _M0L6_2atmpS644;
  #line 159 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  #line 160 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0L6_2atmpS644 = _M0IPC16string6StringPB4Show10to__string(_M0L4selfS187);
  #line 160 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0L6loggerS186.$0->$method_0(_M0L6loggerS186.$1, _M0L6_2atmpS644);
  moonbit_decref(_M0L6_2atmpS644);
  return 0;
}

int32_t _M0IP016_24default__implPB4Show6outputGiE(
  int32_t _M0L4selfS189,
  struct _M0TPB6Logger _M0L6loggerS188
) {
  moonbit_string_t _M0L6_2atmpS645;
  #line 159 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  #line 160 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0L6_2atmpS645 = _M0IPC13int3IntPB4Show10to__string(_M0L4selfS189);
  #line 160 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0L6loggerS188.$0->$method_0(_M0L6loggerS188.$1, _M0L6_2atmpS645);
  moonbit_decref(_M0L6_2atmpS645);
  return 0;
}

int32_t _M0MPC16string10StringView13start__offset(
  struct _M0TPC16string10StringView _M0L4selfS185
) {
  #line 99 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
  return _M0L4selfS185.$1;
}

moonbit_string_t _M0MPC16string10StringView4data(
  struct _M0TPC16string10StringView _M0L4selfS184
) {
  moonbit_string_t _M0L8_2afieldS841;
  #line 92 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
  _M0L8_2afieldS841 = _M0L4selfS184.$0;
  moonbit_incref(_M0L8_2afieldS841);
  return _M0L8_2afieldS841;
}

int32_t _M0IP016_24default__implPB6Logger16write__substringGRPB13StringBuilderE(
  struct _M0TPB13StringBuilder* _M0L4selfS180,
  moonbit_string_t _M0L5valueS181,
  int32_t _M0L5startS182,
  int32_t _M0L3lenS183
) {
  int32_t _M0L6_2atmpS643;
  int64_t _M0L6_2atmpS642;
  struct _M0TPC16string10StringView _M0L6_2atmpS641;
  #line 122 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0L6_2atmpS643 = _M0L5startS182 + _M0L3lenS183;
  _M0L6_2atmpS642 = (int64_t)_M0L6_2atmpS643;
  #line 123 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0L6_2atmpS641
  = _M0MPC16string6String11sub_2einner(_M0L5valueS181, _M0L5startS182, _M0L6_2atmpS642);
  #line 123 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0IPB13StringBuilderPB6Logger11write__view(_M0L4selfS180, _M0L6_2atmpS641);
  moonbit_decref(_M0L6_2atmpS641.$0);
  return 0;
}

struct _M0TPC16string10StringView _M0MPC16string6String11sub_2einner(
  moonbit_string_t _M0L4selfS172,
  int32_t _M0L5startS179,
  int64_t _M0L3endS176
) {
  int32_t _M0L3lenS171;
  int32_t _M0L3endS175;
  int32_t _M0L3endS173;
  int32_t _if__result_913;
  #line 923 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
  _M0L3lenS171 = Moonbit_array_length(_M0L4selfS172);
  if (_M0L3endS176 == 4294967296ll) {
    _M0L3endS175 = _M0L3lenS171;
    goto join_174;
  } else {
    int64_t _M0L7_2aSomeS177 = _M0L3endS176;
    int32_t _M0L6_2aendS178 = (int32_t)_M0L7_2aSomeS177;
    _M0L3endS175 = _M0L6_2aendS178;
    goto join_174;
  }
  goto joinlet_912;
  join_174:;
  _M0L3endS173 = _M0L3endS175;
  joinlet_912:;
  if (_M0L5startS179 >= 0) {
    if (_M0L5startS179 <= _M0L3endS173) {
      _if__result_913 = _M0L3endS173 <= _M0L3lenS171;
    } else {
      _if__result_913 = 0;
    }
  } else {
    _if__result_913 = 0;
  }
  if (_if__result_913) {
    if (_M0L5startS179 < _M0L3lenS171) {
      int32_t _M0L6_2atmpS638 = _M0L4selfS172[_M0L5startS179];
      int32_t _M0L6_2atmpS637;
      #line 931 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
      _M0L6_2atmpS637
      = _M0MPC16uint166UInt1623is__trailing__surrogate(_M0L6_2atmpS638);
      if (!_M0L6_2atmpS637) {
        
      } else {
        #line 931 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
        moonbit_panic();
      }
    }
    if (_M0L3endS173 < _M0L3lenS171) {
      int32_t _M0L6_2atmpS640 = _M0L4selfS172[_M0L3endS173];
      int32_t _M0L6_2atmpS639;
      #line 934 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
      _M0L6_2atmpS639
      = _M0MPC16uint166UInt1623is__trailing__surrogate(_M0L6_2atmpS640);
      if (!_M0L6_2atmpS639) {
        
      } else {
        #line 934 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
        moonbit_panic();
      }
    }
    moonbit_incref(_M0L4selfS172);
    return (struct _M0TPC16string10StringView){.$0 = _M0L4selfS172,
                                                 .$1 = _M0L5startS179,
                                                 .$2 = _M0L3endS173};
  } else {
    #line 929 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
    moonbit_panic();
  }
}

int32_t _M0IP016_24default__implPB6Logger5writeGRPB13StringBuilderE(
  struct _M0TPB13StringBuilder* _M0L4selfS170,
  struct _M0TPB4Show _M0L4showS169
) {
  struct _M0TPB6Logger _M0L6_2atmpS636;
  #line 116 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  moonbit_incref(_M0L4selfS170);
  _M0L6_2atmpS636
  = (struct _M0TPB6Logger){
    _M0FP0119moonbitlang_2fcore_2fbuiltin_2fStringBuilder_2eas___40moonbitlang_2fcore_2fbuiltin_2eLogger_2estatic__method__table__id,
      _M0L4selfS170
  };
  #line 117 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0L4showS169.$0->$method_0(_M0L4showS169.$1, _M0L6_2atmpS636);
  if (_M0L6_2atmpS636.$1) {
    moonbit_decref(_M0L6_2atmpS636.$1);
  }
  return 0;
}

int32_t _M0IP016_24default__implPB6Logger28write__string__interpolationGRPB13StringBuilderE(
  struct _M0TPB13StringBuilder* _M0L4selfS168,
  struct _M0TPB4Show _M0L4showS167
) {
  struct _M0TPB6Logger _M0L6_2atmpS635;
  #line 111 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  moonbit_incref(_M0L4selfS168);
  _M0L6_2atmpS635
  = (struct _M0TPB6Logger){
    _M0FP0119moonbitlang_2fcore_2fbuiltin_2fStringBuilder_2eas___40moonbitlang_2fcore_2fbuiltin_2eLogger_2estatic__method__table__id,
      _M0L4selfS168
  };
  #line 112 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0L4showS167.$0->$method_0(_M0L4showS167.$1, _M0L6_2atmpS635);
  if (_M0L6_2atmpS635.$1) {
    moonbit_decref(_M0L6_2atmpS635.$1);
  }
  return 0;
}

int32_t _M0IPC16uint166UInt16PB7Default7default() {
  #line 201 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uint16_char.mbt"
  return 0;
}

int32_t _M0IPB13StringBuilderPB6Logger13write__string(
  struct _M0TPB13StringBuilder* _M0L4selfS166,
  moonbit_string_t _M0L3strS164
) {
  int32_t _M0L8str__lenS163;
  int32_t _M0L3lenS634;
  int32_t _M0L8requiredS165;
  uint16_t* _M0L4dataS629;
  int32_t _M0L6_2atmpS628;
  int32_t _if__result_914;
  uint16_t* _M0L4dataS630;
  int32_t _M0L3lenS631;
  int32_t _M0L3lenS633;
  int32_t _M0L6_2atmpS632;
  #line 105 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0L8str__lenS163 = Moonbit_array_length(_M0L3strS164);
  if (_M0L8str__lenS163 == 0) {
    return 0;
  }
  _M0L3lenS634 = _M0L4selfS166->$1;
  _M0L8requiredS165 = _M0L3lenS634 + _M0L8str__lenS163;
  _M0L4dataS629 = _M0L4selfS166->$0;
  _M0L6_2atmpS628 = Moonbit_array_length(_M0L4dataS629);
  if (_M0L8requiredS165 > _M0L6_2atmpS628) {
    _if__result_914 = 1;
  } else {
    int32_t _M0L3lenS627 = _M0L4selfS166->$1;
    _if__result_914 = _M0L8requiredS165 < _M0L3lenS627;
  }
  if (_if__result_914) {
    #line 112 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
    _M0MPB13StringBuilder4grow(_M0L4selfS166, _M0L8requiredS165);
  }
  _M0L4dataS630 = _M0L4selfS166->$0;
  _M0L3lenS631 = _M0L4selfS166->$1;
  moonbit_incref(_M0L4dataS630);
  #line 114 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0MPC15array10FixedArray26unsafe__blit__from__string(_M0L4dataS630, _M0L3lenS631, _M0L3strS164, 0, _M0L8str__lenS163);
  moonbit_decref(_M0L4dataS630);
  _M0L3lenS633 = _M0L4selfS166->$1;
  _M0L6_2atmpS632 = _M0L3lenS633 + _M0L8str__lenS163;
  _M0L4selfS166->$1 = _M0L6_2atmpS632;
  return 0;
}

int32_t _M0MPC15array10FixedArray26unsafe__blit__from__string(
  uint16_t* _M0L4selfS159,
  int32_t _M0L11dst__offsetS162,
  moonbit_string_t _M0L3strS160,
  int32_t _M0L11str__offsetS155,
  int32_t _M0L3lenS156
) {
  int32_t _M0L16end__str__offsetS154;
  int32_t _M0L1iS157;
  int32_t _M0L1jS158;
  #line 90 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0L16end__str__offsetS154 = _M0L11str__offsetS155 + _M0L3lenS156;
  _M0L1iS157 = _M0L11str__offsetS155;
  _M0L1jS158 = _M0L11dst__offsetS162;
  while (1) {
    if (_M0L1iS157 < _M0L16end__str__offsetS154) {
      int32_t _M0L6_2atmpS624 = _M0L3strS160[_M0L1iS157];
      int32_t _M0L6_2atmpS625;
      int32_t _M0L6_2atmpS626;
      _M0L4selfS159[_M0L1jS158] = _M0L6_2atmpS624;
      _M0L6_2atmpS625 = _M0L1iS157 + 1;
      _M0L6_2atmpS626 = _M0L1jS158 + 1;
      _M0L1iS157 = _M0L6_2atmpS625;
      _M0L1jS158 = _M0L6_2atmpS626;
      continue;
    }
    break;
  }
  return 0;
}

moonbit_string_t _M0MPC16string6String14escape_2einner(
  moonbit_string_t _M0L4selfS152,
  int32_t _M0L5quoteS153
) {
  struct _M0TPB13StringBuilder* _M0L3bufS151;
  int32_t _M0L6_2atmpS623;
  struct _M0TPC16string10StringView _M0L6_2atmpS621;
  struct _M0TPB6Logger _M0L6_2atmpS622;
  moonbit_string_t _result_916;
  #line 110 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  #line 111 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _M0L3bufS151 = _M0MPB13StringBuilder21StringBuilder_2einner(0);
  _M0L6_2atmpS623 = Moonbit_array_length(_M0L4selfS152);
  moonbit_incref(_M0L4selfS152);
  _M0L6_2atmpS621
  = (struct _M0TPC16string10StringView){
    .$0 = _M0L4selfS152, .$1 = 0, .$2 = _M0L6_2atmpS623
  };
  moonbit_incref(_M0L3bufS151);
  _M0L6_2atmpS622
  = (struct _M0TPB6Logger){
    _M0FP0119moonbitlang_2fcore_2fbuiltin_2fStringBuilder_2eas___40moonbitlang_2fcore_2fbuiltin_2eLogger_2estatic__method__table__id,
      _M0L3bufS151
  };
  #line 112 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _M0MPC16string10StringView18escape__to_2einner(_M0L6_2atmpS621, _M0L6_2atmpS622, _M0L5quoteS153);
  moonbit_decref(_M0L6_2atmpS621.$0);
  if (_M0L6_2atmpS622.$1) {
    moonbit_decref(_M0L6_2atmpS622.$1);
  }
  #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _result_916 = _M0MPB13StringBuilder10to__string(_M0L3bufS151);
  moonbit_decref(_M0L3bufS151);
  return _result_916;
}

int32_t _M0MPC16string10StringView18escape__to_2einner(
  struct _M0TPC16string10StringView _M0L4selfS143,
  struct _M0TPB6Logger _M0L6loggerS141,
  int32_t _M0L5quoteS140
) {
  int32_t _M0L3endS619;
  int32_t _M0L5startS620;
  int32_t _M0L3lenS142;
  struct _M0TURPB6LoggerRPC16string10StringViewE* _M0L6_2aenvS144;
  int32_t _M0L1iS145;
  int32_t _M0L3segS146;
  #line 144 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  if (_M0L5quoteS140) {
    #line 150 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    _M0L6loggerS141.$0->$method_3(_M0L6loggerS141.$1, 34);
  }
  _M0L3endS619 = _M0L4selfS143.$2;
  _M0L5startS620 = _M0L4selfS143.$1;
  _M0L3lenS142 = _M0L3endS619 - _M0L5startS620;
  if (_M0L6loggerS141.$1) {
    moonbit_incref(_M0L6loggerS141.$1);
  }
  moonbit_incref(_M0L4selfS143.$0);
  _M0L6_2aenvS144
  = (struct _M0TURPB6LoggerRPC16string10StringViewE*)moonbit_malloc(sizeof(struct _M0TURPB6LoggerRPC16string10StringViewE));
  Moonbit_object_header(_M0L6_2aenvS144)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 25, 0);
  _M0L6_2aenvS144->$0 = _M0L6loggerS141;
  _M0L6_2aenvS144->$1 = _M0L4selfS143;
  _M0L1iS145 = 0;
  _M0L3segS146 = 0;
  _2afor_147:;
  while (1) {
    moonbit_string_t _M0L3strS616;
    int32_t _M0L5startS618;
    int32_t _M0L6_2atmpS617;
    int32_t _M0L4codeS148;
    int32_t _M0L1cS150;
    int32_t _M0L6_2atmpS600;
    int32_t _M0L6_2atmpS601;
    int32_t _M0L6_2atmpS602;
    if (_M0L1iS145 >= _M0L3lenS142) {
      #line 160 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
      _M0MPC16string10StringView18escape__to_2einnerN14flush__segmentS4266(_M0L6_2aenvS144, _M0L3segS146, _M0L1iS145);
      moonbit_decref(_M0L6_2aenvS144);
      break;
    }
    _M0L3strS616 = _M0L4selfS143.$0;
    _M0L5startS618 = _M0L4selfS143.$1;
    _M0L6_2atmpS617 = _M0L5startS618 + _M0L1iS145;
    _M0L4codeS148 = _M0L3strS616[_M0L6_2atmpS617];
    switch (_M0L4codeS148) {
      case 34: {
        _M0L1cS150 = _M0L4codeS148;
        goto join_149;
        break;
      }
      
      case 92: {
        _M0L1cS150 = _M0L4codeS148;
        goto join_149;
        break;
      }
      
      case 10: {
        int32_t _M0L6_2atmpS603;
        int32_t _M0L6_2atmpS604;
        #line 172 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
        _M0MPC16string10StringView18escape__to_2einnerN14flush__segmentS4266(_M0L6_2aenvS144, _M0L3segS146, _M0L1iS145);
        #line 173 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
        _M0L6loggerS141.$0->$method_0(_M0L6loggerS141.$1, (moonbit_string_t)moonbit_string_literal_13.data);
        _M0L6_2atmpS603 = _M0L1iS145 + 1;
        _M0L6_2atmpS604 = _M0L1iS145 + 1;
        _M0L1iS145 = _M0L6_2atmpS603;
        _M0L3segS146 = _M0L6_2atmpS604;
        goto _2afor_147;
        break;
      }
      
      case 13: {
        int32_t _M0L6_2atmpS605;
        int32_t _M0L6_2atmpS606;
        #line 177 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
        _M0MPC16string10StringView18escape__to_2einnerN14flush__segmentS4266(_M0L6_2aenvS144, _M0L3segS146, _M0L1iS145);
        #line 178 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
        _M0L6loggerS141.$0->$method_0(_M0L6loggerS141.$1, (moonbit_string_t)moonbit_string_literal_14.data);
        _M0L6_2atmpS605 = _M0L1iS145 + 1;
        _M0L6_2atmpS606 = _M0L1iS145 + 1;
        _M0L1iS145 = _M0L6_2atmpS605;
        _M0L3segS146 = _M0L6_2atmpS606;
        goto _2afor_147;
        break;
      }
      
      case 8: {
        int32_t _M0L6_2atmpS607;
        int32_t _M0L6_2atmpS608;
        #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
        _M0MPC16string10StringView18escape__to_2einnerN14flush__segmentS4266(_M0L6_2aenvS144, _M0L3segS146, _M0L1iS145);
        #line 183 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
        _M0L6loggerS141.$0->$method_0(_M0L6loggerS141.$1, (moonbit_string_t)moonbit_string_literal_15.data);
        _M0L6_2atmpS607 = _M0L1iS145 + 1;
        _M0L6_2atmpS608 = _M0L1iS145 + 1;
        _M0L1iS145 = _M0L6_2atmpS607;
        _M0L3segS146 = _M0L6_2atmpS608;
        goto _2afor_147;
        break;
      }
      
      case 9: {
        int32_t _M0L6_2atmpS609;
        int32_t _M0L6_2atmpS610;
        #line 187 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
        _M0MPC16string10StringView18escape__to_2einnerN14flush__segmentS4266(_M0L6_2aenvS144, _M0L3segS146, _M0L1iS145);
        #line 188 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
        _M0L6loggerS141.$0->$method_0(_M0L6loggerS141.$1, (moonbit_string_t)moonbit_string_literal_16.data);
        _M0L6_2atmpS609 = _M0L1iS145 + 1;
        _M0L6_2atmpS610 = _M0L1iS145 + 1;
        _M0L1iS145 = _M0L6_2atmpS609;
        _M0L3segS146 = _M0L6_2atmpS610;
        goto _2afor_147;
        break;
      }
      default: {
        if (_M0L4codeS148 < 32) {
          int32_t _M0L6_2atmpS612;
          moonbit_string_t _M0L6_2atmpS611;
          int32_t _M0L6_2atmpS613;
          int32_t _M0L6_2atmpS614;
          #line 193 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
          _M0MPC16string10StringView18escape__to_2einnerN14flush__segmentS4266(_M0L6_2aenvS144, _M0L3segS146, _M0L1iS145);
          #line 194 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
          _M0L6loggerS141.$0->$method_0(_M0L6loggerS141.$1, (moonbit_string_t)moonbit_string_literal_17.data);
          _M0L6_2atmpS612 = _M0L4codeS148 & 0xff;
          #line 195 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
          _M0L6_2atmpS611 = _M0MPC14byte4Byte7to__hex(_M0L6_2atmpS612);
          #line 195 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
          _M0L6loggerS141.$0->$method_0(_M0L6loggerS141.$1, _M0L6_2atmpS611);
          moonbit_decref(_M0L6_2atmpS611);
          #line 196 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
          _M0L6loggerS141.$0->$method_3(_M0L6loggerS141.$1, 125);
          _M0L6_2atmpS613 = _M0L1iS145 + 1;
          _M0L6_2atmpS614 = _M0L1iS145 + 1;
          _M0L1iS145 = _M0L6_2atmpS613;
          _M0L3segS146 = _M0L6_2atmpS614;
          goto _2afor_147;
        } else {
          int32_t _M0L6_2atmpS615 = _M0L1iS145 + 1;
          int32_t _tmp_919 = _M0L3segS146;
          _M0L1iS145 = _M0L6_2atmpS615;
          _M0L3segS146 = _tmp_919;
          goto _2afor_147;
        }
        break;
      }
    }
    goto joinlet_918;
    join_149:;
    #line 166 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    _M0MPC16string10StringView18escape__to_2einnerN14flush__segmentS4266(_M0L6_2aenvS144, _M0L3segS146, _M0L1iS145);
    #line 167 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    _M0L6loggerS141.$0->$method_3(_M0L6loggerS141.$1, 92);
    #line 168 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    _M0L6_2atmpS600 = _M0MPC16uint166UInt1616unsafe__to__char(_M0L1cS150);
    #line 168 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    _M0L6loggerS141.$0->$method_3(_M0L6loggerS141.$1, _M0L6_2atmpS600);
    _M0L6_2atmpS601 = _M0L1iS145 + 1;
    _M0L6_2atmpS602 = _M0L1iS145 + 1;
    _M0L1iS145 = _M0L6_2atmpS601;
    _M0L3segS146 = _M0L6_2atmpS602;
    continue;
    joinlet_918:;
    break;
  }
  if (_M0L5quoteS140) {
    #line 204 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    _M0L6loggerS141.$0->$method_3(_M0L6loggerS141.$1, 34);
  }
  return 0;
}

int32_t _M0MPC16string10StringView18escape__to_2einnerN14flush__segmentS4266(
  struct _M0TURPB6LoggerRPC16string10StringViewE* _M0L6_2aenvS136,
  int32_t _M0L3segS139,
  int32_t _M0L1iS138
) {
  struct _M0TPC16string10StringView _M0L4selfS135;
  struct _M0TPB6Logger _M0L6loggerS137;
  #line 153 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _M0L4selfS135 = _M0L6_2aenvS136->$1;
  _M0L6loggerS137 = _M0L6_2aenvS136->$0;
  if (_M0L1iS138 > _M0L3segS139) {
    int64_t _M0L6_2atmpS599 = (int64_t)_M0L1iS138;
    struct _M0TPC16string10StringView _M0L6_2atmpS598;
    #line 155 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    _M0L6_2atmpS598
    = _M0MPC16string10StringView11sub_2einner(_M0L4selfS135, _M0L3segS139, _M0L6_2atmpS599);
    #line 155 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    _M0L6loggerS137.$0->$method_2(_M0L6loggerS137.$1, _M0L6_2atmpS598);
    moonbit_decref(_M0L6_2atmpS598.$0);
  }
  return 0;
}

struct _M0TPC16string10StringView _M0MPC16string10StringView11sub_2einner(
  struct _M0TPC16string10StringView _M0L4selfS128,
  int32_t _M0L5startS134,
  int64_t _M0L3endS130
) {
  moonbit_string_t _M0L3strS597;
  int32_t _M0L8str__lenS127;
  int32_t _M0L8abs__endS129;
  int32_t _M0L5startS595;
  int32_t _M0L10abs__startS133;
  int32_t _M0L5startS587;
  int32_t _if__result_920;
  #line 978 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
  _M0L3strS597 = _M0L4selfS128.$0;
  _M0L8str__lenS127 = Moonbit_array_length(_M0L3strS597);
  if (_M0L3endS130 == 4294967296ll) {
    _M0L8abs__endS129 = _M0L4selfS128.$2;
  } else {
    int64_t _M0L7_2aSomeS131 = _M0L3endS130;
    int32_t _M0L6_2aendS132 = (int32_t)_M0L7_2aSomeS131;
    int32_t _M0L5startS596 = _M0L4selfS128.$1;
    _M0L8abs__endS129 = _M0L5startS596 + _M0L6_2aendS132;
  }
  _M0L5startS595 = _M0L4selfS128.$1;
  _M0L10abs__startS133 = _M0L5startS595 + _M0L5startS134;
  _M0L5startS587 = _M0L4selfS128.$1;
  if (_M0L10abs__startS133 >= _M0L5startS587) {
    if (_M0L10abs__startS133 <= _M0L8abs__endS129) {
      int32_t _M0L3endS586 = _M0L4selfS128.$2;
      _if__result_920 = _M0L8abs__endS129 <= _M0L3endS586;
    } else {
      _if__result_920 = 0;
    }
  } else {
    _if__result_920 = 0;
  }
  if (_if__result_920) {
    moonbit_string_t _M0L3strS594;
    if (_M0L10abs__startS133 < _M0L8str__lenS127) {
      moonbit_string_t _M0L3strS590 = _M0L4selfS128.$0;
      int32_t _M0L6_2atmpS589 = _M0L3strS590[_M0L10abs__startS133];
      int32_t _M0L6_2atmpS588;
      #line 1000 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
      _M0L6_2atmpS588
      = _M0MPC16uint166UInt1623is__trailing__surrogate(_M0L6_2atmpS589);
      if (!_M0L6_2atmpS588) {
        
      } else {
        #line 1000 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
        moonbit_panic();
      }
    }
    if (_M0L8abs__endS129 < _M0L8str__lenS127) {
      moonbit_string_t _M0L3strS593 = _M0L4selfS128.$0;
      int32_t _M0L6_2atmpS592 = _M0L3strS593[_M0L8abs__endS129];
      int32_t _M0L6_2atmpS591;
      #line 1003 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
      _M0L6_2atmpS591
      = _M0MPC16uint166UInt1623is__trailing__surrogate(_M0L6_2atmpS592);
      if (!_M0L6_2atmpS591) {
        
      } else {
        #line 1003 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
        moonbit_panic();
      }
    }
    _M0L3strS594 = _M0L4selfS128.$0;
    moonbit_incref(_M0L3strS594);
    return (struct _M0TPC16string10StringView){.$0 = _M0L3strS594,
                                                 .$1 = _M0L10abs__startS133,
                                                 .$2 = _M0L8abs__endS129};
  } else {
    #line 994 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringview.mbt"
    moonbit_panic();
  }
}

moonbit_string_t _M0MPC14byte4Byte7to__hex(int32_t _M0L1bS126) {
  struct _M0TPB13StringBuilder* _M0L7_2aselfS125;
  int32_t _M0L6_2atmpS583;
  int32_t _M0L6_2atmpS582;
  int32_t _M0L6_2atmpS585;
  int32_t _M0L6_2atmpS584;
  struct _M0TPB13StringBuilder* _M0L6_2atmpS581;
  moonbit_string_t _result_921;
  #line 74 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  #line 83 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _M0L7_2aselfS125 = _M0MPB13StringBuilder21StringBuilder_2einner(0);
  #line 83 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _M0L6_2atmpS583 = _M0IPC14byte4BytePB3Div3div(_M0L1bS126, 16);
  #line 83 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _M0L6_2atmpS582
  = _M0MPC14byte4Byte7to__hexN14to__hex__digitS4281(_M0L6_2atmpS583);
  #line 83 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _M0IPB13StringBuilderPB6Logger11write__char(_M0L7_2aselfS125, _M0L6_2atmpS582);
  #line 83 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _M0L6_2atmpS585 = _M0IPC14byte4BytePB3Mod3mod(_M0L1bS126, 16);
  #line 83 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _M0L6_2atmpS584
  = _M0MPC14byte4Byte7to__hexN14to__hex__digitS4281(_M0L6_2atmpS585);
  #line 83 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _M0IPB13StringBuilderPB6Logger11write__char(_M0L7_2aselfS125, _M0L6_2atmpS584);
  _M0L6_2atmpS581 = _M0L7_2aselfS125;
  #line 83 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  _result_921 = _M0MPB13StringBuilder10to__string(_M0L6_2atmpS581);
  moonbit_decref(_M0L6_2atmpS581);
  return _result_921;
}

int32_t _M0MPC14byte4Byte7to__hexN14to__hex__digitS4281(int32_t _M0L1iS124) {
  #line 75 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
  if (_M0L1iS124 < 10) {
    int32_t _M0L6_2atmpS578;
    #line 77 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    _M0L6_2atmpS578 = _M0IPC14byte4BytePB3Add3add(_M0L1iS124, 48);
    #line 77 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    return _M0MPC14byte4Byte8to__char(_M0L6_2atmpS578);
  } else {
    int32_t _M0L6_2atmpS580;
    int32_t _M0L6_2atmpS579;
    #line 79 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    _M0L6_2atmpS580 = _M0IPC14byte4BytePB3Add3add(_M0L1iS124, 97);
    #line 79 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    _M0L6_2atmpS579 = _M0IPC14byte4BytePB3Sub3sub(_M0L6_2atmpS580, 10);
    #line 79 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\show.mbt"
    return _M0MPC14byte4Byte8to__char(_M0L6_2atmpS579);
  }
}

int32_t _M0IPC14byte4BytePB3Sub3sub(
  int32_t _M0L4selfS122,
  int32_t _M0L4thatS123
) {
  int32_t _M0L6_2atmpS576;
  int32_t _M0L6_2atmpS577;
  int32_t _M0L6_2atmpS575;
  #line 133 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\byte.mbt"
  _M0L6_2atmpS576 = (int32_t)_M0L4selfS122;
  _M0L6_2atmpS577 = (int32_t)_M0L4thatS123;
  _M0L6_2atmpS575 = _M0L6_2atmpS576 - _M0L6_2atmpS577;
  return _M0L6_2atmpS575 & 0xff;
}

int32_t _M0IPC14byte4BytePB3Mod3mod(
  int32_t _M0L4selfS120,
  int32_t _M0L4thatS121
) {
  int32_t _M0L6_2atmpS573;
  int32_t _M0L6_2atmpS574;
  int32_t _M0L6_2atmpS572;
  #line 80 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\byte.mbt"
  _M0L6_2atmpS573 = (int32_t)_M0L4selfS120;
  _M0L6_2atmpS574 = (int32_t)_M0L4thatS121;
  _M0L6_2atmpS572 = _M0L6_2atmpS573 % _M0L6_2atmpS574;
  return _M0L6_2atmpS572 & 0xff;
}

int32_t _M0IPC14byte4BytePB3Div3div(
  int32_t _M0L4selfS118,
  int32_t _M0L4thatS119
) {
  int32_t _M0L6_2atmpS570;
  int32_t _M0L6_2atmpS571;
  int32_t _M0L6_2atmpS569;
  #line 75 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\byte.mbt"
  _M0L6_2atmpS570 = (int32_t)_M0L4selfS118;
  _M0L6_2atmpS571 = (int32_t)_M0L4thatS119;
  _M0L6_2atmpS569 = _M0L6_2atmpS570 / _M0L6_2atmpS571;
  return _M0L6_2atmpS569 & 0xff;
}

int32_t _M0IPC14byte4BytePB3Add3add(
  int32_t _M0L4selfS116,
  int32_t _M0L4thatS117
) {
  int32_t _M0L6_2atmpS567;
  int32_t _M0L6_2atmpS568;
  int32_t _M0L6_2atmpS566;
  #line 119 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\byte.mbt"
  _M0L6_2atmpS567 = (int32_t)_M0L4selfS116;
  _M0L6_2atmpS568 = (int32_t)_M0L4thatS117;
  _M0L6_2atmpS566 = _M0L6_2atmpS567 + _M0L6_2atmpS568;
  return _M0L6_2atmpS566 & 0xff;
}

int32_t _M0MPC16uint166UInt1616unsafe__to__char(int32_t _M0L4selfS115) {
  int32_t _M0L6_2atmpS565;
  #line 81 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uint16_char.mbt"
  _M0L6_2atmpS565 = (int32_t)_M0L4selfS115;
  return _M0L6_2atmpS565;
}

int32_t _M0MPC16uint166UInt1623is__trailing__surrogate(int32_t _M0L4selfS114) {
  #line 58 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uint16_char.mbt"
  if (_M0L4selfS114 >= 56320) {
    return _M0L4selfS114 <= 57343;
  } else {
    return 0;
  }
}

int32_t _M0IPB13StringBuilderPB6Logger11write__char(
  struct _M0TPB13StringBuilder* _M0L4selfS112,
  int32_t _M0L2chS111
) {
  uint32_t _M0L4codeS110;
  #line 120 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  #line 121 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0L4codeS110 = _M0MPC14char4Char8to__uint(_M0L2chS111);
  if (_M0L4codeS110 <= 65535u) {
    int32_t _M0L3lenS536 = _M0L4selfS112->$1;
    uint16_t* _M0L4dataS538 = _M0L4selfS112->$0;
    int32_t _M0L6_2atmpS537 = Moonbit_array_length(_M0L4dataS538);
    uint16_t* _M0L4dataS541;
    int32_t _M0L3lenS542;
    int32_t _M0L6_2atmpS543;
    int32_t _M0L3lenS545;
    int32_t _M0L6_2atmpS544;
    if (_M0L3lenS536 >= _M0L6_2atmpS537) {
      int32_t _M0L3lenS540 = _M0L4selfS112->$1;
      int32_t _M0L6_2atmpS539 = _M0L3lenS540 + 1;
      #line 124 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
      _M0MPB13StringBuilder4grow(_M0L4selfS112, _M0L6_2atmpS539);
    }
    _M0L4dataS541 = _M0L4selfS112->$0;
    _M0L3lenS542 = _M0L4selfS112->$1;
    moonbit_incref(_M0L4dataS541);
    #line 126 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
    _M0L6_2atmpS543 = _M0MPC14uint4UInt10to__uint16(_M0L4codeS110);
    if (
      _M0L3lenS542 < 0 || _M0L3lenS542 >= Moonbit_array_length(_M0L4dataS541)
    ) {
      #line 126 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
      moonbit_panic();
    }
    _M0L4dataS541[_M0L3lenS542] = _M0L6_2atmpS543;
    moonbit_decref(_M0L4dataS541);
    _M0L3lenS545 = _M0L4selfS112->$1;
    _M0L6_2atmpS544 = _M0L3lenS545 + 1;
    _M0L4selfS112->$1 = _M0L6_2atmpS544;
  } else if (_M0L4codeS110 <= 1114111u) {
    uint16_t* _M0L4dataS549 = _M0L4selfS112->$0;
    int32_t _M0L6_2atmpS547 = Moonbit_array_length(_M0L4dataS549);
    int32_t _M0L3lenS548 = _M0L4selfS112->$1;
    int32_t _M0L6_2atmpS546 = _M0L6_2atmpS547 - _M0L3lenS548;
    uint32_t _M0L4codeS113;
    uint16_t* _M0L4dataS552;
    int32_t _M0L3lenS553;
    uint32_t _M0L6_2atmpS556;
    uint32_t _M0L6_2atmpS555;
    int32_t _M0L6_2atmpS554;
    uint16_t* _M0L4dataS557;
    int32_t _M0L3lenS562;
    int32_t _M0L6_2atmpS558;
    uint32_t _M0L6_2atmpS561;
    uint32_t _M0L6_2atmpS560;
    int32_t _M0L6_2atmpS559;
    int32_t _M0L3lenS564;
    int32_t _M0L6_2atmpS563;
    if (_M0L6_2atmpS546 < 2) {
      int32_t _M0L3lenS551 = _M0L4selfS112->$1;
      int32_t _M0L6_2atmpS550 = _M0L3lenS551 + 2;
      #line 130 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
      _M0MPB13StringBuilder4grow(_M0L4selfS112, _M0L6_2atmpS550);
    }
    _M0L4codeS113 = _M0L4codeS110 - 65536u;
    _M0L4dataS552 = _M0L4selfS112->$0;
    _M0L3lenS553 = _M0L4selfS112->$1;
    _M0L6_2atmpS556 = _M0L4codeS113 >> 10;
    _M0L6_2atmpS555 = 55296u + _M0L6_2atmpS556;
    moonbit_incref(_M0L4dataS552);
    #line 133 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
    _M0L6_2atmpS554 = _M0MPC14uint4UInt10to__uint16(_M0L6_2atmpS555);
    if (
      _M0L3lenS553 < 0 || _M0L3lenS553 >= Moonbit_array_length(_M0L4dataS552)
    ) {
      #line 133 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
      moonbit_panic();
    }
    _M0L4dataS552[_M0L3lenS553] = _M0L6_2atmpS554;
    moonbit_decref(_M0L4dataS552);
    _M0L4dataS557 = _M0L4selfS112->$0;
    _M0L3lenS562 = _M0L4selfS112->$1;
    _M0L6_2atmpS558 = _M0L3lenS562 + 1;
    _M0L6_2atmpS561 = _M0L4codeS113 & 1023u;
    _M0L6_2atmpS560 = 56320u + _M0L6_2atmpS561;
    moonbit_incref(_M0L4dataS557);
    #line 134 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
    _M0L6_2atmpS559 = _M0MPC14uint4UInt10to__uint16(_M0L6_2atmpS560);
    if (
      _M0L6_2atmpS558 < 0
      || _M0L6_2atmpS558 >= Moonbit_array_length(_M0L4dataS557)
    ) {
      #line 134 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
      moonbit_panic();
    }
    _M0L4dataS557[_M0L6_2atmpS558] = _M0L6_2atmpS559;
    moonbit_decref(_M0L4dataS557);
    _M0L3lenS564 = _M0L4selfS112->$1;
    _M0L6_2atmpS563 = _M0L3lenS564 + 2;
    _M0L4selfS112->$1 = _M0L6_2atmpS563;
  } else {
    #line 137 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
    _M0FPC15abort5abortGuE((moonbit_string_t)moonbit_string_literal_18.data);
  }
  return 0;
}

int32_t _M0MPB13StringBuilder4grow(
  struct _M0TPB13StringBuilder* _M0L4selfS107,
  int32_t _M0L8requiredS108
) {
  uint16_t* _M0L4dataS535;
  int32_t _M0L6_2atmpS533;
  int32_t _M0L3lenS534;
  int32_t _M0L13new__capacityS106;
  uint16_t* _M0L4dataS530;
  int32_t _M0L6_2atmpS531;
  int32_t _M0L3lenS532;
  uint16_t* _M0L9new__dataS109;
  uint16_t* _M0L6_2aoldS849;
  #line 74 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0L4dataS535 = _M0L4selfS107->$0;
  _M0L6_2atmpS533 = Moonbit_array_length(_M0L4dataS535);
  _M0L3lenS534 = _M0L4selfS107->$1;
  #line 75 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0L13new__capacityS106
  = _M0FPB31stringbuilder__growth__capacity(_M0L6_2atmpS533, _M0L3lenS534, _M0L8requiredS108);
  _M0L4dataS530 = _M0L4selfS107->$0;
  moonbit_incref(_M0L4dataS530);
  #line 83 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0L6_2atmpS531 = _M0IPC16uint166UInt16PB7Default7default();
  _M0L3lenS532 = _M0L4selfS107->$1;
  #line 80 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0L9new__dataS109
  = _M0MPC15array10FixedArray23make__and__blit_2einnerGkE(_M0L4dataS530, _M0L13new__capacityS106, _M0L6_2atmpS531, _M0L3lenS532, 0, 0);
  _M0L6_2aoldS849 = _M0L4selfS107->$0;
  moonbit_decref(_M0L6_2aoldS849);
  _M0L4selfS107->$0 = _M0L9new__dataS109;
  return 0;
}

int32_t _M0FPB31stringbuilder__growth__capacity(
  int32_t _M0L7currentS105,
  int32_t _M0L3lenS101,
  int32_t _M0L8requiredS100
) {
  int32_t _M0L5spaceS102;
  #line 48 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  if (_M0L8requiredS100 < _M0L3lenS101) {
    #line 55 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
    _M0FPC15abort5abortGuE((moonbit_string_t)moonbit_string_literal_19.data);
  }
  _M0L5spaceS102 = _M0L7currentS105;
  while (1) {
    if (_M0L5spaceS102 < _M0L8requiredS100) {
      int32_t _M0L4nextS103 = _M0L5spaceS102 * 2;
      if (_M0L4nextS103 <= _M0L5spaceS102) {
        return _M0L8requiredS100;
      }
      _M0L5spaceS102 = _M0L4nextS103;
      continue;
    } else {
      return _M0L5spaceS102;
    }
    break;
  }
}

int32_t _M0MPC14uint4UInt10to__uint16(uint32_t _M0L4selfS99) {
  int32_t _M0L6_2atmpS529;
  #line 2703 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\intrinsics.mbt"
  _M0L6_2atmpS529 = *(int32_t*)&_M0L4selfS99;
  return (uint16_t)_M0L6_2atmpS529;
}

uint32_t _M0MPC14char4Char8to__uint(int32_t _M0L4selfS98) {
  int32_t _M0L6_2atmpS528;
  #line 1255 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\intrinsics.mbt"
  _M0L6_2atmpS528 = _M0L4selfS98;
  return *(uint32_t*)&_M0L6_2atmpS528;
}

moonbit_string_t _M0MPB13StringBuilder10to__string(
  struct _M0TPB13StringBuilder* _M0L4selfS96
) {
  int32_t _M0L3lenS519;
  #line 183 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  _M0L3lenS519 = _M0L4selfS96->$1;
  if (_M0L3lenS519 == 0) {
    return (moonbit_string_t)moonbit_string_literal_0.data;
  } else {
    int32_t _M0L3lenS520 = _M0L4selfS96->$1;
    uint16_t* _M0L4dataS522 = _M0L4selfS96->$0;
    int32_t _M0L6_2atmpS521 = Moonbit_array_length(_M0L4dataS522);
    if (_M0L3lenS520 == _M0L6_2atmpS521) {
      uint16_t* _M0L4dataS523 = _M0L4selfS96->$0;
      moonbit_incref(_M0L4dataS523);
      return _M0L4dataS523;
    } else {
      uint16_t* _M0L4dataS524 = _M0L4selfS96->$0;
      int32_t _M0L3lenS525 = _M0L4selfS96->$1;
      int32_t _M0L6_2atmpS526;
      int32_t _M0L3lenS527;
      uint16_t* _M0L4dataS97;
      moonbit_incref(_M0L4dataS524);
      #line 192 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
      _M0L6_2atmpS526 = _M0IPC16uint166UInt16PB7Default7default();
      _M0L3lenS527 = _M0L4selfS96->$1;
      #line 189 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
      _M0L4dataS97
      = _M0MPC15array10FixedArray23make__and__blit_2einnerGkE(_M0L4dataS524, _M0L3lenS525, _M0L6_2atmpS526, _M0L3lenS527, 0, 0);
      return _M0L4dataS97;
    }
  }
}

uint16_t* _M0MPC15array10FixedArray23make__and__blit_2einnerGkE(
  uint16_t* _M0L3srcS93,
  int32_t _M0L13allocate__lenS89,
  int32_t _M0L4initS94,
  int32_t _M0L3lenS90,
  int32_t _M0L11src__offsetS91,
  int32_t _M0L11dst__offsetS92
) {
  int32_t _if__result_923;
  #line 97 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
  if (_M0L13allocate__lenS89 >= 0) {
    if (_M0L3lenS90 >= 0) {
      if (_M0L11src__offsetS91 >= 0) {
        if (_M0L11dst__offsetS92 >= 0) {
          int32_t _M0L6_2atmpS515 = _M0L11src__offsetS91 + _M0L3lenS90;
          int32_t _M0L6_2atmpS516 = Moonbit_array_length(_M0L3srcS93);
          if (_M0L6_2atmpS515 <= _M0L6_2atmpS516) {
            int32_t _M0L6_2atmpS514 = _M0L11dst__offsetS92 + _M0L3lenS90;
            _if__result_923 = _M0L6_2atmpS514 <= _M0L13allocate__lenS89;
          } else {
            _if__result_923 = 0;
          }
        } else {
          _if__result_923 = 0;
        }
      } else {
        _if__result_923 = 0;
      }
    } else {
      _if__result_923 = 0;
    }
  } else {
    _if__result_923 = 0;
  }
  if (_if__result_923) {
    #line 116 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    return _M0MPC15array10FixedArray23unsafe__make__and__blitGkE(_M0L3srcS93, _M0L13allocate__lenS89, _M0L4initS94, _M0L11src__offsetS91, _M0L11dst__offsetS92, _M0L3lenS90);
  } else {
    struct _M0TPB13StringBuilder* _M0L18_2astring__builderS95;
    int32_t _M0L6_2atmpS518;
    moonbit_string_t _M0L6_2atmpS517;
    uint16_t* _result_924;
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0L18_2astring__builderS95
    = _M0MPB13StringBuilder21StringBuilder_2einner(89);
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS95, (moonbit_string_t)moonbit_string_literal_20.data);
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS95, _M0L13allocate__lenS89);
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS95, (moonbit_string_t)moonbit_string_literal_21.data);
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS95, _M0L11src__offsetS91);
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS95, (moonbit_string_t)moonbit_string_literal_22.data);
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS95, _M0L11dst__offsetS92);
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS95, (moonbit_string_t)moonbit_string_literal_23.data);
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS95, _M0L3lenS90);
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS95, (moonbit_string_t)moonbit_string_literal_24.data);
    _M0L6_2atmpS518 = Moonbit_array_length(_M0L3srcS93);
    moonbit_decref(_M0L3srcS93);
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS95, _M0L6_2atmpS518);
    #line 113 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _M0L6_2atmpS517
    = _M0MPB13StringBuilder10to__string(_M0L18_2astring__builderS95);
    moonbit_decref(_M0L18_2astring__builderS95);
    #line 112 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
    _result_924 = _M0FPC15abort5abortGAkE(_M0L6_2atmpS517);
    moonbit_decref(_M0L6_2atmpS517);
    return _result_924;
  }
}

uint16_t* _M0MPC15array10FixedArray23unsafe__make__and__blitGkE(
  uint16_t* _M0L3srcS86,
  int32_t _M0L13allocate__lenS83,
  int32_t _M0L4initS84,
  int32_t _M0L11src__offsetS87,
  int32_t _M0L11dst__offsetS85,
  int32_t _M0L9blit__lenS88
) {
  uint16_t* _M0L3dstS82;
  #line 79 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
  _M0L3dstS82
  = (uint16_t*)moonbit_make_string(_M0L13allocate__lenS83, _M0L4initS84);
  moonbit_incref(_M0L3dstS82);
  #line 90 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
  moonbit_unsafe_val_array_blit(_M0L3dstS82, _M0L11dst__offsetS85, _M0L3srcS86, _M0L11src__offsetS87, _M0L9blit__lenS88, sizeof(uint16_t));
  return _M0L3dstS82;
}

struct _M0TPB13StringBuilder* _M0MPB13StringBuilder21StringBuilder_2einner(
  int32_t _M0L10size__hintS80
) {
  int32_t _M0L7initialS79;
  uint16_t* _M0L4dataS81;
  struct _M0TPB13StringBuilder* _block_925;
  #line 32 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder_buffer.mbt"
  if (_M0L10size__hintS80 < 1) {
    _M0L7initialS79 = 1;
  } else {
    int32_t _M0L6_2atmpS513 = _M0L10size__hintS80 + 1;
    _M0L7initialS79 = _M0L6_2atmpS513 / 2;
  }
  _M0L4dataS81 = (uint16_t*)moonbit_make_string(_M0L7initialS79, 0);
  _block_925
  = (struct _M0TPB13StringBuilder*)moonbit_malloc(sizeof(struct _M0TPB13StringBuilder));
  Moonbit_object_header(_block_925)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 30, 0);
  _block_925->$0 = _M0L4dataS81;
  _block_925->$1 = 0;
  return _block_925;
}

int32_t _M0MPC14byte4Byte8to__char(int32_t _M0L4selfS78) {
  int32_t _M0L6_2atmpS512;
  #line 1869 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\intrinsics.mbt"
  _M0L6_2atmpS512 = (int32_t)_M0L4selfS78;
  return _M0L6_2atmpS512;
}

moonbit_string_t* _M0MPB18UninitializedArray23make__and__blit_2einnerGsE(
  moonbit_string_t* _M0L3srcS70,
  int32_t _M0L13allocate__lenS66,
  int32_t _M0L3lenS67,
  int32_t _M0L11src__offsetS68,
  int32_t _M0L11dst__offsetS69
) {
  int32_t _if__result_926;
  #line 167 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  if (_M0L13allocate__lenS66 >= 0) {
    if (_M0L3lenS67 >= 0) {
      if (_M0L11src__offsetS68 >= 0) {
        if (_M0L11dst__offsetS69 >= 0) {
          int32_t _M0L6_2atmpS503 = _M0L11src__offsetS68 + _M0L3lenS67;
          int32_t _M0L6_2atmpS504;
          #line 179 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
          _M0L6_2atmpS504 = _M0MPB18UninitializedArray6lengthGsE(_M0L3srcS70);
          if (_M0L6_2atmpS503 <= _M0L6_2atmpS504) {
            int32_t _M0L6_2atmpS502 = _M0L11dst__offsetS69 + _M0L3lenS67;
            _if__result_926 = _M0L6_2atmpS502 <= _M0L13allocate__lenS66;
          } else {
            _if__result_926 = 0;
          }
        } else {
          _if__result_926 = 0;
        }
      } else {
        _if__result_926 = 0;
      }
    } else {
      _if__result_926 = 0;
    }
  } else {
    _if__result_926 = 0;
  }
  if (_if__result_926) {
    #line 185 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    return (moonbit_string_t*)moonbit_make_ref_array_with_blit(_M0L13allocate__lenS66, (moonbit_string_t)moonbit_string_literal_0.data, _M0L3srcS70, _M0L11src__offsetS68, _M0L11dst__offsetS69, _M0L3lenS67);
  } else {
    struct _M0TPB13StringBuilder* _M0L18_2astring__builderS71;
    int32_t _M0L6_2atmpS506;
    moonbit_string_t _M0L6_2atmpS505;
    moonbit_string_t* _result_927;
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0L18_2astring__builderS71
    = _M0MPB13StringBuilder21StringBuilder_2einner(89);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS71, (moonbit_string_t)moonbit_string_literal_20.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS71, _M0L13allocate__lenS66);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS71, (moonbit_string_t)moonbit_string_literal_21.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS71, _M0L11src__offsetS68);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS71, (moonbit_string_t)moonbit_string_literal_22.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS71, _M0L11dst__offsetS69);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS71, (moonbit_string_t)moonbit_string_literal_23.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS71, _M0L3lenS67);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS71, (moonbit_string_t)moonbit_string_literal_24.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0L6_2atmpS506 = _M0MPB18UninitializedArray6lengthGsE(_M0L3srcS70);
    moonbit_decref(_M0L3srcS70);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS71, _M0L6_2atmpS506);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0L6_2atmpS505
    = _M0MPB13StringBuilder10to__string(_M0L18_2astring__builderS71);
    moonbit_decref(_M0L18_2astring__builderS71);
    #line 181 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _result_927
    = _M0FPC15abort5abortGRPB18UninitializedArrayGsEE(_M0L6_2atmpS505);
    moonbit_decref(_M0L6_2atmpS505);
    return _result_927;
  }
}

struct _M0TUsiE** _M0MPB18UninitializedArray23make__and__blit_2einnerGUsiEE(
  struct _M0TUsiE** _M0L3srcS76,
  int32_t _M0L13allocate__lenS72,
  int32_t _M0L3lenS73,
  int32_t _M0L11src__offsetS74,
  int32_t _M0L11dst__offsetS75
) {
  int32_t _if__result_928;
  #line 167 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  if (_M0L13allocate__lenS72 >= 0) {
    if (_M0L3lenS73 >= 0) {
      if (_M0L11src__offsetS74 >= 0) {
        if (_M0L11dst__offsetS75 >= 0) {
          int32_t _M0L6_2atmpS508 = _M0L11src__offsetS74 + _M0L3lenS73;
          int32_t _M0L6_2atmpS509;
          #line 179 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
          _M0L6_2atmpS509
          = _M0MPB18UninitializedArray6lengthGUsiEE(_M0L3srcS76);
          if (_M0L6_2atmpS508 <= _M0L6_2atmpS509) {
            int32_t _M0L6_2atmpS507 = _M0L11dst__offsetS75 + _M0L3lenS73;
            _if__result_928 = _M0L6_2atmpS507 <= _M0L13allocate__lenS72;
          } else {
            _if__result_928 = 0;
          }
        } else {
          _if__result_928 = 0;
        }
      } else {
        _if__result_928 = 0;
      }
    } else {
      _if__result_928 = 0;
    }
  } else {
    _if__result_928 = 0;
  }
  if (_if__result_928) {
    #line 185 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    return (struct _M0TUsiE**)moonbit_make_ref_array_with_blit(_M0L13allocate__lenS72, 0, _M0L3srcS76, _M0L11src__offsetS74, _M0L11dst__offsetS75, _M0L3lenS73);
  } else {
    struct _M0TPB13StringBuilder* _M0L18_2astring__builderS77;
    int32_t _M0L6_2atmpS511;
    moonbit_string_t _M0L6_2atmpS510;
    struct _M0TUsiE** _result_929;
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0L18_2astring__builderS77
    = _M0MPB13StringBuilder21StringBuilder_2einner(89);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS77, (moonbit_string_t)moonbit_string_literal_20.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS77, _M0L13allocate__lenS72);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS77, (moonbit_string_t)moonbit_string_literal_21.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS77, _M0L11src__offsetS74);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS77, (moonbit_string_t)moonbit_string_literal_22.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS77, _M0L11dst__offsetS75);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS77, (moonbit_string_t)moonbit_string_literal_23.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS77, _M0L3lenS73);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0IPB13StringBuilderPB6Logger13write__string(_M0L18_2astring__builderS77, (moonbit_string_t)moonbit_string_literal_24.data);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0L6_2atmpS511 = _M0MPB18UninitializedArray6lengthGUsiEE(_M0L3srcS76);
    moonbit_decref(_M0L3srcS76);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0MPB13StringBuilder13write__objectGiE(_M0L18_2astring__builderS77, _M0L6_2atmpS511);
    #line 182 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _M0L6_2atmpS510
    = _M0MPB13StringBuilder10to__string(_M0L18_2astring__builderS77);
    moonbit_decref(_M0L18_2astring__builderS77);
    #line 181 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
    _result_929
    = _M0FPC15abort5abortGRPB18UninitializedArrayGUsiEEE(_M0L6_2atmpS510);
    moonbit_decref(_M0L6_2atmpS510);
    return _result_929;
  }
}

int32_t _M0MPB13StringBuilder13write__objectGsE(
  struct _M0TPB13StringBuilder* _M0L4selfS63,
  moonbit_string_t _M0L3objS62
) {
  struct _M0TPB6Logger _M0L6_2atmpS500;
  #line 17 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder.mbt"
  moonbit_incref(_M0L4selfS63);
  _M0L6_2atmpS500
  = (struct _M0TPB6Logger){
    _M0FP0119moonbitlang_2fcore_2fbuiltin_2fStringBuilder_2eas___40moonbitlang_2fcore_2fbuiltin_2eLogger_2estatic__method__table__id,
      _M0L4selfS63
  };
  #line 23 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder.mbt"
  _M0IP016_24default__implPB4Show6outputGsE(_M0L3objS62, _M0L6_2atmpS500);
  if (_M0L6_2atmpS500.$1) {
    moonbit_decref(_M0L6_2atmpS500.$1);
  }
  return 0;
}

int32_t _M0MPB13StringBuilder13write__objectGiE(
  struct _M0TPB13StringBuilder* _M0L4selfS65,
  int32_t _M0L3objS64
) {
  struct _M0TPB6Logger _M0L6_2atmpS501;
  #line 17 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder.mbt"
  moonbit_incref(_M0L4selfS65);
  _M0L6_2atmpS501
  = (struct _M0TPB6Logger){
    _M0FP0119moonbitlang_2fcore_2fbuiltin_2fStringBuilder_2eas___40moonbitlang_2fcore_2fbuiltin_2eLogger_2estatic__method__table__id,
      _M0L4selfS65
  };
  #line 23 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\stringbuilder.mbt"
  _M0IP016_24default__implPB4Show6outputGiE(_M0L3objS64, _M0L6_2atmpS501);
  if (_M0L6_2atmpS501.$1) {
    moonbit_decref(_M0L6_2atmpS501.$1);
  }
  return 0;
}

moonbit_string_t* _M0MPB18UninitializedArray23unsafe__make__and__blitGsE(
  moonbit_string_t* _M0L3srcS53,
  int32_t _M0L13allocate__lenS51,
  int32_t _M0L11src__offsetS54,
  int32_t _M0L11dst__offsetS52,
  int32_t _M0L9blit__lenS55
) {
  moonbit_string_t* _M0L3dstS50;
  #line 132 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  _M0L3dstS50
  = (moonbit_string_t*)moonbit_make_ref_array(_M0L13allocate__lenS51, (moonbit_string_t)moonbit_string_literal_0.data);
  #line 142 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  _M0MPB18UninitializedArray12unsafe__blitGsE(_M0L3dstS50, _M0L11dst__offsetS52, _M0L3srcS53, _M0L11src__offsetS54, _M0L9blit__lenS55);
  moonbit_decref(_M0L3srcS53);
  return _M0L3dstS50;
}

struct _M0TUsiE** _M0MPB18UninitializedArray23unsafe__make__and__blitGUsiEE(
  struct _M0TUsiE** _M0L3srcS59,
  int32_t _M0L13allocate__lenS57,
  int32_t _M0L11src__offsetS60,
  int32_t _M0L11dst__offsetS58,
  int32_t _M0L9blit__lenS61
) {
  struct _M0TUsiE** _M0L3dstS56;
  #line 132 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  _M0L3dstS56
  = (struct _M0TUsiE**)moonbit_make_ref_array(_M0L13allocate__lenS57, 0);
  #line 142 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  _M0MPB18UninitializedArray12unsafe__blitGUsiEE(_M0L3dstS56, _M0L11dst__offsetS58, _M0L3srcS59, _M0L11src__offsetS60, _M0L9blit__lenS61);
  moonbit_decref(_M0L3srcS59);
  return _M0L3dstS56;
}

int32_t _M0MPB18UninitializedArray12unsafe__blitGsE(
  moonbit_string_t* _M0L3dstS40,
  int32_t _M0L11dst__offsetS41,
  moonbit_string_t* _M0L3srcS42,
  int32_t _M0L11src__offsetS43,
  int32_t _M0L3lenS44
) {
  #line 118 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  moonbit_incref(_M0L3srcS42);
  moonbit_incref(_M0L3dstS40);
  #line 127 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  moonbit_unsafe_ref_array_blit(_M0L3dstS40, _M0L11dst__offsetS41, _M0L3srcS42, _M0L11src__offsetS43, _M0L3lenS44);
  return 0;
}

int32_t _M0MPB18UninitializedArray12unsafe__blitGUsiEE(
  struct _M0TUsiE** _M0L3dstS45,
  int32_t _M0L11dst__offsetS46,
  struct _M0TUsiE** _M0L3srcS47,
  int32_t _M0L11src__offsetS48,
  int32_t _M0L3lenS49
) {
  #line 118 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  moonbit_incref(_M0L3srcS47);
  moonbit_incref(_M0L3dstS45);
  #line 127 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  moonbit_unsafe_ref_array_blit(_M0L3dstS45, _M0L11dst__offsetS46, _M0L3srcS47, _M0L11src__offsetS48, _M0L3lenS49);
  return 0;
}

int32_t _M0MPC15array10FixedArray12unsafe__blitGkE(
  uint16_t* _M0L3dstS13,
  int32_t _M0L11dst__offsetS15,
  uint16_t* _M0L3srcS14,
  int32_t _M0L11src__offsetS16,
  int32_t _M0L3lenS18
) {
  int32_t _if__result_930;
  #line 38 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
  if (_M0L3dstS13 == _M0L3srcS14) {
    _if__result_930 = _M0L11dst__offsetS15 < _M0L11src__offsetS16;
  } else {
    _if__result_930 = 0;
  }
  if (_if__result_930) {
    int32_t _M0L1iS17 = 0;
    while (1) {
      if (_M0L1iS17 < _M0L3lenS18) {
        int32_t _M0L6_2atmpS473 = _M0L11dst__offsetS15 + _M0L1iS17;
        int32_t _M0L6_2atmpS475 = _M0L11src__offsetS16 + _M0L1iS17;
        int32_t _M0L6_2atmpS474;
        int32_t _M0L6_2atmpS476;
        if (
          _M0L6_2atmpS475 < 0
          || _M0L6_2atmpS475 >= Moonbit_array_length(_M0L3srcS14)
        ) {
          #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2atmpS474 = (int32_t)_M0L3srcS14[_M0L6_2atmpS475];
        if (
          _M0L6_2atmpS473 < 0
          || _M0L6_2atmpS473 >= Moonbit_array_length(_M0L3dstS13)
        ) {
          #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L3dstS13[_M0L6_2atmpS473] = _M0L6_2atmpS474;
        _M0L6_2atmpS476 = _M0L1iS17 + 1;
        _M0L1iS17 = _M0L6_2atmpS476;
        continue;
      } else {
        moonbit_decref(_M0L3srcS14);
        moonbit_decref(_M0L3dstS13);
      }
      break;
    }
  } else {
    int32_t _M0L6_2atmpS481 = _M0L3lenS18 - 1;
    int32_t _M0L1iS20 = _M0L6_2atmpS481;
    while (1) {
      if (_M0L1iS20 >= 0) {
        int32_t _M0L6_2atmpS477 = _M0L11dst__offsetS15 + _M0L1iS20;
        int32_t _M0L6_2atmpS479 = _M0L11src__offsetS16 + _M0L1iS20;
        int32_t _M0L6_2atmpS478;
        int32_t _M0L6_2atmpS480;
        if (
          _M0L6_2atmpS479 < 0
          || _M0L6_2atmpS479 >= Moonbit_array_length(_M0L3srcS14)
        ) {
          #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2atmpS478 = (int32_t)_M0L3srcS14[_M0L6_2atmpS479];
        if (
          _M0L6_2atmpS477 < 0
          || _M0L6_2atmpS477 >= Moonbit_array_length(_M0L3dstS13)
        ) {
          #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L3dstS13[_M0L6_2atmpS477] = _M0L6_2atmpS478;
        _M0L6_2atmpS480 = _M0L1iS20 - 1;
        _M0L1iS20 = _M0L6_2atmpS480;
        continue;
      } else {
        moonbit_decref(_M0L3srcS14);
        moonbit_decref(_M0L3dstS13);
      }
      break;
    }
  }
  return 0;
}

int32_t _M0MPC15array10FixedArray12unsafe__blitGRPB17UnsafeMaybeUninitGsEE(
  moonbit_string_t* _M0L3dstS22,
  int32_t _M0L11dst__offsetS24,
  moonbit_string_t* _M0L3srcS23,
  int32_t _M0L11src__offsetS25,
  int32_t _M0L3lenS27
) {
  int32_t _if__result_933;
  #line 38 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
  if (_M0L3dstS22 == _M0L3srcS23) {
    _if__result_933 = _M0L11dst__offsetS24 < _M0L11src__offsetS25;
  } else {
    _if__result_933 = 0;
  }
  if (_if__result_933) {
    int32_t _M0L1iS26 = 0;
    while (1) {
      if (_M0L1iS26 < _M0L3lenS27) {
        int32_t _M0L6_2atmpS482 = _M0L11dst__offsetS24 + _M0L1iS26;
        int32_t _M0L6_2atmpS484 = _M0L11src__offsetS25 + _M0L1iS26;
        moonbit_string_t _M0L6_2atmpS483;
        moonbit_string_t _M0L6_2aoldS855;
        int32_t _M0L6_2atmpS485;
        if (
          _M0L6_2atmpS484 < 0
          || _M0L6_2atmpS484 >= Moonbit_array_length(_M0L3srcS23)
        ) {
          #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2atmpS483 = (moonbit_string_t)_M0L3srcS23[_M0L6_2atmpS484];
        if (
          _M0L6_2atmpS482 < 0
          || _M0L6_2atmpS482 >= Moonbit_array_length(_M0L3dstS22)
        ) {
          #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2aoldS855 = (moonbit_string_t)_M0L3dstS22[_M0L6_2atmpS482];
        moonbit_incref(_M0L6_2atmpS483);
        moonbit_decref(_M0L6_2aoldS855);
        _M0L3dstS22[_M0L6_2atmpS482] = _M0L6_2atmpS483;
        _M0L6_2atmpS485 = _M0L1iS26 + 1;
        _M0L1iS26 = _M0L6_2atmpS485;
        continue;
      } else {
        moonbit_decref(_M0L3srcS23);
        moonbit_decref(_M0L3dstS22);
      }
      break;
    }
  } else {
    int32_t _M0L6_2atmpS490 = _M0L3lenS27 - 1;
    int32_t _M0L1iS29 = _M0L6_2atmpS490;
    while (1) {
      if (_M0L1iS29 >= 0) {
        int32_t _M0L6_2atmpS486 = _M0L11dst__offsetS24 + _M0L1iS29;
        int32_t _M0L6_2atmpS488 = _M0L11src__offsetS25 + _M0L1iS29;
        moonbit_string_t _M0L6_2atmpS487;
        moonbit_string_t _M0L6_2aoldS857;
        int32_t _M0L6_2atmpS489;
        if (
          _M0L6_2atmpS488 < 0
          || _M0L6_2atmpS488 >= Moonbit_array_length(_M0L3srcS23)
        ) {
          #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2atmpS487 = (moonbit_string_t)_M0L3srcS23[_M0L6_2atmpS488];
        if (
          _M0L6_2atmpS486 < 0
          || _M0L6_2atmpS486 >= Moonbit_array_length(_M0L3dstS22)
        ) {
          #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2aoldS857 = (moonbit_string_t)_M0L3dstS22[_M0L6_2atmpS486];
        moonbit_incref(_M0L6_2atmpS487);
        moonbit_decref(_M0L6_2aoldS857);
        _M0L3dstS22[_M0L6_2atmpS486] = _M0L6_2atmpS487;
        _M0L6_2atmpS489 = _M0L1iS29 - 1;
        _M0L1iS29 = _M0L6_2atmpS489;
        continue;
      } else {
        moonbit_decref(_M0L3srcS23);
        moonbit_decref(_M0L3dstS22);
      }
      break;
    }
  }
  return 0;
}

int32_t _M0MPC15array10FixedArray12unsafe__blitGRPB17UnsafeMaybeUninitGUsiEEE(
  struct _M0TUsiE** _M0L3dstS31,
  int32_t _M0L11dst__offsetS33,
  struct _M0TUsiE** _M0L3srcS32,
  int32_t _M0L11src__offsetS34,
  int32_t _M0L3lenS36
) {
  int32_t _if__result_936;
  #line 38 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
  if (_M0L3dstS31 == _M0L3srcS32) {
    _if__result_936 = _M0L11dst__offsetS33 < _M0L11src__offsetS34;
  } else {
    _if__result_936 = 0;
  }
  if (_if__result_936) {
    int32_t _M0L1iS35 = 0;
    while (1) {
      if (_M0L1iS35 < _M0L3lenS36) {
        int32_t _M0L6_2atmpS491 = _M0L11dst__offsetS33 + _M0L1iS35;
        int32_t _M0L6_2atmpS493 = _M0L11src__offsetS34 + _M0L1iS35;
        struct _M0TUsiE* _M0L6_2atmpS492;
        struct _M0TUsiE* _M0L6_2aoldS859;
        int32_t _M0L6_2atmpS494;
        if (
          _M0L6_2atmpS493 < 0
          || _M0L6_2atmpS493 >= Moonbit_array_length(_M0L3srcS32)
        ) {
          #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2atmpS492 = (struct _M0TUsiE*)_M0L3srcS32[_M0L6_2atmpS493];
        if (
          _M0L6_2atmpS491 < 0
          || _M0L6_2atmpS491 >= Moonbit_array_length(_M0L3dstS31)
        ) {
          #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2aoldS859 = (struct _M0TUsiE*)_M0L3dstS31[_M0L6_2atmpS491];
        if (_M0L6_2atmpS492) {
          moonbit_incref(_M0L6_2atmpS492);
        }
        if (_M0L6_2aoldS859) {
          moonbit_decref(_M0L6_2aoldS859);
        }
        _M0L3dstS31[_M0L6_2atmpS491] = _M0L6_2atmpS492;
        _M0L6_2atmpS494 = _M0L1iS35 + 1;
        _M0L1iS35 = _M0L6_2atmpS494;
        continue;
      } else {
        moonbit_decref(_M0L3srcS32);
        moonbit_decref(_M0L3dstS31);
      }
      break;
    }
  } else {
    int32_t _M0L6_2atmpS499 = _M0L3lenS36 - 1;
    int32_t _M0L1iS38 = _M0L6_2atmpS499;
    while (1) {
      if (_M0L1iS38 >= 0) {
        int32_t _M0L6_2atmpS495 = _M0L11dst__offsetS33 + _M0L1iS38;
        int32_t _M0L6_2atmpS497 = _M0L11src__offsetS34 + _M0L1iS38;
        struct _M0TUsiE* _M0L6_2atmpS496;
        struct _M0TUsiE* _M0L6_2aoldS861;
        int32_t _M0L6_2atmpS498;
        if (
          _M0L6_2atmpS497 < 0
          || _M0L6_2atmpS497 >= Moonbit_array_length(_M0L3srcS32)
        ) {
          #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2atmpS496 = (struct _M0TUsiE*)_M0L3srcS32[_M0L6_2atmpS497];
        if (
          _M0L6_2atmpS495 < 0
          || _M0L6_2atmpS495 >= Moonbit_array_length(_M0L3dstS31)
        ) {
          #line 54 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\fixedarray_block.mbt"
          moonbit_panic();
        }
        _M0L6_2aoldS861 = (struct _M0TUsiE*)_M0L3dstS31[_M0L6_2atmpS495];
        if (_M0L6_2atmpS496) {
          moonbit_incref(_M0L6_2atmpS496);
        }
        if (_M0L6_2aoldS861) {
          moonbit_decref(_M0L6_2aoldS861);
        }
        _M0L3dstS31[_M0L6_2atmpS495] = _M0L6_2atmpS496;
        _M0L6_2atmpS498 = _M0L1iS38 - 1;
        _M0L1iS38 = _M0L6_2atmpS498;
        continue;
      } else {
        moonbit_decref(_M0L3srcS32);
        moonbit_decref(_M0L3dstS31);
      }
      break;
    }
  }
  return 0;
}

int32_t _M0MPB18UninitializedArray6lengthGsE(moonbit_string_t* _M0L4selfS11) {
  #line 112 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  return Moonbit_array_length(_M0L4selfS11);
}

int32_t _M0MPB18UninitializedArray6lengthGUsiEE(
  struct _M0TUsiE** _M0L4selfS12
) {
  #line 112 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\uninitialized_array.mbt"
  return Moonbit_array_length(_M0L4selfS12);
}

int32_t _M0IPB7FailurePB4Show6output(
  void* _M0L10_2ax__6124S7,
  struct _M0TPB6Logger _M0L10_2ax__6125S10
) {
  struct _M0DTPC15error5Error48moonbitlang_2fcore_2fbuiltin_2eFailure_2eFailure* _M0L10_2aFailureS8;
  moonbit_string_t _M0L15_2a_2aarg__6126S9;
  #line 37 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\failure.mbt"
  _M0L10_2aFailureS8
  = (struct _M0DTPC15error5Error48moonbitlang_2fcore_2fbuiltin_2eFailure_2eFailure*)_M0L10_2ax__6124S7;
  _M0L15_2a_2aarg__6126S9 = _M0L10_2aFailureS8->$0;
  #line 37 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\failure.mbt"
  _M0L10_2ax__6125S10.$0->$method_0(_M0L10_2ax__6125S10.$1, (moonbit_string_t)moonbit_string_literal_25.data);
  #line 37 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\failure.mbt"
  _M0MPB6Logger13write__objectGsE(_M0L10_2ax__6125S10, _M0L15_2a_2aarg__6126S9);
  #line 37 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\failure.mbt"
  _M0L10_2ax__6125S10.$0->$method_0(_M0L10_2ax__6125S10.$1, (moonbit_string_t)moonbit_string_literal_26.data);
  return 0;
}

int32_t _M0MPB6Logger13write__objectGsE(
  struct _M0TPB6Logger _M0L4selfS6,
  moonbit_string_t _M0L3objS5
) {
  #line 173 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  #line 174 "C:\\Users\\Administrator\\.moon\\lib\\core\\builtin\\traits.mbt"
  _M0IP016_24default__implPB4Show6outputGsE(_M0L3objS5, _M0L4selfS6);
  return 0;
}

int32_t _M0FPC15abort5abortGuE(moonbit_string_t _M0L3msgS1) {
  #line 47 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  #line 49 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_println(_M0L3msgS1);
  #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_panic();
  return 0;
}

uint16_t* _M0FPC15abort5abortGAkE(moonbit_string_t _M0L3msgS2) {
  #line 47 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  #line 49 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_println(_M0L3msgS2);
  #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_panic();
}

moonbit_string_t* _M0FPC15abort5abortGRPB18UninitializedArrayGsEE(
  moonbit_string_t _M0L3msgS3
) {
  #line 47 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  #line 49 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_println(_M0L3msgS3);
  #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_panic();
}

struct _M0TUsiE** _M0FPC15abort5abortGRPB18UninitializedArrayGUsiEEE(
  moonbit_string_t _M0L3msgS4
) {
  #line 47 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  #line 49 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_println(_M0L3msgS4);
  #line 50 "C:\\Users\\Administrator\\.moon\\lib\\core\\abort\\abort.mbt"
  moonbit_panic();
}

moonbit_string_t _M0FP15Error10to__string(void* _M0L4_2aeS444) {
  switch (Moonbit_object_tag(_M0L4_2aeS444)) {
    case 2: {
      return (moonbit_string_t)moonbit_string_literal_27.data;
      break;
    }
    
    case 1: {
      return (moonbit_string_t)moonbit_string_literal_28.data;
      break;
    }
    
    case 0: {
      return _M0IP016_24default__implPB4Show10to__stringGRPB7FailureE(_M0L4_2aeS444);
      break;
    }
    
    case 3: {
      return (moonbit_string_t)moonbit_string_literal_29.data;
      break;
    }
    default: {
      return (moonbit_string_t)moonbit_string_literal_30.data;
      break;
    }
  }
}

int32_t _M0IP016_24default__implPB6Logger61write_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLoggerGRPB13StringBuilderE(
  void* _M0L11_2aobj__ptrS467,
  struct _M0TPB4Show _M0L8_2aparamS466
) {
  struct _M0TPB13StringBuilder* _M0L7_2aselfS465 =
    (struct _M0TPB13StringBuilder*)_M0L11_2aobj__ptrS467;
  _M0IP016_24default__implPB6Logger5writeGRPB13StringBuilderE(_M0L7_2aselfS465, _M0L8_2aparamS466);
  return 0;
}

int32_t _M0IP016_24default__implPB6Logger84write__string__interpolation_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLoggerGRPB13StringBuilderE(
  void* _M0L11_2aobj__ptrS464,
  struct _M0TPB4Show _M0L8_2aparamS463
) {
  struct _M0TPB13StringBuilder* _M0L7_2aselfS462 =
    (struct _M0TPB13StringBuilder*)_M0L11_2aobj__ptrS464;
  _M0IP016_24default__implPB6Logger28write__string__interpolationGRPB13StringBuilderE(_M0L7_2aselfS462, _M0L8_2aparamS463);
  return 0;
}

int32_t _M0IPB13StringBuilderPB6Logger67write__char_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLogger(
  void* _M0L11_2aobj__ptrS461,
  int32_t _M0L8_2aparamS460
) {
  struct _M0TPB13StringBuilder* _M0L7_2aselfS459 =
    (struct _M0TPB13StringBuilder*)_M0L11_2aobj__ptrS461;
  _M0IPB13StringBuilderPB6Logger11write__char(_M0L7_2aselfS459, _M0L8_2aparamS460);
  return 0;
}

int32_t _M0IPB13StringBuilderPB6Logger67write__view_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLogger(
  void* _M0L11_2aobj__ptrS458,
  struct _M0TPC16string10StringView _M0L8_2aparamS457
) {
  struct _M0TPB13StringBuilder* _M0L7_2aselfS456 =
    (struct _M0TPB13StringBuilder*)_M0L11_2aobj__ptrS458;
  _M0IPB13StringBuilderPB6Logger11write__view(_M0L7_2aselfS456, _M0L8_2aparamS457);
  return 0;
}

int32_t _M0IP016_24default__implPB6Logger72write__substring_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLoggerGRPB13StringBuilderE(
  void* _M0L11_2aobj__ptrS455,
  moonbit_string_t _M0L8_2aparamS452,
  int32_t _M0L8_2aparamS453,
  int32_t _M0L8_2aparamS454
) {
  struct _M0TPB13StringBuilder* _M0L7_2aselfS451 =
    (struct _M0TPB13StringBuilder*)_M0L11_2aobj__ptrS455;
  _M0IP016_24default__implPB6Logger16write__substringGRPB13StringBuilderE(_M0L7_2aselfS451, _M0L8_2aparamS452, _M0L8_2aparamS453, _M0L8_2aparamS454);
  return 0;
}

int32_t _M0IPB13StringBuilderPB6Logger69write__string_2edyncall__as___40moonbitlang_2fcore_2fbuiltin_2eLogger(
  void* _M0L11_2aobj__ptrS450,
  moonbit_string_t _M0L8_2aparamS449
) {
  struct _M0TPB13StringBuilder* _M0L7_2aselfS448 =
    (struct _M0TPB13StringBuilder*)_M0L11_2aobj__ptrS450;
  _M0IPB13StringBuilderPB6Logger13write__string(_M0L7_2aselfS448, _M0L8_2aparamS449);
  return 0;
}

void moonbit_init() {
  moonbit_layout_table = moonbit_layout_table_data;
}

int main(int argc, char** argv) {
  struct _M0TWWuEuWRPC15error5ErrorEuEOuQRPC15error5Error** _M0L6_2atmpS472;
  struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE* _M0L12async__testsS438;
  struct _M0TPB5ArrayGUsiEE* _M0L7_2abindS439;
  int32_t _M0L7_2abindS440;
  int32_t _M0L2__S441;
  moonbit_runtime_init(argc, argv);
  moonbit_init();
  _M0L6_2atmpS472
  = (struct _M0TWWuEuWRPC15error5ErrorEuEOuQRPC15error5Error**)moonbit_empty_ref_array;
  _M0L12async__testsS438
  = (struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE*)moonbit_malloc(sizeof(struct _M0TPB5ArrayGVWEuQRPC15error5ErrorE));
  Moonbit_object_header(_M0L12async__testsS438)->meta
  = Moonbit_make_regular_object_header(MOONBIT_REGULAR_LAYOUT_CLASS_INDEXED, 33, 0);
  _M0L12async__testsS438->$0 = _M0L6_2atmpS472;
  _M0L12async__testsS438->$1 = 0;
  #line 447 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0L7_2abindS439
  = _M0FP27walkzzz11mcp__server52moonbit__test__driver__internal__native__parse__args();
  _M0L7_2abindS440 = _M0L7_2abindS439->$1;
  _M0L2__S441 = 0;
  while (1) {
    if (_M0L2__S441 < _M0L7_2abindS440) {
      struct _M0TUsiE** _M0L3bufS471 = _M0L7_2abindS439->$0;
      struct _M0TUsiE* _M0L3argS442 =
        (struct _M0TUsiE*)_M0L3bufS471[_M0L2__S441];
      moonbit_string_t _M0L6_2atmpS468 = _M0L3argS442->$0;
      int32_t _M0L6_2atmpS469 = _M0L3argS442->$1;
      int32_t _M0L6_2atmpS470;
      moonbit_incref(_M0L6_2atmpS468);
      #line 448 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
      _M0FP27walkzzz11mcp__server44moonbit__test__driver__internal__do__execute(_M0L12async__testsS438, _M0L6_2atmpS468, _M0L6_2atmpS469);
      moonbit_decref(_M0L6_2atmpS468);
      _M0L6_2atmpS470 = _M0L2__S441 + 1;
      _M0L2__S441 = _M0L6_2atmpS470;
      continue;
    } else {
      moonbit_decref(_M0L7_2abindS439);
    }
    break;
  }
  #line 450 "D:\\CodeWorkspace\\moonbit_learning\\mcp_server\\__generated_driver_for_whitebox_test.mbt"
  _M0IP016_24default__implP27walkzzz11mcp__server28MoonBit__Async__Test__Driver17run__async__testsGRP27walkzzz11mcp__server34MoonBit__Async__Test__Driver__ImplE(_M0L12async__testsS438);
  moonbit_decref(_M0L12async__testsS438);
  return 0;
}