# cmd/main

MCP 服务器入口包，实现 stdio 传输层和 JSON-RPC 2.0 协议处理。

## 文件

| 文件 | 说明 |
|------|------|
| `main.mbt` | FFI read/write + JSON-RPC 消息处理 + MCP 工具分发 |
| `moon.pkg` | 包配置（executable，import walkzzz/mcp_server + json + utf8） |

## 函数概览

| 函数 | 说明 |
|------|------|
| `main` | 程序入口，调用 `serve()` |
| `serve` | 主循环：从 stdin 逐块读取并处理请求 |
| `drain_messages` | 按换行符分割累积输入为独立消息 |
| `handle_line` | 处理一行完整 JSON-RPC 请求 |
| `handle_message` | JSON-RPC 方法分发 |
| `call_tool` | MCP 工具分发（add_expense/list_expenses/stats） |
| `tool_ok`/`tool_error` | 构造工具成功/失败结果 |
| `tools_list` | tools/list 响应（工具元数据） |
| `tool_meta_add`/`tool_meta_list`/`tool_meta_stats` | 各工具的 JSON Schema 元数据 |

## 运行

```bash
moon -C mcp_server run cmd/main
```

服务器从 stdin 读取 JSON-RPC 请求（每行一条），向 stdout 输出响应。
