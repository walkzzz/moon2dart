# MoonBit 快速入门教学工程

> 面向零基础学习者的 MoonBit 语言教学 workspace，按主题拆分为 5 个独立模块，
> 由 `moon.work` 统一管理。每个模块聚焦一类核心概念，可独立运行、测试与阅读。

## 快速开始（5 分钟上手）

### 1. 安装 MoonBit 工具链

访问官方安装指引 <https://docs.moonbitlang.com/> ，或使用一键脚本：

```bash
# macOS / Linux
curl -fsSL https://cli.moonbitlang.com/install.sh | bash

# Windows (PowerShell)
irm https://cli.moonbitlang.com/install.ps1 | iex
```

安装完成后验证：

```bash
moon version
```

### 2. 克隆并进入工程

```bash
git clone <repo-url> moonbit_learning
cd moonbit_learning
```

### 3. 一键体验全部示例

```bash
moon run cmd/main           # 运行 basics 演示（需 -C basics 指定模块）
moon test                   # 运行 workspace 内全部 154 个测试
moon check                  # 类型检查全部模块
```

> **提示**：`moon` 命令在 workspace 根目录会自动发现所有成员模块。
> 若要针对单个模块操作，使用 `-C <模块路径>`，例如 `moon -C basics test`。

## 工程结构

```
moonbit_learning
├── moon.work                        # workspace 清单，列出全部成员模块
├── README.md                        # 本文件：工程总览与快速开始
├── AGENTS.md                        # workspace 级开发约定
├── docs/                            # 教学文档体系
│   ├── learning_path.md             # 零基础学习路径（推荐阅读顺序）
│   ├── features.md                  # 已覆盖语言特性清单
│   ├── api_reference.md             # 公开 API 索引
│   ├── examples.md                  # 示例索引与预期输出
│   ├── changelog.md                 # 版本变更日志
│   ├── roadmap.md                   # 教学内容路线图
│   └── faq.md                       # 常见问题与错题本
├── basics/                          # 模块 1：基础语法
├── error/                           # 模块 2：错误处理
├── examine/                         # 模块 3：库包 + 可执行包协作小例
├── method_and_trait/                # 模块 4：方法、trait 与运算符重载
└── advanced_basics/                 # 模块 5：基础进阶（Byte/Ref/Json/切片/defer/管道）
```

## 五大教学模块

| 模块 | 包名 | 主题 | 核心知识点 | 入口命令 |
|------|------|------|-----------|---------|
| `basics` | `walkzzz/basics` | 基础语法 | Unit、数字字面量、字符串、元组、Option/Result、数组、Map、函数、闭包、标签参数、if/match/guard、循环、迭代器、fold | `moon -C basics run cmd/main` |
| `error` | `walkzzz/error` | 错误处理 | suberror、raise、try/catch/noraise、Result 互转、错误传播、泛型错误、callsite | `moon -C error run cmd/main` |
| `examine` | `walkzzz/examine` | 库包与可执行包协作 | pub(all) 结构体、enum、Eq trait 实现、迭代器 filter/count、高阶函数参数 | `moon -C examine run cmd/main` |
| `method_and_trait` | `walkzzz/method_and_trait` | 方法与 trait | 关联函数、trait 定义与实现、trait 继承、默认方法、运算符重载、#alias/#as_free_fn、OpGet/OpSet/OpView、extend | `moon -C method_and_trait run cmd/main` |
| `advanced_basics` | `walkzzz/advanced_basics` | 基础进阶 | Byte/Bytes、Ref[T]、Json、ArrayView/MutArrayView、defer、部分应用、管道 `\|>`、is 表达式、重载字面量 | `moon -C advanced_basics run cmd/main` |

## 推荐学习路径

零基础学习者请按以下顺序阅读，详见 [docs/learning_path.md](docs/learning_path.md)：

1. **环境准备** → 安装工具链，运行第一个 `moon run`
2. **basics** → 掌握值与类型、控制流、集合、函数
3. **error** → 理解 MoonBit 的代数错误处理
4. **examine** → 理解包间依赖与库设计
5. **method_and_trait** → 理解抽象与多态
6. **advanced_basics** → 掌握 Byte/Ref/Json/切片/defer/管道/is 表达式

### 进阶路线（规划中）

基于 [MoonBit 官方文档](https://docs.moonbitlang.cn/language/index.html) 全面规划，详见 [docs/roadmap.md](docs/roadmap.md)：

7. **custom_types** → 结构体/枚举/泛型/位串模式
8. **derive_traits** → derive(Eq/Compare/Debug/Default/Hash/Json)
9. **ffi_demo** → C/JS/Wasm FFI 绑定
10. **testing_demo** → 属性测试/基准测试/覆盖率
11. **attributes_demo** → 属性注解/词法约定
12. **async_demo** → 异步编程（实验性）
13. **verification_demo** → 形式化验证

## 常用命令速查

```bash
# —— workspace 级（在根目录执行）——
moon check                  # 全部模块类型检查
moon test                   # 全部模块测试
moon fmt                    # 全部模块格式化
moon info                   # 生成/更新 .mbti 接口文件
moon doc                    # 生成 HTML 文档到 _build/doc/

# —— 单模块级 ——
moon -C basics run cmd/main # 运行 basics 的演示程序
moon -C basics test         # 仅运行 basics 的测试
moon -C basics check        # 仅检查 basics

# —— workspace 维护 ——
moon work use <path>        # 添加新成员模块
moon work sync              # 同步依赖版本
```

## 文档注释约定

本工程遵循 MoonBit 官方[注释与文档](https://docs.moonbitlang.cn/language/docs.html)规范，采用三级注释体系：

| 级别 | 语法 | 用途 | 位置 |
|------|------|------|------|
| 包/模块级 | `README.md` / `README.mbt.md` | 模块概览、结构、用法 | 每个包目录 |
| 类型/函数级 | `///` + `///|` | 公开 API 的功能、参数、返回值、示例 | 源码中每个 `pub` 项 |
| 行内级 | `//` | 实现细节、为什么这么做 | 源码任意位置 |

公开 API 的文档注释内嵌 ` ```mbt check ` 文档测试，由 `moon test` 自动执行。

## 统计

- 成员模块：5
- 公开 API：69 函数（详见 [docs/api_reference.md](docs/api_reference.md)）
- 测试用例：154（全部通过）
- 教学主题：5 大类 / 70+ 子主题

## 许可证

Apache-2.0
