# walkzzz/examine — 库与可执行包协作教学模块

## 模块职责

演示 MoonBit 中"库包 + 可执行包"的协作模式，提供学生成绩判定与统计的库函数。

## 项目结构

```
examine
├── examine.mbt              # 库包：Student 结构体 + ExamResult 枚举 + 成绩判定/统计函数
├── examine_test.mbt         # 黑盒测试：通过 @examine 访问公开 API
├── examine_wbtest.mbt       # 白盒测试：直接调用包内函数
├── moon.mod                 # 模块元数据
├── moon.pkg                 # 根包配置（库包）
└── cmd/main                 # 演示程序（可执行包）
    ├── main.mbt                # 入口：演示库函数调用
    └── moon.pkg                # 包配置（executable，import "walkzzz/examine"）
```

## 公开 API

| 类型/函数 | 签名 | 说明 |
|-----------|------|------|
| `Student` | `struct { id : String, score : Double }` | 学生结构体（pub(all)） |
| `ExamResult` | `enum { Pass, Fail }` | 考试结果（pub(all), derive(Debug)） |
| `is_qualified` | `(Student, Double) -> ExamResult` | 判定是否达到分数线 |
| `count_qualified_students` | `(Array[Student], (Student)->ExamResult) -> Int` | 统计及格人数 |

## 测试约定

- **黑盒测试**（`examine_test.mbt`）：通过 `@examine.类型/函数` 访问公开 API，验证对外行为
- **白盒测试**（`examine_wbtest.mbt`）：直接调用包内函数，验证内部逻辑与边界条件
- **文档测试**（` ```mbt check `）：每个 `pub fn` / `pub struct` / `pub enum` 附带内嵌文档测试

## 常用命令

```bash
moon -C examine check          # 类型检查
moon -C examine test           # 运行全部测试
moon -C examine run cmd/main   # 运行演示程序
moon -C examine info           # 生成 .mbti 接口文件
moon -C examine fmt            # 格式化
```

## 编码约定

- `///|` 分隔顶层代码块
- `///` 为 `pub` 项编写文档注释，附带 ` ```mbt check ` 文档测试
- `//` 为行内注释
- `pub(all)` 使结构体字段与枚举变体跨包可见
- 自定义 `Eq` 实现用 `pub impl` 使跨包可用
