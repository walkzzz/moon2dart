# cmd/main — 库包协作演示

本包演示可执行包如何引用同 workspace 的库包 `walkzzz/examine` 并调用其公开 API。
运行方式：`moon -C examine run cmd/main`。

## 文件清单

| 文件 | 主题 |
|------|------|
| `main.mbt` | 入口：构造学生数组，调用 `@examine.count_qualified_students` 统计及格人数 |
| `moon.pkg` | 包配置，声明 `import "walkzzz/examine" @examine` |

## 依赖配置

```json
// moon.pkg
import {
  "walkzzz/examine" @examine,
}
```

`@examine` 是导入别名，通过它访问库包的公开类型与函数：
- `@examine.Student::{ id, score }` — 构造学生
- `@examine.is_qualified(student, criteria)` — 判定及格
- `@examine.count_qualified_students(students, fn)` — 统计及格人数

## 预期输出

```
及格人数:2
```

## 学习要点

- 库包（根包）与可执行包（`cmd/main`）的协作模式
- `moon.pkg` 中 `import` 声明与别名
- `pub(all)` 可见性使字段跨包可访问
