# walkzzz/examine

MoonBit 库包与可执行包协作学习项目，演示学生考试及格判定。

## 项目结构

```
examine
├── examine.mbt              # 库包：公开 API（Student / ExamResult / is_qualified / count_qualified_students）
├── examine_test.mbt         # 黑盒测试（通过 @examine 访问公开 API）
├── examine_wbtest.mbt       # 白盒测试（直接调用包内函数）
├── moon.mod                 # 模块元数据
├── moon.pkg                 # 根包配置（库包）
├── README.mbt.md            # 模块级文档（moon 工具链收录）
├── README.md                # 本文件
└── cmd/main                 # 可执行包，引用库包演示
    ├── main.mbt                 # 入口：统计及格人数
    ├── moon.pkg                 # 包配置（import "walkzzz/examine"）
    └── README.md                # 包级文档
```

## 公开 API

| 名称 | 类型 | 说明 |
|------|------|------|
| `Student` | `pub(all) struct` | 含 `id : String`、`score : Double` |
| `ExamResult` | `pub(all) enum` | `Pass` / `Fail`，derive(Debug)，实现 Eq |
| `is_qualified` | `pub fn` | 判定单个学生是否及格 |
| `count_qualified_students` | `pub fn` | 统计及格人数（接受高阶判定函数） |

## 常用命令

| 命令 | 作用 |
|------|------|
| `moon -C examine run cmd/main` | 运行演示 |
| `moon -C examine test` | 运行测试（白盒 + 黑盒 + 文档测试） |
| `moon -C examine check` | 类型检查 |
| `moon -C examine info` | 生成 .mbti 接口文件 |

## 学习目标

- 设计库包的公开 API 与 `pub(all)` 可见性
- 在可执行包中 `import` 库包并调用其 API
- 编写白盒（`_wbtest.mbt`）与黑盒（`_test.mbt`）测试
- 使用 `derive(Debug)` 与手动 `impl Eq`
- 使用迭代器 `filter().count()` 与高阶函数参数
