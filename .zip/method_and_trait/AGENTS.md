# walkzzz/method_and_trait — 方法与 trait 教学模块

## 模块职责

演示 MoonBit 方法定义、trait 定义与实现、运算符重载，同时提供基于 `Shape` trait 的几何工具库函数。

## 项目结构

```
method_and_trait
├── method_and_trait.mbt              # 库包：Shape trait + Circle/Rectangle 实现 + 面积/周长工具
├── method_and_trait_test.mbt         # 黑盒测试：通过 @method_and_trait 访问公开 API
├── method_and_trait_wbtest.mbt       # 白盒测试：直接调用包内函数（含私有 _is_valid_radius）
├── moon.mod                          # 模块元数据
├── moon.pkg                          # 根包配置（库包）
└── cmd/main                          # 演示程序（可执行包）
    ├── main.mbt                         # 入口：综合演示方法/trait/运算符重载
    ├── define_method.mbt                # 泛型链表与关联函数
    ├── alias.mbt                        # 方法别名与自由函数
    ├── reload_method.mbt                # 为内置类型扩展方法
    ├── operator_overload.mbt            # 运算符重载与 OpGet/OpSet/OpView
    ├── trait.mbt                        # trait 继承/默认方法/extend/动态多态
    └── moon.pkg                         # 包配置（executable，import "walkzzz/method_and_trait"）
```

## 公开 API

| 类型/函数 | 签名 | 说明 |
|-----------|------|------|
| `Shape` | `trait { area(Self)->Double, perimeter(Self)->Double }` | 形状 trait |
| `Circle` | `struct { radius : Double }` | 圆形（pub(all)） |
| `Rectangle` | `struct { width : Double, height : Double }` | 矩形（pub(all)） |
| `total_area` | `[S:Shape](Array[S])->Double` | 形状数组总面积 |
| `total_perimeter` | `[S:Shape](Array[S])->Double` | 形状数组总周长 |
| `max_area` | `[S:Shape](Array[S])->Double` | 形状数组最大面积 |

## 测试约定

- **黑盒测试**（`method_and_trait_test.mbt`）：通过 `@method_and_trait.类型/函数` 访问公开 API
- **白盒测试**（`method_and_trait_wbtest.mbt`）：直接调用包内函数，含 `Shape::area`/`Shape::perimeter` 直接调用与私有 `_is_valid_radius`
- **文档测试**（` ```mbt check `）：每个 `pub fn` / `pub struct` / `pub trait` 附带内嵌文档测试

## 常用命令

```bash
moon -C method_and_trait check          # 类型检查
moon -C method_and_trait test            # 运行全部测试
moon -C method_and_trait run cmd/main    # 运行演示程序
moon -C method_and_trait info            # 生成 .mbti 接口文件
moon -C method_and_trait fmt             # 格式化
```

## 编码约定

- `///|` 分隔顶层代码块
- `///` 为 `pub` 项编写文档注释，附带 ` ```mbt check ` 文档测试
- `//` 为行内注释
- `pub(open) trait` 使 trait 可被外部包扩展
- `pub(all) struct` 使字段跨包可见
- `pub impl` 使 trait 实现跨包可见
- 私有函数以 `_` 前缀标记（如 `_is_valid_radius`）
