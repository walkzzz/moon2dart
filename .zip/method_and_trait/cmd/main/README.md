# cmd/main — 方法、trait 与运算符重载演示

本包演示 MoonBit 的方法定义、trait 系统、运算符重载与方法别名。
运行方式：`moon -C method_and_trait run cmd/main`。

## 文件清单

| 文件 | 主题 | 关键概念 |
|------|------|---------|
| `define_method.mbt` | 关联函数与泛型方法 | `List[T]`、`List::length`、`T : Add`/`T : Mul` trait 约束 |
| `reload_method.mbt` | 方法重载与工厂函数 | `Wallet::default`、`Int::factorial`/`Int::sum` 为内置类型扩展 |
| `operator_overload.mbt` | 运算符重载 | `Add`/`Sub`/`Neg`/`Eq` trait 实现，`Student` 的 `+`/`-`/`==`/`-` |
| `trait.mbt` | trait 定义与实现 | `pub(open) trait`、继承 `Object : Position + Draw`、默认方法 `= _`、`extend`、动态多态 `Array[&Animal]` |
| `alias.mbt` | 方法别名与运算符别名 | `#alias`、`#as_free_fn`、`OpGet`/`OpSet`/`OpView`（`_[_]`/`_[_]=_`/`_[_:_]`） |
| `main.mbt` | 综合演示入口 | 按顺序演示上述全部特性 |

## define_method.mbt 详解

- `pub(all) enum List[T]`：泛型链表 `Nil` / `Cons(T, List[T])`
- `List::length`：无 trait 约束，任意 `T` 可用
- `List::sum`：约束 `T : Add`，需要 `+` 运算
- `List::product`：约束 `T : Mul`，需要 `*` 运算

## reload_method.mbt 详解

- `Wallet::default` / `Phone::default`：关联函数作为工厂方法
- `Int::factorial` / `Int::sum`：为内置类型 `Int` 扩展方法（非 pub，因内置类型不可定义 pub 方法）

## operator_overload.mbt 详解

| 运算符 | trait | 示例 |
|--------|-------|------|
| `+` | `Add` | `s1 + s2` 各科相加 |
| `-` | `Sub` | `s1 - s2` 各科相减 |
| `==` | `Eq` | `s1 == s2` 按总分判断 |
| 一元 `-` | `Neg` | `-s1` 各科取负 |

## trait.mbt 详解

### trait 定义

```moonbit
pub(open) trait Position { fn pos(Self) -> (Int, Int) }
pub(open) trait Draw { fn draw(Self, Int, Int) -> Unit }
pub(open) trait Object : Position + Draw {}  // 继承
pub(open) trait J { fn f(Self) -> Unit; fn f_twice(Self) -> Unit = _ }  // 默认方法
pub(open) trait Animal { fn speak(Self) -> String }
```

### 关键特性

- `pub(open)`：trait 可被外部包扩展
- `Object : Position + Draw`：trait 继承，需同时实现父 trait
- `fn f_twice(Self) -> Unit = _`：默认方法，实现者可只提供 `f`
- `extend MyCustomType with Show::{to_string}`：从 `output` 自动派生 `to_string`
- `Array[&Animal]`：动态多态，收集不同类型实例

## alias.mbt 详解

| 注解 | 用途 | 示例 |
|------|------|------|
| `#alias(total)` | 方法别名 | `total(s)` 等价于 `Student::score_sum(s)` |
| `#alias(name, visibility="priv")` | 私有别名 | 仅本包可见 |
| `#as_free_fn(name, visibility="pub")` | 自由函数 | `total(s)` 无需 `Student::` 前缀 |
| `#alias("_[_]")` | OpGet | `coord["x"]` 下标读取 |
| `#alias("_[_]=_")` | OpSet | `coord["x"] = 23` 下标赋值 |
| `#alias("_[_:_]")` | OpView | `data[2:5]` 切片 |

## 学习目标

- 定义关联函数与泛型方法
- 使用 trait 约束（`T : Add`）与 trait 继承（`A : B + C`）
- 实现运算符重载（`Add`/`Sub`/`Neg`/`Eq`）
- 使用 `#alias` / `#as_free_fn` 导出方法别名与自由函数
- 使用 `extend` 复用 trait 实现
- 理解动态多态 `Array[&Trait]`
