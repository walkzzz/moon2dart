# walkzzz/method_and_trait

MoonBit 方法、trait 与运算符重载学习项目。

## 项目结构

```
method_and_trait
├── method_and_trait.mbt              # 根包（占位）
├── method_and_trait_test.mbt         # 黑盒测试（占位）
├── method_and_trait_wbtest.mbt       # 白盒测试（占位）
├── moon.mod                          # 模块元数据
├── moon.pkg                          # 根包配置
├── README.mbt.md                     # 本文件
├── README.md                         # 包级文档（GitHub 风格，供 moon doc 收录）
└── cmd/main                          # 演示程序（可执行包）
    ├── main.mbt                          # 入口：综合演示
    ├── define_method.mbt                 # 关联函数与泛型方法（List）
    ├── reload_method.mbt                 # 方法重载与工厂函数（Wallet/Phone/Int）
    ├── operator_overload.mbt             # 运算符重载（Student 的 +/−/==/Neg）
    ├── trait.mbt                         # trait 定义/继承/默认方法/extend/动态多态
    ├── alias.mbt                         # #alias/#as_free_fn/OpGet/OpSet/OpView
    ├── moon.pkg                          # 包配置（executable）
    └── README.md                         # 包级文档
```

## 常用命令

| 命令 | 作用 |
|------|------|
| `moon -C method_and_trait run cmd/main` | 运行演示 |
| `moon -C method_and_trait test` | 运行测试 |
| `moon -C method_and_trait check` | 类型检查 |
| `moon -C method_and_trait fmt` | 格式化 |

## 公开 API 概览

- **类型**：`List[T]`、`Point`、`Coord`、`Student`、`Wallet`、`Phone`、`Data`、`DataView`、`Duck`、`Fox`、`MyCustomType`、`T`
- **函数**：`draw_object`、`use_extend`、`direct_call`、`total`、`is_pass`、`contains`、`List::length`/`sum`/`product`、`Student::new`/`score_sum`
- **trait**：`I`、`Position`、`Draw`、`Object`、`J`、`Animal`

## 文档注释约定

- `///|` 分隔顶层代码块
- `///` 为 `pub` 项编写文档注释，附带 ` ```mbt check ` 文档测试
- `//` 为行内注释

## 学习目标

- 定义关联函数与泛型方法
- 使用 trait 约束与继承
- 实现运算符重载
- 使用 `#alias` / `#as_free_fn` / `extend`
- 理解动态多态 `Array[&Trait]`
