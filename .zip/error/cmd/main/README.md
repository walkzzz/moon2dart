# cmd/main — MoonBit 错误处理演示

本包演示 MoonBit 的代数错误处理体系，含 `suberror` 定义、`raise`/`try catch`、
`Result` 互转与泛型错误传播。运行方式：`moon -C error run cmd/main`。

## 文件清单

| 文件 | 主题 | 关键概念 |
|------|------|---------|
| `error_learn.mbt` | 错误处理核心 | `suberror`、`raise`、`Failure`、`#callsite`、`noraise`/`raise?`、`try!`、`guard! is` |
| `main.mbt` | 综合演示入口 | `try/catch/noraise` 三段式、表达式级 `catch`、绑定级 `catch` |

## error_learn.mbt 详解

### suberror 定义

| 错误类型 | 变体 | 说明 |
|---------|------|------|
| `E1` | `E1(Int)` | 包装 Int |
| `E2` | `E2` | 无参标记 |
| `E3` | `A` / `B(Int, x~:String)` / `C(a~:String, Char, b~:Bool)` | 演示带标签字段 |
| `CustomError` | `CustomError(UInt)` | 包装 UInt |
| `DivError` | `DivError(String)` derive(Debug) | 除零错误 |

### 错误处理三态

| 标注 | 含义 | 示例函数 |
|------|------|---------|
| `raise E` | 可能抛出具体错误 `E` | `div` raise DivError |
| `raise?` | 多态错误，由调用方决定 | `map_with_polymorphism` |
| `noraise` | 保证不抛错 | `add`、`map_without_error` |

### 关键运算符

| 运算符 | 用途 | 示例 |
|--------|------|------|
| `raise e` | 抛出错误 | `raise DivError("...")` |
| `try ... catch ... noraise` | 三段式处理 | 见 `main.mbt` |
| `try! expr` | 错误传播（等价于 `let x = expr catch { e => raise e }`） | `remainder` |
| `guard! p is Pattern` | 模式守卫，不匹配时 panic | 见测试块 |
| `expr catch { e => fallback }` | 表达式级捕获 | `div(42,0) catch { _ => 0 }` |

### #callsite

```moonbit
#callsite(autofill(loc))
pub fn[T] fail(msg : String, loc~ : SourceLoc) -> T raise Failure
```

`#callsite(autofill(loc))` 自动注入调用处源码位置，便于错误定位。

## main.mbt 详解

四种错误处理模式：

1. **三段式**：`try expr catch { e => ... } noraise { v => ... }`
2. **表达式级**：`println(div(42, 0)) catch { _ => println("Error") }`
3. **绑定级**：`let a = div(42, 0) catch { _ => 0 }`
4. **多错误捕获**：`f13()` 内部 `try { f11(); f12() } catch { E1(_) => ...; E2 => ...; e => raise e }`

## 依赖

```json
// moon.pkg
import {
  "moonbitlang/core/test",   // 提供 @test.assert_eq
}
```

## 学习目标

完成本模块后，学习者应能：

- 定义自定义 `suberror` 类型并用 `raise` 抛出
- 用 `try/catch/noraise` 三段式处理错误
- 理解 `raise` / `raise?` / `noraise` 三种错误传播策略
- 使用 `try!` 简化错误传播
- 在 `Result` 与 `raise` 之间互转
