# walkzzz/error

MoonBit 错误处理学习项目，演示代数错误处理体系。

## 项目结构

```
error
├── error.mbt              # 根包（占位）
├── error_test.mbt         # 黑盒测试（占位）
├── error_wbtest.mbt       # 白盒测试（占位）
├── moon.mod               # 模块元数据
├── moon.pkg               # 根包配置
├── README.mbt.md          # 本文件
├── README.md              # 包级文档（GitHub 风格，供 moon doc 收录）
└── cmd/main               # 错误处理演示（可执行包）
    ├── main.mbt               # 入口：四种错误处理模式综合演示
    ├── error_learn.mbt        # suberror/raise/try-catch/Result 互转/泛型错误
    ├── moon.pkg               # 包配置（executable，依赖 core/test）
    └── README.md              # 包级文档（详见 cmd/main/README.md）
```

## 常用命令

| 命令 | 作用 |
|------|------|
| `moon -C error run cmd/main` | 运行错误处理演示 |
| `moon -C error test` | 运行测试 |
| `moon -C error check` | 类型检查 |
| `moon -C error fmt` | 格式化 |

## 文档注释约定

- `///|` 分隔顶层代码块
- `///` 为 `pub` 项编写文档注释，附带 ` ```mbt check ` 文档测试
- `//` 为行内注释

## 学习目标

- 定义自定义 `suberror` 并用 `raise` 抛出
- 用 `try/catch/noraise` 处理错误
- 理解 `raise` / `raise?` / `noraise` 三态
- 使用 `try!` 传播错误
- `Result` 与 `raise` 互转
