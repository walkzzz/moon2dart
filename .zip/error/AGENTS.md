# walkzzz/error — 错误处理教学模块

## 模块职责

演示 MoonBit 错误处理机制（suberror/raise/try/catch/noraise/try!/raise?），同时提供基于 `Result` 的安全数学运算与解析工具库函数。

## 项目结构

```
error
├── error.mbt              # 库包：安全数学运算 + Result 工具 + 解析函数
├── error_test.mbt         # 黑盒测试：通过 @error 访问公开 API
├── error_wbtest.mbt       # 白盒测试：直接调用包内函数（含私有 _validate_non_negative）
├── moon.mod                # 模块元数据
├── moon.pkg                # 根包配置（库包）
└── cmd/main                # 演示程序（可执行包）
    ├── main.mbt                # 入口：演示 try/catch/noraise 四种模式
    ├── error_learn.mbt         # 错误处理教学演示（suberror/raise/try!/raise?）
    └── moon.pkg                # 包配置（executable，import "walkzzz/error"）
```

## 公开 API

| 函数 | 签名 | 说明 |
|------|------|------|
| `safe_div` | `(Int, Int) -> Result[Int, MathError]` | 安全除法 |
| `safe_mod` | `(Int, Int) -> Result[int, MathError]` | 安全求余 |
| `safe_isqrt` | `(Int) -> Result[int, MathError]` | 安全整数平方根 |
| `map_ok` | `(Result[T,E], (T)->U) -> Result[U,E]` | 对 Ok 分支映射 |
| `map_err` | `(Result[T,E], (E)->F) -> Result[T,F]` | 对 Err 分支映射 |
| `result_to_option` | `(Result[T,E]) -> Option[T]` | Result 转 Option |
| `option_to_result` | `(Option[T], E) -> Result[T,E]` | Option 转 Result |
| `parse_digit` | `(Char) -> Result[int, ParseError]` | 解析数字字符 |
| `parse_int_safe` | `(String) -> Result[int, ParseError]` | 简易整数解析 |

## 错误类型

| 类型 | 变体 | 说明 |
|------|------|------|
| `MathError` | `DivByZero` / `NegativeSqrt(Int)` | 数学运算错误 |
| `ParseError` | `EmptyInput` / `InvalidChar(Char)` | 解析错误 |

## 测试约定

- **黑盒测试**（`error_test.mbt`）：通过 `@error.函数名` 访问公开 API，验证对外行为
- **白盒测试**（`error_wbtest.mbt`）：直接调用包内函数（含私有 `_validate_non_negative`），验证内部逻辑
- **文档测试**（` ```mbt check `）：每个 `pub fn` 附带内嵌文档测试

## 常用命令

```bash
moon -C error check          # 类型检查
moon -C error test            # 运行全部测试
moon -C error run cmd/main    # 运行演示程序
moon -C error info            # 生成 .mbti 接口文件
moon -C error fmt             # 格式化
```

## 编码约定

- `///|` 分隔顶层代码块
- `///` 为 `pub` 项编写文档注释，附带 ` ```mbt check ` 文档测试
- `//` 为行内注释
- 私有函数以 `_` 前缀标记（如 `_validate_non_negative`）
- `suberror` 类型派生 `Debug, Show, Eq`
