# 公开 API 索引

> 本文档汇总 workspace 内全部成员模块的公开 API，由 `moon info` 生成的 `.mbti` 接口文件整理。
> 标注格式：`签名` — 所属模块/包。

## 统计

| 模块 | 公开函数 | 公开类型 | 公开 trait |
|------|---------|---------|-----------|
| `basics`（库包） | 6 (`gcd`/`lcm`/`is_prime`/`reverse_string`/`sum_array`/`average`) | 0 | 0 |
| `basics/cmd/main` | 24 | 1 (`DeclaredCounter`) | 0 |
| `error`（库包） | 9 (`safe_div`/`safe_mod`/`safe_isqrt`/`map_ok`/`map_err`/`result_to_option`/`option_to_result`/`parse_digit`/`parse_int_safe`) | 2 (`MathError`/`ParseError`) | 0 |
| `error/cmd/main` | 7 (`fail`/`div`/`unwrap_or_error`/`map_without_error`/`map_with_error`/`div_reraise`/`remainder`) | 5 (`CustomError`/`DivError`/`E1`/`E2`/`E3`) | 0 |
| `examine`（库包） | 2 (`is_qualified`/`count_qualified_students`) | 2 (`Student`/`ExamResult`) | 0 |
| `examine/cmd/main` | 0 | 0 | 0 |
| `method_and_trait`（库包） | 3 (`total_area`/`total_perimeter`/`max_area`) | 2 (`Circle`/`Rectangle`) | 1 (`Shape`) |
| `method_and_trait/cmd/main` | 10 (`draw_object`/`use_extend`/`direct_call`/`contains`/`Student::new`/`Wallet::default`/`Phone::default`/`List::length`/`List::sum`/`List::product`) | 12 | 6 |
| **合计** | **61** | **24** | **7** |

---

## basics / cmd / main

> 演示包，全部函数返回 `Unit`，仅产生打印副作用。

```moonbit
pub fn arrays() -> Unit
pub fn maps() -> Unit
pub fn numbers() -> Unit
pub fn option_result() -> Unit
pub fn print_hello() -> Unit
pub fn strings() -> Unit
pub fn tuples() -> Unit
```

类型：
```moonbit
type DeclaredCounter   // 包装 Int 的结构体，演示 declare 前向声明
```

---

## error / cmd / main

> 错误处理演示包。

### 公开函数

```moonbit
#callsite(autofill(loc))
pub fn[T] fail(msg : String, loc~ : SourceLoc) -> T raise Failure
```

`fail` 是一个泛型失败函数：抛出 `Failure`，携带调用位置 `loc` 与消息 `msg`。
因返回类型为任意 `T`，可在任何需要值的上下文中使用（类似 `panic`）。

### 错误类型

```moonbit
type CustomError    // suberror，包装 UInt
type DivError derive(Debug)   // 除零错误，包装 String
type E1             // suberror，包装 Int
type E2             // suberror，无参
type E3             // suberror，含 A / B / C 三个变体
```

---

## examine（库包）

> 演示库包设计：学生考试及格判定。

### 公开函数

```moonbit
pub fn is_qualified(student : Student, criteria : Double) -> ExamResult
pub fn count_qualified_students(
  students : Array[Student],
  is_qualified : (Student) -> ExamResult,
) -> Int
```

- `is_qualified`：判定单个学生是否达到分数线，返回 `Pass` / `Fail`。
- `count_qualified_students`：统计及格人数，接受一个判定高阶函数。

### 公开类型

```moonbit
pub(all) enum ExamResult {
  Pass
  Fail
} derive(Debug)

pub(all) struct Student {
  id : String
  score : Double
}
```

`ExamResult` 实现了 `Eq`（`Pass == Pass`、`Fail == Fail`）。

---

## method_and_trait / cmd / main

> 方法、trait 与运算符重载演示包。

### 公开函数

```moonbit
pub fn direct_call() -> Unit
pub fn[O : Object] draw_object(obj : O) -> Unit
pub fn is_pass(s : Student) -> Bool
pub fn total(s : Student) -> Int
pub fn use_extend() -> Unit
```

- `draw_object`：泛型函数，对任何实现 `Object`（即 `Position + Draw`）的类型调用。
- `total` / `is_pass`：由 `#as_free_fn` 生成的自由函数，等价于 `Student::score_sum` / `Student::check_pass`。

### 公开类型

```moonbit
type Coord          // 可变 x/y 坐标，实现 OpGet/OpSet/Eq
type Data           // 切片演示，实现 OpView
type DataView       // Data 的视图类型
type Duck           // 实现 Animal
type Fox            // 实现 Animal
type List[T]        // 链表枚举 Nil/Cons
type MyCustomType   // 实现 Show（通过 extend）
type Phone          // 含 battery，有 default 关联函数
type Point          // 实现 Position + Draw（即 Object）
type Student        // 含 chinese/math，实现 Add/Sub/Neg/Eq
type T              // 含 x，实现 Add
type Wallet         // 含 money，有 default 关联函数
```

### 公开 trait

```moonbit
pub(open) trait Animal { fn speak(Self) -> String }
pub(open) trait Draw { fn draw(Self, Int, Int) -> Unit }
pub(open) trait I { fn method_(Int) -> Int; fn method_with_label(Int, label~ : Int) -> Int }
pub(open) trait J { fn f(Self) -> Unit; fn f_twice(Self) -> Unit = _ }
pub(open) trait Object : Position + Draw {}
pub(open) trait Position { fn pos(Self) -> (Int, Int) }
```

---

## basics（库包）

> 数学与字符串工具函数。

### 公开函数

```moonbit
pub fn gcd(a : Int, b : Int) -> Int
pub fn lcm(a : Int, b : Int) -> Int
pub fn is_prime(n : Int) -> Bool
pub fn reverse_string(s : String) -> String
pub fn sum_array(arr : Array[Int]) -> Int
pub fn average(arr : Array[Int]) -> Int
```

---

## error（库包）

> 基于 `Result` 的安全运算与解析工具。

### 公开函数

```moonbit
pub fn safe_div(x : Int, y : Int) -> Result[Int, MathError]
pub fn safe_mod(x : Int, y : Int) -> Result[int, MathError]
pub fn safe_isqrt(n : Int) -> Result[int, MathError]
pub fn[T, U, E] map_ok(r : Result[T, E], f : (T) -> U) -> Result[U, E]
pub fn[T, E, F] map_err(r : Result[T, E], f : (E) -> F) -> Result[T, F]
pub fn[T, E] result_to_option(r : Result[T, E]) -> Option[T]
pub fn[T, E] option_to_result(opt : Option[T], err : E) -> Result[T, E]
pub fn parse_digit(c : Char) -> Result[int, ParseError]
pub fn parse_int_safe(s : String) -> Result[int, ParseError]
```

### 错误类型

```moonbit
suberror MathError { DivByZero; NegativeSqrt(Int) } derive(Debug, Eq)
suberror ParseError { EmptyInput; InvalidChar(Char) } derive(Debug, Eq)
```

---

## method_and_trait（库包）

> 基于 `Shape` trait 的几何工具。

### 公开函数

```moonbit
pub fn[S : Shape] total_area(shapes : Array[S]) -> Double
pub fn[S : Shape] total_perimeter(shapes : Array[S]) -> Double
pub fn[S : Shape] max_area(shapes : Array[S]) -> Double
```

### 公开类型

```moonbit
pub(all) struct Circle { radius : Double }
pub(all) struct Rectangle { width : Double; height : Double }
```

### 公开 trait

```moonbit
pub(open) trait Shape { fn area(Self) -> Double; fn perimeter(Self) -> Double }
```

`Circle` 和 `Rectangle` 均实现 `Shape`。

---

## 接口文件位置

各包的机器可读接口由 `moon info` 生成，位于：

| 包 | `.mbti` 路径 |
|----|-------------|
| `basics` 根包 | `basics/pkg.generated.mbti` |
| `basics/cmd/main` | `basics/cmd/main/pkg.generated.mbti` |
| `error` 根包 | `error/pkg.generated.mbti` |
| `error/cmd/main` | `error/cmd/main/pkg.generated.mbti` |
| `examine` 根包 | `examine/pkg.generated.mbti` |
| `examine/cmd/main` | `examine/cmd/main/pkg.generated.mbti` |
| `method_and_trait` 根包 | `method_and_trait/pkg.generated.mbti` |
| `method_and_trait/cmd/main` | `method_and_trait/cmd/main/pkg.generated.mbti` |

> **注意**：`.mbti` 文件由 `moon info` 自动生成，请勿手工编辑。
> 提交前执行 `moon info` 并检查 diff，可判断改动是否影响外部可见接口。
