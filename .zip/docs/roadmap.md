# 教学内容路线图

> 本文档规划教学内容的覆盖进度与后续方向，基于
> [MoonBit 官方语言文档](https://docs.moonbitlang.cn/language/index.html) 制定。
> 进度统计随每次迭代更新。

## 当前进度

| Phase | 主题 | 状态 | 完成度 |
|-------|------|------|--------|
| Phase 1 | 基础语法（basics） | ✅ 已完成 | 100% |
| Phase 2 | 错误处理（error） | ✅ 已完成 | 100% |
| Phase 3 | 库包协作（examine） | ✅ 已完成 | 100% |
| Phase 4 | 方法与 trait（method_and_trait） | ✅ 已完成 | 100% |
| Phase 5 | 文档治理与零基础友好 | ✅ 已完成 | 100% |
| Phase 5.5 | 库包完善与测试覆盖 | ✅ 已完成 | 100% |
| Phase 6 | 基础进阶（advanced_basics） | ✅ 已完成 | 100% |
| Phase 7 | 自定义类型与模式匹配（custom_types） | ⬜ 未开始 | 0% |
| Phase 8 | 派生特征（derive_traits） | ⬜ 未开始 | 0% |
| Phase 9 | FFI 绑定（ffi_demo） | ⬜ 未开始 | 0% |
| Phase 10 | 测试与基准测试（testing_demo） | ⬜ 未开始 | 0% |
| Phase 11 | 属性与注解（attributes_demo） | ⬜ 未开始 | 0% |
| Phase 12 | 异步编程（async_demo） | ⬜ 未开始 | 0% |
| Phase 13 | 形式化验证（verification_demo） | ⬜ 未开始 | 0% |
| Phase 14 | mooncakes 生态与工具链 | ⬜ 未开始 | 0% |

**总体完成度**：7/15 = 47%

---

## 已交付（Phase 1-5.5）

### Phase 1: 基础语法 — `basics` 模块

- ✅ Unit 类型与副作用
- ✅ 数字字面量（Int/Int16/UInt64/BigInt/十六进制/二进制/下划线分组）
- ✅ 字符串（普通/`#|`原始多行/`$|`插值多行）与 Char（`\u{}`/`\uXXXX`）
- ✅ 元组打包与解构
- ✅ Option / Result 与 match 穷尽
- ✅ Array / FixedArray / 切片视图
- ✅ Map 字面量与插入顺序迭代
- ✅ 函数（declare/局部/匿名）、闭包、标签参数、可选参数
- ✅ if/else 表达式、match 模式匹配（范围模式）、guard
- ✅ while/nobreak、C 风格 for、for-in、迭代器链、fold

### Phase 2: 错误处理 — `error` 模块

- ✅ suberror 定义（带参/带标签字段/无参）
- ✅ raise / Failure / #callsite / SourceLoc
- ✅ noraise / raise? 多态错误
- ✅ try / catch / noraise 三段式
- ✅ try! 错误传播
- ✅ guard! ... is 模式守卫
- ✅ Result 与 raise 互转
- ✅ 泛型错误处理（map_ok / map_err）

### Phase 3: 库包协作 — `examine` 模块

- ✅ pub(all) struct / enum
- ✅ derive(Debug)
- ✅ impl Eq 自定义相等
- ✅ 高阶函数参数（(Student) -> ExamResult）
- ✅ 迭代器 filter + count
- ✅ 白盒测试 _wbtest.mbt
- ✅ 可执行包 import 库包

### Phase 4: 方法与 trait — `method_and_trait` 模块

- ✅ 关联函数 Type::method
- ✅ 泛型方法 fn[T] / trait 约束 T : Add
- ✅ trait 定义 / pub(open) / 继承 A : B + C
- ✅ 默认方法 = _
- ✅ extend ... with 复用
- ✅ 动态多态 Array[&Animal]
- ✅ 运算符重载（Add/Sub/Neg/Eq）
- ✅ #alias / #as_free_fn
- ✅ OpGet / OpSet / OpView（_[_] / _[_]=_ / _[_:_]）

### Phase 5: 文档治理 — workspace 级

- ✅ moon.work workspace 配置
- ✅ 根目录 README.md 总览
- ✅ AGENTS.md 开发约定
- ✅ docs/ 教学文档体系（learning_path/features/api_reference/examples/faq/changelog/roadmap）
- ✅ 三级文档注释（包级/模块级/API 级）
- ✅ Warning 治理（0 warning 0 error）
- ✅ .mbti 接口文件生成
- ✅ 工程整洁度优化（v0.2.1）

### Phase 5.5: 库包完善与测试覆盖 — 全模块

- ✅ basics 根包库代码：gcd/lcm/is_prime/reverse_string/sum_array/average
- ✅ error 根包库代码：MathError/ParseError + safe_div/safe_mod/safe_isqrt + Result 工具 + parse_digit/parse_int_safe
- ✅ method_and_trait 根包库代码：Shape trait + Circle/Rectangle + total_area/total_perimeter/max_area
- ✅ 黑盒测试（`_test.mbt`）：全部 4 模块根包
- ✅ 白盒测试（`_wbtest.mbt`）：全部 4 模块根包（含私有函数测试）
- ✅ 模块级 AGENTS.md：4 模块全部定制
- ✅ cmd/main 集成：取消注释 @lib 导入 + 添加库函数演示
- ✅ 测试总数：129（全部通过，0 warning）

---

## 待交付（Phase 6-14）

> 以下计划基于 [MoonBit 官方语言文档](https://docs.moonbitlang.cn/language/index.html) v0.10.12 的完整知识体系制定，
> 确保教学项目覆盖官方文档所有主题。

### Phase 6: 基础进阶 — `advanced_basics` 模块（v0.4.0）

> 对应官方文档：[基础](https://docs.moonbitlang.cn/language/fundamentals.html) 中未覆盖的子主题

**cmd/main 演示文件**：

| 文件 | 主题 | 官方文档对应 |
|------|------|-------------|
| `byte.mbt` | Byte/Bytes 字面量与操作 | 基础 → 字节 |
| `ref.mbt` | Ref[T] 可变引用 | 基础 → Ref |
| `json.mbt` | Json 字面量与模式匹配 | 基础 → Json |
| `array_view.mbt` | ArrayView/MutArrayView 切片 | 基础 → ArrayView |
| `comprehension.mbt` | 列表推导式 | 基础 → 列表推导式 |
| `labelled_loop.mbt` | 带标记 Continue/Break、带标签块 | 基础 → 带标记的 Continue/Break |
| `defer.mbt` | defer/errdefer 表达式 | 基础 → defer 和 errdefer |
| `partial_app.mbt` | 部分应用 `_` | 基础 → 部分应用 |
| `pipeline.mbt` | 管道 `\|>`、级联 `..>` | 基础 → 管道、级联运算符 |
| `is_expr.mbt` | is 表达式与模式测试 | 基础 → is 表达式 |
| `spread.mbt` | 展开运算符 `...` | 基础 → 展开运算符 |
| `overloaded_literal.mbt` | 重载字面量 | 基础 → 重载字面量 |

**根包库代码**（`advanced_basics.mbt`）：
- `byte_reverse` / `bytes_concat` — Byte/Bytes 工具
- `ref_counter` — Ref[T] 计数器工具
- `json_lookup` — Json 查询工具
- `slice_sum` — ArrayView 求和

### Phase 7: 自定义类型与模式匹配 — `custom_types` 模块（v0.5.0）

> 对应官方文档：[基础 → 自定义数据类型](https://docs.moonbitlang.cn/language/fundamentals.html#custom-data-types) + [基础 → 模式匹配](https://docs.moonbitlang.cn/language/fundamentals.html#pattern-matching) + [基础 → 泛型](https://docs.moonbitlang.cn/language/fundamentals.html#generics)

**cmd/main 演示文件**：

| 文件 | 主题 | 官方文档对应 |
|------|------|-------------|
| `struct_advanced.mbt` | 结构体简写/更新语法/自定义构造器 | 基础 → 结构体 |
| `enum_advanced.mbt` | 枚举带标签参数/可变字段/可扩展枚举 | 基础 → 枚举 |
| `tuple_struct.mbt` | 元组结构体 | 基础 → 元组结构体 |
| `type_alias.mbt` | 类型别名 | 基础 → 类型别名 |
| `array_pattern.mbt` | 数组模式匹配 | 基础 → 数组模式 |
| `bitstring_pattern.mbt` | 位串模式匹配 | 基础 → 位串模式 |
| `map_pattern.mbt` | Map 模式匹配 | 基础 → Map 模式 |
| `json_pattern.mbt` | Json 模式匹配 | 基础 → Json 模式 |
| `or_pattern.mbt` | or-pattern 与默认绑定 | 基础 → or-pattern |
| `generics.mbt` | 泛型类型与泛型函数 | 基础 → 泛型 |

**根包库代码**（`custom_types.mbt`）：
- `pub(all) struct Point` / `pub(all) enum Shape` — 自定义类型
- `pattern_match_array` / `pattern_match_json` — 模式匹配工具
- `generic_swap` / `generic_max` — 泛型工具函数

### Phase 8: 派生特征 — `derive_traits` 模块（v0.6.0）

> 对应官方文档：[派生内建特征](https://docs.moonbitlang.cn/language/derive.html)

**cmd/main 演示文件**：

| 文件 | 主题 | 官方文档对应 |
|------|------|-------------|
| `derive_eq.mbt` | derive(Eq, Compare) | 派生 → 相等和比较 |
| `derive_debug.mbt` | derive(Debug) 与 debug_inspect | 派生 → Debug |
| `derive_default.mbt` | derive(Default) | 派生 → 默认值 |
| `derive_hash.mbt` | derive(Hash) 与 HashSet/HashMap | 派生 → 哈希值 |
| `derive_arbitrary.mbt` | derive(Arbitrary) 随机生成 | 派生 → 任意值 |
| `derive_shrink.mbt` | derive(Shrink) 属性测试缩小 | 派生 → 缩小 |
| `derive_json.mbt` | derive(FromJson, ToJson) 序列化 | 派生 → 从/到 Json |

**根包库代码**（`derive_traits.mbt`）：
- `pub(all) struct Config` derive(Eq, Compare, Debug, Default, Hash, FromJson, ToJson)
- `pub(all) enum Color` derive(Eq, Compare, Debug, Default)
- `config_to_json` / `config_from_json` — JSON 序列化工具
- `config_hash` — 哈希工具

### Phase 9: FFI 绑定 — `ffi_demo` 模块（v0.7.0）

> 对应官方文档：[外部函数接口 (FFI)](https://docs.moonbitlang.cn/language/ffi.html)

**cmd/main 演示文件**：

| 文件 | 主题 | 官方文档对应 |
|------|------|-------------|
| `ffi_c.mbt` | C FFI `extern "C"` 声明与调用 | FFI → 声明外部函数 → C |
| `ffi_js.mbt` | JS FFI `extern "js"` 声明与调用 | FFI → 声明外部函数 → JavaScript |
| `ffi_wasm.mbt` | Wasm FFI 内联函数 | FFI → 声明外部函数 → Wasm |
| `external_type.mbt` | `#external type` 外部类型 | FFI → 声明外部类型 |
| `export_fn.mbt` | `#export_name` 导出函数 | FFI → 导出函数 |
| `callback.mbt` | FuncRef[T] 回调函数 | FFI → 回调 |
| `lifetime.mbt` | #borrow/#owned 生命周期管理 | FFI → 生命周期管理 |
| `custom_enum.mbt` | 自定义常量枚举整数值 | FFI → 自定义常量枚举 |

**根包库代码**（`ffi_demo.mbt`）：
- `extern "C"` / `extern "js"` 函数声明包装
- `pub fn safe_ffi_call` — 安全 FFI 调用封装

### Phase 10: 测试与基准测试 — `testing_demo` 模块（v0.8.0）

> 对应官方文档：[编写测试](https://docs.moonbitlang.cn/language/tests.html) + [编写基准测试](https://docs.moonbitlang.cn/language/benchmarks.html) + [测量代码覆盖率](https://docs.moonbitlang.cn/toolchain/moon/coverage.html)

**cmd/main 演示文件**：

| 文件 | 主题 | 官方文档对应 |
|------|------|-------------|
| `test_basic.mbt` | test 块、assert_eq/assert_true | 编写测试 |
| `test_inspect.mbt` | debug_inspect 快照测试 | 编写测试 |
| `test_property.mbt` | @quickcheck 属性测试 | 编写测试 |
| `test_inline.mbt` | 内联文档测试 `mbt check` | 编写测试 |
| `bench_basic.mbt` | @bench 基准测试编写 | 编写基准测试 |
| `coverage.mbt` | moon coverage 覆盖率 | 测量代码覆盖率 |

**根包库代码**（`testing_demo.mbt`）：
- `pub fn sort_array` — 用于演示测试的被测函数
- `pub fn fibonacci` — 用于演示基准测试的被测函数

### Phase 11: 属性与注解 — `attributes_demo` 模块（v0.9.0）

> 对应官方文档：[属性](https://docs.moonbitlang.cn/language/attributes.html) + [注释与文档](https://docs.moonbitlang.cn/language/docs.html) + [词法约定](https://docs.moonbitlang.cn/language/lexical-conventions.html)

**cmd/main 演示文件**：

| 文件 | 主题 | 官方文档对应 |
|------|------|-------------|
| `callsite.mbt` | #callsite(autofill) 自动填充参数 | 属性 |
| `alias.mbt` | #alias 函数别名 | 属性 |
| `export_attr.mbt` | #export_name 导出属性 | 属性 |
| `external_attr.mbt` | #external 外部类型属性 | 属性 |
| `deprecated.mbt` | #deprecated 弃用标记 | 属性 |
| `doc_comment.mbt` | /// 文档注释体系 | 注释与文档 |
| `lexical.mbt` | 词法约定（标识符/关键字/运算符） | 词法约定 |

**根包库代码**（`attributes_demo.mbt`）：
- `#callsite(autofill(loc))` 示例函数
- `#alias` 别名函数
- `#deprecated` 弃用函数

### Phase 12: 异步编程 — `async_demo` 模块（v0.10.0）

> 对应官方文档：[异步编程支持](https://docs.moonbitlang.cn/language/async-experimental.html)（实验性）

**cmd/main 演示文件**：

| 文件 | 主题 | 官方文档对应 |
|------|------|-------------|
| `async_basic.mbt` | async/await 基本语法 | 异步编程 |
| `async_error.mbt` | 异步错误处理 | 异步编程 |
| `async_combinator.mbt` | 异步组合器 | 异步编程 |

**根包库代码**（`async_demo.mbt`）：
- `async fn fetch_data` — 异步数据获取
- `async fn parallel_fetch` — 并行异步

> **注意**：异步为实验性特性，可能随版本变化。

### Phase 13: 形式化验证 — `verification_demo` 模块（v0.11.0）

> 对应官方文档：[形式化验证](https://docs.moonbitlang.cn/language/verification.html)

**cmd/main 演示文件**：

| 文件 | 主题 | 官方文档对应 |
|------|------|-------------|
| `prove_basic.mbt` | moon prove 基础 | 形式化验证 |
| `invariant.mbt` | 循环不变量 | 形式化验证 |
| `abstract_fn.mbt` | 抽象函数与表示不变量 | 形式化验证 |

**根包库代码**（`verification_demo.mbt`）：
- `pub fn verified_sum` — 附带形式化证明的求和函数
- `pub fn verified_sort` — 附带形式化证明的排序函数

### Phase 14: mooncakes 生态与工具链（v1.0.0）

> 对应官方文档：[使用包管理项目](https://docs.moonbitlang.cn/language/packages.html) + [Moon 构建系统](https://docs.moonbitlang.cn/toolchain/moon/index.html) + [WebAssembly 集成](https://docs.moonbitlang.cn/toolchain/wasm/index.html)

- ⬜ `moon add` 安装第三方包演示
- ⬜ 常用 mooncakes 包演示（moonbitlang/x）
- ⬜ 发布到 mooncakes.io 流程
- ⬜ `moon work` workspace 管理深入
- ⬜ `.mbtx` 脚本模式
- ⬜ `moon coverage` 代码覆盖率
- ⬜ WebAssembly 集成与组件模型
- ⬜ 多后端构建（wasm/wasm-gc/js/native）

---

## 版本规划

| 版本 | 对应 Phase | 预期内容 | 新增模块 |
|------|-----------|---------|---------|
| v0.2.0 | Phase 5 | 文档治理与零基础教学完善 | — |
| v0.2.1 | Phase 5 | 工程整洁度优化 | — |
| v0.3.0 | Phase 5.5 | 库包完善与测试覆盖 | — |
| v0.3.1 | Phase 5.5 | 消除全部 warning（0 warning 0 error） | — |
| v0.4.0 | Phase 6 | 基础进阶：Byte/Ref/Json/切片/推导式/defer/管道 | `advanced_basics` |
| v0.5.0 | Phase 7 | 自定义类型与模式匹配：结构体/枚举/泛型/位串模式 | `custom_types` |
| v0.6.0 | Phase 8 | 派生特征：Eq/Compare/Debug/Default/Hash/Json | `derive_traits` |
| v0.7.0 | Phase 9 | FFI 绑定：C/JS/Wasm/外部类型/导出/回调 | `ffi_demo` |
| v0.8.0 | Phase 10 | 测试与基准测试：quickcheck/bench/coverage | `testing_demo` |
| v0.9.0 | Phase 11 | 属性与注解：callsite/alias/deprecated/词法 | `attributes_demo` |
| v0.10.0 | Phase 12 | 异步编程：async/await（实验性） | `async_demo` |
| v0.11.0 | Phase 13 | 形式化验证：moon prove/Why3/不变量 | `verification_demo` |
| v1.0.0 | Phase 14 | mooncakes 生态与工具链：全后端/Wasm/发布 | — |

---

## 官方文档覆盖矩阵

> 对照 [MoonBit 语言文档目录](https://docs.moonbitlang.cn/language/index.html) 确保全面覆盖。

| 官方文档主题 | 教学模块 | 覆盖状态 |
|-------------|---------|---------|
| [介绍](https://docs.moonbitlang.cn/language/introduction.html) | README.md | ✅ 已覆盖 |
| [基础](https://docs.moonbitlang.cn/language/fundamentals.html) | basics + advanced_basics + custom_types | ⚠️ 部分（Phase 6/7 补全） |
| [方法和特征](https://docs.moonbitlang.cn/language/methods.html) | method_and_trait | ✅ 已覆盖 |
| [派生内建特征](https://docs.moonbitlang.cn/language/derive.html) | derive_traits | ⬜ Phase 8 |
| [错误处理](https://docs.moonbitlang.cn/language/error-handling.html) | error | ✅ 已覆盖 |
| [使用包管理项目](https://docs.moonbitlang.cn/language/packages.html) | examine + Phase 14 | ⚠️ 部分（Phase 14 补全） |
| [编写测试](https://docs.moonbitlang.cn/language/tests.html) | 全模块 _test.mbt + testing_demo | ⚠️ 部分（Phase 10 补全） |
| [编写基准测试](https://docs.moonbitlang.cn/language/benchmarks.html) | testing_demo | ⬜ Phase 10 |
| [注释与文档](https://docs.moonbitlang.cn/language/docs.html) | attributes_demo | ⬜ Phase 11 |
| [属性](https://docs.moonbitlang.cn/language/attributes.html) | attributes_demo | ⬜ Phase 11 |
| [外部函数接口 (FFI)](https://docs.moonbitlang.cn/language/ffi.html) | ffi_demo | ⬜ Phase 9 |
| [异步编程支持](https://docs.moonbitlang.cn/language/async-experimental.html) | async_demo | ⬜ Phase 12 |
| [形式化验证](https://docs.moonbitlang.cn/language/verification.html) | verification_demo | ⬜ Phase 13 |
| [词法约定](https://docs.moonbitlang.cn/language/lexical-conventions.html) | attributes_demo | ⬜ Phase 11 |
| [错误代码索引](https://docs.moonbitlang.cn/language/error_codes/index.html) | docs/faq.md | ⚠️ 部分（持续补充） |
