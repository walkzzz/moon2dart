# 变更日志

本文件记录 MoonBit 教学工程的版本变更，遵循[语义化版本](https://semver.org/lang/zh-CN/)。

格式：`vX.Y.Z: 亮点 - 变更摘要`，按版本倒序排列。

---

## v0.4.0: 基础进阶模块 — advanced_basics - 2026-09-15

### 亮点

新增 `advanced_basics` 模块，覆盖 MoonBit 基础进阶特性：Byte/Bytes、Ref[T]、Json、ArrayView/MutArrayView、列表推导式（等价写法）、defer、部分应用、管道、is 表达式、展开运算符（等价写法）、重载字面量。

### 新增

- **模块**：`advanced_basics/`（根包库 + cmd/main 演示）
- **根包库代码**：`byte_reverse`/`bytes_concat`/`ref_counter`/`json_lookup`/`slice_sum`/`even_squares`/`pipeline_even_square_sum`/`is_some` + 私有 `_array_length`
- **演示文件**：12 个主题文件（byte/ref/json/array_view/comprehension/labelled_loop/defer/partial_app/pipeline/is_expr/spread/overloaded_literal）
- **黑盒测试**：8 个（`advanced_basics_test.mbt`）
- **白盒测试**：9 个（`advanced_basics_wbtest.mbt`）
- **模块文档**：AGENTS.md、README.mbt.md

### v0.10.9 语法限制

以下特性在官方文档 v0.10.12 中有描述，但工具链 v0.10.9 尚不支持，已用等价写法替代：

- 列表推导式 `[expr for x in range]` → 显式 `for` 循环 + `push`
- 展开运算符 `...arr` → 手动拼接循环
- 带标签 break/continue `break label with value` → 标志变量 + 普通 `break`
- `var` 关键字 → `let mut`
- 局部函数标签参数 → 移至顶层或改用普通参数

### 统计

- 成员模块：5
- 公开 API：61 + 8 = 69 函数
- 测试用例：154（全部通过）
- Warnings：0（全部 `Show` 弃用 warning 已通过迁移至 `@debug.to_string()` 消除）
- Errors：0

---

## v0.3.2: 路线图重构 — 基于官方文档全面规划 - 2026-09-15

### 亮点

对照 MoonBit 官方语言文档（v0.10.12）完整知识体系，重构教学路线图，规划 9 个新模块覆盖全部官方主题。

### 变更

- 重构 `docs/roadmap.md`：Phase 6-14 对应官方文档全部主题
- 新增官方文档覆盖矩阵，逐项标注覆盖状态
- 规划 8 个新教学模块：advanced_basics / custom_types / derive_traits / ffi_demo / testing_demo / attributes_demo / async_demo / verification_demo
- 更新版本规划至 v1.0.0

---

## v0.3.0: 库包完善与测试覆盖 - 2026-09-15

### 亮点

为所有子项目的根包编写库代码、黑盒/白盒测试，定制 AGENTS.md，实现 100% 库包测试覆盖。

### 新增

- **basics 根包库代码**：`gcd`/`lcm`/`is_prime`/`reverse_string`/`sum_array`/`average` + 私有 `_array_length`
- **error 根包库代码**：`MathError`/`ParseError` suberror + `safe_div`/`safe_mod`/`safe_isqrt`/`map_ok`/`map_err`/`result_to_option`/`option_to_result`/`parse_digit`/`parse_int_safe` + 私有 `_validate_non_negative`
- **method_and_trait 根包库代码**：`Shape` trait + `Circle`/`Rectangle` 实现 + `total_area`/`total_perimeter`/`max_area` + 私有 `_is_valid_radius`
- **黑盒测试**（`_test.mbt`）：basics 6 个、error 9 个、examine 4 个、method_and_trait 6 个
- **白盒测试**（`_wbtest.mbt`）：basics 7 个、error 8 个、examine 3 个、method_and_trait 8 个
- **模块级 AGENTS.md**：4 个模块全部替换为定制文档（模块职责/项目结构/公开 API/测试约定/常用命令/编码约定）
- **cmd/main 集成**：basics/error/method_and_trait 取消注释 `@lib` 导入并添加库函数演示调用

### 修复

- `lcm` 负数返回值：对结果取绝对值
- `fold` 语法：使用标签参数 `init=0` 而非位置参数
- `suberror` 黑盒可见性：黑盒测试用 `is Err(_)` 代替 `is Err(DivByZero)`，白盒测试可精确匹配
- `derive(Show)` 弃用：改为 `derive(Debug, Eq)`
- 空数组类型推断：添加 `Array[Rectangle]` 等显式标注

### 统计

- 成员模块：4
- 公开 API：43 + 18 = 61 函数
- 测试用例：129（全部通过）
- Warnings：0（原 9 条 `unresolved_type_variable` 已全部修复，为裸 `Ok`/`Err`/`None` 添加显式类型标注）

---

## v0.2.1: 工程整洁度优化 - 2026-09-15

### 亮点

清理未使用依赖、补齐缺失文档、修正文档不一致，提升工程整洁度。

### 修复

- 清理 `basics` 模块未使用的 `.mooncakes/walkzzz/image` 依赖（注释掉的 import 残留）
- 补齐 `examine/README.md`（此前唯一缺失包级 README 的模块）
- 修正 4 个模块 `README.mbt.md` 中 `README.md` 的"空"描述为实际内容
- 修正 `changelog.md` v0.2.0 中 `api_reference.md` "14 个公开函数"笔误为 43
- 修正 `examples.md` 测试计数：basics 24→26、error 13→14、method_and_trait 17→14

### 统计

- 成员模块：4
- 公开 API：43 函数
- 测试用例：61（全部通过）
- Warnings：0

---

## v0.2.0: 文档治理与零基础教学完善 - 2026-09-15

### 亮点

将 4 个独立教学模块统一为 workspace 工程，建立面向零基础学习者的三级文档体系。

### 新增

- **workspace 配置**：根目录 `moon.work` 统一管理 `basics`/`error`/`examine`/`method_and_trait`
- **根目录总览** `README.md`：快速开始、工程结构、模块对照表、学习路径、命令速查
- **workspace 级开发约定** `AGENTS.md`：三级文档注释体系、warning 治理原则、提交规范
- **docs/ 教学文档体系**：
  - `learning_path.md`：零基础 5 步学习路径，含前置知识与验证标准
  - `features.md`：已覆盖 60+ 语言特性清单（✅/⚠️/❌ 标记）
  - `api_reference.md`：43 个公开函数、20 个公开类型、6 个公开 trait 索引
  - `examples.md`：各模块预期输出与测试说明
  - `faq.md`：12 类常见问题与错题本（环境/类型/错误处理/包/测试）
  - `changelog.md`：本文件
  - `roadmap.md`：教学内容路线图
- **basics 3 级文档注释**：为 `functions`/`closures`/`labelled`/`if_expr`/`match_expr`/`guard`/`for_loop`/`for_in`/`while_loop`/`iterator`/`fold` 共 11 个文件补充完整文档注释
- **error 3 级文档注释**：为 `error_learn.mbt`/`main.mbt` 全部函数与 suberror 补充文档注释
- **examine 3 级文档注释**：为 `Student`/`ExamResult`/`is_qualified`/`count_qualified_students` 补充文档注释
- **method_and_trait 3 级文档注释**：为 `define_method`/`reload_method`/`operator_overload`/`trait`/`alias` 全部补充文档注释
- **包级 README**：为 `error`/`examine`/`method_and_trait` 的 `cmd/main` 新增 `README.md`
- **模块级 README.mbt.md**：完善 `error`/`examine`/`method_and_trait` 的模块说明

### 修复

- `basics/cmd/main/if_expr.mbt`：`state1`/`state2` unused warning，改为在 `if_else()` 中演示并加教学注释
- `error/cmd/main/error_learn.mbt`：`E3::A/B/C` unused constructor，在测试中构造以消除
- `error/cmd/main/error_learn.mbt`：`f` unused function，在测试中调用以消除
- `error/cmd/main/main.mbt`：`f11`/`f12`/`f13` 的 `...` todo，改为完整 `raise` 实现以演示错误传播
- `method_and_trait/cmd/main/trait.mbt`：`MyCustomType::output` 的 `self` unused，改为 `_self`
- `method_and_trait/cmd/main/trait.mbt`：`Fox` unused，在测试中构造以消除

### 文档

- 统一三级文档注释体系：包级 `README.md` / 模块级 `README.mbt.md` / API 级 `///`+`///|`
- 公开 API 文档注释内嵌 ` ```mbt check ` 文档测试

### 统计

- 成员模块：4
- 公开 API：43 函数
- 测试用例：61（全部通过）
- 教学主题：4 大类 / 60+ 子主题
- Warnings：0（全部修复）

---

## v0.1.0: 初始教学模块 - 2026-09-09

### 初始内容

- `basics`：基础语法演示（Unit/数字/字符串/元组/Option/Result/数组/Map/函数/闭包/标签参数/控制流/循环/迭代器/fold）
- `error`：错误处理演示（suberror/raise/try-catch/Result 互转/泛型错误）
- `examine`：库包与可执行包协作小例（学生及格判定）
- `method_and_trait`：方法、trait、运算符重载、别名、OpGet/OpSet/OpView 演示
