# 零基础学习路径

> 本文档为从未接触过 MoonBit 的学习者设计一条由浅入深的学习路线。
> 每一步都标注了"前置知识"和"学完后能做什么"，确保循序渐进。

## 总览：6 步走完 MoonBit 入门

```
步骤 0  环境准备        →  步骤 1  basics 基础语法
                                     ↓
步骤 3  method_and_trait  ←  步骤 2  error 错误处理
         方法与多态                代数错误处理
                                     ↓
                               步骤 4  examine 库包协作
                                     ↓
                               步骤 5  advanced_basics 基础进阶
```

---

## 步骤 0：环境准备（10 分钟）

**目标**：能在本地运行 `moon version` 并执行第一个程序。

**操作**：
1. 按 [根目录 README](../README.md#1-安装-moonbit-工具链) 安装工具链
2. 在工程根目录执行 `moon -C basics run cmd/main`，看到输出即成功

**学完后能做**：
- 使用 `moon run` / `moon check` / `moon test` 三大基础命令
- 理解 workspace 与成员模块的关系

---

## 步骤 1：basics — 基础语法（建议 2 小时）

**前置知识**：任意一门编程语言的基础（变量、函数、条件、循环）

**阅读顺序**（按文件逐个读，配合运行）：

| 顺序 | 文件 | 主题 | 关键概念 |
|------|------|------|---------|
| 1 | `cmd/main/unit.mbt` | Unit 类型 | `-> Unit`、副作用、`println` |
| 2 | `cmd/main/numbers.mbt` | 数字与布尔 | 字面量、`0x`/`0b`、下划线分组、`Int16`/`UInt64`/`BigInt`、`&&`/`!` |
| 3 | `cmd/main/strings.mbt` | 字符串与字符 | `#|` 原始多行、`$|` 插值多行、`Char`、`\u{}` |
| 4 | `cmd/main/tuple.mbt` | 元组 | 打包、解构、位置访问 |
| 5 | `cmd/main/option_result.mbt` | Option / Result | `Some`/`None`、`Ok`/`Err`、match 穷尽 |
| 6 | `cmd/main/array.mbt` | 数组 | `Array`、`FixedArray`、切片视图 |
| 7 | `cmd/main/map.mbt` | Map | 字面量、插入顺序迭代 |
| 8 | `cmd/main/functions.mbt` | 函数 | `declare`、局部函数、匿名函数 |
| 9 | `cmd/main/closures.mbt` | 闭包 | 捕获变量、`each` |
| 10 | `cmd/main/labelled.mbt` | 标签参数 | `name~`、可选参数 `?`、默认值 |
| 11 | `cmd/main/if_expr.mbt` | 条件表达式 | `if`/`else if`/`else` 作为表达式 |
| 12 | `cmd/main/match_expr.mbt` | 模式匹配 | 范围模式 `0..<6`、通配 `_` |
| 13 | `cmd/main/guard.mbt` | 守卫 | `guard ... else { ... }` |
| 14 | `cmd/main/while_loop.mbt` | while 循环 | `while`/`nobreak` |
| 15 | `cmd/main/for_loop.mbt` | for 循环 | C 风格 `for`、九九乘法表 |
| 16 | `cmd/main/for_in.mbt` | for-in | 遍历数组/字符串/Map |
| 17 | `cmd/main/iterator.mbt` | 迭代器 | `iter().filter().collect()` |
| 18 | `cmd/main/fold.mbt` | fold | `fold` 归约 |

**库包实践**（根包 `basics/`）：

| 顺序 | 文件 | 主题 | 关键概念 |
|------|------|------|---------|
| 19 | `basics.mbt` | 库包公开 API | `pub fn`、`pub(test) fn`、文档注释 `///`+`///|`、内嵌文档测试 |
| 20 | `basics_test.mbt` | 黑盒测试 | `test "name" { ... }`、`assert_eq`、通过 `@lib` 调用 |
| 21 | `basics_wbtest.mbt` | 白盒测试 | 包内测试、直接调用私有函数 `_array_length` |

**学完后能做**：
- 读写 MoonBit 基础代码，理解类型标注与类型推断
- 使用 `Option`/`Result`/`match` 处理可选与分支
- 使用集合类型与迭代器链
- 编写库包公开 API 并配以黑盒/白盒测试

**验证**：`moon -C basics test` 全部通过（80 tests）

---

## 步骤 2：error — 错误处理（建议 1.5 小时）

**前置知识**：步骤 1（尤其 `Option`/`Result`/`match`）

**阅读顺序**：

| 顺序 | 文件 | 主题 | 关键概念 |
|------|------|------|---------|
| 1 | `cmd/main/error_learn.mbt` 1-19 行 | suberror 定义 | `suberror`、带参变体、标签字段 |
| 2 | `cmd/main/error_learn.mbt` 22-37 行 | Error 类型与 match | `Error` 顶层类型、`guard! ... is` |
| 3 | `cmd/main/error_learn.mbt` 40-56 行 | raise 与 callsite | `raise`、`Failure`、`#callsite`、`SourceLoc` |
| 4 | `cmd/main/error_learn.mbt` 59-72 行 | noraise 与错误传播 | `noraise`、`raise?` 多态错误 |
| 5 | `cmd/main/error_learn.mbt` 75-114 行 | 泛型错误处理 | `raise E`、`raise?`、`noraise` 三态 |
| 6 | `cmd/main/error_learn.mbt` 117-148 行 | try/catch 与 Result 互转 | `try ... catch ... noraise`、`try!` |
| 7 | `cmd/main/main.mbt` | 综合演示 | 完整的错误处理流程 |

**学完后能做**：
- 定义自定义错误类型并用 `raise` 抛出
- 用 `try/catch/noraise` 三段式处理错误
- 理解 `raise`/`raise?`/`noraise` 三种错误传播策略

**库包实践**（根包 `error/`）：

| 顺序 | 文件 | 主题 | 关键概念 |
|------|------|------|---------|
| 8 | `error.mbt` | 库包公开 API | `suberror`+`derive(Debug, Eq)`、`Result` 工具函数、`parse_int_safe` |
| 9 | `error_test.mbt` | 黑盒测试 | `is Err(_)` 模式（suberror 构造器黑盒不可见） |
| 10 | `error_wbtest.mbt` | 白盒测试 | `is Err(DivByZero)` 精确匹配 suberror 构造器 |

> **关键**：`suberror` 构造器仅在定义包内可见。黑盒测试用 `is Err(_)`，白盒测试用 `is Err(DivByZero)`。

**验证**：`moon -C error test` 全部通过

---

## 步骤 3：method_and_trait — 方法与多态（建议 2 小时）

**前置知识**：步骤 1、2

**阅读顺序**：

| 顺序 | 文件 | 主题 | 关键概念 |
|------|------|------|---------|
| 1 | `cmd/main/define_method.mbt` | 关联函数与方法 | `List::length`、泛型方法、`Add`/`Mul` trait 约束 |
| 2 | `cmd/main/reload_method.mbt` | 方法重载与默认值 | `Wallet::default`、`Int::factorial` |
| 3 | `cmd/main/operator_overload.mbt` | 运算符重载 | `Add`/`Sub`/`Eq`/`Neg` trait 实现 |
| 4 | `cmd/main/trait.mbt` 1-86 行 | trait 定义与实现 | `pub(open) trait`、继承 `Object: Position + Draw`、默认方法 `= _` |
| 5 | `cmd/main/trait.mbt` 89-149 行 | Eq、Show、extend | `extend ... with Show::{to_string}`、动态多态 `Array[&Animal]` |
| 6 | `cmd/main/alias.mbt` | #alias 与 #as_free_fn | 方法别名、自由函数、`OpGet`/`OpSet`/`OpView` |

**学完后能做**：
- 为自定义类型定义关联函数与 trait 实现
- 使用运算符重载让自定义类型支持 `+`/`-`/`==` 等
- 理解 trait 继承、默认方法、`extend` 复用

**库包实践**（根包 `method_and_trait/`）：

| 顺序 | 文件 | 主题 | 关键概念 |
|------|------|------|---------|
| 7 | `method_and_trait.mbt` | 库包公开 API | `pub(open) trait Shape`、`pub(all) struct`、`pub impl`、工具函数 |
| 8 | `method_and_trait_test.mbt` | 黑盒测试 | 通过公开 API 测试 trait 多态、`total_area` 等 |
| 9 | `method_and_trait_wbtest.mbt` | 白盒测试 | 精确类型构造、私有函数 `_is_valid_radius` |

**验证**：`moon -C method_and_trait test` 全部通过

---

## 步骤 4：examine — 库包协作（建议 1 小时）

**前置知识**：步骤 1-3

**阅读顺序**：

| 顺序 | 文件 | 主题 | 关键概念 |
|------|------|------|---------|
| 1 | `examine.mbt` | 库包公开 API | `pub(all) struct`、`pub(all) enum`、`derive(Debug)`、`impl Eq` |
| 2 | `examine_test.mbt` | 黑盒测试 | 通过 `@lib` 调用公开 API、`assert_eq` 验证 |
| 3 | `examine_wbtest.mbt` | 白盒测试 | 包内测试、直接调用内部函数 |
| 4 | `cmd/main/main.mbt` | 可执行包引用库包 | `import "walkzzz/examine"`、`@examine.Student` |
| 5 | `cmd/main/moon.pkg` | 包依赖配置 | `import` 声明 |

**学完后能做**：
- 设计库包的公开 API 与可见性
- 在可执行包中引用库包并调用其 API
- 编写白盒与黑盒测试

**验证**：`moon -C examine test` 全部通过

---

## 步骤 5：advanced_basics — 基础进阶（建议 2 小时）

**前置知识**：步骤 1-4

**阅读顺序**：

| 顺序 | 文件 | 主题 | 关键概念 |
|------|------|------|---------|
| 1 | `cmd/main/byte.mbt` | Byte / Bytes | `b"..."`、`@buffer`、字节操作 |
| 2 | `cmd/main/ref.mbt` | Ref[T] | `{ val: x }`、可变引用 |
| 3 | `cmd/main/json.mbt` | Json | 字面量重载、模式匹配 `Number(x, ..)` |
| 4 | `cmd/main/array_view.mbt` | ArrayView / MutArrayView | `arr[start:end]`、可变视图 |
| 5 | `cmd/main/comprehension.mbt` | 列表推导式 | v0.10.9 等价写法（显式循环） |
| 6 | `cmd/main/labelled_loop.mbt` | 带标签循环 | v0.10.9 等价写法（标志变量） |
| 7 | `cmd/main/defer.mbt` | defer | 作用域结束清理、LIFO 顺序 |
| 8 | `cmd/main/partial_app.mbt` | 部分应用 | `x => f(a, x)`、柯里化 |
| 9 | `cmd/main/pipeline.mbt` | 管道 `|>` | 链式调用、数据处理流水线 |
| 10 | `cmd/main/is_expr.mbt` | is 表达式 | `opt is Some(_)`、guard 配合 |
| 11 | `cmd/main/spread.mbt` | 展开运算符 | v0.10.9 等价写法（手动拼接） |
| 12 | `cmd/main/overloaded_literal.mbt` | 重载字面量 | 类型导向字面量、Json/Map 重载 |

**库包实践**（根包 `advanced_basics/`）：

| 顺序 | 文件 | 主题 | 关键概念 |
|------|------|------|---------|
| 13 | `advanced_basics.mbt` | 库包公开 API | `pub fn`、`@buffer`、`Json` 模式匹配、`ArrayView` |
| 14 | `advanced_basics_test.mbt` | 黑盒测试 | 8 个测试覆盖全部公开 API |
| 15 | `advanced_basics_wbtest.mbt` | 白盒测试 | 9 个测试含私有 `_array_length` |

**学完后能做**：
- 使用 Byte/Bytes/Buffer 进行字节级操作
- 用 Ref[T] 实现可变引用语义
- 构造和模式匹配 Json 数据
- 使用 ArrayView/MutArrayView 切片操作数组
- 用 defer 管理资源清理
- 用管道 `|>` 和部分应用构建数据处理流水线
- 用 is 表达式进行运行时类型检查

**验证**：`moon -C advanced_basics test` 全部通过

> **注意**：v0.10.9 工具链不支持列表推导式、展开运算符、带标签 break，演示文件中用等价写法替代并注释说明。

---

## 进阶路线（Phase 7-14）

> 以下步骤基于 [MoonBit 官方语言文档](https://docs.moonbitlang.cn/language/index.html) 制定，确保覆盖全部主题。
> 详细规划见 [路线图](roadmap.md)。

完成以上 6 步后，可继续探索：

| 步骤 | 模块 | 主题 | 官方文档对应 |
|------|------|------|-------------|
| 6 | `custom_types` | 结构体/枚举/泛型/位串模式/Map模式 | [基础 → 自定义数据类型](https://docs.moonbitlang.cn/language/fundamentals.html#custom-data-types) |
| 7 | `derive_traits` | derive(Eq/Compare/Debug/Default/Hash/Json) | [派生内建特征](https://docs.moonbitlang.cn/language/derive.html) |
| 8 | `ffi_demo` | C/JS/Wasm FFI/外部类型/导出/回调 | [FFI](https://docs.moonbitlang.cn/language/ffi.html) |
| 9 | `testing_demo` | quickcheck/bench/coverage | [编写测试](https://docs.moonbitlang.cn/language/tests.html) + [基准测试](https://docs.moonbitlang.cn/language/benchmarks.html) |
| 10 | `attributes_demo` | callsite/alias/deprecated/词法约定 | [属性](https://docs.moonbitlang.cn/language/attributes.html) + [词法约定](https://docs.moonbitlang.cn/language/lexical-conventions.html) |
| 11 | `async_demo` | async/await（实验性） | [异步编程](https://docs.moonbitlang.cn/language/async-experimental.html) |
| 12 | `verification_demo` | moon prove/Why3/不变量 | [形式化验证](https://docs.moonbitlang.cn/language/verification.html) |

参见官方文档 <https://docs.moonbitlang.cn/> 。
