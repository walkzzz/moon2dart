# 已覆盖语言特性清单

> 本文档记录本教学工程已演示的 MoonBit 语言特性，供学习者对照检查掌握情况。
> 标记说明：✅ 已覆盖并文档化；⚠️ 已覆盖但文档待完善；❌ 未覆盖。

## 基础类型与字面量

| 特性 | 状态 | 演示位置 |
|------|------|---------|
| `Unit` 类型与 `-> Unit` | ✅ | `basics/cmd/main/unit.mbt` |
| `Int` / `Int16` / `UInt64` / `BigInt` | ✅ | `basics/cmd/main/numbers.mbt` |
| `Double` | ✅ | `basics/cmd/main/tuple.mbt` |
| `Bool` 与 `&&` / `!` | ✅ | `basics/cmd/main/numbers.mbt` |
| `String` 字面量与插值 `\{}` | ✅ | `basics/cmd/main/strings.mbt` |
| 多行原始字符串 `#|` | ✅ | `basics/cmd/main/strings.mbt` |
| 多行插值字符串 `$|` | ✅ | `basics/cmd/main/strings.mbt` |
| `Char` 与 Unicode 码点转义 | ✅ | `basics/cmd/main/strings.mbt` |
| 数字字面量下划线分组 | ✅ | `basics/cmd/main/numbers.mbt` |
| 十六进制 `0x` / 二进制 `0b` | ✅ | `basics/cmd/main/numbers.mbt` |
| `N` / `UL` 后缀 | ✅ | `basics/cmd/main/numbers.mbt` |

## 复合类型

| 特性 | 状态 | 演示位置 |
|------|------|---------|
| 元组与解构 | ✅ | `basics/cmd/main/tuple.mbt` |
| `Option[T]` (`Int?`) | ✅ | `basics/cmd/main/option_result.mbt` |
| `Result[T, E]` | ✅ | `basics/cmd/main/option_result.mbt` |
| `Array[T]` | ✅ | `basics/cmd/main/array.mbt` |
| `FixedArray[T]` | ✅ | `basics/cmd/main/array.mbt` |
| 切片 `arr[a:b]` (`ArrayView`) | ✅ | `basics/cmd/main/array.mbt` |
| `Map[K, V]` | ✅ | `basics/cmd/main/map.mbt` |
| `struct` 结构体 | ✅ | `examine/examine.mbt`, `method_and_trait/cmd/main/operator_overload.mbt` |
| `enum` 枚举 | ✅ | `examine/examine.mbt`, `method_and_trait/cmd/main/define_method.mbt` |
| `pub(all)` 可见性 | ✅ | `examine/examine.mbt` |
| `derive(Debug)` | ✅ | `examine/examine.mbt`, `error/cmd/main/error_learn.mbt` |
| `derive(Eq)` | ✅ | `error/error.mbt` (`MathError`/`ParseError`) |
| `suberror` 可见性（黑盒抽象/白盒可见） | ✅ | `error/error.mbt` + `error_test.mbt` + `error_wbtest.mbt` |

## 函数与控制流

| 特性 | 状态 | 演示位置 |
|------|------|---------|
| 函数定义与返回值 | ✅ | `basics/cmd/main/functions.mbt` |
| `declare` 前向声明 | ✅ | `basics/cmd/main/functions.mbt` |
| 局部函数与匿名函数 | ✅ | `basics/cmd/main/functions.mbt` |
| 闭包与变量捕获 | ✅ | `basics/cmd/main/closures.mbt` |
| 标签参数 `name~` | ✅ | `basics/cmd/main/labelled.mbt` |
| 可选参数 `?` 与默认值 | ✅ | `basics/cmd/main/labelled.mbt` |
| `if` / `else if` / `else` 表达式 | ✅ | `basics/cmd/main/if_expr.mbt` |
| `match` 模式匹配 | ✅ | `basics/cmd/main/match_expr.mbt` |
| 范围模式 `0..<6` | ✅ | `basics/cmd/main/match_expr.mbt` |
| `guard ... else` | ✅ | `basics/cmd/main/guard.mbt` |
| `while` / `nobreak` | ✅ | `basics/cmd/main/while_loop.mbt` |
| C 风格 `for` 循环 | ✅ | `basics/cmd/main/for_loop.mbt` |
| `for-in` 遍历 | ✅ | `basics/cmd/main/for_in.mbt` |
| 迭代器 `iter().filter().collect()` | ✅ | `basics/cmd/main/iterator.mbt` |
| `fold` 归约 | ✅ | `basics/cmd/main/fold.mbt` |

## 错误处理

| 特性 | 状态 | 演示位置 |
|------|------|---------|
| `suberror` 定义 | ✅ | `error/cmd/main/error_learn.mbt` |
| `raise` 抛出错误 | ✅ | `error/cmd/main/error_learn.mbt` |
| `try / catch / noraise` | ✅ | `error/cmd/main/main.mbt` |
| `try!` 错误传播 | ✅ | `error/cmd/main/error_learn.mbt` |
| `guard! ... is` | ✅ | `error/cmd/main/error_learn.mbt` |
| `noraise` 标注 | ✅ | `error/cmd/main/error_learn.mbt` |
| `raise?` 多态错误 | ✅ | `error/cmd/main/error_learn.mbt` |
| `#callsite(autofill(loc))` | ✅ | `error/cmd/main/error_learn.mbt` |
| `Result` 与 `raise` 互转 | ✅ | `error/cmd/main/error_learn.mbt` |
| 泛型错误处理 | ✅ | `error/cmd/main/error_learn.mbt` |
| `Result` 工具函数（`map_ok`/`map_err`/`result_to_option`） | ✅ | `error/error.mbt` |
| 安全运算（`safe_div`/`safe_mod`/`safe_isqrt`） | ✅ | `error/error.mbt` |
| 字符解析（`parse_digit`/`parse_int_safe`） | ✅ | `error/error.mbt` |

## 方法、trait 与多态

| 特性 | 状态 | 演示位置 |
|------|------|---------|
| 关联函数 `Type::method` | ✅ | `method_and_trait/cmd/main/define_method.mbt` |
| 泛型方法 `fn[T]` | ✅ | `method_and_trait/cmd/main/define_method.mbt` |
| trait 约束 `T : Add` | ✅ | `method_and_trait/cmd/main/define_method.mbt` |
| `trait` 定义与 `impl` | ✅ | `method_and_trait/cmd/main/trait.mbt` |
| `pub(open) trait` | ✅ | `method_and_trait/cmd/main/trait.mbt` |
| trait 继承 `A : B + C` | ✅ | `method_and_trait/cmd/main/trait.mbt` |
| 默认方法 `= _` | ✅ | `method_and_trait/cmd/main/trait.mbt` |
| `extend ... with` | ✅ | `method_and_trait/cmd/main/trait.mbt` |
| 动态多态 `Array[&Animal]` | ✅ | `method_and_trait/cmd/main/trait.mbt` |
| 运算符重载 `Add`/`Sub`/`Neg`/`Eq` | ✅ | `method_and_trait/cmd/main/operator_overload.mbt` |
| `#alias` 方法别名 | ✅ | `method_and_trait/cmd/main/alias.mbt` |
| `#as_free_fn` 自由函数 | ✅ | `method_and_trait/cmd/main/alias.mbt` |
| `OpGet`/`OpSet`/`OpView` (`_[_]`/`_[_]=_`/`_[_:_]`) | ✅ | `method_and_trait/cmd/main/alias.mbt` |
| 库包 `Shape` trait + 实现 | ✅ | `method_and_trait/method_and_trait.mbt` |
| 泛型工具函数（`total_area`/`max_area`） | ✅ | `method_and_trait/method_and_trait.mbt` |

## 包与工程

| 特性 | 状态 | 演示位置 |
|------|------|---------|
| workspace `moon.work` | ✅ | 根目录 |
| 库包与可执行包协作 | ✅ | `examine` |
| `import` 依赖声明 | ✅ | `examine/cmd/main/moon.pkg` |
| 白盒测试 `_wbtest.mbt` | ✅ | 各模块根包 `_wbtest.mbt` |
| 黑盒测试 `_test.mbt` | ✅ | 各模块根包 `_test.mbt` |
| 文档测试 ` ```mbt check ` | ✅ | `basics/cmd/main/*.mbt` |
| 库包与可执行包双向协作 | ✅ | `basics`/`error`/`method_and_trait` 根包 + `cmd/main` |
| 模块级 `AGENTS.md` | ✅ | 各模块根目录 `AGENTS.md` |

## 尚未覆盖（进阶话题）

| 特性 | 状态 | 备注 |
|------|------|------|
| C FFI `extern "c"` | ❌ | 见官方文档 |
| JS FFI `extern "js"` | ❌ | 见官方文档 |
| `moon prove` 形式化验证 | ❌ | 见官方文档 |
| mooncakes 第三方包 | ❌ | 见官方文档 |
| 并发与异步 | ❌ | 见官方文档 |
| `Json` 类型 | ❌ | 见官方文档 |
