# 示例索引与预期输出

> 本文档汇总各模块可运行示例及其预期输出，便于学习者对照验证。

## basics — 基础语法演示

**运行**：`moon -C basics run cmd/main`

**预期输出**（节选关键部分）：

```
Hello, world!
-----------------
true
42
14
1000000000000000000000000
129900
255
10
true
-----------------
兔rabbit
...
-----------------
false 100 text 3.14
-----------------
没有值
错误 出错了
-----------------
top score is 92
fixed_array_1[2] is 70
88 92
-----------------
key:x value:1
key:y value:2
key:z value:3
-----------------
6
3
100
9
-----------------
你好，Moonbit
你好，Moonbit
你好，Moonbit
-----------------
3
-----------------
42
-----------------
initial: 1
-----------------
早上好
-----------------
tennis
-----------------
None
-----------------
有10张票
...
售罄
-----------------
...
```

**测试**：`moon -C basics test` — 80 个测试（26 个 cmd/main 文档测试 + 6 个库包文档测试 + 6 个黑盒 + 7 个白盒 + 35 个 `test` 块）

---

## error — 错误处理演示

**运行**：`moon -C error run cmd/main`

**预期输出**：

```
Divide by zero
Error
0
--- 库函数演示 ---
safe_div(10, 2) = 5
safe_div(10, 0) 出错：除零
safe_isqrt(16) = 4
parse_digit('7') = 7
parse_digit('x') 出错：非法字符
```

**测试**：`moon -C error test` — 26 个测试（9 个库包文档测试 + 9 个黑盒 + 8 个白盒 + 原有 cmd/main 测试）
- `suberror` 模式匹配（`CustomError`/`E1`）
- `try/catch/noraise` 三段式
- `Result` 互转
- 泛型 `map` 家族
- `f2`/`g` 的 `Failure` 捕获
- `unwrap_or_error` 错误路径

---

## examine — 库包协作演示

**运行**：`moon -C examine run cmd/main`

**预期输出**：

```
及格人数:2
```

**测试**：`moon -C examine test` — 11 个测试（4 个文档测试 + 4 个黑盒 + 3 个白盒）
- `is qualified`：3 个断言（50<60 Fail、60>=60 Pass、13>=7 Pass）
- `count qualified students`：2 个断言（阈值 10 全及格、阈值 50 仅 2 人及格）

---

## method_and_trait — 方法与 trait 演示

**运行**：`moon -C method_and_trait run cmd/main`

**预期输出**（节选）：

```
3
6
0
100
21
6
720
tom 总分（原名score_sum）：177
tom 总分（alias别名total）：177
tom 总分（自由函数total）：177
lily 总分（内部私有函数）：178
lily 总分（私有自由函数）：178
s1 + s2：语文=145, 数学=160
s1 - s2：语文=25, 数学=20
s1 == s2 ? false
-s1：语文=-85, 数学=-90
a + b = 2
x: 1,y: 2
y
x: 23,y: 2
23
...
draw point at (1, 2)
10
MyCustomType
42
-1
false
true
矩形面积：12
矩形周长：14
圆形面积：12.566370614359172
圆形周长：12.566370614359172
```

**测试**：`moon -C method_and_trait test` — 19 个测试（3 个库包文档测试 + 6 个黑盒 + 8 个白盒 + 原有 cmd/main 测试）

---

## 如何刷新预期输出

当修改源码导致输出变化时：

```bash
moon -C <module> run cmd/main          # 查看新输出
moon -C <module> test --update         # 刷新快照测试（如有）
```

> **注意**：`debug_inspect` 的快照内容写在源码 `content=(#|...)` 中，
> 修改实现后需手动更新或运行 `moon test --update`。
