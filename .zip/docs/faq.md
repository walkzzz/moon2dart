# 常见问题与错题本

> 本文档记录学习过程中常见问题、典型编译/运行错误及其修复方案。
> 遇到报错先查本表，修复后若有新模式请补充。

## 环境与工具链

### Q1: `moon` 命令找不到？

**原因**：工具链未安装或未加入 PATH。

**修复**：
```bash
# 重新安装
curl -fsSL https://cli.moonbitlang.com/install.sh | bash
# 或 Windows
irm https://cli.moonbitlang.com/install.ps1 | iex
```

确认 `~/.moon/bin` 在系统 PATH 中。

### Q2: `moon check` 报 "package not found"？

**原因**：在非 workspace 根目录执行，或模块名拼写错误。

**修复**：
- workspace 级命令须在含 `moon.work` 的根目录执行
- 单模块命令用 `-C`：`moon -C basics check`

### Q3: 切换 MoonBit 版本后构建异常？

**原因**：旧构建缓存与新编译器不兼容。

**修复**：
```bash
moon clean   # 清理 _build
moon check
```

---

## 类型与编译错误

### E1: `Warning (unused_value): Unused toplevel variable`

**示例**：
```
let state1 : String = if temp < 0 { "结冰" } else { "液态" }
```

**原因**：顶层 `let` 绑定未被任何函数引用。MoonBit 顶层 `let` 不是全局变量，需在函数中消费。

**修复方案**（按场景选择）：
1. **演示用，故意保留**：加行内注释说明，并在 `fn init { ... }` 或测试中引用
2. **确实不需要**：删除
3. **需在启动时执行**：改用 `fn init { let state1 = ...; println(state1) }`

**本工程实例**：`basics/cmd/main/if_expr.mbt` 的 `state1`/`state2` 演示 if 表达式，
已通过文档注释说明"演示用"并在 `if_else()` 中引用同类表达式。

### E2: `Warning (unused_constructor): Variant 'X' is never constructed`

**原因**：枚举变体已定义但从未构造。

**修复方案**：
1. **演示枚举语法**：在测试中构造一次，或加注释说明"演示 suberror 语法，故意未构造"
2. **确实不需要**：删除该变体

**本工程实例**：`error/cmd/main/error_learn.mbt` 的 `E3::A/B/C` 演示 suberror 带标签字段语法，
已在测试中构造以消除 warning。

### E3: `Warning (todo): unfinished code`

**示例**：
```
fn f11() -> Unit raise E1 {
  ...
}
```

**原因**：`...` 是 MoonBit 的 `todo` 占位符，表示未完成代码。

**修复方案**：
1. **教学演示 `...` 语法**：保留并加注释说明"演示 todo 占位"
2. **需完成实现**：替换 `...` 为具体实现

**本工程实例**：`error/cmd/main/main.mbt` 的 `f11`/`f12`/`f13` 演示 `raise E` 签名与 `try/catch`，
`...` 体改为 `raise` 具体错误以消除 warning 并演示完整流程。

### E4: `Warning (unused_value): Unused variable 'self'`

**原因**：方法实现中未使用 `self` 参数。

**修复**：若确实不需 self，改名为 `_self`；若需使用，补充逻辑。

**本工程实例**：`method_and_trait/cmd/main/trait.mbt` 的 `MyCustomType::output` 改为 `_self`。

### E5: match 不穷尽（non-exhaustive）

**原因**：`match` 未覆盖所有可能分支。

**修复**：补充缺失分支，或用 `_ =>` 兜底。对 `Option` 须同时处理 `Some` 与 `None`，
对 `Result` 须同时处理 `Ok` 与 `Err`。

### E6: `suberror` 构造器在黑盒测试中不可见

**示例**：
```
Error: The type @walkzzz/error.MathError is a abstract type
and not an enum or enumview, so it does not have any constructor patterns.
```

**原因**：`suberror` 类型的构造器（如 `DivByZero`）仅在定义包内可见，黑盒测试（`_test.mbt`）和文档测试中无法引用。

**修复**：
- **黑盒测试**：用 `is Err(_)` 代替 `is Err(DivByZero)`，仅检查是否出错
- **白盒测试**（`_wbtest.mbt`）：可直接用 `is Err(DivByZero)` 精确匹配
- **构造错误值**：黑盒中无法直接构造 `DivByZero`，需通过库函数获取（如 `@error.safe_div(1, 0)` 返回 `Err(DivByZero)`）

### E7: `derive(Show)` 弃用警告

**示例**：
```
Warning (deprecated_syntax): `derive(Show)` is deprecated.
Use `derive(Debug)` or manually implement the `Show` trait instead.
```

**修复**：将 `derive(Debug, Show)` 改为 `derive(Debug, Eq)`。`Debug` 已足够用于 `println` 输出。

### E8: `unresolved_type_variable` 警告

**示例**：
```
Warning (unresolved_type_variable): The type of this expression is
(Result[Int, _/0], (Int) -> Int) -> Result[Int, _/0],
which contains unresolved type variables. The type variable is default to Unit.
```

**原因**：泛型函数调用时类型变量无法从上下文推断，默认为 `Unit`。常见于 `Ok(5)` 或 `Err("bad")` 无显式类型标注。

**修复**：
- 加显式标注：`let ok : Result[Int, String] = Ok(42)`，然后用变量传入泛型函数
- 或从库函数获取有类型的值：`let ok = @error.safe_div(10, 2)`
- 此警告本身**无害**，类型变量默认为 `Unit` 不影响 `is` 模式匹配，但应消除以保持 0 warning

**本工程实例**：`error/error.mbt`、`error_test.mbt`、`error_wbtest.mbt` 中所有裸 `Ok`/`Err`/`None` 均已添加显式类型标注，`moon check` 达到 0 warning。

### E9: `fold` 标签参数语法

**错误**：`arr.iter().fold(0, fn(acc, x) { acc + x })` 编译失败。

**修复**：`fold` 的初始值必须用标签参数 `init~`：
```moonbit
arr.iter().fold(init=0, fn(acc, x) { acc + x })
```

### E10: 空数组类型推断为 `Unit`

**示例**：
```
Error: Type Unit does not implement trait Shape: no `impl` is defined
```

**原因**：`[]` 无上下文时类型推断为 `Array[Unit]`，`Unit` 未实现所需 trait。

**修复**：加显式类型标注：
```moonbit
let empty : Array[Rectangle] = []
```

---

## 错误处理专题

### E11: `raise` 在非 `raise` 函数中使用

**错误**：函数签名未声明 `raise E`，但函数体 `raise e`。

**修复**：在签名中声明 `raise E`（或 `raise` 表示 `raise Error`）：
```moonbit
fn div(x : Int, y : Int) -> Int raise DivError { ... }
```

### E12: `try` 块中 `catch` 后 `noraise` 的语义

**易混淆**：`try expr catch { e => ... } noraise { v => ... }`
- `catch`：`expr` 抛错时执行
- `noraise`：`expr` 正常返回时执行（`v` 是返回值）

**注意**：`noraise` 分支不是"不抛错"，而是"处理正常返回值"。

### E13: `raise` vs `raise?` vs `noraise`

| 标注 | 含义 | 适用场景 |
|------|------|---------|
| `raise E` | 可能抛出 `E`（或其子类型） | 函数会抛错 |
| `raise?` | 可能抛出"某种"错误（多态） | 泛型错误传播 |
| `noraise` | 保证不抛错 | 纯函数、已处理所有错误 |

---

## 包与工程

### E14: `@lib` 导入失败

**原因**：`moon.pkg` 中 `import` 被注释或模块名不匹配。

**修复**：取消注释并确保包名与 `moon.mod` 的 `name` 一致：
```json
// cmd/main/moon.pkg
import {
  "walkzzz/examine" @examine,
}
```

### E15: workspace 中某模块 `moon check` 失败但单独通过

**原因**：workspace 级检查可能因依赖解析顺序不同而暴露问题。

**修复**：
```bash
moon clean
moon check   # workspace 级重新检查
```

---

## 测试

### E16: 文档测试 ` ```mbt check ` 不执行

**原因**：被测函数非 `pub`，或测试块语法错误。

**修复**：
- 确保被测项为 `pub`（文档测试是黑盒的，通过 `@包名.函数` 调用）
- 检查代码块语言标记为 `mbt check`

### E17: `debug_inspect` 快照不匹配

**原因**：实现变化导致输出改变。

**修复**：
```bash
moon test --update   # 刷新快照
```
或手动更新源码中 `content=(#|...)` 的期望值。

---

## v0.10.9 语法限制

> 以下特性在官方文档 v0.10.12 中有描述，但工具链 v0.10.9 尚不支持。
> 演示代码中用等价写法替代并注释说明。

### E18: 列表推导式 `[expr for x in range]` 不支持

**错误**：`Parse error, unexpected token 'for'`

**修复**：用显式 `for` 循环 + `push` 替代：
```moonbit
// 不支持：let squares = [x * x for x in 0..<10]
// 等价写法：
let squares : Array[Int] = []
for x in 0..<10 {
  squares.push(x * x)
}
```

### E19: 展开运算符 `...arr` 不支持

**错误**：`Parse error, unexpected token '...'`

**修复**：用手动拼接循环替代：
```moonbit
// 不支持：let b = [0, ...a, 4]
// 等价写法：
let b : Array[Int] = [0]
for x in a { b.push(x) }
b.push(4)
```

### E20: 带标签 break/continue `break label with value` 不支持

**错误**：`'break' outside of a loop` 或 `Parse error, unexpected token 'with'`

**修复**：用标志变量 + 普通 `break` 替代：
```moonbit
// 不支持：break outer with (i, j)
// 等价写法：
let mut found = (-1, -1)
let mut done = false
for i in 0..<5 {
  if done { break }
  for j in 0..<5 {
    if condition { found = (i, j); done = true; break }
  }
}
```

### E21: `var` 是保留关键字

**错误**：`reserved_keyword: The word 'var' is reserved`

**修复**：用 `let mut` 替代：
```moonbit
// 不支持：var result = 1
// 正确写法：
let mut result = 1
```

### E22: 局部函数不能有标签参数

**错误**：`Only toplevel functions can have labelled arguments`

**修复**：将标签参数改为普通参数，或移至顶层：
```moonbit
// 不支持（局部函数）：
fn power(base~ : Int, exp~ : Int) -> Int { ... }
// 正确写法（普通参数）：
fn power(base : Int, exp : Int) -> Int { ... }
```

### E23: `Number(v)` 模式缺少参数标记

**警告**：`missing_pattern_arguments: The argument(s) repr of constructor Number are omitted`

**修复**：添加 `..` 到参数列表末尾：
```moonbit
// 有警告：Some(Number(v)) => ...
// 正确写法：Some(Number(v, ..)) => ...
```

### E24: Map 模式缺少 rest mark

**警告**：`missing_rest_mark: Map patterns are always open, so '..' should be added`

**修复**：在模式末尾添加 `..`：
```moonbit
// 有警告：{ "x": Number(x) } => ...
// 正确写法：{ "x": Number(x, ..), .. } => ...
```

---

## 命名约定

本工程遵循 `snake_case` 命名（见 AGENTS.md 用户偏好）：
- 函数/变量：`snake_case`（如 `is_qualified`、`count_qualified_students`）
- 类型/枚举/trait：`PascalCase`（MoonBit 强制，如 `Student`、`ExamResult`）
- 模块包名：`snake_case`（如 `method_and_trait`）

> **注意**：MoonBit 类型名必须 `PascalCase`，这是语言强制要求，与 `snake_case` 偏好不冲突。
