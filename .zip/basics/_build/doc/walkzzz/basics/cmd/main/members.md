# cmd/main — MoonBit 基础类型演示

本包按主题拆分文件，逐一演示 MoonBit 的基础类型与字面量语法。
运行方式：`moon run cmd/main`。

## Unit 类型（unit.mbt）

演示 MoonBit 中的 `Unit` 类型——只有一个值 `()` 的类型，相当于其他语言中的
void。函数若无实际返回值，可显式标注 `-> Unit`，也可以省略返回类型
（编译器默认推断为 Unit）。

## 数字与布尔（numbers.mbt）

演示各种数字字面量写法与布尔运算：

- 下划线分隔的十进制字面量（仅提升可读性，不影响数值）
- 十六进制（`0x`）与二进制（`0b`）字面量
- 类型标注的 Int16 与带后缀的 UInt64（`UL`）、BigInt（`N`）
- Bool 类型上的逻辑与（`&&`）、逻辑非（`!`）

## 字符串与字符（strings.mbt）

演示 String 与 Char 的多种字面量写法：

- 普通双引号字符串（支持 `\n` 等转义与 `\{}` 插值）
- 多行原始字符串 `#|`（不处理转义，也不做插值）
- 多行插值字符串 `$|`（不处理转义，但会求值 `\{expr}`）
- Char 字面量：单引号字符与 `\u{}` / `\uXXXX` 码点转义

## 元组（tuple.mbt）

演示元组类型：

- 元组用圆括号包裹，元素类型可以不同，长度固定
- 函数可以返回元组，调用方用解构（destructuring）一次性取出各分量
- 与结构体不同，元组按位置访问、无需字段名，适合临时打包少量值

## Option 与 Result（option_result.mbt）

演示两个最常用的内置枚举：

- `Option[T]`：表示"可能有值（Some）也可能没有值（None）"，用于可空返回
- `Result[T, E]`：表示"成功（Ok）或失败（Err）"，用于显式错误处理

两者都通过 match 模式匹配来消费，编译器强制穷尽所有分支。

## 数组（array.mbt）

演示几种数组类型与切片：

- `Array[T]`：可变长数组，按引用语义就地修改
- `FixedArray[T]`：定长数组，长度创建后不可变，但元素可修改
- 切片 `arr[start:end]`：零拷贝视图（`ArrayView`），不复制底层数据

索引从 0 开始，越界访问会 panic；安全访问可用 `get()` 返回 Option。

## Map（map.mbt）

演示内置的 `Map[String, Int]`：

- 可变映射，保持插入顺序
- 字面量语法 `{ "key": value, ... }`
- `for k, v in map` 同时迭代键与值，顺序即插入顺序

## 程序入口（main.mbt）

本包入口点，按顺序调用上述各演示函数。每个演示函数位于同包下的独立文件中
（文件不划分命名空间，同包内所有顶层定义互相可见，可直接调用）。

---
# Documentation
|Value|description|
|---|---|
|[arrays](#arrays)||
|[maps](#maps)||
|[numbers](#numbers)||
|[option\_result](#option_result)||
|[print\_hello](#print_hello)||
|[strings](#strings)||
|[tuples](#tuples)||

## arrays

```moonbit
:::source,walkzzz/basics/cmd/main/array.mbt,11:::fn arrays() -> Unit
```

 演示数组索引、定长数组修改与切片视图。

 #### 测试

 ```mbt check
 test "arrays 演示可正常调用" {
   @main.arrays()
 }
 ```

## maps

```moonbit
:::source,walkzzz/basics/cmd/main/map.mbt,11:::fn maps() -> Unit
```

 演示 Map 字面量构造与迭代。

 #### 测试

 ```mbt check
 test "maps 演示可正常调用" {
   @main.maps()
 }
 ```

## numbers

```moonbit
:::source,walkzzz/basics/cmd/main/numbers.mbt,14:::fn numbers() -> Unit
```

 演示数字字面量与布尔运算。

 MoonBit 的整数字面量会根据上下文类型自动消歧：
当类型已知时（如 `small : Int16`），字面量 `42` 会被解释为对应类型。

 #### 测试

 ```mbt check
 test "numbers 演示可正常调用" {
   @main.numbers()
 }
 ```

## option\_result

```moonbit
:::source,walkzzz/basics/cmd/main/option_result.mbt,11:::fn option_result() -> Unit
```

 演示 Option 与 Result 的 match 处理。

 #### 测试

 ```mbt check
 test "option_result 演示可正常调用" {
   @main.option_result()
 }
 ```

## print\_hello

```moonbit
:::source,walkzzz/basics/cmd/main/unit.mbt,14:::fn print_hello() -> Unit
```

 文档：打印问候语。

 演示 `-> Unit` 返回类型标注：`println` 本身返回 `Unit`，
因此本函数没有有意义的返回值，仅产生副作用（向标准输出打印）。

 #### 测试

 ```mbt check
 test "print_hello 可正常调用" {
   @main.print_hello()
 }
 ```

## strings

```moonbit
:::source,walkzzz/basics/cmd/main/strings.mbt,11:::fn strings() -> Unit
```

 演示多行字符串与 Char 字面量。

 #### 测试

 ```mbt check
 test "strings 演示可正常调用" {
   @main.strings()
 }
 ```

## tuples

```moonbit
:::source,walkzzz/basics/cmd/main/tuple.mbt,14:::fn tuples() -> Unit
```

 演示元组的打包与解构。

 内部 `pack` 函数把四个不同类型的值打包成一个四元组返回，
调用方再用 `let (a, b, c, d) = quad` 按位置解构。

 #### 测试

 ```mbt check
 test "tuples 演示可正常调用" {
   @main.tuples()
 }
 ```
