# walkzzz/basics

MoonBit 基础语法学习项目，按主题演示语言核心类型与字面量语法。

## 项目结构

```
basics
├── basics.mbt          # 根包（占位）
└── cmd/main            # 演示程序（可执行包）
    ├── main.mbt            # 入口：按顺序调用各演示函数
    ├── unit.mbt            # Unit 类型与 -> Unit 返回标注
    ├── numbers.mbt         # 数字字面量（下划线分组、0x/0b、UL/N 后缀）与布尔运算
    ├── strings.mbt         # 多行字符串 #|（原始）与 $|（插值）、Char 码点转义
    ├── tuple.mbt           # 元组打包与解构
    ├── option_result.mbt   # Option / Result 的 match 穷尽处理
    ├── array.mbt           # Array / FixedArray / 切片零拷贝视图
    ├── map.mbt             # Map 字面量与插入顺序迭代
    └── README.md           # 包级文档（详见 cmd/main/README.md）
```

## 常用命令

在项目根目录执行：

| 命令 | 作用 |
|------|------|
| `moon run cmd/main` | 运行全部基础类型演示 |
| `moon test cmd/main` | 运行测试（含文档注释内嵌的 doc test） |
| `moon check` | 类型检查 |
| `moon fmt` | 格式化代码 |
| `moon doc` | 生成 HTML 文档到 `_build/doc/` |
| `moon doc --serve` | 启动本地文档站点（默认 127.0.0.1:3000） |

## 文档注释约定

本项目遵循 MoonBit 官方[注释与文档](https://docs.moonbitlang.cn/language/docs.html)规范：

- `///|` 分隔顶层代码块
- `///` 为顶层条目编写 Markdown 文档注释，公开 API 附带
  ` ```mbt check ` 文档测试（黑盒测试，要求被测项为 `pub`）
- `//` 为行内代码注释
- 包级模块说明放在包目录的 `README.md`，由 `moon doc` 收录进文档站

---
# Documentation