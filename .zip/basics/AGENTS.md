# walkzzz/basics — 基础语法教学模块

## 模块职责

演示 MoonBit 基础语法与核心类型，同时提供数学工具库函数（gcd/lcm/is_prime/reverse_string/sum_array/average）。

## 项目结构

```
basics
├── basics.mbt              # 库包：数学与字符串工具函数（pub fn gcd/lcm/is_prime/reverse_string/sum_array/average）
├── basics_test.mbt         # 黑盒测试：通过 @basics 访问公开 API
├── basics_wbtest.mbt       # 白盒测试：直接调用包内函数（含私有 _array_length）
├── moon.mod                # 模块元数据
├── moon.pkg                # 根包配置（库包）
└── cmd/main                # 演示程序（可执行包）
    ├── main.mbt                # 入口：按顺序调用各演示函数
    ├── unit.mbt ~ fold.mbt     # 18 个主题文件
    └── moon.pkg                # 包配置（executable，import "walkzzz/basics"）
```

## 公开 API

| 函数 | 签名 | 说明 |
|------|------|------|
| `gcd` | `(Int, Int) -> Int` | 最大公约数 |
| `lcm` | `(Int, Int) -> Int` | 最小公倍数 |
| `is_prime` | `(Int) -> Bool` | 素数判定 |
| `reverse_string` | `(String) -> String` | 字符串反转 |
| `sum_array` | `(Array[Int]) -> Int` | 数组求和 |
| `average` | `(Array[Int]) -> Int` | 数组平均值（整数除法） |

## 测试约定

- **黑盒测试**（`basics_test.mbt`）：通过 `@basics.函数名` 访问公开 API，验证对外行为
- **白盒测试**（`basics_wbtest.mbt`）：直接调用包内函数（含私有 `_array_length`），验证内部逻辑
- **文档测试**（` ```mbt check `）：每个 `pub fn` 附带内嵌文档测试

## 常用命令

```bash
moon -C basics check          # 类型检查
moon -C basics test           # 运行全部测试
moon -C basics run cmd/main   # 运行演示程序
moon -C basics info           # 生成 .mbti 接口文件
moon -C basics fmt            # 格式化
```

## 编码约定

- `///|` 分隔顶层代码块
- `///` 为 `pub` 项编写文档注释，附带 ` ```mbt check ` 文档测试
- `//` 为行内注释
- 私有函数以 `_` 前缀标记（如 `_array_length`）
