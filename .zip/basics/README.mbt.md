# walkzzz/basics

MoonBit 基础语法学习项目，按主题演示语言核心类型与字面量语法。

## 项目结构

```
basics
├── basics.mbt              # 根包（占位）
├── basics_test.mbt         # 黑盒测试（占位）
├── basics_wbtest.mbt       # 白盒测试（占位）
├── moon.mod                # 模块元数据
├── moon.pkg                # 根包配置
├── README.mbt.md           # 本文件
├── README.md               # 包级文档（GitHub 风格，供 moon doc 收录）
└── cmd/main                # 演示程序（可执行包）
    ├── main.mbt                # 入口：按顺序调用各演示函数
    ├── unit.mbt                # Unit 类型与 -> Unit 返回标注
    ├── numbers.mbt             # 数字字面量（下划线分组、0x/0b、UL/N 后缀）与布尔运算
    ├── strings.mbt             # 多行字符串 #|（原始）与 $|（插值）、Char 码点转义
    ├── tuple.mbt               # 元组打包与解构
    ├── option_result.mbt       # Option / Result 的 match 穷尽处理
    ├── array.mbt               # Array / FixedArray / 切片零拷贝视图
    ├── map.mbt                 # Map 字面量与插入顺序迭代
    ├── functions.mbt           # 函数定义、declare 前向声明、局部/匿名函数
    ├── closures.mbt            # 闭包捕获与 each 遍历
    ├── labelled.mbt            # 标签参数 name~ 与可选参数 ? 及默认值
    ├── if_expr.mbt             # if/else if/else 表达式
    ├── match_expr.mbt          # match 范围模式与字符串模式
    ├── guard.mbt               # guard ... else 守卫
    ├── while_loop.mbt          # while/nobreak 循环
    ├── for_loop.mbt            # C 风格 for 与九九乘法表
    ├── for_in.mbt              # for-in 遍历数组/字符串/Map
    ├── iterator.mbt            # 迭代器 filter/collect 链
    ├── fold.mbt                # fold 归约求和与求积
    ├── moon.pkg                # 包配置（executable）
    └── README.md               # 包级文档（详见 cmd/main/README.md）
```

## 常用命令

在工程根目录执行：

| 命令 | 作用 |
|------|------|
| `moon -C basics run cmd/main` | 运行全部基础类型演示 |
| `moon -C basics test` | 运行测试（含文档注释内嵌的 doc test） |
| `moon -C basics check` | 类型检查 |
| `moon -C basics fmt` | 格式化代码 |
| `moon -C basics doc` | 生成 HTML 文档到 `_build/doc/` |

也可在 workspace 根目录直接 `moon run`/`moon test`/`moon check` 作用于全部模块。

## 文档注释约定

本项目遵循 MoonBit 官方[注释与文档](https://docs.moonbitlang.cn/language/docs.html)规范：

- `///|` 分隔顶层代码块
- `///` 为顶层条目编写 Markdown 文档注释，公开 API 附带
  ` ```mbt check ` 文档测试（黑盒测试，要求被测项为 `pub`）
- `//` 为行内代码注释
- 包级模块说明放在包目录的 `README.md`，由 `moon doc` 收录进文档站

## 学习目标

完成本模块后，学习者应能：

- 读写 MoonBit 基础代码，理解类型标注与类型推断
- 使用 `Option`/`Result`/`match` 处理可选与分支
- 使用集合类型（`Array`/`FixedArray`/`Map`）与迭代器链
- 理解函数定义、闭包、标签参数与控制流表达式
