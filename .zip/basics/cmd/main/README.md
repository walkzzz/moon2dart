# cmd/main — MoonBit 基础语法演示

本包按主题拆分文件，逐一演示 MoonBit 的基础类型与字面量语法。
运行方式：`moon -C basics run cmd/main`。

## 文件清单与主题

| 文件 | 主题 | 关键概念 |
|------|------|---------|
| `main.mbt` | 程序入口 | 按顺序调用各演示函数 |
| `unit.mbt` | Unit 类型 | `-> Unit`、副作用、`println` |
| `numbers.mbt` | 数字与布尔 | 下划线分组、`0x`/`0b`、`Int16`/`UInt64`/`BigInt`、`&&`/`!` |
| `strings.mbt` | 字符串与字符 | `#|` 原始多行、`$|` 插值多行、`Char`、`\u{}` |
| `tuple.mbt` | 元组 | 打包、解构、位置访问 |
| `option_result.mbt` | Option / Result | `Some`/`None`、`Ok`/`Err`、match 穷尽 |
| `array.mbt` | 数组 | `Array`、`FixedArray`、切片视图 |
| `map.mbt` | Map | 字面量、插入顺序迭代 |
| `functions.mbt` | 函数 | `declare` 前向声明、局部函数、匿名函数、关联函数 |
| `closures.mbt` | 闭包 | 捕获外部变量、`each` 遍历 |
| `labelled.mbt` | 标签参数 | `name~` 必传标签、`?` 可选参数、默认值 |
| `if_expr.mbt` | 条件表达式 | `if`/`else if`/`else` 作为表达式产生值 |
| `match_expr.mbt` | 模式匹配 | 范围模式 `0..<6`、字符串模式、通配 `_` |
| `guard.mbt` | 守卫 | `guard cond else { fallback }` 前置条件检查 |
| `while_loop.mbt` | while 循环 | `while`/`nobreak` 子句 |
| `for_loop.mbt` | for 循环 | C 风格 `for`、九九乘法表嵌套循环 |
| `for_in.mbt` | for-in | 遍历数组/字符串/带索引/Map |
| `iterator.mbt` | 迭代器 | `iter().filter().collect()` 链式调用 |
| `fold.mbt` | fold 归约 | `fold(Int::add, init=0)` 求和、`fold(Int::mul, init=1)` 求积 |

## 详细说明

### Unit 类型（unit.mbt）

演示 MoonBit 中的 `Unit` 类型——只有一个值 `()` 的类型，相当于其他语言中的
void。函数若无实际返回值，可显式标注 `-> Unit`，也可以省略返回类型
（编译器默认推断为 Unit）。

### 数字与布尔（numbers.mbt）

- 下划线分隔的十进制字面量（仅提升可读性，不影响数值）
- 十六进制（`0x`）与二进制（`0b`）字面量
- 类型标注的 Int16 与带后缀的 UInt64（`UL`）、BigInt（`N`）
- Bool 类型上的逻辑与（`&&`）、逻辑非（`!`）

### 字符串与字符（strings.mbt）

- 普通双引号字符串（支持 `\n` 等转义与 `\{}` 插值）
- 多行原始字符串 `#|`（不处理转义，也不做插值）
- 多行插值字符串 `$|`（不处理转义，但会求值 `\{expr}`）
- Char 字面量：单引号字符与 `\u{}` / `\uXXXX` 码点转义

### 元组（tuple.mbt）

- 元组用圆括号包裹，元素类型可以不同，长度固定
- 函数可以返回元组，调用方用解构（destructuring）一次性取出各分量
- 与结构体不同，元组按位置访问、无需字段名，适合临时打包少量值

### Option 与 Result（option_result.mbt）

- `Option[T]`：表示"可能有值（Some）也可能没有值（None）"，用于可空返回
- `Result[T, E]`：表示"成功（Ok）或失败（Err）"，用于显式错误处理

两者都通过 match 模式匹配来消费，编译器强制穷尽所有分支。

### 数组（array.mbt）

- `Array[T]`：可变长数组，按引用语义就地修改
- `FixedArray[T]`：定长数组，长度创建后不可变，但元素可修改
- 切片 `arr[start:end]`：零拷贝视图（`ArrayView`），不复制底层数据

索引从 0 开始，越界访问会 panic；安全访问可用 `get()` 返回 Option。

### Map（map.mbt）

- 可变映射，保持插入顺序
- 字面量语法 `{ "key": value, ... }`
- `for k, v in map` 同时迭代键与值，顺序即插入顺序

### 函数（functions.mbt）

- 普通函数定义：最后一个表达式即返回值，无需 `return`
- `declare` 前向声明：先声明签名后提供实现，用于互递归或接口分离
- 局部函数：定义在函数内部，仅外层作用域可见
- 匿名函数：`(fn(x) { body })(arg)` 立即调用
- 关联函数：`Type::method` 形式

### 闭包（closures.mbt）

局部函数捕获外层作用域的变量，形成闭包。`each(x => ...)` 对数组每个元素调用 lambda。

### 标签参数（labelled.mbt）

- `name~ : T`：标签参数，调用时 `name=value`，顺序无关
- `name? : T = default`：可选参数，带默认值，调用时可省略

### 条件表达式（if_expr.mbt）

`if`/`else if`/`else` 是表达式而非语句，每个分支须返回相同类型。可在顶层 `let` 中直接绑定。

### 模式匹配（match_expr.mbt）

- 范围模式 `0..<6`：匹配半开区间
- 字符串模式 `"sunny"`：精确匹配
- 通配 `_`：兜底匹配剩余
- 分支体可为任意表达式，包括嵌套 `if`

### 守卫（guard.mbt）

`guard cond else { fallback }`：条件为假时立即返回 `fallback`，避免深层嵌套。常用于前置条件检查。

### while 循环（while_loop.mbt）

`while cond { body } nobreak { after }`：`nobreak` 块在循环正常结束时执行，`break` 跳出时不执行。

### for 循环（for_loop.mbt）

C 风格 `for init; cond; update { body }`，支持嵌套实现九九乘法表。

### for-in（for_in.mbt）

- `for x in array`：遍历元素
- `for _ in array`：仅计数
- `for c in string`：遍历字符
- `for i, x in array`：带下标
- `for k, v in map`：遍历键值对

### 迭代器（iterator.mbt）

`iter().filter(pred).collect()` 链式调用，惰性求值后收集为新数组。

### fold 归约（fold.mbt）

`iter().fold(combine, init=acc)`：从 `acc` 开始依次合并每个元素。
- `fold(Int::add, init=0)` 实现求和
- `fold(Int::mul, init=1)` 实现求积

### 程序入口（main.mbt）

本包入口点，按顺序调用上述各演示函数。每个演示函数位于同包下的独立文件中
（文件不划分命名空间，同包内所有顶层定义互相可见，可直接调用）。
