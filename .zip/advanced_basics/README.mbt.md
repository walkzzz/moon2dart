# walkzzz/advanced_basics

MoonBit 基础进阶教学模块，覆盖官方文档 [基础](https://docs.moonbitlang.cn/language/fundamentals.html) 中进阶主题。

## 主题清单

| 文件 | 主题 |
|------|------|
| `byte.mbt` | Byte/Bytes 字面量与操作 |
| `ref.mbt` | Ref[T] 可变引用 |
| `json.mbt` | Json 字面量与模式匹配 |
| `array_view.mbt` | ArrayView/MutArrayView 切片 |
| `comprehension.mbt` | 列表推导式 |
| `labelled_loop.mbt` | 带标记 Continue/Break |
| `defer.mbt` | defer/errdefer 表达式 |
| `partial_app.mbt` | 部分应用 |
| `pipeline.mbt` | 管道 \|> |
| `is_expr.mbt` | is 表达式 |
| `spread.mbt` | 展开运算符 ... |
| `overloaded_literal.mbt` | 重载字面量 |

## 运行

```bash
moon -C advanced_basics run cmd/main
moon -C advanced_basics test
```
