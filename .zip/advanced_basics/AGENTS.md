# walkzzz/advanced_basics — 基础进阶教学模块

## 模块职责

演示 MoonBit 基础进阶特性：Byte/Bytes、Ref[T]、Json、ArrayView/MutArrayView、列表推导式、带标签循环、defer、部分应用、管道、is 表达式、展开运算符、重载字面量。同时提供工具库函数。

## 项目结构

```
advanced_basics
├── advanced_basics.mbt              # 库包：Byte/Ref/Json/切片/推导式/管道工具函数
├── advanced_basics_test.mbt         # 黑盒测试：通过 @advanced_basics 访问公开 API
├── advanced_basics_wbtest.mbt       # 白盒测试：直接调用包内函数（含私有 _array_length）
├── moon.mod                          # 模块元数据
├── moon.pkg                          # 根包配置（库包）
└── cmd/main                          # 演示程序（可执行包）
    ├── main.mbt                          # 入口：按顺序调用各演示函数
    ├── byte.mbt                          # Byte/Bytes 字面量与操作
    ├── ref.mbt                           # Ref[T] 可变引用
    ├── json.mbt                          # Json 字面量与模式匹配
    ├── array_view.mbt                    # ArrayView/MutArrayView 切片
    ├── comprehension.mbt                 # 列表推导式
    ├── labelled_loop.mbt                 # 带标记 Continue/Break
    ├── defer.mbt                         # defer/errdefer 表达式
    ├── partial_app.mbt                   # 部分应用
    ├── pipeline.mbt                      # 管道 |>
    ├── is_expr.mbt                       # is 表达式
    ├── spread.mbt                        # 展开运算符 ...
    ├── overloaded_literal.mbt            # 重载字面量
    └── moon.pkg                          # 包配置（executable，import "walkzzz/advanced_basics"）
```

## 公开 API

| 函数 | 签名 | 说明 |
|------|------|------|
| `byte_reverse` | `(Bytes) -> Bytes` | 反转字节序列 |
| `bytes_concat` | `(Bytes, Bytes) -> Bytes` | 拼接两个字节序列 |
| `ref_counter` | `(Int) -> Int` | 使用 Ref 累加 0..n-1 |
| `json_lookup` | `(Json, String) -> Int?` | 从 Json 对象查找整数值 |
| `slice_sum` | `(Array[Int], Int, Int) -> Int` | 切片视图求和 |
| `even_squares` | `(Int) -> Array[Int]` | 偶数平方推导式 |
| `pipeline_even_square_sum` | `(Array[Int]) -> Int` | 管道风格偶数平方和 |
| `is_some` | `(Int?) -> Bool` | is 表达式检查 Option |

## 测试约定

- **黑盒测试**（`advanced_basics_test.mbt`）：通过 `@advanced_basics.函数名` 访问公开 API
- **白盒测试**（`advanced_basics_wbtest.mbt`）：直接调用包内函数（含私有 `_array_length`）
- **文档测试**（` ```mbt check `）：每个 `pub fn` 附带内嵌文档测试

## 常用命令

```bash
moon -C advanced_basics check          # 类型检查
moon -C advanced_basics test           # 运行全部测试
moon -C advanced_basics run cmd/main   # 运行演示程序
moon -C advanced_basics info           # 生成 .mbti 接口文件
moon -C advanced_basics fmt            # 格式化
```

## 编码约定

- `///|` 分隔顶层代码块
- `///` 为 `pub` 项编写文档注释，附带 ` ```mbt check ` 文档测试
- `//` 为行内注释
- 私有函数以 `_` 前缀标记（如 `_array_length`）
